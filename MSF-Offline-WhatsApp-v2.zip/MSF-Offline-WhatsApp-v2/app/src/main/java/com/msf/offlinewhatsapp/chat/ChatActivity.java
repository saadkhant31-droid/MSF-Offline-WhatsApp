package com.msf.offlinewhatsapp.chat;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.msf.offlinewhatsapp.R;
import com.msf.offlinewhatsapp.network.LocalNetwork;
import com.msf.offlinewhatsapp.network.LocalStore;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatActivity extends Activity {
    private static final int PICK = 7;
    private LinearLayout box;
    private EditText input;
    private TextView connection;
    private int shown = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() { updateHeader(); handler.postDelayed(this, 1000); }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_chat);
        box = findViewById(R.id.messagesContainer);
        input = findViewById(R.id.messageInput);
        connection = findViewById(R.id.chatConnection);
        LocalNetwork.init(this);
        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        findViewById(R.id.sendButton).setOnClickListener(v -> send());
        findViewById(R.id.attachButton).setOnClickListener(v -> pick());
        findViewById(R.id.callButton).setOnClickListener(v -> Toast.makeText(this, "Voice calls are not available yet.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.videoButton).setOnClickListener(v -> Toast.makeText(this, "Video calls are not available yet.", Toast.LENGTH_SHORT).show());
    }

    @Override protected void onResume() {
        super.onResume();
        LocalStore.setListener(this::refresh);
        refresh();
        handler.post(ticker);
    }

    @Override protected void onPause() {
        super.onPause();
        LocalStore.setListener(null);
        handler.removeCallbacks(ticker);
    }

    private void updateHeader() {
        if (LocalNetwork.isReady(this)) connection.setText("✓ Connected • " + LocalNetwork.peerAddress());
        else connection.setText("Waiting for MSF device…");
    }

    private void send() {
        String s = input.getText().toString().trim();
        if (s.isEmpty()) return;
        if (!LocalNetwork.sendText(s)) {
            Toast.makeText(this, "No device connected — message not sent.", Toast.LENGTH_SHORT).show();
            return;
        }
        LocalStore.addOutgoing(s);
        input.setText("");
        refresh();
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK);
    }

    @Override protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r == PICK && c == RESULT_OK && d != null && d.getData() != null) {
            try {
                File f = copyToCache(d.getData());
                if (LocalNetwork.sendFile(f)) {
                    LocalStore.addOutgoing("\uD83D\uDCCE " + f.getName());
                    refresh();
                } else {
                    Toast.makeText(this, "No device connected — file not sent.", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Could not read file", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private File copyToCache(Uri u) throws Exception {
        String name = "file";
        Cursor c = getContentResolver().query(u, null, null, null, null);
        if (c != null) {
            int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (c.moveToFirst() && ix >= 0) name = c.getString(ix);
            c.close();
        }
        name = name.replaceAll("[\\\\/]", "_");
        File f = new File(getCacheDir(), name);
        InputStream in = getContentResolver().openInputStream(u);
        FileOutputStream out = new FileOutputStream(f);
        try {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        } finally {
            in.close();
            out.close();
        }
        return f;
    }

    private void refresh() {
        List<LocalStore.Msg> all = LocalStore.all();
        for (int i = shown; i < all.size(); i++) addBubble(all.get(i));
        shown = all.size();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private void addBubble(LocalStore.Msg m) {
        TextView t = new TextView(this);
        t.setText(m.text + "\n" + new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(m.time)));
        t.setTextSize(16);
        t.setTextColor(0xff16202a);
        t.setPadding(dp(12), dp(8), dp(12), dp(6));
        t.setBackgroundResource(m.outgoing ? R.drawable.bg_outgoing : R.drawable.bg_incoming);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.gravity = m.outgoing ? Gravity.END : Gravity.START;
        p.setMargins(0, 0, 0, dp(8));
        box.addView(t, p);
        final ScrollView sv = findViewById(R.id.messagesScroll);
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
    }
}
