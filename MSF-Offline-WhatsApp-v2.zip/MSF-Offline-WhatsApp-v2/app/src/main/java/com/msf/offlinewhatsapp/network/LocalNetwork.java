package com.msf.offlinewhatsapp.network;

import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Local Wi-Fi / Hotspot networking.
 * Discovery: UDP broadcast "hello" on port 45455 (works for both the hotspot host and the client).
 * Transport: TCP on port 45454.
 */
public final class LocalNetwork {
    public static final int PORT = 45454;
    public static final int DISCOVERY_PORT = 45455;
    private static final long PEER_TIMEOUT_MS = 12000;
    private static final String HELLO = "MSF_HELLO";
    private static final String ACK = "MSF_ACK";
    private static final String MY_ID = UUID.randomUUID().toString();

    private static Context appContext;
    private static boolean started = false;
    private static ServerSocket server;
    private static DatagramSocket udp;
    private static WifiManager.MulticastLock multicastLock;
    private static final ExecutorService pool = Executors.newCachedThreadPool();
    private static volatile InetAddress peer;
    private static volatile long peerSeen = 0;

    private LocalNetwork() {}

    public static synchronized void init(Context c) {
        if (started) return;
        appContext = c.getApplicationContext();
        started = true;
        acquireMulticastLock();
        startTcpServer();
        startUdpListener();
        startBeacon();
    }

    private static void acquireMulticastLock() {
        try {
            WifiManager wm = (WifiManager) appContext.getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                multicastLock = wm.createMulticastLock("msf-offline");
                multicastLock.setReferenceCounted(false);
                multicastLock.acquire();
            }
        } catch (Exception ignored) {}
    }

    // ---------- TCP server (receives messages and files) ----------
    private static void startTcpServer() {
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    server = new ServerSocket();
                    server.setReuseAddress(true);
                    server.bind(new InetSocketAddress(PORT));
                    while (!server.isClosed()) {
                        final Socket s = server.accept();
                        pool.execute(new Runnable() { @Override public void run() { handle(s); } });
                    }
                } catch (Exception ignored) {}
            }
        });
    }

    private static void handle(Socket s) {
        try {
            s.setSoTimeout(15000);
            InetAddress from = s.getInetAddress();
            DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
            String type = in.readUTF();
            if ("TEXT".equals(type)) {
                int len = in.readInt();
                if (len < 0 || len > 1000000) return;
                byte[] data = new byte[len];
                in.readFully(data);
                LocalStore.addIncoming(new String(data, StandardCharsets.UTF_8));
                markPeer(from);
                LocalStore.notifyChange();
            } else if ("FILE".equals(type)) {
                String name = in.readUTF();
                long len = in.readLong();
                File base = appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (base == null) base = appContext.getCacheDir();
                File dir = new File(base, "MSF Offline WhatsApp");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, System.currentTimeMillis() + "_" + name.replaceAll("[^a-zA-Z0-9._-]", "_"));
                FileOutputStream out = new FileOutputStream(f);
                try {
                    byte[] b = new byte[8192];
                    long left = len;
                    int n;
                    while (left > 0 && (n = in.read(b, 0, (int) Math.min(b.length, left))) != -1) {
                        out.write(b, 0, n);
                        left -= n;
                    }
                } finally {
                    out.close();
                }
                LocalStore.addIncoming("\uD83D\uDCCE Received: " + f.getName());
                markPeer(from);
                LocalStore.notifyChange();
            }
        } catch (Exception ignored) {
        } finally {
            try { s.close(); } catch (Exception ignored) {}
        }
    }

    // ---------- UDP discovery ----------
    private static void startUdpListener() {
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    udp = new DatagramSocket(null);
                    udp.setReuseAddress(true);
                    udp.setBroadcast(true);
                    udp.bind(new InetSocketAddress(DISCOVERY_PORT));
                    byte[] buf = new byte[256];
                    while (!udp.isClosed()) {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        udp.receive(p);
                        String msg = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                        String[] parts = msg.split("\\|");
                        if (parts.length < 2 || parts[1].equals(MY_ID)) continue;
                        if (!HELLO.equals(parts[0]) && !ACK.equals(parts[0])) continue;
                        markPeer(p.getAddress());
                        if (HELLO.equals(parts[0])) sendUdp(ACK, p.getAddress());
                    }
                } catch (Exception ignored) {}
            }
        });
    }

    private static void startBeacon() {
        pool.execute(new Runnable() {
            @Override public void run() {
                while (true) {
                    try {
                        if (hasLocalNetwork()) sendBeacon();
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        return;
                    } catch (Exception ignored) {}
                }
            }
        });
    }

    private static void sendBeacon() throws Exception {
        Set<InetAddress> targets = new HashSet<InetAddress>();
        targets.add(InetAddress.getByName("255.255.255.255"));
        Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
        if (en != null) {
            while (en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!isLocalIface(ni)) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null) targets.add(b);
                }
            }
        }
        InetAddress gw = gateway();
        if (gw != null) targets.add(gw);
        for (InetAddress t : targets) sendUdp(HELLO, t);
    }

    private static void sendUdp(String type, InetAddress to) {
        try {
            DatagramSocket s = udp;
            if (s == null || s.isClosed()) return;
            byte[] d = (type + "|" + MY_ID).getBytes(StandardCharsets.UTF_8);
            s.send(new DatagramPacket(d, d.length, to, DISCOVERY_PORT));
        } catch (Exception ignored) {}
    }

    @SuppressWarnings("deprecation")
    private static InetAddress gateway() {
        try {
            WifiManager wm = (WifiManager) appContext.getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return null;
            DhcpInfo d = wm.getDhcpInfo();
            if (d == null || d.gateway == 0) return null;
            int g = d.gateway;
            byte[] ip = new byte[] { (byte) (g & 0xff), (byte) ((g >> 8) & 0xff), (byte) ((g >> 16) & 0xff), (byte) ((g >> 24) & 0xff) };
            return InetAddress.getByAddress(ip);
        } catch (Exception e) {
            return null;
        }
    }

    private static void markPeer(InetAddress a) {
        if (a == null) return;
        peer = a;
        peerSeen = System.currentTimeMillis();
    }

    // ---------- Local network state ----------
    private static boolean isLocalIface(NetworkInterface ni) {
        try {
            if (!ni.isUp() || ni.isLoopback()) return false;
        } catch (SocketException e) {
            return false;
        }
        String n = ni.getName().toLowerCase(Locale.ROOT);
        if (!(n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("softap") || n.startsWith("eth"))) return false;
        for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
            InetAddress a = ia.getAddress();
            if (a instanceof Inet4Address && a.isSiteLocalAddress()) return true;
        }
        return false;
    }

    /** True if this phone is on a Wi-Fi network OR is running a Mobile Hotspot. */
    public static boolean hasLocalNetwork() {
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            if (en == null) return false;
            while (en.hasMoreElements()) {
                if (isLocalIface(en.nextElement())) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    public static String localAddress() {
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            if (en == null) return "";
            while (en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!isLocalIface(ni)) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress a = ia.getAddress();
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        return "";
    }

    public static boolean isConnected(Context c) { return hasLocalNetwork(); }

    public static boolean hasPeer() {
        return peer != null && (System.currentTimeMillis() - peerSeen) < PEER_TIMEOUT_MS;
    }

    public static boolean isReady(Context c) { return hasLocalNetwork() && hasPeer(); }

    public static String peerAddress() {
        InetAddress p = peer;
        return p == null ? "" : p.getHostAddress();
    }

    // ---------- Sending ----------
    private static void toast(final String m) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override public void run() { Toast.makeText(appContext, m, Toast.LENGTH_SHORT).show(); }
        });
    }

    public static boolean sendText(final String text) {
        final InetAddress p = hasPeer() ? peer : null;
        if (p == null) return false;
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    Socket s = new Socket();
                    try {
                        s.connect(new InetSocketAddress(p, PORT), 4000);
                        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
                        byte[] data = text.getBytes(StandardCharsets.UTF_8);
                        out.writeUTF("TEXT");
                        out.writeInt(data.length);
                        out.write(data);
                        out.flush();
                    } finally {
                        s.close();
                    }
                } catch (Exception e) {
                    toast("Message could not be delivered");
                }
            }
        });
        return true;
    }

    public static boolean sendFile(final File file) {
        final InetAddress p = hasPeer() ? peer : null;
        if (p == null) return false;
        pool.execute(new Runnable() {
            @Override public void run() {
                try {
                    Socket s = new Socket();
                    FileInputStream in = new FileInputStream(file);
                    try {
                        s.connect(new InetSocketAddress(p, PORT), 4000);
                        DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
                        out.writeUTF("FILE");
                        out.writeUTF(file.getName());
                        out.writeLong(file.length());
                        byte[] b = new byte[8192];
                        int n;
                        while ((n = in.read(b)) != -1) out.write(b, 0, n);
                        out.flush();
                    } finally {
                        in.close();
                        s.close();
                    }
                } catch (Exception e) {
                    toast("File could not be sent");
                }
            }
        });
        return true;
    }
}
