package com.msf.offlinewhatsapp.network;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.msf.offlinewhatsapp.R;
import com.msf.offlinewhatsapp.chat.ChatActivity;

public class DeviceActivity extends Activity {
    private TextView status, connectionBadge, details;
    private Button hostButton, joinButton, chatButton;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable watcher = new Runnable() {
        @Override public void run() { refreshConnection(); handler.postDelayed(this, 1000); }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_devices);
        status = findViewById(R.id.deviceStatus);
        connectionBadge = findViewById(R.id.connectionBadge);
        details = findViewById(R.id.connectionDetails);
        hostButton = findViewById(R.id.hostButton);
        joinButton = findViewById(R.id.joinButton);
        chatButton = findViewById(R.id.chatButton);
        LocalNetwork.init(this);
        hostButton.setOnClickListener(v -> {
            Toast.makeText(this, "Turn ON Mobile Hotspot, then come back to this app.", Toast.LENGTH_LONG).show();
            open(Settings.ACTION_WIRELESS_SETTINGS);
        });
        joinButton.setOnClickListener(v -> {
            Toast.makeText(this, "Connect to the host's Hotspot, then come back to this app.", Toast.LENGTH_LONG).show();
            open(Settings.ACTION_WIFI_SETTINGS);
        });
        chatButton.setOnClickListener(v -> {
            if (LocalNetwork.isReady(this)) startActivity(new Intent(this, ChatActivity.class));
            else Toast.makeText(this, "Complete the Wi-Fi/Hotspot connection first.", Toast.LENGTH_SHORT).show();
        });
        refreshConnection();
    }

    private void open(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} }
    }

    private void refreshConnection() {
        boolean wifi = LocalNetwork.isConnected(this);
        boolean ready = LocalNetwork.isReady(this);
        if (ready) {
            connectionBadge.setText("✓  CONNECTED");
            connectionBadge.setTextColor(Color.WHITE);
            connectionBadge.setBackgroundColor(0xFF16A765);
            status.setText("Connection successful — MSF Offline WhatsApp is ready.");
            details.setText("This phone: " + LocalNetwork.localAddress() + "\nOther phone: " + LocalNetwork.peerAddress() + "\nInternet is not required.");
            chatButton.setEnabled(true); chatButton.setAlpha(1f);
        } else if (wifi) {
            connectionBadge.setText("◌  WI-FI CONNECTED / WAITING");
            connectionBadge.setTextColor(Color.WHITE);
            connectionBadge.setBackgroundColor(0xFFF39C12);
            status.setText("Wi-Fi/Hotspot is on, but no MSF device has been found yet.");
            details.setText("This phone: " + LocalNetwork.localAddress() + "\nKeep both phones on the same Hotspot and keep this app open on both.");
            chatButton.setEnabled(false); chatButton.setAlpha(.5f);
        } else {
            connectionBadge.setText("✕  NOT CONNECTED");
            connectionBadge.setTextColor(Color.WHITE);
            connectionBadge.setBackgroundColor(0xFFD93025);
            status.setText("No local Wi-Fi connection — chat is unavailable.");
            details.setText("Host phone: turn ON Mobile Hotspot.\nOther phone: turn ON Wi-Fi and connect to that Hotspot.");
            chatButton.setEnabled(false); chatButton.setAlpha(.5f);
        }
    }

    @Override protected void onResume() { super.onResume(); handler.post(watcher); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(watcher); }
}
