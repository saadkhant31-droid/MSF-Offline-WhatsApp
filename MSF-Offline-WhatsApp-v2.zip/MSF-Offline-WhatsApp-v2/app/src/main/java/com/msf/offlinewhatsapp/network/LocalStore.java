package com.msf.offlinewhatsapp.network;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class LocalStore {
    public static final class Msg {
        public final String text;
        public final boolean outgoing;
        public final long time;
        Msg(String text, boolean outgoing) {
            this.text = text;
            this.outgoing = outgoing;
            this.time = System.currentTimeMillis();
        }
    }

    private static final List<Msg> messages = Collections.synchronizedList(new ArrayList<Msg>());
    private static volatile Runnable listener;

    private LocalStore() {}

    public static void addIncoming(String s) { messages.add(new Msg(s, false)); }
    public static void addOutgoing(String s) { messages.add(new Msg(s, true)); }

    public static List<Msg> all() {
        synchronized (messages) { return new ArrayList<Msg>(messages); }
    }

    public static Msg last() {
        synchronized (messages) { return messages.isEmpty() ? null : messages.get(messages.size() - 1); }
    }

    public static void setListener(Runnable r) { listener = r; }

    public static void notifyChange() {
        final Runnable r = listener;
        if (r != null) new Handler(Looper.getMainLooper()).post(r);
    }
}
