package com.msf.offlinewhatsapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.TextView;
import android.widget.Toast;
import com.msf.offlinewhatsapp.chat.ChatActivity;
import com.msf.offlinewhatsapp.network.DeviceActivity;
import com.msf.offlinewhatsapp.network.LocalNetwork;
import com.msf.offlinewhatsapp.network.LocalStore;
import com.msf.offlinewhatsapp.settings.SettingsActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView networkStatus, chatName, chatPreview, chatTime, chatAvatar;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override public void run() { updateStatus(); handler.postDelayed(this, 1000); }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        networkStatus = findViewById(R.id.networkStatus);
        chatName = findViewById(R.id.name);
        chatPreview = findViewById(R.id.preview);
        chatTime = findViewById(R.id.time);
        chatAvatar = findViewById(R.id.avatar);
        LocalNetwork.init(this);

        findViewById(R.id.hostButton).setOnClickListener(v -> openSettings(true));
        findViewById(R.id.joinButton).setOnClickListener(v -> openSettings(false));
        findViewById(R.id.settingsButton).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.scanButton).setOnClickListener(v -> {
            LocalNetwork.init(this);
            Toast.makeText(this, "Searching local Wi-Fi for MSF devices…", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.devicesButton).setOnClickListener(v -> startActivity(new Intent(this, DeviceActivity.class)));
        findViewById(R.id.groupsButton).setOnClickListener(v -> Toast.makeText(this, "Groups are not available yet.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.chatRow).setOnClickListener(v -> openChat());
    }

    private void openChat() {
        if (!LocalNetwork.isReady(this)) {
            Toast.makeText(this, "Connect both phones to the same Hotspot/Wi-Fi first.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, DeviceActivity.class));
            return;
        }
        startActivity(new Intent(this, ChatActivity.class));
    }

    private void openSettings(boolean host) {
        Toast.makeText(this, host ? "Turn ON Mobile Hotspot, then come back to this app." : "Connect to the host's Hotspot, then come back to this app.", Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(host ? Settings.ACTION_WIRELESS_SETTINGS : Settings.ACTION_WIFI_SETTINGS));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {}
        }
    }

    private void updateStatus() {
        boolean ready = LocalNetwork.isReady(this);
        if (ready) {
            networkStatus.setText("✓ Connected • Local Wi-Fi • Internet not required");
            networkStatus.setTextColor(0xFFC8FFD8);
            chatName.setText("MSF device (" + LocalNetwork.peerAddress() + ")");
        } else if (LocalNetwork.isConnected(this)) {
            networkStatus.setText("Wi-Fi connected • Waiting for MSF device…");
            networkStatus.setTextColor(0xFFFFE6A6);
            chatName.setText("Waiting for MSF device…");
        } else {
            networkStatus.setText("✕ Not connected • Chat unavailable");
            networkStatus.setTextColor(0xFFFFC7C7);
            chatName.setText("No device connected");
        }
        chatAvatar.setText("M");
        LocalStore.Msg last = LocalStore.last();
        if (last == null) {
            chatPreview.setText(ready ? "Tap to start chatting" : "Connect to start chatting");
            chatTime.setText("");
        } else {
            chatPreview.setText(last.text);
            chatTime.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(last.time)));
        }
    }

    @Override protected void onResume() { super.onResume(); handler.post(ticker); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(ticker); }
}
