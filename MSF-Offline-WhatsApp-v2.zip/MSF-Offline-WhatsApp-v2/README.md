# MSF Offline WhatsApp (v2)

Android (Java + XML) local chat over a Wi-Fi network or a phone's Mobile Hotspot. No internet, Firebase, phone number or OTP.

## How to use
1. Phone A: turn ON Mobile Hotspot.
2. Phone B: turn ON Wi-Fi and join Phone A's hotspot.
3. Open the app on BOTH phones (keep it open for a few seconds).
4. When the status turns green ("Connected"), tap the chat row to message and send files.

## How it works
- Discovery: UDP broadcast on port 45455 (works on the hotspot host and the client).
- Messages/files: TCP on port 45454.
- Received files are saved in `Android/data/com.msf.offlinewhatsapp/files/Download/MSF Offline WhatsApp/`.

## Not included yet
- Voice/video calls, groups, message history after the app is closed.
- Range is normal Wi-Fi/hotspot range only.

## Build
Open in Android Studio, or use the included GitHub Actions workflow (Gradle 8.9, JDK 17, SDK 35).
