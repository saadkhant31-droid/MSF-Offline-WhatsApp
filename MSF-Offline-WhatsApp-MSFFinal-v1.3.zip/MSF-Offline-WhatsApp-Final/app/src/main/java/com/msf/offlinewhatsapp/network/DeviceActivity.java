package com.msf.offlinewhatsapp.network;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.content.Intent;
import android.view.View;
import android.widget.*;
import com.msf.offlinewhatsapp.R;
import com.msf.offlinewhatsapp.chat.ChatActivity;

public class DeviceActivity extends Activity {
    private TextView status, connectionBadge, details;
    private Button hostButton, joinButton, chatButton;
    private final Handler handler = new Handler();
    private final Runnable watcher = new Runnable(){ @Override public void run(){ refreshConnection(); handler.postDelayed(this,1000); } };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_devices);
        status=findViewById(R.id.deviceStatus);
        connectionBadge=findViewById(R.id.connectionBadge);
        details=findViewById(R.id.connectionDetails);
        hostButton=findViewById(R.id.hostButton);
        joinButton=findViewById(R.id.joinButton);
        chatButton=findViewById(R.id.chatButton);
        LocalNetwork.init(this);
        hostButton.setOnClickListener(v->{
            LocalNetwork.register(this);
            LocalNetwork.startDiscovery(this);
            Toast.makeText(this,"Hotspot ON کریں، پھر دوسرے فون کو اس Wi-Fi سے connect کریں.",Toast.LENGTH_LONG).show();
            refreshConnection();
        });
        joinButton.setOnClickListener(v->{
            LocalNetwork.startDiscovery(this);
            Toast.makeText(this,"اب Android Wi-Fi settings میں Host کے Hotspot سے connect کریں، پھر یہاں واپس آئیں.",Toast.LENGTH_LONG).show();
            startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS));
        });
        chatButton.setOnClickListener(v->{ if(LocalNetwork.isReady(this)) startActivity(new Intent(this, ChatActivity.class)); else Toast.makeText(this,"پہلے Wi-Fi/Hotspot connection مکمل کریں.",Toast.LENGTH_SHORT).show(); });
        refreshConnection();
    }
    private void refreshConnection(){
        boolean wifi=LocalNetwork.isConnected(this);
        boolean ready=LocalNetwork.isReady(this);
        if(ready){
            connectionBadge.setText("✓  CONNECTED");
            connectionBadge.setTextColor(Color.WHITE);
            connectionBadge.setBackgroundColor(0xFF16A765);
            status.setText("Connection successful — MSF Offline WhatsApp is ready.");
            details.setText("Local Wi-Fi peer: "+LocalNetwork.peerAddress()+"\nInternet is not required. Messages and media use this local connection.");
            chatButton.setEnabled(true); chatButton.setAlpha(1f);
        } else if(wifi){
            connectionBadge.setText("◌  WI-FI CONNECTED / WAITING");
            connectionBadge.setTextColor(Color.WHITE);
            connectionBadge.setBackgroundColor(0xFFF39C12);
            status.setText("Wi-Fi is connected, but no MSF device has been discovered yet.");
            details.setText("Keep both phones on the same Host Hotspot and keep MSF Offline WhatsApp open.");
            chatButton.setEnabled(false); chatButton.setAlpha(.5f);
            LocalNetwork.startDiscovery(this);
        } else {
            connectionBadge.setText("✕  NOT CONNECTED");
            connectionBadge.setTextColor(Color.WHITE);
            connectionBadge.setBackgroundColor(0xFFD93025);
            status.setText("No local Wi-Fi connection — MSF Offline WhatsApp chat is unavailable.");
            details.setText("Host phone: turn ON Mobile Hotspot.\nOther phone: turn ON Wi-Fi and connect to that Hotspot.");
            chatButton.setEnabled(false); chatButton.setAlpha(.5f);
        }
    }
    @Override protected void onResume(){ super.onResume(); handler.post(watcher); refreshConnection(); }
    @Override protected void onPause(){ super.onPause(); handler.removeCallbacks(watcher); }
}
