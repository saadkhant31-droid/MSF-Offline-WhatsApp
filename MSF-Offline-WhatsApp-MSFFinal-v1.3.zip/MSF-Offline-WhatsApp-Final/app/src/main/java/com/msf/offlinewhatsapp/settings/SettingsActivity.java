package com.msf.offlinewhatsapp.settings;
import android.app.Activity;import android.os.Bundle;import com.msf.offlinewhatsapp.R;
public class SettingsActivity extends Activity { @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings);} }
