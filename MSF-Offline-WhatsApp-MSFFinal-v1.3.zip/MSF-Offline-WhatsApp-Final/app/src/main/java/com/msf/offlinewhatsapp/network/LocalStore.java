package com.msf.offlinewhatsapp.network;
import java.util.*;
public final class LocalStore { private static final List<String> messages=Collections.synchronizedList(new ArrayList<>()); private static Runnable listener; public static void addIncoming(String s){messages.add(s);} public static void addOutgoing(String s){messages.add("ME: "+s);} public static List<String> all(){return new ArrayList<>(messages);} public static void setListener(Runnable r){listener=r;} public static void notifyChange(){if(listener!=null)new android.os.Handler(android.os.Looper.getMainLooper()).post(listener);} }
