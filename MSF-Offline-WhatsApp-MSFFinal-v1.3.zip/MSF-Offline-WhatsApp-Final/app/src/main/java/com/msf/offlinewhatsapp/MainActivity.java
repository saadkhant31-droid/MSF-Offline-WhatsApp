package com.msf.offlinewhatsapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import com.msf.offlinewhatsapp.chat.ChatActivity;
import com.msf.offlinewhatsapp.settings.SettingsActivity;
import com.msf.offlinewhatsapp.network.LocalNetwork;

public class MainActivity extends Activity {
    private TextView networkStatus;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        networkStatus = findViewById(R.id.networkStatus);
        LocalNetwork.init(this);
        updateStatus();
        findViewById(R.id.hostButton).setOnClickListener(v -> openWifi(true));
        findViewById(R.id.joinButton).setOnClickListener(v -> openWifi(false));
        findViewById(R.id.settingsButton).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.scanButton).setOnClickListener(v -> { LocalNetwork.startDiscovery(this); Toast.makeText(this,"Searching local Wi-Fi devices…",Toast.LENGTH_SHORT).show(); });
        findViewById(R.id.devicesButton).setOnClickListener(v -> startActivity(new Intent(this, com.msf.offlinewhatsapp.network.DeviceActivity.class)));
        findViewById(R.id.groupsButton).setOnClickListener(v -> Toast.makeText(this,"Local groups are available after devices connect.",Toast.LENGTH_SHORT).show());
        findViewById(R.id.chatList).setOnClickListener(v -> openChat());
        ((ListView)findViewById(R.id.chatList)).setOnItemClickListener((p,v,pos,id) -> openChat());
        String[] names={"Muhammad Ali","Ayesha Khan","MSF Friends"};
        String[] previews={"Assalamualaikum! Kaise ho?","📷 Photo","👥 Group message"};
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,R.layout.item_chat,R.id.name,names){
            @Override public android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent){
                android.view.View row=super.getView(position,convertView,parent);
                ((TextView)row.findViewById(R.id.avatar)).setText(names[position].substring(0,1));
                ((TextView)row.findViewById(R.id.preview)).setText(previews[position]);
                ((TextView)row.findViewById(R.id.time)).setText(position==0?"10:25 AM":position==1?"09:42 AM":"Yesterday");
                return row;
            }
        };
        ((ListView)findViewById(R.id.chatList)).setAdapter(adapter);
    }
    private void openChat(){ if(!LocalNetwork.isReady(this)){ Toast.makeText(this,"MSF Offline WhatsApp کام کرنے کے لیے Host Hotspot سے Wi-Fi connect کریں اور peer discovered ہونے دیں.",Toast.LENGTH_LONG).show(); startActivity(new Intent(this, com.msf.offlinewhatsapp.network.DeviceActivity.class)); return; } startActivity(new Intent(this, ChatActivity.class)); }
    private void openWifi(boolean host){
        Toast.makeText(this, host?"Turn ON Mobile Hotspot, then return to MSF Offline WhatsApp.":"Connect to the host Hotspot using Wi-Fi, then return to the app.",Toast.LENGTH_LONG).show();
        try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); } catch(Exception e){ startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }
    private void updateStatus(){ if(LocalNetwork.isReady(this)){ networkStatus.setText("✓ Connected • Local Wi-Fi • Internet not required"); networkStatus.setTextColor(0xFFC8FFD8); } else if(LocalNetwork.isConnected(this)){ networkStatus.setText("Wi-Fi connected • Waiting for MSF device…"); networkStatus.setTextColor(0xFFFFE6A6); } else { networkStatus.setText("✕ Not connected • Chat unavailable"); networkStatus.setTextColor(0xFFFFC7C7); } }
    @Override protected void onResume(){super.onResume(); if(networkStatus!=null) updateStatus();}
}
