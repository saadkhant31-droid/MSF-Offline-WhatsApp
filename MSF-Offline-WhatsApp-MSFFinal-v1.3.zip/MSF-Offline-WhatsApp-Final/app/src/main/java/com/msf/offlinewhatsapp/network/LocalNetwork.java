package com.msf.offlinewhatsapp.network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Environment;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public final class LocalNetwork {
    public static final int PORT=45454;
    private static Context appContext; private static NsdManager nsd; private static NsdManager.RegistrationListener reg; private static NsdManager.DiscoveryListener disc;
    private static ServerSocket server; private static ExecutorService pool=Executors.newCachedThreadPool();
    private static volatile InetAddress peer;
    private LocalNetwork(){}
    public static void init(Context c){ appContext=c.getApplicationContext(); if(nsd==null) nsd=(NsdManager)c.getApplicationContext().getSystemService(Context.NSD_SERVICE); startServer(); }
    private static void startServer(){ if(server!=null&&!server.isClosed()) return; pool.execute(()->{try{server=new ServerSocket(PORT); while(!server.isClosed()){Socket s=server.accept(); pool.execute(()->handle(s));}}catch(IOException ignored){}}); }
    private static void handle(Socket s){try(DataInputStream in=new DataInputStream(new BufferedInputStream(s.getInputStream()))){String type=in.readUTF(); if("TEXT".equals(type)){String text=in.readUTF(); LocalStore.addIncoming(text); LocalStore.notifyChange();} else if("FILE".equals(type)){String name=in.readUTF(); long len=in.readLong(); File dir=new File(appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"MSF Offline WhatsApp"); if(!dir.exists()) dir.mkdirs(); File f=new File(dir,System.currentTimeMillis()+"_"+name.replaceAll("[^a-zA-Z0-9._-]","_")); try(FileOutputStream out=new FileOutputStream(f)){byte[] b=new byte[8192]; long left=len; int n; while(left>0&&(n=in.read(b,0,(int)Math.min(b.length,left)))!=-1){out.write(b,0,n);left-=n;}} LocalStore.addIncoming("📎 Received: "+f.getName()); LocalStore.notifyChange();}}catch(Exception ignored){}finally{try{s.close();}catch(Exception ignored){}}}
    public static void startDiscovery(Context c){ if(nsd==null) init(c); try{ if(disc!=null) nsd.stopServiceDiscovery(disc);}catch(Exception ignored){} disc=new NsdManager.DiscoveryListener(){public void onDiscoveryStarted(String s){} public void onServiceFound(NsdServiceInfo i){ if("_msfchat._tcp.".equals(i.getServiceType())) nsd.resolveService(i,new NsdManager.ResolveListener(){public void onResolveFailed(NsdServiceInfo x,int e){} public void onServiceResolved(NsdServiceInfo x){peer=x.getHost();}});} public void onServiceLost(NsdServiceInfo i){} public void onDiscoveryStopped(String s){} public void onStartDiscoveryFailed(String s,int e){} public void onStopDiscoveryFailed(String s,int e){}}; nsd.discoverServices("_msfchat._tcp.",NsdManager.PROTOCOL_DNS_SD,disc); }
    public static void register(Context c){ if(nsd==null)init(c); if(reg!=null)return; NsdServiceInfo info=new NsdServiceInfo(); info.setServiceName("MSF Offline WhatsApp"); info.setServiceType("_msfchat._tcp."); info.setPort(PORT); reg=new NsdManager.RegistrationListener(){public void onServiceRegistered(NsdServiceInfo i){} public void onRegistrationFailed(NsdServiceInfo i,int e){} public void onServiceUnregistered(NsdServiceInfo i){} public void onUnregistrationFailed(NsdServiceInfo i,int e){}}; nsd.registerService(info,NsdManager.PROTOCOL_DNS_SD,reg); }
    public static boolean sendText(String text){if(peer==null)return false; pool.execute(()->{try(Socket s=new Socket(peer,PORT);DataOutputStream out=new DataOutputStream(new BufferedOutputStream(s.getOutputStream()))){out.writeUTF("TEXT");out.writeUTF(text);out.flush();}catch(Exception ignored){}});return true;}
    public static boolean sendFile(File file){if(peer==null)return false; pool.execute(()->{try(Socket s=new Socket(peer,PORT);DataOutputStream out=new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));FileInputStream in=new FileInputStream(file)){out.writeUTF("FILE");out.writeUTF(file.getName());out.writeLong(file.length());byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);out.flush();}catch(Exception ignored){}});return true;}
    public static boolean isConnected(Context c){ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE); Network n=cm.getActiveNetwork(); NetworkCapabilities cap=cm.getNetworkCapabilities(n);return cap!=null&&cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);}
    public static boolean hasPeer(){ return peer!=null; }
    public static boolean isReady(Context c){ return isConnected(c) && hasPeer(); }
    public static String peerAddress(){ return peer==null ? "" : peer.getHostAddress(); }
}
