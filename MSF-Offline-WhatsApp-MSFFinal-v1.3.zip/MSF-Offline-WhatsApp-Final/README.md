# MSF Offline WhatsApp

MSF Offline WhatsApp is an Android Java + XML local-chat project designed for **direct communication over a local Wi-Fi network**.

## Connection model

- Phone A: turn **Mobile Hotspot ON** manually.
- Phone B: turn **Wi-Fi ON** and connect to Phone A's hotspot.
- Open MSF Offline WhatsApp on both phones.
- On the host, open **Devices** and tap Host to advertise the chat service.
- On the client, open **Devices** and use Join/Scan to discover the host.
- The app uses Android NSD (Network Service Discovery) and a local TCP socket. Internet/Firebase/Gmail/phone-number login is not required.

## Included

- Home page
- Chat page inspired by the supplied UI references
- Local Wi-Fi host/join flow
- Nearby-device discovery using NSD
- Local text-message transport
- Local file transport (images/video/documents can be selected with the Android document picker)
- Settings screen
- Design-reference screenshots supplied by the user

## Important limitations

This project does **not** turn a normal phone hotspot into a 5–6 km radio link. Normal phone Wi-Fi range is limited by hardware, environment and regulatory limits. Long-range operation requires suitable external radio/network hardware.

Voice/video calling UI is included as a foundation, but real-time voice/video calling requires an additional media transport implementation and is not claimed as production-ready in this ZIP.

## Build

Open the root folder in Android Studio or AndroidIDE and let the IDE install/sync the required Android Gradle components. The project targets SDK 35 and uses Java/XML only.


## Connection rule
MSF Offline WhatsApp requires a local Wi-Fi connection to work. The host phone turns on Mobile Hotspot; the other phone turns on Wi-Fi and joins that Hotspot. The app shows **NOT CONNECTED**, **WI-FI CONNECTED / WAITING**, or **CONNECTED**. Chat and local media transfer are disabled until an MSF peer is discovered. Internet, Gmail, phone number, OTP, and Firebase are not required.

## Offline-only connection rule

MSF Offline WhatsApp is designed for a local Hotspot/Wi-Fi network:
1. Host phone turns on Mobile Hotspot.
2. Other phone turns on Wi-Fi and joins that Hotspot.
3. Both phones open MSF Offline WhatsApp.
4. The app discovers the other MSF device over the local network.
5. Only after a local peer is discovered does Chat become ready.

If Wi-Fi/Hotspot is not connected, the app shows **Not Connected / Chat Unavailable**.
If Wi-Fi is connected but the other MSF device has not been discovered, it shows **Wi-Fi Connected / Waiting for MSF Device**.
When the peer is discovered, it shows **✓ Connected • Local Wi-Fi • Internet not required**.

The app does not require Firebase, Gmail, a phone number, OTP, or a cloud database. The Android `INTERNET` permission is retained because Android local TCP sockets use the same networking API; the app's chat transport is intended for the local Wi-Fi network, not an Internet server.

## Profile image

The supplied MSF Offline WhatsApp logo/profile image is installed as:
`app/src/main/res/drawable-nodpi/msf_profile.png`
and is used in the Home and Chat headers.
