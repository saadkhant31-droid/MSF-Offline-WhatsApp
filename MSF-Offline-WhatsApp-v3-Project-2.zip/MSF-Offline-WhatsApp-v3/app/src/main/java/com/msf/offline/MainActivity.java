package com.msf.offline;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.*;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
  WebView w; ValueCallback<Uri[]> fcb;
  ServerSocket ss; Socket cs;
  final List<Socket> cl = new CopyOnWriteArrayList<>();
  final ExecutorService ex = Executors.newCachedThreadPool();
  final ExecutorService wr = Executors.newSingleThreadExecutor();

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
    w = new WebView(this);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false); s.setAllowFileAccess(true);
    w.addJavascriptInterface(new Br(), "Android");
    w.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
        if (fcb != null) fcb.onReceiveValue(null);
        fcb = cb;
        try { startActivityForResult(p.createIntent(), 7); } catch (Exception e) { fcb = null; return false; }
        return true;
      }
      @Override public void onPermissionRequest(final PermissionRequest r) { runOnUiThread(() -> r.grant(r.getResources())); }
    });
    setContentView(w);
    w.loadUrl("file:///android_asset/index.html");
  }

  @Override protected void onActivityResult(int req, int res, Intent d) {
    if (req == 7 && fcb != null) { fcb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d)); fcb = null; }
  }
  @Override public void onBackPressed() { w.evaluateJavascript("goBack()", v -> { if ("false".equals(v)) finish(); }); }

  void js(final String s) { runOnUiThread(() -> w.evaluateJavascript(s, null)); }
  void stat(String c) { js("onStat(" + JSONObject.quote(c) + ")"); }
  void write(final Socket c, final String l) {
    wr.execute(() -> { try { OutputStream o = c.getOutputStream(); o.write((l + "\n").getBytes("UTF-8")); o.flush(); } catch (Exception e) {} });
  }
  void readLoop(Socket s, boolean host) {
    try (BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"))) {
      String l;
      while ((l = r.readLine()) != null) {
        if (host) for (Socket c : cl) if (c != s) write(c, l);
        js("onNet(" + JSONObject.quote(l) + ")");
      }
    } catch (Exception e) {}
    cl.remove(s);
    try { s.close(); } catch (Exception e) {}
    if (!host) stat("closed");
  }

  class Br {
    @JavascriptInterface public void host(final int port) {
      ex.execute(() -> {
        try {
          if (ss != null) ss.close();
          ss = new ServerSocket(); ss.setReuseAddress(true); ss.bind(new InetSocketAddress(port));
          stat("host_on");
          while (true) { final Socket s = ss.accept(); cl.add(s); ex.execute(() -> readLoop(s, true)); }
        } catch (Exception e) { if (ss != null && !ss.isClosed()) stat("host_err"); }
      });
    }
    @JavascriptInterface public void join(final String ip, final int port) {
      ex.execute(() -> {
        try {
          bindWifi();
          cs = new Socket(); cs.connect(new InetSocketAddress(ip, port), 6000);
          stat("joined"); readLoop(cs, false);
        } catch (Exception e) { stat("join_err"); }
      });
    }
    @JavascriptInterface public void send(String l) {
      if (ss != null && !ss.isClosed()) { for (Socket c : cl) write(c, l); }
      else if (cs != null) write(cs, l);
    }
    @JavascriptInterface public void stop() {
      try { if (ss != null) ss.close(); } catch (Exception e) {}
      try { if (cs != null) cs.close(); } catch (Exception e) {}
      for (Socket c : cl) try { c.close(); } catch (Exception e) {}
      cl.clear(); ss = null; cs = null; stat("closed");
    }
    @JavascriptInterface public String ip() {
      try {
        String any = "";
        for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces()))
          for (InetAddress a : Collections.list(n.getInetAddresses()))
            if (a instanceof Inet4Address && !a.isLoopbackAddress() && a.isSiteLocalAddress()) {
              String nm = n.getName();
              if (nm.startsWith("ap") || nm.startsWith("wlan") || nm.startsWith("swlan")) return a.getHostAddress();
              any = a.getHostAddress();
            }
        return any;
      } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public String hs() {
      try {
        boolean noGw = gw0() == 0;
        for (NetworkInterface n : Collections.list(NetworkInterface.getNetworkInterfaces())) {
          String nm = n.getName();
          boolean ap = nm.startsWith("ap") || nm.startsWith("swlan") || nm.startsWith("softap") || nm.matches("wlan[1-9].*") || (nm.equals("wlan0") && noGw);
          if (!ap || !n.isUp()) continue;
          for (InetAddress a : Collections.list(n.getInetAddresses()))
            if (a instanceof Inet4Address && a.isSiteLocalAddress()) return a.getHostAddress();
        }
      } catch (Exception e) {}
      return "";
    }
    @JavascriptInterface public String gateway() {
      try {
        DhcpInfo d = ((WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE)).getDhcpInfo();
        int g = d.gateway;
        return g == 0 ? "" : (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff);
      } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public void hotspot() {
      try { Intent i = new Intent(); i.setClassName("com.android.settings", "com.android.settings.TetherSettings"); startActivity(i); }
      catch (Exception e) { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); }
    }
    @JavascriptInterface public void wifi() { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); }
    @JavascriptInterface public String saveFile(String name, String b64) {
      try {
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        File f = new File(dir, name.replaceAll("[/\\\\]", "_"));
        FileOutputStream o = new FileOutputStream(f); o.write(Base64.decode(b64, Base64.DEFAULT)); o.close();
        return f.getAbsolutePath();
      } catch (Exception e) { return ""; }
    }
  }

  int gw0() {
    try { return ((WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE)).getDhcpInfo().gateway; } catch (Exception e) { return 0; }
  }

  void bindWifi() {
    try {
      if (Build.VERSION.SDK_INT >= 23) {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        for (Network n : cm.getAllNetworks()) {
          NetworkCapabilities c = cm.getNetworkCapabilities(n);
          if (c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) { cm.bindProcessToNetwork(n); break; }
        }
      }
    } catch (Exception e) {}
  }
}
