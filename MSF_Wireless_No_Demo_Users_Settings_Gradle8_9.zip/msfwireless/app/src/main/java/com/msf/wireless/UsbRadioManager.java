package com.msf.wireless;
import android.content.*; import android.hardware.usb.*; import java.util.*; import java.nio.charset.StandardCharsets;

public class UsbRadioManager {
    public interface Listener { void onRadioUser(String name,int signal); void onRadioUserLeft(String name); }
    private final Context context; private UsbDeviceConnection connection; private UsbEndpoint out,in; private Listener listener; private Thread reader; private volatile boolean reading;
    public UsbRadioManager(Context c){context=c.getApplicationContext();}
    public void setListener(Listener l){listener=l;}
    public List<UsbDevice> devices(){return new ArrayList<>(((UsbManager)context.getSystemService(Context.USB_SERVICE)).getDeviceList().values());}
    public boolean openFirst(){UsbManager m=(UsbManager)context.getSystemService(Context.USB_SERVICE);for(UsbDevice d:devices()){if(!m.hasPermission(d))continue;for(int i=0;i<d.getInterfaceCount();i++){UsbInterface ui=d.getInterface(i);if(ui.getEndpointCount()==0)continue;UsbDeviceConnection c=m.openDevice(d);if(c!=null&&c.claimInterface(ui,true)){for(int e=0;e<ui.getEndpointCount();e++){UsbEndpoint ep=ui.getEndpoint(e);if(ep.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK){if(ep.getDirection()==UsbConstants.USB_DIR_OUT)out=ep;else in=ep;}}connection=c;if(in!=null)startReader();return true;}}}return false;}
    private void startReader(){if(reading)return;reading=true;reader=new Thread(()->{byte[] b=new byte[512];StringBuilder sb=new StringBuilder();while(reading&&connection!=null&&in!=null){int n=connection.bulkTransfer(in,b,b.length,500);if(n<=0)continue;sb.append(new String(b,0,n,StandardCharsets.UTF_8));int k;while((k=sb.indexOf("\n"))>=0){String line=sb.substring(0,k).trim();sb.delete(0,k+1);parse(line);}}},"MSF-Radio-Reader");reader.start();}
    private void parse(String s){try{String[] p=s.split("\\|",-1);if(p.length>=3&&!"MSFW".equals(p[0]))return;if(p.length>=4&&"USER".equals(p[1])){int sig=3;try{sig=Integer.parseInt(p[3]);}catch(Exception ignored){}if(listener!=null)listener.onRadioUser(p[2],sig);}else if(p.length>=3&&"LEAVE".equals(p[1])){if(listener!=null)listener.onRadioUserLeft(p[2]);}}catch(Exception ignored){}}
    public int send(byte[] data,int timeout){if(connection==null||out==null)return -1;return connection.bulkTransfer(out,data,data.length,timeout);}
    public void scan(){send("MSFW|SCAN\n".getBytes(StandardCharsets.UTF_8),200);}
    public void close(){reading=false;if(connection!=null){connection.close();connection=null;}}
}
