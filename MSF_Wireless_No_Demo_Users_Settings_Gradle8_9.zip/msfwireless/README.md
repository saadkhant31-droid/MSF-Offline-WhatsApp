# MSF Wireless

This version uses the supplied MSF Wireless Home Screen artwork and removes the pre-filled demo user names. Connected user names are drawn by the app at runtime.

## Connected users
The USB radio reader accepts peer announcements in this simple data format:
- `MSFW|USER|NAME|SIGNAL\n` -> add/update a connected user
- `MSFW|LEAVE|NAME\n` -> remove a user
- `MSFW|SCAN\n` -> scan request

The exact RF module still needs to implement/bridge this protocol. No fake Admin/Ahmed/Zain/Usman/Ali names are included.

## Settings
The Settings area is functional. It opens a separate settings screen where the user can save their own display name and channel. The saved channel is also used by the Home channel +/- controls.

## Audio/PTT
PTT uses Android AudioRecord for real microphone capture while held. Captured PCM is passed to the USB-OTG radio abstraction. External RF hardware, voice codec and radio protocol are required for actual over-the-air voice communication.

Java + XML, Gradle 8.9 / Android Gradle Plugin 8.7.3.
