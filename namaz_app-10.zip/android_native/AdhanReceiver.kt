package __PACKAGE__

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AdhanReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val name = intent.getStringExtra("name") ?: "نماز"
        val sound = intent.getStringExtra("sound") ?: "adhan1"
        try {
            if (sound == "silent") {
                AdhanNotifier.alert(ctx, name)
            } else {
                val i = Intent(ctx, AdhanService::class.java)
                i.putExtra("name", name)
                i.putExtra("sound", sound)
                i.putExtra("vibrate", intent.getBooleanExtra("vibrate", true))
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            }
        } catch (e: Exception) {
            try { AdhanNotifier.alert(ctx, name) } catch (e2: Exception) {}
        }
        // اگلے دنوں کے الارم آگے بڑھا دیتا ہے
        try { AdhanScheduler.schedule(ctx) } catch (e: Exception) {}
    }
}
