package __PACKAGE__

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject

/**
 * ہر نماز کے وقت کا الارم لگاتا ہے۔ اوقات flutter ایپ (wallpaper_sync.dart) کے محفوظ کردہ
 * ڈیٹا (اگلے 30 دن) سے پڑھتا ہے، اس لیے ایپ بند ہو یا موبائل ری اسٹارٹ ہو، اذان وقت پر آتی ہے۔
 */
object AdhanScheduler {
    private const val BASE = 5000
    const val TEST_CODE = 4999

    private fun load(ctx: Context): JSONObject? = try {
        val sp = ctx.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
        val s = sp.getString("flutter.wp_data", null)
        if (s == null) null else JSONObject(s)
    } catch (e: Exception) {
        null
    }

    private fun pi(ctx: Context, code: Int, name: String?, sound: String?, vib: Boolean, create: Boolean): PendingIntent? {
        val i = Intent(ctx, AdhanReceiver::class.java)
        if (name != null) {
            i.putExtra("name", name)
            i.putExtra("sound", sound)
            i.putExtra("vibrate", vib)
        }
        val base = if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE
        return PendingIntent.getBroadcast(ctx, code, i, base or PendingIntent.FLAG_IMMUTABLE)
    }

    /** ایک الارم لگاتا ہے۔ درست وقت کی اجازت ہو تو true */
    fun setAt(ctx: Context, am: AlarmManager, code: Int, whenMs: Long, name: String, sound: String, vib: Boolean): Boolean {
        val p = pi(ctx, code, name, sound, vib, true) ?: return false
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (exact) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, p)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, p)
        }
        return exact
    }

    fun schedule(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (code in BASE until BASE + 400) {
            val p = pi(ctx, code, null, null, false, false)
            if (p != null) {
                am.cancel(p)
                p.cancel()
            }
        }
        val d = load(ctx) ?: return true
        if (!d.optBoolean("notifyOn", true)) return true
        val sound = d.optString("sound", "adhan1")
        val vib = d.optBoolean("vibrate", true)
        val notify = HashSet<String>()
        val arr = d.optJSONArray("notify")
        if (arr != null) for (i in 0 until arr.length()) notify.add(arr.getString(i))
        val days = d.optJSONArray("days") ?: return true
        val now = System.currentTimeMillis()
        var count = 0
        var exact = true
        for (i in 0 until days.length()) {
            val pr = days.getJSONObject(i).getJSONArray("p")
            for (j in 0 until pr.length()) {
                val o = pr.getJSONObject(j)
                val name = o.getString("n")
                val s = o.getLong("s")
                if (!notify.contains(name) || s <= now + 1000) continue
                if (count >= 60) return exact
                if (!setAt(ctx, am, BASE + i * 10 + j, s, name, sound, vib)) exact = false
                count++
            }
        }
        return exact
    }
}
