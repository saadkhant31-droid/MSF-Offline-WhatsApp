package __PACKAGE__

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** موبائل ری اسٹارٹ یا ایپ اپڈیٹ کے بعد الارم دوبارہ لگاتا ہے */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        try { AdhanScheduler.schedule(ctx) } catch (e: Exception) {}
    }
}
