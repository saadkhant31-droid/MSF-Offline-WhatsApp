package __PACKAGE__

import android.Manifest
import android.app.AlarmManager
import android.app.WallpaperManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.FileInputStream

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "msf/wallpaper")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "setLiveWallpaper" -> {
                        try {
                            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                            intent.putExtra(
                                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                ComponentName(this, SimpleClockWallpaperService::class.java)
                            )
                            startActivity(intent)
                            result.success(true)
                        } catch (e: Exception) {
                            try {
                                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                                result.success(true)
                            } catch (e2: Exception) {
                                result.success(false)
                            }
                        }
                    }
                    "setImageWallpaper" -> {
                        val path = call.argument<String>("path")
                        val which = call.argument<Int>("which") ?: 3
                        if (path == null) {
                            result.success(false)
                            return@setMethodCallHandler
                        }
                        Thread {
                            var ok = false
                            try {
                                val wm = WallpaperManager.getInstance(applicationContext)
                                FileInputStream(path).use { ins ->
                                    if (Build.VERSION.SDK_INT >= 24) {
                                        val flag = when (which) {
                                            1 -> WallpaperManager.FLAG_SYSTEM
                                            2 -> WallpaperManager.FLAG_LOCK
                                            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                                        }
                                        wm.setStream(ins, null, true, flag)
                                    } else {
                                        wm.setStream(ins)
                                    }
                                }
                                ok = true
                            } catch (e: Exception) {
                            }
                            runOnUiThread { result.success(ok) }
                        }.start()
                    }
                    "scheduleAdhan" -> {
                        result.success(try { AdhanScheduler.schedule(applicationContext) } catch (e: Exception) { false })
                    }
                    "previewAdhan" -> {
                        val sound = call.argument<String>("sound") ?: "adhan1"
                        if (sound == "silent") {
                            result.success(false)
                        } else {
                            try {
                                val i = Intent(this, AdhanService::class.java)
                                i.putExtra("name", "آزمائش")
                                i.putExtra("sound", sound)
                                i.putExtra("preview", true)
                                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                                result.success(true)
                            } catch (e: Exception) {
                                result.success(false)
                            }
                        }
                    }
                    "stopAdhan" -> {
                        stopService(Intent(this, AdhanService::class.java))
                        result.success(true)
                    }
                    "testAdhan" -> {
                        val sound = call.argument<String>("sound") ?: "adhan1"
                        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        result.success(
                            try {
                                AdhanScheduler.setAt(applicationContext, am, AdhanScheduler.TEST_CODE,
                                    System.currentTimeMillis() + 10000, "ٹیسٹ", sound, true)
                            } catch (e: Exception) { false }
                        )
                    }
                    "requestNotificationPermission" -> {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
                        }
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
