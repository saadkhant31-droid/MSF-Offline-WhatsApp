package __PACKAGE__

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Vibrator

/** اذان پوری چلاتا ہے (res/raw/adhan1.m4a, adhan2.m4a)۔ فورگراؤنڈ سروس، اس لیے ایپ بند ہو تب بھی چلتی ہے */
class AdhanService : Service() {
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            finish()
            return START_NOT_STICKY
        }
        val name = intent?.getStringExtra("name") ?: "نماز"
        val sound = intent?.getStringExtra("sound") ?: "adhan1"
        val preview = intent?.getBooleanExtra("preview", false) ?: false
        val vib = intent?.getBooleanExtra("vibrate", false) ?: false

        AdhanNotifier.ensureChannels(this)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AdhanService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = AdhanNotifier.builder(this, AdhanNotifier.CH_ADHAN)
            .setSmallIcon(applicationInfo.icon)
            .setContentTitle(if (preview) "اذان کی آزمائش" else "نماز کا وقت: $name")
            .setContentText(if (preview) "اذان سنائی جا رہی ہے" else "اذان جاری ہے")
            .setContentIntent(AdhanNotifier.openIntent(this))
            .addAction(android.R.drawable.ic_media_pause, "روکیں", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(11, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(11, n)
        }

        if (vib && !preview) {
            try {
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                v.vibrate(longArrayOf(0, 500, 200, 500), -1)
            } catch (e: Exception) {
            }
        }
        play(sound, preview)
        return START_NOT_STICKY
    }

    private fun play(sound: String, preview: Boolean) {
        val id = resources.getIdentifier(sound, "raw", packageName)
        if (id == 0) {
            finish()
            return
        }
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            val afd = resources.openRawResourceFd(id)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setOnCompletionListener { finish() }
            mp.setOnErrorListener { _, _, _ -> finish(); true }
            mp.prepare()
            mp.start()
            player = mp
            if (preview) handler.postDelayed({ finish() }, 15000)
        } catch (e: Exception) {
            finish()
        }
    }

    private fun finish() {
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (e: Exception) {}
        try { player?.release() } catch (e: Exception) {}
        player = null
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
        } else {
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        try { player?.release() } catch (e: Exception) {}
        player = null
        super.onDestroy()
    }
}
