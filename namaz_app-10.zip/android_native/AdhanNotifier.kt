package __PACKAGE__

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AdhanNotifier {
    const val CH_ALERT = "msf_prayer_alert"
    const val CH_ADHAN = "msf_adhan_playing"

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "نماز کے اوقات", NotificationManager.IMPORTANCE_HIGH)
        )
        val low = NotificationChannel(CH_ADHAN, "اذان", NotificationManager.IMPORTANCE_LOW)
        low.setSound(null, null)
        nm.createNotificationChannel(low)
    }

    fun builder(ctx: Context, channel: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, channel) else Notification.Builder(ctx)

    fun openIntent(ctx: Context): PendingIntent {
        val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: Intent()
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** آواز کے بغیر والا (صرف نوٹیفکیشن) */
    fun alert(ctx: Context, name: String) {
        ensureChannels(ctx)
        val n = builder(ctx, CH_ALERT)
            .setSmallIcon(ctx.applicationInfo.icon)
            .setContentTitle("نماز کا وقت: $name")
            .setContentText("$name کی نماز کا وقت ہو گیا ہے")
            .setContentIntent(openIntent(ctx))
            .setAutoCancel(true)
            .build()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(name.hashCode(), n)
    }
}
