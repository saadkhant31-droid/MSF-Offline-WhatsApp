import 'dart:convert';
import 'hijri_service.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:flutter/services.dart' show MethodChannel;
import 'package:shared_preferences/shared_preferences.dart';
import 'app_settings.dart';
import 'prayer_service.dart';
import 'qibla_math.dart';

const _prayerNames = {
  'fajr': 'فجر',
  'dhuhr': 'ظہر',
  'asr': 'عصر',
  'maghrib': 'مغرب',
  'isha': 'عشاء',
};
const _wdUr = ['پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ', 'اتوار'];
const _gUr = [
  'جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون',
  'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'
];
const _hUr = [
  'محرم', 'صفر', 'ربیع الاول', 'ربیع الآخر', 'جمادی الاول', 'جمادی الآخر',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذوالقعدہ', 'ذوالحجہ'
];

/// لائیو وال پیپر (اینڈرائیڈ کا اپنا حصہ) کے لیے اگلے 8 دن کے اوقات محفوظ کرتا ہے۔
/// ایپ نہ کھولیں تو بھی ایک ہفتہ تک وال پیپر پر صحیح اوقات آتے رہتے ہیں۔
Future<void> syncWallpaperData() async {
  try {
    final s = appSettings;
    final now = DateTime.now();
    final days = <Map<String, dynamic>>[];
    for (int i = 0; i < 30; i++) {
      final d = DateTime(now.year, now.month, now.day + i, 12);
      final slots =
          PrayerService.slots(d, s).where((p) => p.key != 'sunrise').toList();
      final h = HijriService.of(d, adjust: s.hijriAdjust);
      days.add({
        'ymd': DateFormat('yyyy-MM-dd').format(d),
        'wd': _wdUr[d.weekday - 1],
        'greg': '${d.day} ${_gUr[d.month - 1]} ${d.year}',
        'hijri': '${h.hDay} ${HijriService.monthsUr[h.hMonth - 1]} ${h.hYear}',
        'p': [
          for (final p in slots)
            {
              'n': p.name,
              's': p.start.millisecondsSinceEpoch,
              'e': p.end!.millisecondsSinceEpoch,
            }
        ],
      });
    }
    final data = {
      'city': s.city,
      'country': s.country,
      'qibla': qiblaBearing(s.latitude, s.longitude).round(),
      'h24': s.use24h,
      'style': s.wallpaperStyle,
      // اذان / نوٹیفکیشن (اینڈرائیڈ الارم انہی کو پڑھتے ہیں)
      'notifyOn': s.notificationsOn,
      'sound': s.adhanEnabled ? s.adhanSound : 'silent',
      'vibrate': s.vibration,
      'notify': [
        for (final k in s.notifyPrayers)
          if (_prayerNames.containsKey(k)) _prayerNames[k]
      ],
      'days': days,
    };
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('wp_data', jsonEncode(data));
    try {
      await const MethodChannel('msf/wallpaper').invokeMethod('scheduleAdhan');
    } catch (_) {}
  } catch (_) {}
}
