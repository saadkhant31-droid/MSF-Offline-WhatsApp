import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:hijri/hijri_calendar.dart';

/// ایک دن کی ہجری تاریخ (پاکستانی کیلنڈر 2026–2060 سے)
class HDate {
  final int hDay, hMonth, hYear;
  final String? occasion; // اسلامی موقع (اگر ہو)
  const HDate(this.hDay, this.hMonth, this.hYear, [this.occasion]);
}

/// پاکستانی اسلامی کیلنڈر 2026 تا 2060 (assets/hijri/pk_hijri_2026_2060.json)۔
/// یہ حسابی/متوقع تاریخیں ہیں؛ چاند نظر آنے پر ایک دن آگے پیچھے ہو سکتی ہیں۔
/// اس مدت سے باہر کی تاریخوں کے لیے hijri پیکیج کا حساب استعمال ہوتا ہے۔
class HijriService {
  static List<int> _codes = const [];
  static Map<int, String> _occ = {};
  static List<String> _months = const [
    'محرم الحرام', 'صفر المظفر', 'ربیع الاول', 'ربیع الثانی', 'جمادی الاول',
    'جمادی الثانی', 'رجب المرجب', 'شعبان المعظم', 'رمضان المبارک',
    'شوال المکرم', 'ذوالقعدہ', 'ذوالحجہ'
  ];
  static final DateTime _start = DateTime.utc(2026, 1, 1);

  /// مہینوں کے اردو نام (1 تا 12)
  static List<String> get monthsUr => _months;
  static bool get loaded => _codes.isNotEmpty;

  static Future<void> init() async {
    try {
      final s = await rootBundle.loadString('assets/hijri/pk_hijri_2026_2060.json');
      final j = jsonDecode(s) as Map<String, dynamic>;
      _codes = (j['d'] as List).cast<int>();
      final names = (j['months'] as List).cast<String>();
      if (names.length == 12) _months = names;
      final occList = (j['occ'] as List).cast<String>();
      final o = j['o'] as Map<String, dynamic>;
      _occ = {
        for (final e in o.entries) int.parse(e.key): occList[e.value as int]
      };
    } catch (_) {}
  }

  /// [d] کی ہجری تاریخ۔ [adjust]: دستی ±دن کی تبدیلی (سیٹنگز)
  static HDate of(DateTime d, {int adjust = 0}) {
    final g = DateTime.utc(d.year, d.month, d.day + adjust);
    final idx = g.difference(_start).inDays;
    if (idx >= 0 && idx < _codes.length) {
      final c = _codes[idx];
      return HDate(c % 100, (c ~/ 100) % 100, c ~/ 10000, _occ[idx]);
    }
    final h = HijriCalendar.fromDate(DateTime(g.year, g.month, g.day, 12));
    return HDate(h.hDay, h.hMonth, h.hYear);
  }
}
