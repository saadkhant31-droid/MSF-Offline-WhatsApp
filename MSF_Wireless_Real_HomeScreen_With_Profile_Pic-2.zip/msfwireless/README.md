# MSF Wireless

Android Java/XML prototype based on the supplied MSF Wireless home-screen design.

## Working in this project
- Real microphone capture using Android `AudioRecord` while PTT is held.
- PTT is press-and-hold; release stops capture.
- Channel +/- UI, scan, one-to-one/group mode UI, voice-speed control.
- USB Host manager for an external radio/transceiver.
- PCM frames are handed to the radio transport layer.
- Supplied reference image is included as `msf_wireless_home_reference.png`.

## Important radio note
This APK does **not** magically create 1–4+ km radio communication using the phone alone. A compatible external RF transceiver/radio module and its exact protocol/codec are required. The USB layer is intentionally generic because the correct driver, frequency, modulation, legal power and packet/voice protocol depend on the selected hardware.

For production long-range voice, select a legal radio module that supports sufficient data rate and a voice codec, then implement its documented USB/serial protocol in `UsbRadioManager`/a dedicated transport class.
