package com.msf.wireless;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

public class VoiceAudioEngine {
    public interface Listener { void onPcm(byte[] data, int length); }
    private AudioRecord record; private Thread thread; private volatile boolean running;
    private final Listener listener;
    public VoiceAudioEngine(Listener listener){ this.listener=listener; }
    public synchronized void start(){ if(running)return; int min=AudioRecord.getMinBufferSize(16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT); int size=Math.max(min,4096); record=new AudioRecord(MediaRecorder.AudioSource.MIC,16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,size); record.startRecording(); running=true; thread=new Thread(()->{byte[] b=new byte[2048]; while(running){int n=record.read(b,0,b.length); if(n>0) listener.onPcm(b,n);}},"MSF-Audio"); thread.start(); }
    public synchronized void stop(){ running=false; if(record!=null){try{record.stop();}catch(Exception ignored){} record.release(); record=null;} }
}
