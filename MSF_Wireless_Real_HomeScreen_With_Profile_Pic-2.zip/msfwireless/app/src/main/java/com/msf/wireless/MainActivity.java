package com.msf.wireless;

import android.Manifest; import android.app.Activity; import android.os.Bundle; import android.content.pm.PackageManager; import android.view.MotionEvent; import android.widget.*; import android.view.View;

public class MainActivity extends Activity {
 private VoiceAudioEngine audio; private UsbRadioManager radio; private TextView channel,speedText,signal; private int ch=1; private boolean transmitting;
 @Override public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main); channel=findViewById(R.id.channel); speedText=findViewById(R.id.speedText); signal=findViewById(R.id.signalText); radio=new UsbRadioManager(this);
  if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);
  audio=new VoiceAudioEngine((data,len)->{ /* PCM is ready for the selected radio codec/protocol. */ if(transmitting) radio.send(java.util.Arrays.copyOf(data,len),50); });
  findViewById(R.id.channelMinus).setOnClickListener(v->{ch=Math.max(1,ch-1); updateChannel();}); findViewById(R.id.channelPlus).setOnClickListener(v->{ch=Math.min(99,ch+1); updateChannel();});
  findViewById(R.id.scan).setOnClickListener(v->Toast.makeText(this,"Scanning available radio channels…",Toast.LENGTH_SHORT).show());
  findViewById(R.id.one).setOnClickListener(v->Toast.makeText(this,"One-to-One mode selected",Toast.LENGTH_SHORT).show()); findViewById(R.id.group).setOnClickListener(v->Toast.makeText(this,"Group mode selected",Toast.LENGTH_SHORT).show());
  ((SeekBar)findViewById(R.id.speed)).setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){speedText.setText(String.format(java.util.Locale.US,"%.1fx",0.5+p*0.05));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
  View ptt=findViewById(R.id.ptt); ptt.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){startTx();return true;} if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){stopTx();return true;} return true;});
 }
 private void updateChannel(){channel.setText(String.format(java.util.Locale.US,"Channel %02d\n(Main)",ch));}
 private void startTx(){if(transmitting)return; transmitting=true; try{audio.start(); signal.setText("TX • Strong");}catch(Exception e){transmitting=false;Toast.makeText(this,"Microphone start failed: "+e.getMessage(),Toast.LENGTH_SHORT).show();}}
 private void stopTx(){if(!transmitting)return; transmitting=false; audio.stop(); signal.setText("Strong");}
 @Override protected void onDestroy(){if(audio!=null)audio.stop();if(radio!=null)radio.close();super.onDestroy();}
}
