package com.msf.wireless;

import android.content.*; import android.hardware.usb.*; import java.util.*;

public class UsbRadioManager {
    private final Context context; private UsbDeviceConnection connection; private UsbEndpoint out;
    public UsbRadioManager(Context c){context=c.getApplicationContext();}
    public List<UsbDevice> devices(){return new ArrayList<>(((UsbManager)context.getSystemService(Context.USB_SERVICE)).getDeviceList().values());}
    public boolean openFirst(){ UsbManager m=(UsbManager)context.getSystemService(Context.USB_SERVICE); for(UsbDevice d:devices()){ if(!m.hasPermission(d)) continue; for(int i=0;i<d.getInterfaceCount();i++){UsbInterface in=d.getInterface(i); if(in.getEndpointCount()==0)continue; connection=m.openDevice(d); if(connection!=null && connection.claimInterface(in,true)){ for(int e=0;e<in.getEndpointCount();e++){UsbEndpoint ep=in.getEndpoint(e); if(ep.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK && ep.getDirection()==UsbConstants.USB_DIR_OUT){out=ep; return true;}}}}} return false; }
    public int send(byte[] data,int timeout){if(connection==null||out==null)return -1; return connection.bulkTransfer(out,data,data.length,timeout);}
    public void close(){if(connection!=null){connection.close();connection=null;}}
}
