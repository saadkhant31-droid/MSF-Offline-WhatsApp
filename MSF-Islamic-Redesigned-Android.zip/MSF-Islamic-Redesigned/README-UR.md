# MSF Islamic — Redesigned Android Starter

یہ نیا ZIP سبز اور سنہری اسلامی طرز کے ڈیزائن کے ساتھ Kotlin + XML Android project ہے۔

### شامل
- نیا ہوم اسکرین ڈیزائن
- ڈیجیٹل گھڑی
- عیسوی تاریخ اور Android Hijrah calendar سے ہجری تاریخ
- چند نمونہ شہروں کا انتخاب
- بنیادی تخمینی نماز اوقات
- منتخب مقام کے لیے قبلہ کا زاویہ

### ابھی مکمل نہیں
یہ production-ready ایپ نہیں ہے۔ 57 ممالک کے تمام صوبے، اضلاع اور شہر، validated prayer-time engine، حقیقی کمپاس سینسر، GPS، اذان آڈیو/نوٹیفکیشن، ماہانہ جدول اور قضا سے متعلق شرعی منطق ابھی نافذ نہیں۔ نماز کے اوقات مقامی مستند مسجد یا سرکاری ٹائم ٹیبل سے تصدیق کیے بغیر شرعی عمل کے لیے استعمال نہ کریں۔ ٹائم زونز بھی اس demo میں مقررہ مثالیں ہیں۔

### Build
1. ZIP Extract کریں۔
2. AndroidIDE/Android Studio میں فولڈر کھولیں۔
3. Gradle Sync کریں۔
4. app کی assembleDebug build چلائیں۔

Package: com.msf.islamic
