package com.msf.islamic

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.chrono.HijrahDate
import java.util.Locale
import kotlin.math.*

data class City(val country:String,val name:String,val lat:Double,val lon:Double,val offset:Double) {
    override fun toString() = "$name، $country"
}
data class Prayer(val name:String,val time:LocalTime)
object PrayerMath {
    private const val R=Math.PI/180.0
    fun qibla(lat:Double,lon:Double):Double {
        val klat=21.4225*R; val klon=39.8262*R; val a=lat*R; val b=lon*R
        return (atan2(sin(klon-b),cos(a)*tan(klat)-sin(a)*cos(klon-b))/R+360)%360
    }
    fun calculate(date:LocalDate,c:City):List<Prayer> {
        val n=date.dayOfYear.toDouble()
        val decl=23.45*sin(R*360.0*(284+n)/365.0)
        fun hour(angle:Double,morning:Boolean):Double {
            val co=(cos(R*angle)-sin(R*c.lat)*sin(R*decl))/(cos(R*c.lat)*cos(R*decl))
            if(co !in -1.0..1.0) return if(morning) 5.0 else 19.0
            val h=acos(co)/15.0
            return (if(morning) 12-h else 12+h)-c.lon/15.0
        }
        val rise=hour(90.833,true); val set=hour(90.833,false); val noon=(rise+set)/2
        val fajr=hour(18.0,true); val isha=hour(17.0,false)
        val shadow=1.0/(2.0+tan(R*abs(c.lat-decl)))
        val asr=noon+(12.0-atan(shadow)/R)/15.0
        fun t(h:Double)=LocalTime.MIDNIGHT.plusMinutes(((h+c.offset)*60).roundToInt().toLong())
        return listOf(Prayer("فجر",t(fajr)),Prayer("طلوعِ آفتاب",t(rise)),Prayer("ظہر",t(noon)),Prayer("عصر",t(asr)),Prayer("مغرب",t(set)),Prayer("عشاء",t(isha)))
    }
}
class MainActivity:Activity() {
    private lateinit var clock:TextView; private lateinit var dates:TextView; private lateinit var spinner:Spinner
    private lateinit var coords:TextView; private lateinit var next:TextView; private lateinit var list:LinearLayout; private lateinit var qibla:TextView
    private val handler=Handler(Looper.getMainLooper())
    private val cities=listOf(
        City("پاکستان","اسلام آباد",33.6844,73.0479,5.0),City("پاکستان","کراچی",24.8607,67.0011,5.0),
        City("پاکستان","لاہور",31.5204,74.3587,5.0),City("پاکستان","پشاور",34.0151,71.5249,5.0),
        City("پاکستان","کوئٹہ",30.1798,66.9750,5.0),City("سعودی عرب","مکہ مکرمہ",21.3891,39.8579,3.0),
        City("سعودی عرب","مدینہ منورہ",24.4672,39.6024,3.0),City("افغانستان","کابل",34.5553,69.2075,4.5),
        City("بنگلہ دیش","ڈھاکہ",23.8103,90.4125,6.0),City("ترکیہ","استنبول",41.0082,28.9784,3.0),
        City("متحدہ عرب امارات","دبئی",25.2048,55.2708,4.0),City("ملائیشیا","کوالالمپور",3.139,101.6869,8.0),
        City("انڈونیشیا","جکارتہ",-6.2088,106.8456,7.0),City("مصر","قاہرہ",30.0444,31.2357,2.0),
        City("برطانیہ","لندن",51.5072,-0.1276,1.0),City("امریکہ","نیویارک",40.7128,-74.006, -4.0))
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_main)
        clock=findViewById(R.id.txtClock);dates=findViewById(R.id.txtDates);spinner=findViewById(R.id.spinnerCity)
        coords=findViewById(R.id.txtCoordinates);next=findViewById(R.id.txtNextPrayer);list=findViewById(R.id.prayerList);qibla=findViewById(R.id.txtQibla)
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cities)
        spinner.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onItemSelected(p:android.widget.AdapterView<*>?,v:View?,pos:Int,id:Long)=refresh()
            override fun onNothingSelected(p:android.widget.AdapterView<*>?){}
        }
        handler.post(ticker)
    }
    private val ticker=object:Runnable{override fun run(){
        val n=LocalDateTime.now();clock.text=n.format(DateTimeFormatter.ofPattern("hh:mm:ss a",Locale.ENGLISH))
        dates.text="${n.toLocalDate()}  •  ہجری: ${HijrahDate.from(n.toLocalDate())}"
        handler.postDelayed(this,1000)
    }}
    private fun refresh(){
        if(!::list.isInitialized)return
        val c=cities[spinner.selectedItemPosition.coerceIn(cities.indices)]
        coords.text="GPS: ${c.lat}, ${c.lon} • UTC ${if(c.offset>=0) "+" else ""}${c.offset}"
        qibla.text="${"%.1f".format(Locale.ENGLISH,PrayerMath.qibla(c.lat,c.lon))}°"
        val prayers=PrayerMath.calculate(LocalDate.now(),c);list.removeAllViews()
        prayers.forEach{p->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(16,15,16,15);setBackgroundResource(R.drawable.card_bg)}
            row.addView(TextView(this).apply{text=p.name;textSize=17f;setTextColor(0xFF173E35.toInt())},LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this).apply{text=p.time.format(DateTimeFormatter.ofPattern("hh:mm a",Locale.ENGLISH));textSize=17f;setTextColor(0xFF075E4D.toInt());gravity=Gravity.END},LinearLayout.LayoutParams(0,-2,1f))
            list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=7})
        }
        val now=LocalTime.now().toSecondOfDay()
        val upcoming=prayers.firstOrNull{it.name!="طلوعِ آفتاب" && it.time.toSecondOfDay()>now}
        next.text=if(upcoming!=null) "${upcoming.name} • ${upcoming.time.format(DateTimeFormatter.ofPattern("hh:mm a",Locale.ENGLISH))}" else "فجر • اگلے دن"
    }
    override fun onDestroy(){handler.removeCallbacks(ticker);super.onDestroy()}
}
