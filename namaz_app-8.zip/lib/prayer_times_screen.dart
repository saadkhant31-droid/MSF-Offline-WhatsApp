import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'app_settings.dart';
import 'kohat_table_screen.dart';
import 'prayer_service.dart';

const _monthsUr = [
  'جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون',
  'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'
];
const _wdShort = ['پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ', 'اتوار'];

/// نماز کے اوقات کا ماہانہ نقشہ کسی بھی مہینے اور سال کے لیے (منتخب شہر کا)
class PrayerTimesScreen extends StatefulWidget {
  const PrayerTimesScreen({super.key});
  @override
  State<PrayerTimesScreen> createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen> {
  late int year;
  late int month;

  @override
  void initState() {
    super.initState();
    final n = DateTime.now();
    year = n.year;
    month = n.month;
  }

  void _shift(int delta) {
    setState(() {
      month += delta;
      if (month < 1) {
        month = 12;
        year--;
      } else if (month > 12) {
        month = 1;
        year++;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) {
        final s = appSettings;
        final cs = Theme.of(context).colorScheme;
        final fmt = DateFormat(s.use24h ? 'HH:mm' : 'hh:mm');
        final days = DateTime(year, month + 1, 0).day;
        final today = DateTime.now();

        Widget cell(String t, {bool bold = false, Color? color, double flex = 1}) =>
            Expanded(
              flex: (flex * 10).round(),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(t,
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: bold ? FontWeight.bold : null,
                        color: color)),
              ),
            );

        return Scaffold(
          appBar: AppBar(title: const Text('نماز کے اوقات')),
          body: Column(children: [
            ListTile(
              leading: const Icon(Icons.table_chart),
              title: const Text('کوہاٹ کا ماہانہ نقشہ'),
              subtitle: const Text('12 مہینوں کا تصویری ٹیبل، ہر سال کے لیے'),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const KohatTableScreen())),
            ),
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: Row(children: [
                  IconButton(
                      onPressed: () => _shift(-1),
                      icon: const Icon(Icons.chevron_left)),
                  Expanded(
                    child: Column(children: [
                      Text('${_monthsUr[month - 1]} $year',
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold)),
                      Text(
                          '${s.city} • ${PrayerService.methodLabels[s.method] ?? ''} • ${s.hanafi ? 'حنفی' : 'شافعی'} عصر',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 11, color: cs.onSurfaceVariant)),
                    ]),
                  ),
                  IconButton(
                      onPressed: () => _shift(1),
                      icon: const Icon(Icons.chevron_right)),
                ]),
              ),
            ),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Container(
                color: cs.primaryContainer,
                padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
                child: Row(children: [
                  cell('دن', bold: true, flex: 1.6),
                  cell('فجر', bold: true),
                  cell('طلوع', bold: true),
                  cell('ظہر', bold: true),
                  cell('عصر', bold: true),
                  cell('مغرب', bold: true),
                  cell('عشاء', bold: true),
                ]),
              ),
            ),
            Expanded(
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: ListView.builder(
                  itemCount: days,
                  itemBuilder: (_, i) {
                    final d = i + 1;
                    final date = DateTime(year, month, d, 12);
                    final t = PrayerService.forDay(date, s);
                    final isToday = today.year == year &&
                        today.month == month &&
                        today.day == d;
                    final isFri = date.weekday == DateTime.friday;
                    return Container(
                      color: isToday
                          ? cs.secondaryContainer
                          : (i.isOdd ? cs.surfaceContainerHighest.withOpacity(0.35) : null),
                      padding:
                          const EdgeInsets.symmetric(vertical: 7, horizontal: 6),
                      child: Row(children: [
                        cell('$d ${_wdShort[date.weekday - 1]}',
                            bold: isToday,
                            color: isFri ? cs.primary : null,
                            flex: 1.6),
                        for (final e in t)
                          cell(fmt.format(e.time), bold: isToday),
                      ]),
                    );
                  },
                ),
              ),
            ),
          ]),
        );
      },
    );
  }
}
