import 'dart:convert';
import 'package:hijri/hijri_calendar.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:shared_preferences/shared_preferences.dart';
import 'app_settings.dart';
import 'prayer_service.dart';
import 'qibla_math.dart';

const _wdUr = ['پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ', 'اتوار'];
const _gUr = [
  'جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون',
  'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'
];
const _hUr = [
  'محرم', 'صفر', 'ربیع الاول', 'ربیع الآخر', 'جمادی الاول', 'جمادی الآخر',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذوالقعدہ', 'ذوالحجہ'
];

/// لائیو وال پیپر (اینڈرائیڈ کا اپنا حصہ) کے لیے اگلے 8 دن کے اوقات محفوظ کرتا ہے۔
/// ایپ نہ کھولیں تو بھی ایک ہفتہ تک وال پیپر پر صحیح اوقات آتے رہتے ہیں۔
Future<void> syncWallpaperData() async {
  try {
    final s = appSettings;
    final now = DateTime.now();
    final days = <Map<String, dynamic>>[];
    for (int i = 0; i < 8; i++) {
      final d = DateTime(now.year, now.month, now.day + i, 12);
      final slots =
          PrayerService.slots(d, s).where((p) => p.key != 'sunrise').toList();
      final h = HijriCalendar.fromDate(
          DateTime(d.year, d.month, d.day + s.hijriAdjust, 12));
      days.add({
        'ymd': DateFormat('yyyy-MM-dd').format(d),
        'wd': _wdUr[d.weekday - 1],
        'greg': '${d.day} ${_gUr[d.month - 1]} ${d.year}',
        'hijri': '${h.hDay} ${_hUr[h.hMonth - 1]} ${h.hYear}',
        'p': [
          for (final p in slots)
            {
              'n': p.name,
              's': p.start.millisecondsSinceEpoch,
              'e': p.end!.millisecondsSinceEpoch,
            }
        ],
      });
    }
    final data = {
      'city': s.city,
      'country': s.country,
      'qibla': qiblaBearing(s.latitude, s.longitude).round(),
      'h24': s.use24h,
      'days': days,
    };
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('wp_data', jsonEncode(data));
  } catch (_) {}
}
