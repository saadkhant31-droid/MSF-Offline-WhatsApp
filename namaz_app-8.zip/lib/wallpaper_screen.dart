import 'dart:async';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'app_settings.dart';
import 'wallpaper_styles.dart';
import 'wallpaper_sync.dart';

const _channel = MethodChannel('msf/wallpaper');

/// گھڑی کے 9 ڈیزائن دیکھنے اور وال پیپر لگانے کی اسکرین
class WallpaperScreen extends StatefulWidget {
  const WallpaperScreen({super.key});
  @override
  State<WallpaperScreen> createState() => _WallpaperScreenState();
}

class _WallpaperScreenState extends State<WallpaperScreen> {
  late final PageController _pc;
  late int index;
  late Timer _t;
  DateTime now = DateTime.now();
  final GlobalKey _capKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    index = wallpaperStyles
        .indexWhere((e) => e.id == appSettings.wallpaperStyle)
        .clamp(0, wallpaperStyles.length - 1);
    _pc = PageController(viewportFraction: 0.66, initialPage: index);
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _t.cancel();
    _pc.dispose();
    super.dispose();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  // ---------- 1) لائیو گھڑی (اینڈرائیڈ کا اپنا سادہ وال پیپر، چلتی ہوئی گھڑی) ----------
  Future<void> _setLive() async {
    if (!Platform.isAndroid) {
      _snack('وال پیپر صرف اینڈرائیڈ پر لگتا ہے');
      return;
    }
    await syncWallpaperData();
    try {
      final ok = await _channel.invokeMethod<bool>('setLiveWallpaper');
      if (ok != true && mounted) _snack('وال پیپر کی اسکرین نہیں کھل سکی');
    } on MissingPluginException {
      _snack('اینڈرائیڈ والا حصہ شامل نہیں ہوا (setup_android.py چلائیں)');
    } catch (_) {
      _snack('وال پیپر لگانے میں مسئلہ آیا');
    }
  }

  // ---------- 2) منتخب ڈیزائن تصویر کے طور پر ----------
  Future<String?> _capture() async {
    final ctx = _capKey.currentContext;
    if (ctx == null) return null;
    final b = ctx.findRenderObject() as RenderRepaintBoundary;
    final img = await b.toImage(pixelRatio: 1080 / b.size.width);
    final data = await img.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) return null;
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/msf_wallpaper_${index + 1}.png');
    await f.writeAsBytes(data.buffer.asUint8List());
    return f.path;
  }

  Future<void> _setImage() async {
    if (!Platform.isAndroid) {
      _snack('وال پیپر صرف اینڈرائیڈ پر لگتا ہے');
      return;
    }
    final which = await showModalBottomSheet<int>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Padding(
              padding: EdgeInsets.all(14),
              child: Text('کہاں لگائیں؟',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            ListTile(
                leading: const Icon(Icons.home),
                title: const Text('ہوم اسکرین'),
                onTap: () => Navigator.pop(ctx, 1)),
            ListTile(
                leading: const Icon(Icons.lock),
                title: const Text('لاک اسکرین'),
                onTap: () => Navigator.pop(ctx, 2)),
            ListTile(
                leading: const Icon(Icons.phone_android),
                title: const Text('دونوں'),
                onTap: () => Navigator.pop(ctx, 3)),
          ]),
        ),
      ),
    );
    if (which == null) return;
    final st = wallpaperStyles[index];
    await appSettings.update(() => appSettings.wallpaperStyle = st.id);
    final path = await _capture();
    if (path == null) {
      _snack('تصویر نہیں بن سکی');
      return;
    }
    try {
      final ok = await _channel
          .invokeMethod<bool>('setImageWallpaper', {'path': path, 'which': which});
      _snack(ok == true ? 'وال پیپر لگ گیا' : 'وال پیپر نہیں لگ سکا');
    } on MissingPluginException {
      _snack('اینڈرائیڈ والا حصہ شامل نہیں ہوا (setup_android.py چلائیں)');
    } catch (_) {
      _snack('وال پیپر لگانے میں مسئلہ آیا');
    }
  }

  void _fullScreen() {
    final st = wallpaperStyles[index];
    Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => _FullScreenClock(styleId: st.id)));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('گھڑی وال پیپر')),
      body: Column(children: [
        const SizedBox(height: 12),
        Expanded(
          child: PageView.builder(
            controller: _pc,
            itemCount: wallpaperStyles.length,
            onPageChanged: (i) => setState(() => index = i),
            itemBuilder: (_, i) {
              final selected = i == index;
              return AnimatedScale(
                scale: selected ? 1 : 0.9,
                duration: const Duration(milliseconds: 200),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                  child: AspectRatio(
                    aspectRatio: 360 / 760,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                            color: selected
                                ? const Color(0xFFE6B94D)
                                : Colors.transparent,
                            width: 3),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: RepaintBoundary(
                        key: selected ? _capKey : null,
                        child: WallpaperView(
                            styleId: wallpaperStyles[i].id, now: now),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Text(
            '${wallpaperStyles[index].name}  •  ${index + 1}/${wallpaperStyles.length}',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (int i = 0; i < wallpaperStyles.length; i++)
            Container(
              width: i == index ? 18 : 7,
              height: 7,
              margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(
                color: i == index ? cs.primary : cs.outlineVariant,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
        ]),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Column(children: [
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _setImage,
                  icon: const Icon(Icons.image),
                  label: const Text('یہ ڈیزائن لگائیں'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _setLive,
                  icon: const Icon(Icons.access_time),
                  label: const Text('چلتی گھڑی (لائیو)'),
                ),
              ),
            ]),
            const SizedBox(height: 4),
            TextButton.icon(
              onPressed: _fullScreen,
              icon: const Icon(Icons.fullscreen),
              label: const Text('پوری اسکرین پر دیکھیں'),
            ),
            Text(
              '"یہ ڈیزائن لگائیں" تصویر کی شکل میں لگتا ہے، اس میں وقت چلتا نہیں۔ چلتی ہوئی گھڑی کے لیے "لائیو" والا لگائیں۔',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _FullScreenClock extends StatefulWidget {
  final String styleId;
  const _FullScreenClock({required this.styleId});
  @override
  State<_FullScreenClock> createState() => _FullScreenClockState();
}

class _FullScreenClockState extends State<_FullScreenClock> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: TickingWallpaper(styleId: widget.styleId),
        ),
      );
}
