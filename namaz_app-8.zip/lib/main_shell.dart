import 'package:flutter/material.dart';
import 'calendar_screen.dart';
import 'home_screen.dart';
import 'kohat_table_screen.dart';
import 'location_picker.dart';
import 'prayer_times_screen.dart';
import 'qibla_screen.dart';
import 'settings_screen.dart';
import 'wallpaper_screen.dart';

/// نچلی بار: ہوم، نماز کے اوقات، قبلہ، کیلنڈر، کتابیں، مزید
class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: index, children: [
        HomeScreen(onNavigate: (i) => setState(() => index = i)),
        const PrayerTimesScreen(),
        QiblaScreen(
          active: index == 2,
          onBack: () => setState(() => index = 0),
        ),
        const CalendarScreen(),
        const _Soon('کتابیں'),
        const MorePage(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'ہوم'),
          NavigationDestination(icon: Icon(Icons.mosque_outlined), selectedIcon: Icon(Icons.mosque), label: 'نماز کے اوقات'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'قبلہ'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'کیلنڈر'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'کتابیں'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'مزید'),
        ],
      ),
    );
  }
}

class _Soon extends StatelessWidget {
  final String title;
  const _Soon(this.title);
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: const Center(child: Text('یہ سیکشن اگلے مرحلے میں شامل ہوگا')),
      );
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مزید')),
      body: ListView(children: [
        ListTile(
          leading: const Icon(Icons.settings),
          title: const Text('سیٹنگز'),
          subtitle: const Text('ایپ کی ترتیبات'),
          onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.table_chart),
          title: const Text('کوہاٹ کا ماہانہ نقشہ'),
          subtitle: const Text('12 مہینوں کا نماز ٹیبل'),
          onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const KohatTableScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.wallpaper),
          title: const Text('گھڑی وال پیپر'),
          subtitle: const Text('9 ڈیزائن، موبائل کی اسکرین کے لیے'),
          onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const WallpaperScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.public),
          title: const Text('57 اسلامی ممالک'),
          subtitle: const Text('ملک، صوبے اور شہر'),
          onTap: () => showLocationPicker(context),
        ),
      ]),
    );
  }
}
