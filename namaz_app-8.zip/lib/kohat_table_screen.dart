import 'package:flutter/material.dart';

const _monthsEn = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];
const _monthsUr = [
  'جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون',
  'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'
];

/// کوہاٹ کا ماہانہ نماز نقشہ (12 تصویری ٹیبل، ہر سال کے لیے)
class KohatTableScreen extends StatefulWidget {
  const KohatTableScreen({super.key});
  @override
  State<KohatTableScreen> createState() => _KohatTableScreenState();
}

class _KohatTableScreenState extends State<KohatTableScreen> {
  late final PageController _pc;
  late int index;

  @override
  void initState() {
    super.initState();
    index = DateTime.now().month - 1;
    _pc = PageController(initialPage: index);
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('کوہاٹ کا نماز نقشہ')),
      body: Column(children: [
        SizedBox(
          height: 52,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            itemCount: 12,
            itemBuilder: (_, i) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: ChoiceChip(
                label: Text(_monthsUr[i]),
                selected: i == index,
                onSelected: (_) => _pc.animateToPage(i,
                    duration: const Duration(milliseconds: 250),
                    curve: Curves.easeOut),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            'کالم: فجر • طلوع • ظہر • عصر • مغرب • عشاء (اوپر سے نیچے دن بہ دن)',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
          ),
        ),
        Expanded(
          child: PageView.builder(
            controller: _pc,
            itemCount: 12,
            onPageChanged: (i) => setState(() => index = i),
            itemBuilder: (_, i) => InteractiveViewer(
              minScale: 1,
              maxScale: 4,
              child: Center(
                child: Container(
                  color: Colors.white,
                  child: Image.asset('assets/kohat/${_monthsEn[i]}.png',
                      fit: BoxFit.contain),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
          child: Text(
            'یہ نقشہ ہر سال کے لیے ہے۔ وقت پاکستان اسٹینڈرڈ ٹائم میں ہیں (طریقہ: کراچی، عصر: حنفی)۔ دو انگلیوں سے زوم کریں۔ تسلی کے لیے اپنی مسجد کے اوقات سے ملا لیں۔',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant),
          ),
        ),
      ]),
    );
  }
}
