import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'app_settings.dart';
import 'gps_helper.dart';
import 'location_picker.dart';
import 'qibla_math.dart';
import 'settings_screen.dart';

const _green = Color(0xFF0B3D2E);
const _greenMid = Color(0xFF0B6E4F);
const _gold = Color(0xFFE6B94D);
const _kaabaLat = 21.4225;
const _kaabaLng = 39.8262;

class QiblaScreen extends StatefulWidget {
  /// جب یہ ٹیب سامنے ہو تبھی سینسر چلتا ہے (بیٹری بچانے کے لیے)
  final bool active;
  final VoidCallback onBack;
  const QiblaScreen({super.key, required this.active, required this.onBack});
  @override
  State<QiblaScreen> createState() => _QiblaScreenState();
}

class _QiblaScreenState extends State<QiblaScreen> {
  AppSettings get s => appSettings;
  StreamSubscription<CompassEvent>? _sub;
  double? heading; // موبائل کا رخ (شمال سے ڈگری)
  bool live = true;
  bool noSensor = false;
  bool _wasAligned = false;

  double get bearing => qiblaBearing(s.latitude, s.longitude);

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(QiblaScreen old) {
    super.didUpdateWidget(old);
    if (old.active != widget.active) _sync();
  }

  @override
  void dispose() {
    _stop();
    super.dispose();
  }

  void _sync() {
    if (widget.active && live) {
      _start();
    } else {
      _stop();
    }
  }

  double _diff(double a, double b) => ((a - b + 540) % 360) - 180;

  Timer? _watch1, _watch2;
  StreamSubscription<AccelerometerEvent>? _accSub;
  StreamSubscription<MagnetometerEvent>? _magSub;
  List<double>? _g, _m;
  bool _preferFallback = false;
  DateTime _lastChange = DateTime.now();
  double manual = 0; // دستی طور پر لگایا گیا رخ

  void _onHeading(double raw) {
    if (!mounted) return;
    final v = (raw + 360) % 360;
    final prev = heading;
    final sm = prev == null ? v : (prev + _diff(v, prev) * 0.25 + 360) % 360;
    if (prev == null || (sm - prev).abs() > 0.3) _lastChange = DateTime.now();
    final aligned = _diff(sm, bearing).abs() < 3;
    if (aligned && !_wasAligned && s.vibration) {
      HapticFeedback.mediumImpact();
    }
    _wasAligned = aligned;
    setState(() {
      heading = sm;
      noSensor = false;
    });
  }

  void _start() {
    if (_sub != null || _accSub != null) return;
    final stream = FlutterCompass.events;
    if (stream != null) {
      _sub = stream.listen((e) {
        final h = e.heading;
        if (h != null) _onHeading(h);
      }, onError: (_) {});
    }
    if (_preferFallback) _startFallback();
    // 2 سیکنڈ میں کمپاس سے ڈیٹا نہ آیا تو متبادل سینسر (accelerometer + magnetometer) چلا دیتا ہے
    // اگر رخ بدل نہ رہا ہو (کئی موبائلوں میں کمپاس 0° پر اٹکا رہتا ہے) تو بھی متبادل سینسر
    _lastChange = DateTime.now();
    _watch1 = Timer.periodic(const Duration(seconds: 2), (_) {
      if (_accSub == null &&
          DateTime.now().difference(_lastChange).inSeconds >= 3) {
        _startFallback();
      }
    });
    _watch2 = Timer(const Duration(seconds: 5), () {
      if (heading == null && mounted) setState(() => noSensor = true);
    });
  }

  void _startFallback() {
    if (_accSub != null) return;
    _preferFallback = true;
    _sub?.cancel();
    _sub = null;
    try {
      _accSub = accelerometerEventStream(
              samplingPeriod: SensorInterval.uiInterval)
          .listen((e) {
        final o = _g;
        _g = o == null
            ? [e.x, e.y, e.z]
            : [o[0] * 0.8 + e.x * 0.2, o[1] * 0.8 + e.y * 0.2, o[2] * 0.8 + e.z * 0.2];
      }, onError: (_) {});
      _magSub = magnetometerEventStream(samplingPeriod: SensorInterval.uiInterval)
          .listen((e) {
        final o = _m;
        _m = o == null
            ? [e.x, e.y, e.z]
            : [o[0] * 0.8 + e.x * 0.2, o[1] * 0.8 + e.y * 0.2, o[2] * 0.8 + e.z * 0.2];
        _fuse();
      }, onError: (_) {});
    } catch (_) {}
  }

  /// accelerometer + magnetometer سے رخ (شمال سے ڈگری) نکالتا ہے
  void _fuse() {
    final a = _g, m = _m;
    if (a == null || m == null) return;
    final hx0 = m[1] * a[2] - m[2] * a[1];
    final hy0 = m[2] * a[0] - m[0] * a[2];
    final hz0 = m[0] * a[1] - m[1] * a[0];
    final nh = sqrt(hx0 * hx0 + hy0 * hy0 + hz0 * hz0);
    final na = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
    if (nh < 0.1 || na < 0.1) return;
    final hx = hx0 / nh, hy = hy0 / nh, hz = hz0 / nh;
    final gx = a[0] / na, gz = a[2] / na;
    final my = gz * hx - gx * hz;
    _onHeading(atan2(hy, my) * 180 / pi);
  }

  void _stop() {
    _sub?.cancel();
    _sub = null;
    _accSub?.cancel();
    _accSub = null;
    _magSub?.cancel();
    _magSub = null;
    _watch1?.cancel();
    _watch2?.cancel();
    _g = null;
    _m = null;
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  // ---------- بٹنوں کے کام ----------
  Future<void> _useGps() async {
    final err = await useCurrentLocation();
    if (!mounted) return;
    _snack(err ?? 'موجودہ مقام سیٹ ہو گیا');
  }

  Future<void> _openMap() async {
    final uri = Uri.parse(
        'https://www.google.com/maps/dir/?api=1&origin=${s.latitude},${s.longitude}&destination=$_kaabaLat,$_kaabaLng');
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok && mounted) _snack('نقشہ نہیں کھل سکا');
    } catch (_) {
      if (mounted) _snack('نقشہ نہیں کھل سکا');
    }
  }

  Future<void> _openUrl(String url) async {
    try {
      final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      if (!ok && mounted) _snack('لنک نہیں کھل سکا');
    } catch (_) {
      if (mounted) _snack('لنک نہیں کھل سکا');
    }
  }

  /// سینسر نہ چلے تو قبلہ معلوم کرنے کے آسان طریقے
  void _easy() {
    final b = bearing;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: StatefulBuilder(
          builder: (ctx, setSheet) => SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Text('قبلہ معلوم کرنے کے آسان طریقے',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ListTile(
                  leading: const Icon(Icons.travel_explore),
                  title: const Text('گوگل قبلہ فائنڈر'),
                  subtitle: const Text('براؤزر میں کھلتا ہے، موبائل کے کمپاس سے سمت بتاتا ہے'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _openUrl('https://qiblafinder.withgoogle.com');
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.map_outlined),
                  title: const Text('نقشے پر کعبہ تک راستہ'),
                  subtitle: const Text('گوگل میپس میں آپ کے مقام سے کعبہ کی سمت'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _openMap();
                  },
                ),
                const Divider(),
                const Text('دستی طریقہ', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(
                    '1) کسی بھی کمپاس سے (فون کی کمپاس ایپ یا گوگل میپس) شمال معلوم کریں۔\n'
                    '2) شمال سے گھڑی کی سمت ${b.round()}° گھومیں۔\n'
                    '3) یہی قبلہ کی سمت ہے: ${compassUrdu(b)}۔',
                    style: const TextStyle(height: 1.6)),
                const SizedBox(height: 10),
                Text('اپنا رخ خود لگائیں: ${manual.round()}°  (دوسری کمپاس ایپ سے دیکھ کر)',
                    style: const TextStyle(fontSize: 13)),
                Slider(
                  min: 0,
                  max: 359,
                  value: manual,
                  onChanged: (v) {
                    if (live) {
                      live = false;
                      _sync();
                    }
                    setState(() => manual = v);
                    setSheet(() {});
                  },
                ),
                const Text('جب سرخ تیر اوپر آ جائے تو آپ قبلہ رخ ہیں۔',
                    style: TextStyle(fontSize: 12, color: Colors.grey)),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  void _toggleLive() {
    setState(() => live = !live);
    _sync();
  }

  void _calibrate() {
    showDialog(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('کمپاس کی کیلیبریشن'),
          content: const Text(
              'موبائل کو ہوا میں "8" کی شکل میں چند بار گھمائیں۔ موبائل کو مقناطیس، دھاتی چیزوں اور اسپیکر سے دور رکھیں۔'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('ٹھیک ہے'))
          ],
        ),
      ),
    );
  }

  String _status() {
    if (!live) return 'لائیو کمپاس بند ہے';
    if (noSensor) return 'کمپاس سینسر کا ڈیٹا نہیں آ رہا۔ موبائل کو "8" کی شکل میں گھمائیں';
    if (heading == null) return 'کمپاس سے سمت معلوم ہو رہی ہے…';
    return _diff(heading!, bearing).abs() < 3
        ? '✓ آپ قبلہ رخ ہیں'
        : 'موبائل سیدھا رکھ کر گھمائیں، سرخ تیر کو اوپر لائیں (رخ: ${heading!.round()}°)';
  }

  // ================= بناوٹ =================
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) {
        final dark = Theme.of(context).brightness == Brightness.dark;
        final panel = dark ? const Color(0xFF16201C) : const Color(0xFFF5F2E6);
        return Scaffold(
          backgroundColor: panel,
          body: SingleChildScrollView(
            child: Column(children: [
              _top(),
              Container(
                color: _green,
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                child: _infoCard(dark),
              ),
              Container(
                color: _green,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(12, 14, 12, 16),
                  decoration: BoxDecoration(
                    color: panel,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(24)),
                  ),
                  child: Column(children: [
                    _statusRow(),
                    const SizedBox(height: 10),
                    _actions(dark),
                    const SizedBox(height: 12),
                    _locationDetails(),
                  ]),
                ),
              ),
            ]),
          ),
        );
      },
    );
  }

  // ---------- اوپر: عنوان، کمپاس، دونوں کارڈ ----------
  Widget _top() {
    final topPad = MediaQuery.of(context).padding.top;
    return LayoutBuilder(builder: (context, c) {
      final w = c.maxWidth;
      final d = w * 0.54;
      final compassTop = topPad + 78;
      final cw = (w - d) / 2 - 10;
      final h = compassTop + d + 14;
      final deg = bearing.round();

      return Directionality(
        textDirection: TextDirection.ltr,
        child: SizedBox(
          height: h,
          child: Stack(children: [
            Positioned.fill(child: Container(color: _green)),
            // کعبہ کی پس منظر تصویر (اختیاری: assets/qibla_bg.jpg)
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              height: compassTop + d * 0.55,
              child: Stack(fit: StackFit.expand, children: [
                Image.asset(
                  'assets/qibla_bg.jpg',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF0E5A41), _green],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.black.withOpacity(0.35),
                        Colors.transparent,
                        _green,
                      ],
                      stops: const [0, 0.5, 1],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ]),
            ),
            // عنوان
            Positioned(
              top: topPad + 8,
              left: 0,
              right: 0,
              child: const Column(children: [
                Text('قبلہ',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.bold)),
                Text('Qibla Direction',
                    style: TextStyle(color: Colors.white, fontSize: 15)),
              ]),
            ),
            Positioned(
                top: topPad + 10,
                left: 12,
                child: _roundBtn(Icons.chevron_left, widget.onBack)),
            Positioned(
                top: topPad + 10,
                right: 12,
                child: _roundBtn(
                    Icons.settings,
                    () => Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => const SettingsScreen())))),
            // کمپاس
            Positioned(
              top: compassTop,
              left: (w - d) / 2,
              width: d,
              height: d,
              child: _compass(d),
            ),
            // موجودہ مقام کا کارڈ (بائیں)
            Positioned(
              left: 8,
              width: cw,
              top: compassTop + d * 0.5,
              height: d * 0.46,
              child: _sideCard(
                onTap: () => showLocationPicker(context),
                icon: Icons.location_on,
                label: 'موجودہ مقام',
                big: s.city,
                small: s.autoGps ? 'GPS' : s.country,
              ),
            ),
            // قبلہ کا زاویہ (دائیں)
            Positioned(
              right: 8,
              width: cw,
              top: compassTop + d * 0.5,
              height: d * 0.46,
              child: _sideCard(
                onTap: null,
                icon: Icons.view_in_ar,
                label: 'قبلہ کا زاویہ',
                big: '$deg°',
                small: '',
                bigSize: 24,
              ),
            ),
          ]),
        ),
      );
    });
  }

  Widget _roundBtn(IconData icon, VoidCallback onTap) => InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _green.withOpacity(0.85),
            border: Border.all(color: _greenMid, width: 2),
          ),
          child: Icon(icon, color: Colors.white),
        ),
      );

  Widget _sideCard({
    required VoidCallback? onTap,
    required IconData icon,
    required String label,
    required String big,
    required String small,
    double bigSize = 18,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: _green.withOpacity(0.92),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _greenMid),
        ),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, color: const Color(0xFF2ECC71), size: 26),
            const SizedBox(height: 2),
            Text(label,
                style: const TextStyle(color: Colors.white70, fontSize: 11)),
            Text(big,
                style: TextStyle(
                    color: Colors.white,
                    fontSize: bigSize,
                    fontWeight: FontWeight.bold)),
            if (small.isNotEmpty)
              Text(small,
                  style:
                      const TextStyle(color: Colors.white60, fontSize: 11)),
          ]),
        ),
      ),
    );
  }

  // ---------- کمپاس ----------
  Widget _compass(double d) {
    final h = live ? (heading ?? 0.0) : manual;
    final aligned = live && heading != null && _diff(heading!, bearing).abs() < 3;

    return Stack(alignment: Alignment.center, children: [
      // گھومنے والی ڈائل + سرخ تیر (تیر قبلہ کی طرف رہتا ہے)
      Transform.rotate(
        angle: -h * pi / 180,
        child: SizedBox(
          width: d,
          height: d,
          child: Stack(children: [
            CustomPaint(size: Size(d, d), painter: _DialPainter()),
            Transform.rotate(
              angle: bearing * pi / 180,
              child: CustomPaint(size: Size(d, d), painter: _NeedlePainter()),
            ),
          ]),
        ),
      ),
      // درمیان میں کعبہ
      Container(
        width: d * 0.27,
        height: d * 0.27,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: aligned ? const Color(0xFF2ECC71) : Colors.black38,
              blurRadius: aligned ? 16 : 6,
              spreadRadius: aligned ? 3 : 0,
            ),
          ],
        ),
        child: Center(child: _kaaba(d * 0.16)),
      ),
      // اوپر سنہری نشان (موبائل کا سامنے کا رخ)
      Positioned(
        top: -4,
        child: Transform.rotate(
          angle: pi / 4,
          child: Container(width: 14, height: 14, color: _gold),
        ),
      ),
    ]);
  }

  Widget _kaaba(double size) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: const Color(0xFF111111),
          borderRadius: BorderRadius.circular(3),
        ),
        child: Align(
          alignment: const Alignment(0, -0.35),
          child: Container(height: size * 0.14, color: _gold),
        ),
      );

  // ---------- معلوماتی کارڈ ----------
  Widget _infoCard(bool dark) {
    final deg = bearing;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF1E2A25) : Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(children: [
        Expanded(
          child: Row(children: [
            _kaaba(40),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('کعبہ کا مقام',
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                    Directionality(
                      textDirection: TextDirection.ltr,
                      child: Text(
                          '${fmtLat(_kaabaLat)}\n${fmtLng(_kaabaLng)}',
                          style: const TextStyle(
                              fontSize: 13, fontWeight: FontWeight.w600)),
                    ),
                  ]),
            ),
          ]),
        ),
        Container(width: 1, height: 50, color: _gold),
        const SizedBox(width: 12),
        Expanded(
          child: Row(children: [
            const Icon(Icons.location_on, color: _green, size: 34),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('آپ کی سمت',
                        style: TextStyle(fontSize: 12, color: Colors.grey)),
                    Text('${compassUrdu(deg)} (${compassAbbr(deg)})',
                        style: const TextStyle(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                    Text('${deg.round()}°',
                        style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: _greenMid)),
                  ]),
            ),
          ]),
        ),
      ]),
    );
  }

  // ---------- فاصلہ اور حالت ----------
  Widget _statusRow() {
    final km = distanceKm(s.latitude, s.longitude, _kaabaLat, _kaabaLng);
    final aligned = live && heading != null && _diff(heading!, bearing).abs() < 3;
    final kmText = km.round().toString().replaceAllMapped(
        RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
    return Row(children: [
      Expanded(
        child: Text(_status(),
            style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: aligned ? const Color(0xFF1E9E55) : null)),
      ),
      const Icon(Icons.straighten, size: 18, color: _greenMid),
      const SizedBox(width: 4),
      Text('کعبہ تک $kmText کلومیٹر',
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
    ]);
  }

  // ---------- چار بٹن ----------
  Widget _actions(bool dark) {
    Widget btn(IconData icon, String text, VoidCallback onTap,
        {bool selected = false}) {
      return Expanded(
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            height: 78,
            margin: const EdgeInsets.symmetric(horizontal: 3),
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: selected
                  ? _greenMid
                  : (dark ? const Color(0xFF1E2A25) : Colors.white),
              borderRadius: BorderRadius.circular(14),
              boxShadow: const [
                BoxShadow(color: Colors.black12, blurRadius: 4)
              ],
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, size: 26, color: selected ? Colors.white : null),
              const SizedBox(height: 4),
              Text(text,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: selected ? Colors.white : null)),
            ]),
          ),
        ),
      );
    }

    return Column(children: [
      Row(children: [
        btn(Icons.search, 'دستی طور پر شہر منتخب کریں',
            () => showLocationPicker(context)),
        btn(Icons.my_location, 'موجودہ مقام استعمال کریں', _useGps),
        btn(Icons.map_outlined, 'نقشے میں دیکھیں', _openMap),
        btn(Icons.explore, live ? 'کمپاس (لائیو)' : 'کمپاس (بند)', _toggleLive,
            selected: live),
      ]),
      Wrap(
        alignment: WrapAlignment.center,
        spacing: 4,
        children: [
          TextButton.icon(
            onPressed: _easy,
            icon: const Icon(Icons.lightbulb_outline, size: 18),
            label: const Text('آسان طریقہ'),
          ),
          TextButton.icon(
            onPressed: _calibrate,
            icon: const Icon(Icons.tune, size: 18),
            label: const Text('کمپاس کیلیبریٹ کریں'),
          ),
        ],
      ),
    ]);
  }

  // ---------- مقامات کی تفصیل ----------
  Widget _locationDetails() {
    Widget kv(String k, String v) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(children: [
            Expanded(
                child: Text(k,
                    style:
                        const TextStyle(color: Colors.white70, fontSize: 11))),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Text(v,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600)),
            ),
          ]),
        );

    Widget col(Widget leading, String title, List<Widget> rows) => Expanded(
          child: Column(children: [
            Row(children: [
              leading,
              const SizedBox(width: 8),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold)),
            ]),
            const SizedBox(height: 6),
            ...rows,
          ]),
        );

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [_green, Color(0xFF0B5A3C)]),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        col(
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                border: Border.all(color: _gold, width: 2)),
            child: Center(child: _kaaba(22)),
          ),
          'کعبہ کا مقام',
          [
            kv('عرض بلد (Latitude)', fmtLat(_kaabaLat)),
            kv('طول بلد (Longitude)', fmtLng(_kaabaLng)),
            kv('شہر', 'مکہ مکرمہ'),
            kv('ملک', 'سعودی عرب'),
          ],
        ),
        Container(
            width: 1,
            height: 110,
            margin: const EdgeInsets.symmetric(horizontal: 10),
            color: _gold.withOpacity(0.6)),
        col(
          const Icon(Icons.public, color: Colors.white, size: 36),
          'میرا مقام',
          [
            kv('عرض بلد (Latitude)', fmtLat(s.latitude)),
            kv('طول بلد (Longitude)', fmtLng(s.longitude)),
            kv('شہر', s.city),
            kv('ملک', s.autoGps ? '-' : s.country),
          ],
        ),
      ]),
    );
  }
}

// ================= ڈائل کی ڈرائنگ =================
class _DialPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;

    // سنہری کنارہ اور سبز چہرہ
    canvas.drawCircle(c, r, Paint()..color = _gold);
    canvas.drawCircle(c, r * 0.965, Paint()..color = const Color(0xFF0E7A52));
    canvas.drawCircle(c, r * 0.93, Paint()..color = const Color(0xFF0B4A33));

    // اندرونی دائرے اور سیدھی لکیریں
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = const Color(0xFF2E9E6E);
    canvas.drawCircle(c, r * 0.62, ring);
    canvas.drawCircle(c, r * 0.42, ring);
    canvas.drawLine(Offset(c.dx - r * 0.9, c.dy), Offset(c.dx + r * 0.9, c.dy), ring);
    canvas.drawLine(Offset(c.dx, c.dy - r * 0.9), Offset(c.dx, c.dy + r * 0.9), ring);

    // نشانات (ہر 5 ڈگری)
    for (int d = 0; d < 360; d += 5) {
      final major = d % 45 == 0;
      final mid = d % 15 == 0;
      final len = major ? r * 0.09 : (mid ? r * 0.06 : r * 0.035);
      final a = (d - 90) * pi / 180;
      final dir = Offset(cos(a), sin(a));
      canvas.drawLine(
        c + dir * (r * 0.92),
        c + dir * (r * 0.92 - len),
        Paint()
          ..color = major ? _gold : Colors.white70
          ..strokeWidth = major ? 2 : 1,
      );
    }

    void label(String t, double deg,
        {double size = 12, bool bold = false, double radius = 0.76, bool rotate = false}) {
      final tp = TextPainter(
        text: TextSpan(
            text: t,
            style: TextStyle(
                color: Colors.white,
                fontSize: size,
                fontWeight: bold ? FontWeight.bold : FontWeight.w500)),
        textDirection: TextDirection.ltr,
      )..layout();
      final a = (deg - 90) * pi / 180;
      final pos = c + Offset(cos(a), sin(a)) * (r * radius);
      canvas.save();
      canvas.translate(pos.dx, pos.dy);
      if (rotate) {
        canvas.rotate(((deg > 90 && deg < 270) ? deg - 180 : deg) * pi / 180);
      }
      canvas.translate(-tp.width / 2, -tp.height / 2);
      tp.paint(canvas, Offset.zero);
      canvas.restore();
    }

    label('N', 0, size: r * 0.2, bold: true);
    label('E', 90, size: r * 0.17, bold: true);
    label('S', 180, size: r * 0.17, bold: true);
    label('W', 270, size: r * 0.17, bold: true);
    label('NE', 45, rotate: true, size: r * 0.1);
    label('SE', 135, rotate: true, size: r * 0.1);
    label('SW', 225, rotate: true, size: r * 0.1);
    label('NW', 315, rotate: true, size: r * 0.1);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class _NeedlePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final path = Path()
      ..moveTo(c.dx, c.dy - r * 0.68)
      ..lineTo(c.dx - r * 0.1, c.dy)
      ..lineTo(c.dx + r * 0.1, c.dy)
      ..close();
    canvas.drawPath(
      path,
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xFFFF3B30), Color(0xFF9E0F0F)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromCircle(center: c, radius: r)),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
