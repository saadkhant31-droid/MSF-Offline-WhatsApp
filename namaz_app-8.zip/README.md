# نماز ایپ

## چلانے کا طریقہ
1. Flutter انسٹال کریں، پھر اس فولڈر میں:  flutter create . --org com.yourname --project-name namaz_app
   (یہ android/ios فولڈر بنا دے گا، lib اور pubspec وہی رہیں گے)
2. flutter pub get
3. flutter run

اگر adhan_dart کے ورژن کی وجہ سے کلاس کے نام نہ ملیں تو pubspec میں ورژن چیک کریں۔

## Android اجازتیں (GPS کے لیے)
android/app/src/main/AndroidManifest.xml میں <manifest> کے اندر شامل کریں:
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>

## قبلہ اسکرین
- کمپاس کے لیے کوئی اجازت درکار نہیں (موبائل کا سینسر چاہیے)۔
- "نقشے میں دیکھیں" کے لیے AndroidManifest.xml میں <manifest> کے اندر شامل کریں:
    <queries>
      <intent>
        <action android:name="android.intent.action.VIEW"/>
        <data android:scheme="https"/>
      </intent>
    </queries>
- کعبہ کی پس منظر تصویر اختیاری ہے: assets/qibla_bg.jpg کے نام سے رکھ دیں۔

## کیلنڈر اسکرین
- پس منظر تصویر اختیاری ہے: assets/calendar_bg.jpg کے نام سے رکھ دیں۔
- ہجری تاریخیں hijri پیکیج (ام القریٰ) سے آتی ہیں؛ رویتِ ہلال کے فرق کے لیے سیٹنگز میں ±دن کی تبدیلی ہے۔

## گھڑی وال پیپر (9 ڈیزائن)
- ایپ کے اندر: ہوم ← "گھڑی وال پیپر" (یا مزید ← گھڑی وال پیپر)۔
- لائیو وال پیپر کے لیے اینڈرائیڈ حصہ شامل کریں (flutter create . کے بعد ایک بار):
      python3 android_native/setup_android.py
- پس منظر کی تصاویر اختیاری: assets/wallpaper/style1.jpg ... style9.jpg
- ہر ڈیزائن کے اوپر "MSF Islamic App" لکھا آتا ہے۔

## GitHub Actions سے APK بنانا
- یہ پروجیکٹ Flutter کا ہے، اسے الگ نئی ریپوزٹری میں اپلوڈ کریں (زپ کھول کر اندر کی فائلیں ریپو کی جڑ میں)۔
- .github/workflows/build-apk.yml پہلے سے موجود ہے۔ Actions ٹیب سے "Build APK" چلائیں۔
- مکمل ہونے پر Artifacts میں msf-prayer-app-apk ڈاؤن لوڈ کریں۔

## فونٹس
- اردو: جمیل نوری نستعلیق (assets/fonts/JameelNooriNastaleeq.ttf) پوری ایپ میں۔
- عربی/قرآنی: المصحف، المجید، القلم۔ سیٹنگز ← "عربی / قرآنی فونٹ" سے بدلیں۔
- لائیو وال پیپر کے اردو متن میں بھی جمیل نوری استعمال ہوتا ہے۔
