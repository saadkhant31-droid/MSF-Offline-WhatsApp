package __PACKAGE__

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/**
 * سادہ مگر مضبوط لائیو وال پیپر: اینڈرائیڈ کی اپنی Canvas سے چلتی گھڑی، تاریخ، اوقاتِ نماز۔
 * ڈیٹا فلٹر ایپ (wallpaper_sync.dart) محفوظ کرتی ہے، اس لیے فلٹر انجن کی ضرورت نہیں۔
 */
class SimpleClockWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ClockEngine()

    inner class ClockEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var data: JSONObject? = null
        private var lastLoad = 0L
        private val gold = 0xFFE6B94D.toInt()
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // جمیل نوری نستعلیق (فلٹر کے assets سے)
        private val urduFace: Typeface by lazy {
            try {
                Typeface.createFromAsset(assets, "flutter_assets/assets/fonts/JameelNooriNastaleeq.ttf")
            } catch (e: Exception) {
                Typeface.DEFAULT
            }
        }

        private val runner = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 1000)
            }
        }

        private fun loadData(): JSONObject? {
            return try {
                val sp = applicationContext.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                val s = sp.getString("flutter.wp_data", null) ?: return null
                JSONObject(s)
            } catch (e: Exception) {
                null
            }
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(runner)
            if (v) handler.post(runner)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(runner)
            super.onDestroy()
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = holder.lockCanvas()
                if (c != null) render(c, c.width.toFloat(), c.height.toFloat())
            } catch (e: Exception) {
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (e: Exception) {}
                }
            }
        }

        private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false, urdu: Boolean = false) {
            p.reset()
            p.isAntiAlias = true
            p.textAlign = Paint.Align.CENTER
            p.textSize = size
            p.color = color
            p.typeface = if (urdu) urduFace else if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.isFakeBoldText = bold && urdu
            c.drawText(s, x, y, p)
        }

        private fun render(c: Canvas, w: Float, h: Float) {
            val nowMs = System.currentTimeMillis()
            if (data == null || nowMs - lastLoad > 20000) {
                data = loadData()
                lastLoad = nowMs
            }
            val d = data

            // پس منظر
            p.reset()
            p.isAntiAlias = true
            p.shader = LinearGradient(0f, 0f, 0f, h, 0xFF0E5A41.toInt(), 0xFF041B13.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = null

            // عنوان: MSF Islamic App
            val tp = Paint(Paint.ANTI_ALIAS_FLAG)
            tp.typeface = Typeface.DEFAULT_BOLD
            tp.textSize = w * 0.075f
            val tb = Paint(tp)
            tb.textSize = w * 0.06f
            val a = "MSF "
            val b = "Islamic App"
            val wa = tp.measureText(a)
            val wb = tb.measureText(b)
            val x0 = (w - wa - wb) / 2f
            val ty = h * 0.075f
            tp.color = gold
            c.drawText(a, x0, ty, tp)
            tb.color = Color.WHITE
            c.drawText(b, x0 + wa, ty, tb)

            // اینالاگ گھڑی
            val cx = w / 2f
            val cy = h * 0.255f
            val r = w * 0.27f
            p.reset(); p.isAntiAlias = true
            p.color = gold; c.drawCircle(cx, cy, r, p)
            p.color = 0xFF062A1F.toInt(); c.drawCircle(cx, cy, r * 0.95f, p)
            p.color = 0xFF0B4A33.toInt(); c.drawCircle(cx, cy, r * 0.91f, p)
            for (i in 0 until 60) {
                val ang = Math.toRadians((i * 6 - 90).toDouble())
                val major = i % 5 == 0
                val len = if (major) r * 0.09f else r * 0.04f
                p.color = if (major) Color.WHITE else 0x99FFFFFF.toInt()
                p.strokeWidth = if (major) 5f else 2f
                val ca = cos(ang).toFloat()
                val sa = sin(ang).toFloat()
                c.drawLine(cx + ca * r * 0.87f, cy + sa * r * 0.87f, cx + ca * (r * 0.87f - len), cy + sa * (r * 0.87f - len), p)
            }
            val nums = listOf(12 to 0.0, 3 to 90.0, 6 to 180.0, 9 to 270.0)
            for ((n, deg) in nums) {
                val ang = Math.toRadians(deg - 90)
                text(c, n.toString(), cx + cos(ang).toFloat() * r * 0.68f, cy + sin(ang).toFloat() * r * 0.68f + r * 0.07f, r * 0.2f, Color.WHITE, true)
            }
            val cal = Calendar.getInstance()
            val sec = cal.get(Calendar.SECOND)
            val min = cal.get(Calendar.MINUTE)
            val hr = cal.get(Calendar.HOUR) + min / 60f
            fun hand(deg: Float, len: Float, width: Float, color: Int) {
                val ang = Math.toRadians((deg - 90).toDouble())
                p.color = color
                p.strokeWidth = width
                p.strokeCap = Paint.Cap.ROUND
                c.drawLine(cx - cos(ang).toFloat() * r * 0.08f, cy - sin(ang).toFloat() * r * 0.08f,
                    cx + cos(ang).toFloat() * r * len, cy + sin(ang).toFloat() * r * len, p)
            }
            hand(hr * 30f, 0.46f, r * 0.05f, gold)
            hand((min + sec / 60f) * 6f, 0.68f, r * 0.035f, gold)
            hand(sec * 6f, 0.8f, r * 0.014f, 0xFF3DDC84.toInt())
            p.color = gold
            c.drawCircle(cx, cy, r * 0.05f, p)

            if (d == null) {
                text(c, "MSF Prayer App کھولیں تاکہ اوقات لگ جائیں", cx, h * 0.62f, w * 0.045f, Color.WHITE, urdu = true)
                return
            }

            val h24 = d.optBoolean("h24", false)
            val tf = SimpleDateFormat(if (h24) "HH:mm:ss" else "hh:mm:ss a", Locale.US)
            val hm = SimpleDateFormat(if (h24) "HH:mm" else "hh:mm", Locale.US)

            // ڈیجیٹل وقت
            text(c, tf.format(Date(nowMs)), cx, cy + r + w * 0.15f, w * 0.1f, Color.WHITE, true)

            // آج کا دن
            val ymd = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(nowMs))
            val days = d.getJSONArray("days")
            var idx = 0
            for (i in 0 until days.length()) {
                if (days.getJSONObject(i).getString("ymd") == ymd) { idx = i; break }
            }
            val day = days.getJSONObject(idx)
            val yy = cy + r + w * 0.15f
            text(c, day.optString("wd") + "، " + day.optString("greg"), cx, yy + w * 0.075f, w * 0.045f, Color.WHITE, urdu = true)
            text(c, day.optString("hijri") + " ہجری", cx, yy + w * 0.14f, w * 0.045f, gold, true, true)
            text(c, d.optString("city") + " • " + d.optString("country"), cx, yy + w * 0.2f, w * 0.038f, 0xCCFFFFFF.toInt(), urdu = true)

            // اگلی نماز
            val pr = day.getJSONArray("p")
            var nextName = ""
            var nextMs = 0L
            for (i in 0 until pr.length()) {
                val o = pr.getJSONObject(i)
                if (o.getLong("s") > nowMs) { nextName = o.getString("n"); nextMs = o.getLong("s"); break }
            }
            if (nextName.isEmpty()) {
                if (idx + 1 < days.length()) {
                    val o = days.getJSONObject(idx + 1).getJSONArray("p").getJSONObject(0)
                    nextName = o.getString("n"); nextMs = o.getLong("s")
                } else {
                    val o = pr.getJSONObject(0)
                    nextName = o.getString("n"); nextMs = o.getLong("s") + 86400000L
                }
            }
            var left = (nextMs - nowMs) / 1000
            if (left < 0) left = 0
            val cd = String.format(Locale.US, "%02d:%02d:%02d", left / 3600, (left % 3600) / 60, left % 60)

            val boxTop = yy + w * 0.27f
            val rect = RectF(w * 0.08f, boxTop, w * 0.92f, boxTop + w * 0.2f)
            p.reset(); p.isAntiAlias = true
            p.color = 0xCC0B3D2E.toInt(); c.drawRoundRect(rect, w * 0.05f, w * 0.05f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = gold
            c.drawRoundRect(rect, w * 0.05f, w * 0.05f, p)
            text(c, "اگلی نماز: $nextName", cx, rect.top + w * 0.07f, w * 0.045f, Color.WHITE, true, true)
            text(c, cd, cx, rect.top + w * 0.16f, w * 0.075f, gold, true)

            // پانچ نمازیں
            val top = rect.bottom + w * 0.05f
            val gap = w * 0.02f
            val bw = (w * 0.9f - gap * 4) / 5f
            val bh = w * 0.2f
            for (i in 0 until pr.length().coerceAtMost(5)) {
                val o = pr.getJSONObject(i)
                val s = o.getLong("s")
                val e = o.getLong("e")
                val left0 = w * 0.05f + i * (bw + gap)
                val rr = RectF(left0, top, left0 + bw, top + bh)
                val current = nowMs in s until e
                val isNext = o.getString("n") == nextName
                p.reset(); p.isAntiAlias = true
                p.style = Paint.Style.FILL
                p.color = if (current) 0xFFE6B94D.toInt() else if (isNext) 0xFF1E9E55.toInt() else 0xB30B3D2E.toInt()
                c.drawRoundRect(rr, w * 0.03f, w * 0.03f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = gold
                c.drawRoundRect(rr, w * 0.03f, w * 0.03f, p)
                val tc = if (current) 0xFF062A1F.toInt() else Color.WHITE
                text(c, o.getString("n"), rr.centerX(), rr.top + bh * 0.4f, w * 0.042f, tc, true, true)
                text(c, hm.format(Date(s)), rr.centerX(), rr.top + bh * 0.78f, w * 0.036f, tc)
            }

            // قبلہ
            text(c, "قبلہ کی سمت: " + d.optInt("qibla") + "°", cx, top + bh + w * 0.1f, w * 0.04f, 0xCCFFFFFF.toInt(), urdu = true)
        }
    }
}
