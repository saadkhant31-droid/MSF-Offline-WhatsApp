package __PACKAGE__

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.FileInputStream

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "msf/wallpaper")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "setLiveWallpaper" -> {
                        try {
                            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                            intent.putExtra(
                                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                                ComponentName(this, SimpleClockWallpaperService::class.java)
                            )
                            startActivity(intent)
                            result.success(true)
                        } catch (e: Exception) {
                            try {
                                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                                result.success(true)
                            } catch (e2: Exception) {
                                result.success(false)
                            }
                        }
                    }
                    "setImageWallpaper" -> {
                        val path = call.argument<String>("path")
                        val which = call.argument<Int>("which") ?: 3
                        if (path == null) {
                            result.success(false)
                            return@setMethodCallHandler
                        }
                        Thread {
                            var ok = false
                            try {
                                val wm = WallpaperManager.getInstance(applicationContext)
                                FileInputStream(path).use { ins ->
                                    if (Build.VERSION.SDK_INT >= 24) {
                                        val flag = when (which) {
                                            1 -> WallpaperManager.FLAG_SYSTEM
                                            2 -> WallpaperManager.FLAG_LOCK
                                            else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                                        }
                                        wm.setStream(ins, null, true, flag)
                                    } else {
                                        wm.setStream(ins)
                                    }
                                }
                                ok = true
                            } catch (e: Exception) {
                            }
                            runOnUiThread { result.success(ok) }
                        }.start()
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
