KOHAT PRAYER TIMES — MONTHLY SET

Included: January through December.
Removed from the displayed tables: Gregorian year, Hijri year/date labels,
weekday names, and the date column. The month name and prayer-time columns
(Fajr, Sunrise, Dhuhr, Asr, Maghrib, Isha) remain.

These are image tables cropped from the screenshots supplied in the chat.
Please verify prayer times with your local mosque before relying on them.
