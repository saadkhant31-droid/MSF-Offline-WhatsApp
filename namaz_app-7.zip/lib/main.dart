import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import 'app_settings.dart';
import 'main_shell.dart';
import 'wallpaper_entry.dart';

/// اینڈرائیڈ لائیو وال پیپر کا داخلی نقطہ۔
/// یہ لازمی main.dart میں ہو، ورنہ انجن اسے ڈھونڈ نہیں پاتا (وال پیپر کالا آتا ہے)
@pragma('vm:entry-point')
Future<void> wallpaperMain() => runWallpaper();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  HijriCalendar.setLocal('ar');
  await appSettings.load();
  runApp(const NamazApp());
}

class NamazApp extends StatelessWidget {
  const NamazApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) {
        final dark = appSettings.theme == 'dark';
        return MaterialApp(
          title: 'MSF Prayer App',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            colorSchemeSeed: const Color(0xFF0B6E4F),
            brightness: dark ? Brightness.dark : Brightness.light,
          ),
          builder: (context, child) => MediaQuery(
            data: MediaQuery.of(context).copyWith(
              textScaler: TextScaler.linear(appSettings.fontSize / 16),
            ),
            child: Directionality(
                textDirection: TextDirection.rtl, child: child!),
          ),
          home: const MainShell(),
        );
      },
    );
  }
}
