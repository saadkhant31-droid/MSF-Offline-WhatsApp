import 'package:flutter/material.dart';
import 'app_settings.dart';
import 'wallpaper_styles.dart';

/// لائیو وال پیپر چلاتا ہے۔ اینڈرائیڈ سروس "wallpaperMain" (جو main.dart میں ہے) کو بلاتی ہے،
/// اور وہ یہاں پہنچتا ہے۔
Future<void> runWallpaper() async {
  WidgetsFlutterBinding.ensureInitialized();
  await appSettings.load();
  runApp(const _WallpaperApp());
}

class _WallpaperApp extends StatelessWidget {
  const _WallpaperApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, brightness: Brightness.dark),
      home: const Scaffold(
        backgroundColor: Colors.black,
        body: TickingWallpaper(),
      ),
    );
  }
}
