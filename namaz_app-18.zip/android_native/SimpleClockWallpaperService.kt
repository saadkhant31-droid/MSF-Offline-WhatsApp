package __PACKAGE__

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/**
 * لائیو وال پیپر کے 9 انداز۔ سب اینڈرائیڈ کی اپنی Canvas سے بنتے ہیں، فلٹر انجن کی ضرورت نہیں۔
 * ڈیٹا ایپ (wallpaper_sync.dart) محفوظ کرتی ہے، اور ایپ میں منتخب انداز یہاں خود لگ جاتا ہے۔
 *
 * clock: 0 اینالاگ (12/3/6/9)  1 اینالاگ (سب ہندسے)  2 اینالاگ (صرف نشانات)
 *        3 ڈیجیٹل دائرہ  4 بڑا ڈیجیٹل  5 نشانات والا دائرہ + ڈیجیٹل
 * cards: 0 ڈبے  1 رنگین  2 کریم  3 محراب  4 سیدھی قطار  5 جدول (باقی وقت کے ساتھ)
 */
private data class Cfg(
    val bg1: Int, val bg2: Int, val accent: Int,
    val clock: Int, val pill: Boolean, val cards: Int, val frame: Boolean
)

private val GOLD = 0xFFE6B94D.toInt()

private val STYLES = listOf(
    Cfg(0xFF0E5A41.toInt(), 0xFF062A1F.toInt(), GOLD, 0, true, 1, false),
    Cfg(0xFF0B4A33.toInt(), 0xFF052418.toInt(), GOLD, 3, false, 2, false),
    Cfg(0xFF0B4A33.toInt(), 0xFF041B13.toInt(), GOLD, 4, false, 5, true),
    Cfg(0xFF0B3D2E.toInt(), 0xFF05261C.toInt(), GOLD, 5, true, 3, false),
    Cfg(0xFF11624A.toInt(), 0xFF062A1F.toInt(), GOLD, 2, false, 1, false),
    Cfg(0xFF0B4A33.toInt(), 0xFF041B13.toInt(), GOLD, 4, false, 3, true),
    Cfg(0xFF0B4A33.toInt(), 0xFF052418.toInt(), GOLD, 5, false, 4, false),
    Cfg(0xFF0B4A33.toInt(), 0xFF052418.toInt(), GOLD, 1, true, 0, false),
    Cfg(0xFF0B4A33.toInt(), 0xFF041B13.toInt(), 0xFFF4D98C.toInt(), 4, false, 4, true)
)

private val PASTEL = listOf(
    Pair(0xFFE6F4FC.toInt(), 0xFF9CD0EA.toInt()),
    Pair(0xFFFFF1C2.toInt(), 0xFFE7B84A.toInt()),
    Pair(0xFFFBD99C.toInt(), 0xFFE59A2B.toInt()),
    Pair(0xFFC76FA8.toInt(), 0xFF7A2E7A.toInt()),
    Pair(0xFF4A6CC0.toInt(), 0xFF1B2F78.toInt())
)

class SimpleClockWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ClockEngine()

    inner class ClockEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var data: JSONObject? = null
        private var lastLoad = 0L
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        private val urduFace: Typeface by lazy {
            try {
                Typeface.createFromAsset(assets, "flutter_assets/assets/fonts/JameelNooriNastaleeq.ttf")
            } catch (e: Exception) {
                Typeface.DEFAULT
            }
        }

        private var accent = GOLD
        private var W = 0f
        private var H = 0f
        private var nowMs = 0L
        private var h24 = false
        private var kScale = 1f
        private val banners = HashMap<Int, Bitmap?>()

        private fun banner(idx: Int): Bitmap? {
            if (banners.containsKey(idx)) return banners[idx]
            var bm: Bitmap? = null
            try {
                assets.open("flutter_assets/assets/wallpaper/style${idx + 1}.jpg").use { bm = BitmapFactory.decodeStream(it) }
            } catch (e: Exception) {
            }
            banners[idx] = bm
            return bm
        }

        private val runner = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 1000)
            }
        }

        private fun loadData(): JSONObject? {
            return try {
                val sp = applicationContext.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                val s = sp.getString("flutter.wp_data", null) ?: return null
                JSONObject(s)
            } catch (e: Exception) {
                null
            }
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(runner)
            if (v) handler.post(runner)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(runner)
            super.onDestroy()
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = holder.lockCanvas()
                if (c != null) render(c, c.width.toFloat(), c.height.toFloat())
            } catch (e: Exception) {
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (e: Exception) {}
                }
            }
        }

        // ---------- چھوٹے مددگار ----------
        private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
                         bold: Boolean = false, urdu: Boolean = false) {
            p.reset()
            p.isAntiAlias = true
            p.textAlign = Paint.Align.CENTER
            p.textSize = size
            p.color = color
            p.typeface = if (urdu) urduFace else if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.isFakeBoldText = bold && urdu
            c.drawText(s, x, y, p)
        }

        private fun fill(c: Canvas, r: RectF, rad: Float, color: Int) {
            p.reset(); p.isAntiAlias = true; p.color = color
            c.drawRoundRect(r, rad, rad, p)
        }

        private fun stroke(c: Canvas, r: RectF, rad: Float, color: Int, width: Float) {
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE
            p.strokeWidth = width; p.color = color
            c.drawRoundRect(r, rad, rad, p)
        }

        private fun hm(ms: Long): String =
            SimpleDateFormat(if (h24) "HH:mm" else "hh:mm", Locale.US).format(Date(ms))

        private fun hms(sec: Long): String {
            val s = if (sec < 0) 0L else sec
            return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        }

        private fun untilSlot(s: Long, e: Long): Long =
            if (nowMs < s) s - nowMs else if (nowMs < e) e - nowMs else s + 86400000L - nowMs

        private fun styleIndex(d: JSONObject?): Int {
            val s = d?.optString("style", "style1") ?: "style1"
            val n = s.filter { it.isDigit() }.toIntOrNull() ?: 1
            return (n - 1).coerceIn(0, STYLES.size - 1)
        }

        // ---------- اصل ڈرائنگ ----------
        private fun render(c: Canvas, w: Float, h: Float) {
            W = w; H = h
            nowMs = System.currentTimeMillis()
            if (data == null || nowMs - lastLoad > 20000) {
                data = loadData()
                lastLoad = nowMs
            }
            val d = data
            val si = styleIndex(d)
            val cfg = STYLES[si]
            accent = cfg.accent
            h24 = d?.optBoolean("h24", false) ?: false

            p.reset(); p.isAntiAlias = true
            p.shader = LinearGradient(0f, 0f, 0f, h, cfg.bg1, cfg.bg2, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = null
            // ڈیمو ڈیزائن کی کعبہ/مسجد کی پٹی (اوپر)
            val bm = banner(si)
            if (bm != null) {
                val bh = w * bm.height / bm.width
                p.reset(); p.isAntiAlias = true; p.isFilterBitmap = true
                c.drawBitmap(bm, null, RectF(0f, 0f, w, bh), p)
                p.reset(); p.isAntiAlias = true
                p.shader = LinearGradient(0f, bh * 0.55f, 0f, bh * 1.05f, cfg.bg1 and 0x00FFFFFF, cfg.bg1, Shader.TileMode.CLAMP)
                c.drawRect(0f, bh * 0.55f, w, bh * 1.05f, p)
                p.shader = null
            }
            if (cfg.frame) stroke(c, RectF(w * 0.03f, w * 0.03f, w * 0.97f, h - w * 0.03f), w * 0.1f, accent, 6f)

            // چھوٹی اسکرین پر سب کچھ سمیٹ کر فٹ کرتا ہے
            val k = if (h < w * 1.95f) h / (w * 1.95f) else 1f
            kScale = k
            c.save()
            c.scale(k, k, w / 2f, 0f)
            try {
                content(c, cfg, d)
            } catch (e: Exception) {
            }
            c.restore()
        }

        private fun content(c: Canvas, cfg: Cfg, d: JSONObject?) {
            val cal = Calendar.getInstance()
            // لاک اسکرین پر فون کی اپنی گھڑی ہو تو وال پیپر کی گھڑی چھپا کر باقی معلومات نیچے رکھتا ہے
            val showClock = d?.optBoolean("showClock", true) ?: true
            var y: Float
            if (showClock) {
                y = drawTitle(c, W * 0.14f)
                y = drawClock(c, cfg, cal, d, y)
            } else {
                y = drawTitle(c, (H * 0.30f) / kScale)
            }
            if (d == null) {
                text(c, "MSF Prayer App کھولیں تاکہ اوقات لگ جائیں", W / 2f, y + W * 0.1f, W * 0.05f, Color.WHITE, false, true)
                return
            }
            val ymd = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(nowMs))
            val days = d.getJSONArray("days")
            var idx = 0
            for (i in 0 until days.length()) {
                if (days.getJSONObject(i).getString("ymd") == ymd) { idx = i; break }
            }
            val day = days.getJSONObject(idx)
            val pr = day.getJSONArray("p")

            var nextName = ""
            var nextMs = 0L
            for (i in 0 until pr.length()) {
                val o = pr.getJSONObject(i)
                if (o.getLong("s") > nowMs) { nextName = o.getString("n"); nextMs = o.getLong("s"); break }
            }
            if (nextName.isEmpty()) {
                if (idx + 1 < days.length()) {
                    val o = days.getJSONObject(idx + 1).getJSONArray("p").getJSONObject(0)
                    nextName = o.getString("n"); nextMs = o.getLong("s")
                } else {
                    val o = pr.getJSONObject(0)
                    nextName = o.getString("n"); nextMs = o.getLong("s") + 86400000L
                }
            }

            // تاریخیں
            text(c, day.optString("wd") + "، " + day.optString("greg"), W / 2f, y + W * 0.05f, W * 0.05f, Color.WHITE, false, true)
            text(c, day.optString("hijri") + " ہجری", W / 2f, y + W * 0.115f, W * 0.05f, accent, true, true)
            text(c, d.optString("city") + " • " + d.optString("country"), W / 2f, y + W * 0.17f, W * 0.04f, 0xCCFFFFFF.toInt(), false, true)
            y += W * 0.21f

            // اگلی نماز
            val rect = RectF(W * 0.08f, y, W * 0.92f, y + W * 0.2f)
            fill(c, rect, W * 0.05f, 0xCC0B3D2E.toInt())
            stroke(c, rect, W * 0.05f, accent, 3f)
            text(c, "اگلی نماز: $nextName", W / 2f, rect.top + W * 0.07f, W * 0.05f, Color.WHITE, true, true)
            text(c, hms((nextMs - nowMs) / 1000), W / 2f, rect.top + W * 0.16f, W * 0.075f, accent, true)
            y = rect.bottom + W * 0.04f

            // نمازیں
            y = drawPrayers(c, cfg, pr, y, nextName)

            text(c, "قبلہ کی سمت: " + d.optInt("qibla") + "°", W / 2f, y + W * 0.06f, W * 0.042f, 0xCCFFFFFF.toInt(), false, true)
        }

        private fun drawTitle(c: Canvas, ty: Float): Float {
            val tp = Paint(Paint.ANTI_ALIAS_FLAG)
            tp.typeface = Typeface.DEFAULT_BOLD
            tp.textSize = W * 0.075f
            val tb = Paint(tp)
            tb.textSize = W * 0.06f
            val a = "MSF "
            val b = "Islamic App"
            val wa = tp.measureText(a)
            val wb = tb.measureText(b)
            val x0 = (W - wa - wb) / 2f
            tp.color = accent
            c.drawText(a, x0, ty, tp)
            tb.color = Color.WHITE
            c.drawText(b, x0 + wa, ty, tb)
            return ty + W * 0.04f
        }

        private fun analogFace(c: Canvas, cx: Float, cy: Float, r: Float, nums: Int, face: Int) {
            p.reset(); p.isAntiAlias = true
            p.color = accent; c.drawCircle(cx, cy, r, p)
            p.color = 0xFF062A1F.toInt(); c.drawCircle(cx, cy, r * 0.95f, p)
            p.color = face; c.drawCircle(cx, cy, r * 0.91f, p)
            for (i in 0 until 60) {
                val ang = Math.toRadians((i * 6 - 90).toDouble())
                val major = i % 5 == 0
                val len = if (major) r * 0.09f else r * 0.04f
                p.reset(); p.isAntiAlias = true
                p.color = if (major) Color.WHITE else 0x99FFFFFF.toInt()
                p.strokeWidth = if (major) 5f else 2f
                val ca = cos(ang).toFloat()
                val sa = sin(ang).toFloat()
                c.drawLine(cx + ca * r * 0.87f, cy + sa * r * 0.87f,
                    cx + ca * (r * 0.87f - len), cy + sa * (r * 0.87f - len), p)
            }
            if (nums == 4) {
                val list = listOf(12 to 0.0, 3 to 90.0, 6 to 180.0, 9 to 270.0)
                for ((n, deg) in list) {
                    val ang = Math.toRadians(deg - 90)
                    text(c, n.toString(), cx + cos(ang).toFloat() * r * 0.68f,
                        cy + sin(ang).toFloat() * r * 0.68f + r * 0.07f, r * 0.2f, Color.WHITE, true)
                }
            } else if (nums == 12) {
                for (n in 1..12) {
                    val ang = Math.toRadians((n * 30 - 90).toDouble())
                    text(c, n.toString(), cx + cos(ang).toFloat() * r * 0.68f,
                        cy + sin(ang).toFloat() * r * 0.68f + r * 0.07f, r * 0.18f, accent, true)
                }
            }
        }

        private fun hands(c: Canvas, cx: Float, cy: Float, r: Float, hr: Float, min: Float, sec: Int) {
            fun hand(deg: Float, len: Float, width: Float, color: Int) {
                val ang = Math.toRadians((deg - 90).toDouble())
                p.reset(); p.isAntiAlias = true
                p.color = color
                p.strokeWidth = width
                p.strokeCap = Paint.Cap.ROUND
                c.drawLine(cx - cos(ang).toFloat() * r * 0.08f, cy - sin(ang).toFloat() * r * 0.08f,
                    cx + cos(ang).toFloat() * r * len, cy + sin(ang).toFloat() * r * len, p)
            }
            hand(hr * 30f, 0.46f, r * 0.05f, accent)
            hand(min * 6f, 0.68f, r * 0.035f, accent)
            hand(sec * 6f, 0.8f, r * 0.014f, 0xFF3DDC84.toInt())
            p.reset(); p.isAntiAlias = true; p.color = accent
            c.drawCircle(cx, cy, r * 0.05f, p)
        }

        /** گھڑی کا حصہ بناتا ہے اور اس کے نیچے کا y واپس کرتا ہے */
        private fun drawClock(c: Canvas, cfg: Cfg, cal: Calendar, d: JSONObject?, top: Float): Float {
            val cx = W / 2f
            val sec = cal.get(Calendar.SECOND)
            val min = cal.get(Calendar.MINUTE)
            val hrs = cal.get(Calendar.HOUR) + min / 60f
            val timeFull = SimpleDateFormat(if (h24) "HH:mm:ss" else "hh:mm:ss a", Locale.US).format(Date(nowMs))
            val hmStr = hm(nowMs)
            val secStr = SimpleDateFormat(if (h24) "ss" else "ss a", Locale.US).format(Date(nowMs))

            when (cfg.clock) {
                0, 1, 2 -> {
                    val r = W * 0.27f
                    val cy = top + r + W * 0.02f
                    analogFace(c, cx, cy, r, if (cfg.clock == 0) 4 else if (cfg.clock == 1) 12 else 0, 0xFF0B4A33.toInt())
                    hands(c, cx, cy, r, hrs, min + sec / 60f, sec)
                    if (cfg.pill) {
                        val rect = RectF(cx - r * 0.62f, cy + r * 0.22f, cx + r * 0.62f, cy + r * 0.56f)
                        fill(c, rect, r * 0.15f, 0xE60B3D2E.toInt())
                        stroke(c, rect, r * 0.15f, accent, 3f)
                        text(c, timeFull, cx, rect.centerY() + r * 0.07f, r * 0.19f, Color.WHITE, true)
                        return cy + r + W * 0.03f
                    }
                    text(c, timeFull, cx, cy + r + W * 0.13f, W * 0.1f, Color.WHITE, true)
                    return cy + r + W * 0.17f
                }
                3 -> {
                    val r = W * 0.3f
                    val cy = top + r + W * 0.02f
                    p.reset(); p.isAntiAlias = true
                    p.color = accent; c.drawCircle(cx, cy, r, p)
                    p.color = 0xFF0B3D2E.toInt(); c.drawCircle(cx, cy, r * 0.94f, p)
                    text(c, "الوقت الآن", cx, cy - r * 0.42f, r * 0.17f, 0xCCFFFFFF.toInt(), false, true)
                    text(c, hmStr, cx, cy + r * 0.18f, r * 0.56f, Color.WHITE, true)
                    text(c, ":$secStr", cx, cy + r * 0.52f, r * 0.2f, accent, true)
                    return cy + r + W * 0.04f
                }
                4 -> {
                    text(c, "الوقت الآن", cx, top + W * 0.07f, W * 0.05f, 0xCCFFFFFF.toInt(), false, true)
                    text(c, hmStr, cx, top + W * 0.27f, W * 0.26f, Color.WHITE, true)
                    text(c, ":$secStr", cx, top + W * 0.37f, W * 0.08f, accent, true)
                    return top + W * 0.42f
                }
                else -> {
                    val r = W * 0.31f
                    val cy = top + r + W * 0.02f
                    analogFace(c, cx, cy, r, 0, 0xFF062A1F.toInt())
                    text(c, hmStr, cx, cy + r * 0.05f, r * 0.5f, Color.WHITE, true)
                    text(c, ":$secStr", cx, cy + r * 0.3f, r * 0.16f, accent, true)
                    val wd = d?.getJSONArray("days")?.getJSONObject(0)?.optString("wd") ?: ""
                    if (wd.isNotEmpty()) text(c, wd, cx, cy + r * 0.58f, r * 0.2f, Color.WHITE, true, true)
                    return cy + r + W * 0.04f
                }
            }
        }

        /** پانچ نمازوں کے خانے */
        private fun drawPrayers(c: Canvas, cfg: Cfg, pr: JSONArray, y0: Float, nextName: String): Float {
            val n = if (pr.length() > 5) 5 else pr.length()
            val gap = W * 0.02f
            val bw = (W * 0.9f - gap * 4) / 5f
            val left0 = W * 0.05f
            val ch = when (cfg.cards) {
                5 -> W * 0.48f
                4, 0 -> W * 0.2f
                else -> W * 0.34f
            }
            if (cfg.cards == 5) {
                fill(c, RectF(W * 0.04f, y0 - W * 0.015f, W * 0.96f, y0 + ch + W * 0.015f), W * 0.03f, 0xFFFBF6E8.toInt())
            }
            for (i in 0 until n) {
                val o = pr.getJSONObject(i)
                val nm = o.getString("n")
                val s = o.getLong("s")
                val e = o.getLong("e")
                val x = left0 + i * (bw + gap)
                val rr = RectF(x, y0, x + bw, y0 + ch)
                val current = nowMs >= s && nowMs < e
                val isNext = nm == nextName
                val cx = rr.centerX()
                when (cfg.cards) {
                    0 -> {
                        fill(c, rr, W * 0.03f, if (current) accent else if (isNext) 0xFF1E9E55.toInt() else 0xB30B3D2E.toInt())
                        stroke(c, rr, W * 0.03f, accent, 2f)
                        val tc = if (current) 0xFF062A1F.toInt() else Color.WHITE
                        text(c, nm, cx, rr.top + ch * 0.4f, W * 0.042f, tc, true, true)
                        text(c, hm(s), cx, rr.top + ch * 0.78f, W * 0.036f, tc)
                    }
                    1 -> {
                        val cols = PASTEL[i % 5]
                        p.reset(); p.isAntiAlias = true
                        p.shader = LinearGradient(0f, rr.top, 0f, rr.bottom, cols.first, cols.second, Shader.TileMode.CLAMP)
                        c.drawRoundRect(rr, W * 0.04f, W * 0.04f, p)
                        stroke(c, rr, W * 0.04f, if (current || isNext) Color.WHITE else accent, if (current || isNext) 5f else 2f)
                        val tc = if (i < 3) 0xFF0B3D2E.toInt() else Color.WHITE
                        text(c, nm, cx, rr.top + ch * 0.24f, W * 0.045f, tc, true, true)
                        text(c, hm(s), cx, rr.top + ch * 0.45f, W * 0.04f, tc, true)
                        text(c, "داخل " + hm(s), cx, rr.top + ch * 0.66f, W * 0.027f, tc, false, true)
                        text(c, "ختم " + hm(e), cx, rr.top + ch * 0.84f, W * 0.027f, tc, false, true)
                    }
                    2 -> {
                        fill(c, rr, W * 0.04f, 0xFFFBF6E8.toInt())
                        stroke(c, rr, W * 0.04f, if (current || isNext) 0xFF1E9E55.toInt() else accent, if (current || isNext) 5f else 2f)
                        val dk = 0xFF0B3D2E.toInt()
                        text(c, nm, cx, rr.top + ch * 0.2f, W * 0.045f, dk, true, true)
                        text(c, hm(s), cx, rr.top + ch * 0.4f, W * 0.04f, dk, true)
                        text(c, "داخل " + hm(s), cx, rr.top + ch * 0.58f, W * 0.027f, 0xFF555555.toInt(), false, true)
                        text(c, "ختم " + hm(e), cx, rr.top + ch * 0.72f, W * 0.027f, 0xFF555555.toInt(), false, true)
                        chip(c, rr, ch, current, isNext, nowMs >= e)
                    }
                    3 -> {
                        val a = W * 0.09f
                        val b = W * 0.02f
                        val path = Path()
                        path.addRoundRect(rr, floatArrayOf(a, a, a, a, b, b, b, b), Path.Direction.CW)
                        p.reset(); p.isAntiAlias = true
                        p.shader = LinearGradient(0f, rr.top, 0f, rr.bottom, 0xFF0B3D2E.toInt(), 0xFF062A1F.toInt(), Shader.TileMode.CLAMP)
                        c.drawPath(path, p)
                        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE
                        p.strokeWidth = if (current || isNext) 5f else 2f; p.color = accent
                        c.drawPath(path, p)
                        text(c, nm, cx, rr.top + ch * 0.3f, W * 0.045f, Color.WHITE, true, true)
                        text(c, hm(s), cx, rr.top + ch * 0.5f, W * 0.04f, accent, true)
                        text(c, "آغاز", cx, rr.top + ch * 0.64f, W * 0.027f, 0xCCFFFFFF.toInt(), false, true)
                        chip(c, rr, ch, current, isNext, nowMs >= e)
                    }
                    4 -> {
                        if (i > 0) {
                            p.reset(); p.isAntiAlias = true; p.color = 0x80E6B94D.toInt(); p.strokeWidth = 2f
                            c.drawLine(x - gap / 2f, rr.top + ch * 0.1f, x - gap / 2f, rr.bottom - ch * 0.1f, p)
                        }
                        val hi = current || isNext
                        text(c, nm, cx, rr.top + ch * 0.32f, W * 0.047f, if (hi) accent else Color.WHITE, true, true)
                        text(c, hm(s), cx, rr.top + ch * 0.64f, W * 0.04f, Color.WHITE, true)
                        text(c, "داخل", cx, rr.top + ch * 0.92f, W * 0.028f, 0xFF3DDC84.toInt(), false, true)
                    }
                    else -> {
                        val pill = RectF(rr.left + bw * 0.04f, rr.top + W * 0.01f, rr.right - bw * 0.04f, rr.top + W * 0.08f)
                        fill(c, pill, W * 0.02f, if (current || isNext) 0xFF1E9E55.toInt() else 0xFF0B3D2E.toInt())
                        text(c, nm, cx, pill.centerY() + W * 0.015f, W * 0.04f, Color.WHITE, true, true)
                        val dk = 0xFF0B3D2E.toInt()
                        val gr = 0xFF666666.toInt()
                        text(c, "وقت داخل", cx, rr.top + W * 0.14f, W * 0.027f, gr, false, true)
                        text(c, hm(s), cx, rr.top + W * 0.185f, W * 0.036f, dk, true)
                        text(c, "وقت ختم", cx, rr.top + W * 0.25f, W * 0.027f, gr, false, true)
                        text(c, hm(e), cx, rr.top + W * 0.295f, W * 0.036f, dk, true)
                        val box = RectF(rr.left + bw * 0.04f, rr.top + W * 0.33f, rr.right - bw * 0.04f, rr.top + W * 0.46f)
                        fill(c, box, W * 0.02f, 0xFF0B3D2E.toInt())
                        text(c, "باقی وقت", cx, box.top + W * 0.04f, W * 0.025f, 0xCCFFFFFF.toInt(), false, true)
                        text(c, hms(untilSlot(s, e) / 1000), cx, box.top + W * 0.095f, W * 0.03f, accent, true)
                    }
                }
            }
            return y0 + ch + W * 0.04f
        }

        private fun chip(c: Canvas, rr: RectF, ch: Float, current: Boolean, isNext: Boolean, passed: Boolean) {
            val label = if (current) "جاری" else if (isNext) "اگلی" else if (passed) "مکمل" else "آنے والی"
            val color = if (current || isNext) 0xFF1E9E55.toInt() else 0xFF3A4A44.toInt()
            val r = RectF(rr.left + rr.width() * 0.1f, rr.bottom - ch * 0.2f, rr.right - rr.width() * 0.1f, rr.bottom - ch * 0.05f)
            fill(c, r, W * 0.015f, color)
            text(c, label, r.centerX(), r.centerY() + W * 0.01f, W * 0.026f, Color.WHITE, false, true)
        }
    }
}
