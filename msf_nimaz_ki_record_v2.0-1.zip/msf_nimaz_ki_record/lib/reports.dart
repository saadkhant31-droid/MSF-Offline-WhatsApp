import 'package:flutter/material.dart';
import 'store.dart';
import 'widgets.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});
  @override
  State<ReportScreen> createState() => _ReportState();
}

class _ReportState extends State<ReportScreen> {
  int range = 7;
  DateTime anchor = dayOnly(DateTime.now());

  void _move(int dir) {
    final nd = addDays(anchor, dir * range);
    final today = dayOnly(DateTime.now());
    setState(() => anchor = nd.isAfter(today) ? today : nd);
  }

  @override
  Widget build(BuildContext context) => Screen(
        'نماز کی رپورٹس',
        Rebuild((c) {
          final today = dayOnly(DateTime.now());
          final days = <DateTime>[];
          for (int k = range - 1; k >= 0; k--) {
            final d = addDays(anchor, -k);
            if (!d.isAfter(today)) days.add(d);
          }
          final counts = [0, 0, 0, 0];
          final perPrayer = List<int>.filled(5, 0);
          for (final d in days) {
            for (int i = 0; i < 5; i++) {
              final s = prayerState(d, i);
              counts[s]++;
              if (s == 1 || s == 2) perPrayer[i]++;
            }
          }
          final slots = days.length * 5;
          final offered = counts[1] + counts[2];
          final pct = slots == 0 ? 0 : (offered * 100 / slots).round();
          final start = addDays(anchor, -(range - 1));
          final label = range == 1 ? fmtDate(anchor) : '${fmtShort(start)} تا ${fmtShort(anchor)} ${anchor.year}';

          final text = StringBuffer('نماز رپورٹ ($label)\n');
          text.writeln('ادا: $offered / $slots ($pct٪)');
          text.writeln('با جماعت: ${counts[2]} • قضا: ${counts[3]} • باقی: ${counts[0]}');
          for (int i = 0; i < 5; i++) {
            text.writeln('${prayerInfos[i].name}: ${perPrayer[i]} / ${days.length}');
          }

          return ListView(padding: const EdgeInsets.all(10), children: [
            Directionality(
              textDirection: TextDirection.ltr,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 1, label: Text('روزانہ')),
                  ButtonSegment(value: 7, label: Text('ہفتہ وار')),
                  ButtonSegment(value: 30, label: Text('ماہانہ')),
                ],
                selected: {range},
                onSelectionChanged: (s) => setState(() => range = s.first),
              ),
            ),
            const SizedBox(height: 10),
            DateNav(label: label, onPrev: () => _move(-1), onNext: () => _move(1)),
            box(
              c,
              child: Column(children: [
                Text('$pct٪', style: const TextStyle(fontSize: 44, fontWeight: FontWeight.bold, color: green)),
                Text('ادا شدہ نمازیں: $offered / $slots'),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(value: slots == 0 ? 0 : offered / slots, minHeight: 10, color: green, backgroundColor: Colors.grey.withAlpha(60)),
                ),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _chip('با جماعت', counts[2], statusColor(2)),
                  _chip('اکیلے', counts[1], statusColor(1)),
                  _chip('قضا', counts[3], statusColor(3)),
                  _chip('باقی', counts[0], Colors.orange),
                ]),
              ]),
            ),
            sectionTitle('ہر نماز کا ریکارڈ'),
            box(
              c,
              child: Column(children: [
                for (int i = 0; i < 5; i++)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Row(children: [
                      SizedBox(width: 52, child: Text(prayerInfos[i].name, style: const TextStyle(fontWeight: FontWeight.bold))),
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: LinearProgressIndicator(value: days.isEmpty ? 0 : perPrayer[i] / days.length, minHeight: 9, color: green, backgroundColor: Colors.grey.withAlpha(60)),
                        ),
                      ),
                      SizedBox(width: 56, child: Text('${perPrayer[i]} / ${days.length}', textAlign: TextAlign.end)),
                    ]),
                  ),
              ]),
            ),
            if (range > 1) ...[
              sectionTitle('روزانہ تفصیل'),
              for (final d in days.reversed)
                box(
                  c,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(children: [
                    Expanded(child: Text(fmtDate(d), style: const TextStyle(fontSize: 13))),
                    for (int i = 0; i < 5; i++)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: Icon(
                          prayerState(d, i) == 3 ? Icons.cancel : (prayerState(d, i) == 0 ? Icons.circle_outlined : Icons.check_circle),
                          size: 18,
                          color: prayerState(d, i) == 0 ? Colors.grey : statusColor(prayerState(d, i)),
                        ),
                      ),
                  ]),
                ),
            ],
            FilledButton.icon(onPressed: () => copyText(c, text.toString()), icon: const Icon(Icons.copy), label: const Text('رپورٹ کاپی / شیئر کریں')),
          ]);
        }),
      );

  Widget _chip(String t, int n, Color col) => Column(children: [
        Text('$n', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: col)),
        Text(t, style: const TextStyle(fontSize: 12)),
      ]);
}
