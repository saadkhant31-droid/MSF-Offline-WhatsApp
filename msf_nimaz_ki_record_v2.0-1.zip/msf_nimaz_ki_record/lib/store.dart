import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const green = Color(0xFF0B5D3B);
const gold = Color(0xFFE2B33C);

late SharedPreferences sp;
final ValueNotifier<int> tick = ValueNotifier<int>(0);
final ValueNotifier<ThemeMode> themeMode = ValueNotifier<ThemeMode>(ThemeMode.light);
void bump() => tick.value++;

int getI(String k, [int d = 0]) => sp.getInt(k) ?? d;
bool getB(String k, [bool d = false]) => sp.getBool(k) ?? d;
String getS(String k, [String d = '']) => sp.getString(k) ?? d;
void setI(String k, int v) {
  sp.setInt(k, v);
  bump();
}

void setB(String k, bool v) {
  sp.setBool(k, v);
  bump();
}

void setS(String k, String v) {
  sp.setString(k, v);
  bump();
}

void del(String k) {
  sp.remove(k);
  bump();
}

int clampI(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

/// Rebuilds whenever any stored value changes.
class Rebuild extends StatelessWidget {
  final Widget Function(BuildContext) builder;
  const Rebuild(this.builder, {super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: tick,
        builder: (c, _, __) => builder(c),
      );
}

// ---------------------------------------------------------------- dates
const urduMonths = ['جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون', 'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'];
const urduDays = ['پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ', 'اتوار'];
const hijriMonths = ['محرم', 'صفر', 'ربیع الاول', 'ربیع الثانی', 'جمادی الاول', 'جمادی الثانی', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذوالقعدہ', 'ذوالحجہ'];

String dayKey(DateTime d) => '${d.year}-${d.month}-${d.day}';
DateTime dayOnly(DateTime d) => DateTime(d.year, d.month, d.day);
DateTime addDays(DateTime d, int n) => DateTime(d.year, d.month, d.day + n);
bool sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;
String fmtDate(DateTime d) => '${d.day} ${urduMonths[d.month - 1]} ${d.year} (${urduDays[d.weekday - 1]})';
String fmtShort(DateTime d) => '${d.day} ${urduMonths[d.month - 1]}';

String fmtTime(DateTime t) {
  final h = t.hour % 12 == 0 ? 12 : t.hour % 12;
  return '$h:${t.minute.toString().padLeft(2, '0')} ${t.hour >= 12 ? 'PM' : 'AM'}';
}

/// returns [year, month, day] (tabular Islamic calendar, with user adjustment)
List<int> toHijri(DateTime g0) {
  final g = g0.add(Duration(days: getI('hadj')));
  final a = (14 - g.month) ~/ 12;
  final yy = g.year + 4800 - a;
  final mm = g.month + 12 * a - 3;
  final jd = g.day + (153 * mm + 2) ~/ 5 + 365 * yy + yy ~/ 4 - yy ~/ 100 + yy ~/ 400 - 32045;
  var l = jd - 1948440 + 10632;
  final n = (l - 1) ~/ 10631;
  l = l - 10631 * n + 354;
  final j = ((10985 - l) ~/ 5316) * ((50 * l) ~/ 17719) + (l ~/ 5670) * ((43 * l) ~/ 15238);
  l = l - ((30 - j) ~/ 15) * ((17719 * j) ~/ 50) - (j ~/ 16) * ((15238 * j) ~/ 43) + 29;
  final m = (24 * l) ~/ 709;
  final d = l - (709 * m) ~/ 24;
  final y = 30 * n + j - 30;
  return [y, m, d];
}

String hijriText(DateTime g) {
  final h = toHijri(g);
  return '${h[2].toString().padLeft(2, '0')} ${hijriMonths[clampI(h[1] - 1, 0, 11)]} ${h[0]}ھ';
}

// ---------------------------------------------------------------- prayers
class PrayerInfo {
  final String name;
  final IconData icon;
  final List<String> rakat;
  const PrayerInfo(this.name, this.icon, this.rakat);
}

const prayerInfos = [
  PrayerInfo('فجر', Icons.wb_twilight, ['2 سنت مؤکدہ', '2 فرض']),
  PrayerInfo('ظہر', Icons.wb_sunny, ['4 سنت مؤکدہ', '4 فرض', '2 سنت مؤکدہ', '2 نفل']),
  PrayerInfo('عصر', Icons.wb_cloudy, ['4 سنت غیر مؤکدہ', '4 فرض']),
  PrayerInfo('مغرب', Icons.brightness_4, ['3 فرض', '2 سنت مؤکدہ', '2 نفل']),
  PrayerInfo('عشاء', Icons.nightlight_round, ['4 سنت غیر مؤکدہ', '4 فرض', '2 سنت مؤکدہ', '2 نفل', '3 وتر', '2 نفل']),
];

const statusLabels = ['باقی', 'ادا', 'با جماعت ادا', 'قضا'];
Color statusColor(int s) {
  switch (s) {
    case 1:
      return const Color(0xFF2E9E57);
    case 2:
      return const Color(0xFF0B5D3B);
    case 3:
      return const Color(0xFFD32F2F);
    default:
      return Colors.grey;
  }
}

String prayerKey(DateTime d, int i) => 'pr|${dayKey(d)}|$i';
int prayerState(DateTime d, int i) => getI(prayerKey(d, i));

void setPrayerState(DateTime d, int i, int s) {
  final k = prayerKey(d, i);
  final old = getI(k);
  if (s == 0) {
    sp.remove(k);
  } else {
    sp.setInt(k, s);
  }
  if (old == 3 && s != 3) removeQazaBySrc(k);
  if (s == 3 && old != 3) addQaza(i, d, 'نماز ریکارڈ سے', src: k, notify: false);
  bump();
}

// ---------------------------------------------------------------- qaza
const qazaNames = ['فجر', 'ظہر', 'عصر', 'مغرب', 'عشاء', 'وتر'];

List<Map<String, dynamic>> qazaLog() {
  final s = getS('qz_log');
  if (s.isEmpty) return [];
  try {
    return (jsonDecode(s) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  } catch (_) {
    return [];
  }
}

void saveQazaLog(List<Map<String, dynamic>> l) {
  sp.setString('qz_log', jsonEncode(l));
  bump();
}

void addQaza(int prayer, DateTime d, String reason, {String src = '', bool notify = true}) {
  final l = qazaLog();
  l.add({
    'id': DateTime.now().microsecondsSinceEpoch.toString(),
    'p': prayer,
    'd': dayKey(d),
    'r': reason,
    'done': false,
    'src': src,
  });
  if (notify) {
    saveQazaLog(l);
  } else {
    sp.setString('qz_log', jsonEncode(l));
  }
}

void removeQazaBySrc(String src) {
  final l = qazaLog();
  l.removeWhere((e) => e['src'] == src && e['done'] != true);
  sp.setString('qz_log', jsonEncode(l));
}

int qazaBase(int i) => getI('qz_base_$i');
int qazaMade(int i) => getI('qz_made_$i');
int qazaPending(int i) => qazaBase(i) + qazaLog().where((e) => e['p'] == i && e['done'] != true).length;
int qazaPendingTotal() {
  var t = 0;
  for (var i = 0; i < 6; i++) {
    t += qazaPending(i);
  }
  return t;
}

int qazaMadeTotal() {
  var t = 0;
  for (var i = 0; i < 6; i++) {
    t += qazaMade(i);
  }
  return t;
}

// ---------------------------------------------------------------- cities & times
class City {
  final String name;
  final double lat, lng;
  const City(this.name, this.lat, this.lng);
}

const cities = [
  City('کراچی', 24.8607, 67.0011),
  City('لاہور', 31.5204, 74.3587),
  City('اسلام آباد', 33.6844, 73.0479),
  City('راولپنڈی', 33.5651, 73.0169),
  City('پشاور', 34.0151, 71.5785),
  City('کوئٹہ', 30.1798, 66.9750),
  City('ملتان', 30.1575, 71.5249),
  City('فیصل آباد', 31.4504, 73.1350),
  City('حیدرآباد (پاکستان)', 25.3960, 68.3578),
  City('سیالکوٹ', 32.4945, 74.5229),
  City('گوجرانوالہ', 32.1877, 74.1945),
  City('دہلی', 28.6139, 77.2090),
  City('ممبئی', 19.0760, 72.8777),
  City('لکھنؤ', 26.8467, 80.9462),
  City('حیدرآباد (انڈیا)', 17.3850, 78.4867),
  City('کولکتہ', 22.5726, 88.3639),
  City('ڈھاکہ', 23.8103, 90.4125),
  City('مکہ مکرمہ', 21.3891, 39.8579),
  City('مدینہ منورہ', 24.5247, 39.5692),
  City('ریاض', 24.7136, 46.6753),
  City('دبئی', 25.2048, 55.2708),
  City('لندن', 51.5072, -0.1276),
  City('نیویارک', 40.7128, -74.0060),
  City('ٹورنٹو', 43.6532, -79.3832),
];

City currentCity() => cities[clampI(getI('city'), 0, cities.length - 1)];

double _r(double d) => d * math.pi / 180;
double _d(double r) => r * 180 / math.pi;
double _sin(double d) => math.sin(_r(d));
double _cos(double d) => math.cos(_r(d));
double _fixA(double a) => a % 360;
double _fixH(double h) => h % 24;

double _julian(int y, int m, int d) {
  var yy = y;
  var mm = m;
  if (mm <= 2) {
    yy -= 1;
    mm += 12;
  }
  final a = (yy / 100).floor();
  final b = 2 - a + (a / 4).floor();
  return (365.25 * (yy + 4716)).floor() + (30.6001 * (mm + 1)).floor() + d + b - 1524.5;
}

List<double> _sunPos(double jd) {
  final dd = jd - 2451545.0;
  final g = _fixA(357.529 + 0.98560028 * dd);
  final q = _fixA(280.459 + 0.98564736 * dd);
  final l = _fixA(q + 1.915 * _sin(g) + 0.020 * _sin(2 * g));
  final e = 23.439 - 0.00000036 * dd;
  final ra = _fixH(_d(math.atan2(_cos(e) * _sin(l), _cos(l))) / 15);
  final decl = _d(math.asin(_sin(e) * _sin(l)));
  var eqt = q / 15 - ra;
  if (eqt > 12) eqt -= 24;
  if (eqt < -12) eqt += 24;
  return [decl, eqt];
}

/// keys: fajr, sunrise, dhuhr, asr, maghrib, isha
Map<String, DateTime> prayerTimes(DateTime date, City c, int asrFactor) {
  final tz = date.timeZoneOffset.inMinutes / 60.0;
  final jd = _julian(date.year, date.month, date.day) - c.lng / 360.0 + 0.5;
  final pos = _sunPos(jd);
  final decl = pos[0];
  final eqt = pos[1];
  final noon = 12 + tz - c.lng / 15 - eqt;
  double at(double angle, bool after) {
    final v = (-_sin(angle) - _sin(decl) * _sin(c.lat)) / (_cos(decl) * _cos(c.lat));
    final vv = v < -1.0 ? -1.0 : (v > 1.0 ? 1.0 : v);
    final t = _d(math.acos(vv)) / 15;
    return after ? noon + t : noon - t;
  }

  final asrAngle = -_d(math.atan(1 / (asrFactor + math.tan(_r((c.lat - decl).abs())))));
  final base = DateTime(date.year, date.month, date.day);
  DateTime dt(double h) => base.add(Duration(minutes: (h * 60).round()));
  return {
    'fajr': dt(at(18, false)),
    'sunrise': dt(at(0.833, false)),
    'dhuhr': dt(noon + 1 / 60),
    'asr': dt(at(asrAngle, true)),
    'maghrib': dt(at(0.833, true) + 1 / 60),
    'isha': dt(at(18, true)),
  };
}

const prayerKeys = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

// ---------------------------------------------------------------- qibla
const kaabaLat = 21.4225;
const kaabaLng = 39.8262;

double qiblaBearing(double lat, double lng) {
  final dLng = kaabaLng - lng;
  final y = _sin(dLng) * _cos(kaabaLat);
  final x = _cos(lat) * _sin(kaabaLat) - _sin(lat) * _cos(kaabaLat) * _cos(dLng);
  final t = _d(math.atan2(y, x));
  return (t + 360) % 360;
}

double kaabaDistance(double lat, double lng) {
  final dLat = _r(kaabaLat - lat);
  final dLng = _r(kaabaLng - lng);
  final a = math.pow(math.sin(dLat / 2), 2) + math.cos(_r(lat)) * math.cos(_r(kaabaLat)) * math.pow(math.sin(dLng / 2), 2);
  return 6371 * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
}

// ---------------------------------------------------------------- backup
String exportData() {
  final m = <String, dynamic>{};
  for (final k in sp.getKeys()) {
    m[k] = sp.get(k);
  }
  return jsonEncode(m);
}

Future<bool> importData(String s) async {
  try {
    final m = jsonDecode(s) as Map<String, dynamic>;
    await sp.clear();
    for (final e in m.entries) {
      final v = e.value;
      if (v is bool) {
        await sp.setBool(e.key, v);
      } else if (v is int) {
        await sp.setInt(e.key, v);
      } else if (v is double) {
        await sp.setDouble(e.key, v);
      } else if (v is String) {
        await sp.setString(e.key, v);
      } else if (v is List) {
        await sp.setStringList(e.key, v.map((x) => x.toString()).toList());
      }
    }
    themeMode.value = getB('dark') ? ThemeMode.dark : ThemeMode.light;
    bump();
    return true;
  } catch (_) {
    return false;
  }
}
