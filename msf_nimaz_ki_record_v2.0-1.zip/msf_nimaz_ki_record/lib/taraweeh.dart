import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'timetable.dart';
import 'home.dart';
import 'prayers.dart';
import 'reports.dart';
import 'settings.dart';

const _deep = Color(0xFF0B4D2E);
const _panel = Color(0xFF0E5B37);
const _ok = Color(0xFF1B7F45);
const _blue = Color(0xFF1565C0);
const _orange = Color(0xFFEF7D12);
const _red = Color(0xFFD32F2F);

const _verse = 'رمضان وہ مہینہ ہے جس میں قرآن نازل کیا گیا';
const _verseRef = '(البقرۃ: 185)';

// ------------------------------------------------------------------ data helpers
// Same keys as the Nafl screen ('tar' / 'para'), so old records keep working.
String _k(DateTime d, String f) => 'nk|${dayKey(d)}|$f';
int _tar(DateTime d) => clampI(getI(_k(d, 'tar')), 0, 20);
int _para(DateTime d) => clampI(getI(_k(d, 'para')), 0, 30);
String _note(DateTime d) => getS(_k(d, 'tarnote'));
int _mode(DateTime d) => getI(_k(d, 'tarjam')); // 0 = not chosen, 1 = jamaat, 2 = alone

void _setTar(DateTime d, int v) {
  if (v <= 0) {
    del(_k(d, 'tar'));
  } else {
    setI(_k(d, 'tar'), clampI(v, 0, 20));
  }
}

void _setPara(DateTime d, int v) {
  if (v <= 0) {
    del(_k(d, 'para'));
  } else {
    setI(_k(d, 'para'), clampI(v, 0, 30));
  }
}

void _setNote(DateTime d, String v) {
  if (v.trim().isEmpty) {
    del(_k(d, 'tarnote'));
  } else {
    setS(_k(d, 'tarnote'), v.trim());
  }
}

String _two(int n) => n.toString().padLeft(2, '0');
String _iso(DateTime d) => '${d.year}-${_two(d.month)}-${_two(d.day)}';

List<DateTime> _recordDays() {
  final out = <DateTime>[];
  for (final k in sp.getKeys()) {
    if (!k.startsWith('nk|')) continue;
    final p = k.split('|');
    if (p.length != 3) continue;
    if (p[2] == 'tar') {
      if ((sp.getInt(k) ?? 0) <= 0) continue;
    } else if (p[2] == 'tarnote') {
      if ((sp.getString(k) ?? '').isEmpty) continue;
    } else {
      continue;
    }
    final dp = p[1].split('-');
    if (dp.length != 3) continue;
    final y = int.tryParse(dp[0]);
    final m = int.tryParse(dp[1]);
    final d = int.tryParse(dp[2]);
    if (y == null || m == null || d == null) continue;
    final dt = DateTime(y, m, d);
    if (!out.any((e) => sameDay(e, dt))) out.add(dt);
  }
  out.sort((a, b) => b.compareTo(a));
  return out;
}

DateTime _ramadanStart(DateTime ref) {
  final hy = toHijri(ref)[0];
  for (int i = -400; i <= 400; i++) {
    final x = addDays(ref, i);
    final h = toHijri(x);
    if (h[0] == hy && h[1] == 9 && h[2] == 1) return x;
  }
  return ref;
}

// ------------------------------------------------------------------ screen
class TaraweehScreen extends StatefulWidget {
  const TaraweehScreen({super.key});
  @override
  State<TaraweehScreen> createState() => _TaraweehState();
}

class _TaraweehState extends State<TaraweehScreen> {
  DateTime date = dayOnly(DateTime.now());
  bool showAll = false;
  final ScrollController _sc = ScrollController();

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  bool get _isToday => sameDay(date, dayOnly(DateTime.now()));

  void _toTop() {
    if (_sc.hasClients) _sc.animateTo(0, duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
  }

  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
        child: Scaffold(
          backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
          body: Rebuild((c) => _body(c)),
          bottomNavigationBar: _nav(context),
        ),
      );

  Widget _body(BuildContext c) {
    final w = MediaQuery.of(c).size.width;
    return ListView(controller: _sc, padding: EdgeInsets.zero, children: [
      _header(c, w),
      Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
        child: Column(children: [
          _summary(c),
          const SizedBox(height: 8),
          _infoCards(c),
          const SizedBox(height: 8),
          _rakatPanel(c),
          const SizedBox(height: 8),
          _actions(c),
          const SizedBox(height: 8),
          _history(c),
          const SizedBox(height: 8),
          _banner(c),
          const SizedBox(height: 8),
          Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Expanded(child: _noteCard(c)),
            const SizedBox(width: 8),
            Expanded(child: _monthly(c)),
          ]),
        ]),
      ),
    ]);
  }

  // ---------------------------------------------------------------- header
  Widget _header(BuildContext c, double w) => SizedBox(
        width: w,
        height: w * 250 / 1024,
        child: Stack(children: [
          Positioned.fill(child: Image.asset('assets/taraweeh/header.png', fit: BoxFit.fill)),
          // transparent hit area over the "واپس" button drawn in the artwork
          Positioned(
            left: w * 0.02,
            top: w * 58 / 1024,
            width: w * 0.17,
            height: w * 70 / 1024,
            child: Material(
              color: Colors.transparent,
              child: InkWell(borderRadius: BorderRadius.circular(30), onTap: () => Navigator.maybePop(c)),
            ),
          ),
        ]),
      );

  // ---------------------------------------------------------------- summary row
  BoxDecoration _cardDeco(BuildContext c) => BoxDecoration(
        color: cardColor(c),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: green.withAlpha(60)),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(18), blurRadius: 5, offset: const Offset(0, 2))],
      );

  Widget _statCard(BuildContext c, IconData? icon, String label, Widget value, {Widget? extra}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        decoration: _cardDeco(c),
        child: Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (icon != null) ...[Icon(icon, color: _panel, size: 30), const SizedBox(height: 4)],
              Text(label, style: TextStyle(fontSize: 11, color: subText(c))),
              const SizedBox(height: 2),
              value,
              if (extra != null) ...[const SizedBox(height: 6), extra],
            ]),
          ),
        ),
      );

  Widget _smallButton(String text, IconData icon, VoidCallback onTap) => Material(
        color: _ok,
        borderRadius: BorderRadius.circular(8),
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(icon, color: Colors.white, size: 14),
              const SizedBox(width: 4),
              Text(text, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
      );

  Widget _summary(BuildContext c) {
    final tar = _tar(date);
    final pct = (tar * 100 / 20).round();
    return SizedBox(
      height: 124,
      child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(
          flex: 30,
          child: _statCard(
            c,
            null,
            'تکمیل کا تناسب',
            Text('$pct%', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            extra: SizedBox(
              width: 64,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(value: tar / 20, minHeight: 9, color: _ok, backgroundColor: Colors.grey.withAlpha(60)),
              ),
            ),
          ),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 30,
          child: _statCard(c, Icons.access_time, 'باقی رکعتیں', Text('${20 - tar}', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 34,
          child: _statCard(
            c,
            Icons.menu_book,
            'پڑھی گئی رکعتیں',
            Text('$tar', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            extra: _smallButton('تبدیل کریں', Icons.check, _editRakats),
          ),
        ),
        const SizedBox(width: 6),
        Expanded(flex: 66, child: _mainCard(c)),
      ]),
    );
  }

  Widget _mainCard(BuildContext c) => ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Stack(children: [
          Positioned.fill(child: Image.asset('assets/taraweeh/mosque.png', fit: BoxFit.cover, alignment: Alignment.centerLeft)),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [_deep.withAlpha(20), _deep.withAlpha(235), _deep],
                  stops: const [0.0, 0.55, 1.0],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _showMethodInfo,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  child: Row(children: [
                    Expanded(
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: AlignmentDirectional.centerStart,
                        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('تراویح', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                          const Text('کل رکعتیں: 20', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 2),
                          const Text('(حنفی فقہ میں معروف طریقہ)', style: TextStyle(color: Colors.white70, fontSize: 10.5)),
                        ]),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: _deep, border: Border.all(color: gold, width: 2)),
                      child: const Icon(Icons.nightlight_round, color: Colors.white, size: 26),
                    ),
                  ]),
                ),
              ),
            ),
          ),
        ]),
      );

  void _showMethodInfo() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تراویح کی رکعات'),
        content: const Text(
          'حنفی فقہ میں تراویح کی 20 رکعات (10 سلام کے ساتھ) معروف طریقہ ہے۔ بعض اہلِ علم کے ہاں 8 رکعات بھی منقول ہیں۔ فقہی اختلاف کی صورت میں اپنے مسلک اور عالمِ دین کی رہنمائی پر عمل کریں۔',
          style: TextStyle(height: 1.7),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ٹھیک ہے'))],
      ),
    );
  }

  // ---------------------------------------------------------------- info cards
  Widget _infoCard(BuildContext c, IconData icon, String title, String value, String sub, VoidCallback onTap, {Widget? extra}) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: _cardDeco(c),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              child: Row(children: [
                Icon(icon, color: _panel, size: 34),
                const SizedBox(width: 8),
                Expanded(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: AlignmentDirectional.centerStart,
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: TextStyle(fontSize: 11.5, color: subText(c))),
                      Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                      if (sub.isNotEmpty) Text(sub, style: TextStyle(fontSize: 11, color: subText(c))),
                      if (extra != null) ...[const SizedBox(height: 4), extra],
                    ]),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );

  Widget _infoCards(BuildContext c) {
    final start = _ramadanStart(date);
    final para = _para(date);
    return Column(children: [
      IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            child: _infoCard(c, Icons.calendar_month, _isToday ? 'آج کی تاریخ' : 'منتخب تاریخ', _iso(date), '(${hijriText(date)})', _pickDate),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _infoCard(c, Icons.mosque, 'تراویح شروع ہونے کی تاریخ', '1 رمضان', '(${_iso(start)} تقریباً)', () {
              toast(c, '1 رمضان ${toHijri(start)[0]}ھ ≈ ${fmtDate(start)}');
            }),
          ),
        ]),
      ),
      const SizedBox(height: 8),
      IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            child: _infoCard(
              c,
              Icons.auto_stories,
              'قرآن مکمل کرنے کا ریکارڈ',
              para == 0 ? 'پارہ درج نہیں' : 'پارہ $para / 30',
              '',
              _pickPara,
              extra: _smallButton('تبدیل کریں', Icons.edit, _pickPara),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Material(
              color: Colors.transparent,
              child: Ink(
                decoration: BoxDecoration(
                  color: Color.alphaBlend(green.withAlpha(22), cardColor(c)),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: green.withAlpha(60)),
                ),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => copyText(c, '$_verse $_verseRef'),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Text(_verse, textAlign: TextAlign.center, style: TextStyle(fontSize: 12.5, height: 1.6)),
                      Text(_verseRef, style: TextStyle(fontSize: 11, color: subText(c))),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        ]),
      ),
    ]);
  }

  Future<void> _pickDate() async {
    final now = dayOnly(DateTime.now());
    final r = await showDatePicker(
      context: context,
      initialDate: date,
      firstDate: DateTime(now.year - 5),
      lastDate: now,
      helpText: 'تاریخ منتخب کریں',
      cancelText: 'منسوخ',
      confirmText: 'ٹھیک ہے',
    );
    if (r != null && mounted) setState(() => date = dayOnly(r));
  }

  Future<void> _pickPara() async {
    final cur = _para(date);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('پارہ نمبر منتخب کریں - ${_iso(date)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [
                for (int i = 1; i <= 30; i++)
                  InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () {
                      _setPara(date, i);
                      Navigator.pop(ctx);
                    },
                    child: Container(
                      width: 44,
                      height: 44,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: i == cur ? _ok : Colors.transparent,
                        border: Border.all(color: i == cur ? _ok : Colors.grey, width: 1.3),
                      ),
                      child: Text('$i', style: TextStyle(fontWeight: FontWeight.bold, color: i == cur ? Colors.white : null)),
                    ),
                  ),
              ]),
            ),
            const SizedBox(height: 10),
            if (cur > 0)
              TextButton.icon(
                onPressed: () {
                  _setPara(date, 0);
                  Navigator.pop(ctx);
                },
                icon: const Icon(Icons.clear, color: _red),
                label: const Text('پارہ ہٹائیں', style: TextStyle(color: _red)),
              ),
          ]),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- section bar
  Widget _bar(String title) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: const BoxDecoration(color: _panel, borderRadius: BorderRadius.vertical(top: Radius.circular(12))),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Row(children: [
            Expanded(child: Text(title, textDirection: TextDirection.rtl, textAlign: TextAlign.left, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold))),
            const Icon(Icons.star_border, color: Colors.white38, size: 22),
          ]),
        ),
      );

  Widget _section(BuildContext c, String title, Widget child) => Container(
        decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(70))),
        child: Column(children: [_bar(title), child]),
      );

  // ---------------------------------------------------------------- rakat panel
  void _tapRakat(int i) {
    final tar = _tar(date);
    _setTar(date, tar == i ? i - 1 : i);
  }

  Widget _rakatPanel(BuildContext c) {
    final tar = _tar(date);
    return _section(
      c,
      'تراویح کی رکعات کی تفصیل',
      Padding(
        padding: const EdgeInsets.all(10),
        child: Column(children: [
          LayoutBuilder(builder: (c, cs) {
            const gap = 4.0;
            final double s = ((cs.maxWidth - gap * 9) / 10).clamp(20.0, 44.0).toDouble();
            Widget chip(int i) {
              final done = i <= tar;
              return InkWell(
                customBorder: const CircleBorder(),
                onTap: () => _tapRakat(i),
                child: Container(
                  width: s,
                  height: s,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: done ? _ok : Colors.transparent,
                    border: Border.all(color: done ? _ok : Colors.grey.withAlpha(160), width: 1.4),
                  ),
                  child: Text('$i', style: TextStyle(fontSize: s * 0.42, fontWeight: FontWeight.bold, color: done ? Colors.white : subText(c))),
                ),
              );
            }

            return Directionality(
              textDirection: TextDirection.ltr,
              child: Column(children: [
                for (int r = 0; r < 2; r++)
                  Padding(
                    padding: EdgeInsets.only(bottom: r == 0 ? 8 : 0),
                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      for (int j = 1; j <= 10; j++) chip(r * 10 + j),
                    ]),
                  ),
              ]),
            );
          }),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _quick('2 رکعت شامل', Icons.add, () => _setTar(date, tar + 2), _ok)),
            const SizedBox(width: 6),
            Expanded(child: _quick('مکمل 20', Icons.done_all, () => _setTar(date, 20), _blue)),
            const SizedBox(width: 6),
            Expanded(child: _quick('صاف کریں', Icons.refresh, () => _setTar(date, 0), _red)),
          ]),
          const SizedBox(height: 6),
          Text('کسی نمبر پر دبائیں تو اتنی رکعتیں درج ہو جائیں گی۔', style: TextStyle(fontSize: 10.5, color: subText(c))),
        ]),
      ),
    );
  }

  Widget _quick(String text, IconData icon, VoidCallback onTap, Color col) => InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(color: col.withAlpha(24), borderRadius: BorderRadius.circular(10), border: Border.all(color: col.withAlpha(100))),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(icon, color: col, size: 16),
              const SizedBox(width: 4),
              Text(text, style: TextStyle(color: col, fontSize: 12, fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
      );

  Future<void> _editRakats() async {
    var v = _tar(date);
    final r = await showDialog<int>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: Text('پڑھی گئی رکعتیں - ${_iso(date)}', style: const TextStyle(fontSize: 16)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(
                onPressed: v > 0 ? () => set(() { v--; }) : null,
                icon: const Icon(Icons.remove_circle, color: _red, size: 38),
              ),
              SizedBox(width: 70, child: Text('$v', textAlign: TextAlign.center, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.bold))),
              IconButton(
                onPressed: v < 20 ? () => set(() { v++; }) : null,
                icon: const Icon(Icons.add_circle, color: _ok, size: 38),
              ),
            ]),
            const SizedBox(height: 8),
            Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center, children: [
              for (final q in const [2, 4, 8, 12, 16, 20]) ActionChip(label: Text('$q'), onPressed: () => set(() { v = q; })),
            ]),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('منسوخ')),
            TextButton(onPressed: () => Navigator.pop(ctx, v), child: const Text('محفوظ کریں')),
          ],
        ),
      ),
    );
    if (r != null) _setTar(date, r);
  }

  // ---------------------------------------------------------------- action buttons
  Widget _actionTile(BuildContext c, IconData icon, String title, String sub, VoidCallback onTap) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: _cardDeco(c),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 8),
              child: Center(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: _panel),
                      child: Icon(icon, color: Colors.white, size: 22),
                    ),
                    const SizedBox(height: 5),
                    Text(title, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9.5, color: subText(c))),
                  ]),
                ),
              ),
            ),
          ),
        ),
      );

  Widget _actions(BuildContext c) {
    final note = _note(date);
    final m = _mode(date);
    return SizedBox(
      height: 104,
      child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(
          child: Material(
            color: Colors.transparent,
            child: Ink(
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [_deep, Color(0xFF14804A)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [BoxShadow(color: Colors.black.withAlpha(30), blurRadius: 5, offset: const Offset(0, 2))],
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: _addNew,
                child: const Padding(
                  padding: EdgeInsets.all(6),
                  child: Center(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.add_circle_outline, color: Colors.white, size: 34),
                        SizedBox(height: 4),
                        Text('نئی تراویح', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
                        Text('شامل کریں', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
                      ]),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 6),
        Expanded(child: _actionTile(c, Icons.sticky_note_2, 'نوٹ', note.isEmpty ? 'ملاحظات لکھیں' : note, _editNote)),
        const SizedBox(width: 6),
        Expanded(child: _actionTile(c, Icons.groups, 'تراویح کی نوعیت', m == 1 ? 'جماعت کے ساتھ' : (m == 2 ? 'اکیلے' : 'منتخب کریں'), _pickMode)),
        const SizedBox(width: 6),
        Expanded(child: _actionTile(c, Icons.access_time_filled, 'نماز کا وقت', 'عشاء کے بعد', _showTime)),
      ]),
    );
  }

  Future<void> _editNote() async {
    final ctrl = TextEditingController(text: _note(date));
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('نوٹ - ${_iso(date)}', style: const TextStyle(fontSize: 16)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'مثلاً: بیماری کی وجہ سے کم، یا تکمیل جاری'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('محفوظ کریں')),
        ],
      ),
    );
    final text = ctrl.text;
    ctrl.dispose();
    if (ok == true) _setNote(date, text);
  }

  Future<void> _pickMode() async {
    final cur = _mode(date);
    await showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Text('تراویح کی نوعیت - ${_iso(date)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
          for (final o in const [
            [1, 'جماعت کے ساتھ'],
            [2, 'اکیلے'],
            [0, 'نشان ہٹائیں'],
          ])
            ListTile(
              leading: Icon(o[0] == 1 ? Icons.groups : (o[0] == 2 ? Icons.person : Icons.clear), color: o[0] == 0 ? Colors.grey : _ok),
              title: Text(o[1] as String),
              trailing: cur == o[0] ? const Icon(Icons.check_circle, color: _ok) : null,
              onTap: () {
                if (o[0] == 0) {
                  del(_k(date, 'tarjam'));
                } else {
                  setI(_k(date, 'tarjam'), o[0] as int);
                }
                Navigator.pop(ctx);
              },
            ),
        ]),
      ),
    );
  }

  void _showTime() {
    String isha;
    try {
      isha = fmtTime(dayTimes(date).isha);
    } catch (_) {
      isha = '—';
    }
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تراویح کا وقت'),
        content: Text(
          'تراویح کا وقت عشاء کے فرض کے بعد شروع ہوتا ہے (وتر سے پہلے)۔\n\n${fmtDate(date)}\nعشاء کا وقت: $isha',
          style: const TextStyle(height: 1.8),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ٹھیک ہے'))],
      ),
    );
  }

  Future<void> _addNew() async {
    final now = dayOnly(DateTime.now());
    var d = date;
    var tar = _tar(date) > 0 ? _tar(date) : 20;
    var para = _para(date);
    final ctrl = TextEditingController(text: _note(date));
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) {
          Widget stepper(int v, int max, void Function(int) onChange) => Row(mainAxisSize: MainAxisSize.min, children: [
                InkWell(onTap: v > 0 ? () => set(() => onChange(v - 1)) : null, child: const Icon(Icons.remove_circle_outline, color: _red, size: 28)),
                SizedBox(width: 40, child: Text('$v', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                InkWell(onTap: v < max ? () => set(() => onChange(v + 1)) : null, child: const Icon(Icons.add_circle_outline, color: _ok, size: 28)),
              ]);
          return AlertDialog(
            title: const Text('نئی تراویح شامل کریں'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                OutlinedButton.icon(
                  onPressed: () async {
                    final r = await showDatePicker(context: ctx, initialDate: d, firstDate: DateTime(now.year - 5), lastDate: now);
                    if (r != null) set(() => d = dayOnly(r));
                  },
                  icon: const Icon(Icons.calendar_month),
                  label: Text(_iso(d)),
                ),
                const SizedBox(height: 10),
                Row(children: [
                  const Expanded(child: Text('رکعتیں (20 میں سے)')),
                  stepper(tar, 20, (x) => tar = x),
                ]),
                const SizedBox(height: 6),
                Row(children: [
                  const Expanded(child: Text('پارہ نمبر')),
                  stepper(para, 30, (x) => para = x),
                ]),
                const SizedBox(height: 6),
                TextField(controller: ctrl, decoration: const InputDecoration(labelText: 'نوٹ (اختیاری)')),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
              TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('محفوظ کریں')),
            ],
          );
        },
      ),
    );
    final note = ctrl.text;
    ctrl.dispose();
    if (ok != true) return;
    _setTar(d, tar);
    _setPara(d, para);
    _setNote(d, note);
    if (!mounted) return;
    setState(() => date = d);
    toast(context, 'تراویح کا ریکارڈ محفوظ ہو گیا');
  }

  // ---------------------------------------------------------------- history table
  Widget _cell(int flex, Widget child) => Expanded(flex: flex, child: Center(child: child));

  Widget _hd(String t, BuildContext c) => FittedBox(
        fit: BoxFit.scaleDown,
        child: Text(t, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, color: subText(c))),
      );

  Widget _num(String t, {Color? color}) => Text(t, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: color));

  Widget _pill(int st) {
    final Color col = st == 0 ? _ok : (st == 1 ? _blue : _orange);
    final String label = st == 0 ? 'مکمل' : (st == 1 ? 'جاری' : 'نامکمل');
    final IconData icon = st == 0 ? Icons.check : (st == 1 ? Icons.schedule : Icons.hourglass_bottom);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
      decoration: BoxDecoration(color: col, borderRadius: BorderRadius.circular(8)),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: Colors.white, size: 12),
          const SizedBox(width: 3),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
        ]),
      ),
    );
  }

  Widget _histRow(BuildContext c, DateTime d, bool alt) {
    final tar = _tar(d);
    final para = _para(d);
    final note = _note(d);
    final today = sameDay(d, dayOnly(DateTime.now()));
    final st = tar >= 20 ? 0 : (today ? 1 : 2);
    final selected = sameDay(d, date);
    return InkWell(
      onTap: () {
        setState(() => date = d);
        _toTop();
      },
      onLongPress: () => _deleteDay(d),
      child: Container(
        color: selected ? gold.withAlpha(45) : (alt ? green.withAlpha(12) : null),
        padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 4),
        child: Row(children: [
          _cell(34, FittedBox(fit: BoxFit.scaleDown, child: Text(_iso(d), style: const TextStyle(fontSize: 11.5)))),
          _cell(15, _num('20')),
          _cell(15, _num('$tar')),
          _cell(14, _num('${20 - tar}')),
          _cell(14, _num(para == 0 ? '-' : '$para')),
          _cell(
            28,
            Text(note.isEmpty ? '-' : note, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, height: 1.3)),
          ),
          _cell(26, _pill(st)),
        ]),
      ),
    );
  }

  Future<void> _deleteDay(DateTime d) async {
    final yes = await confirmDialog(context, '${_iso(d)} کا تراویح ریکارڈ حذف کریں؟');
    if (!yes) return;
    for (final f in const ['tar', 'para', 'tarnote', 'tarjam']) {
      del(_k(d, f));
    }
    if (mounted) toast(context, 'ریکارڈ حذف ہو گیا');
  }

  Widget _history(BuildContext c) {
    final days = _recordDays();
    final shown = showAll ? days : days.take(7).toList();
    return _section(
      c,
      'تراویح کا ریکارڈ (ماضی)',
      Column(children: [
        Container(
          color: green.withAlpha(20),
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          child: Row(children: [
            _cell(34, _hd('تاریخ', c)),
            _cell(15, _hd('کل رکعتیں', c)),
            _cell(15, _hd('ادا کی گئیں', c)),
            _cell(14, _hd('باقی', c)),
            _cell(14, _hd('پارہ نمبر', c)),
            _cell(28, _hd('ملاحظات', c)),
            _cell(26, _hd('اسٹیٹس', c)),
          ]),
        ),
        if (shown.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('ابھی کوئی ریکارڈ نہیں۔ اوپر سے رکعتیں درج کریں۔', style: TextStyle(color: subText(c), fontSize: 12)),
          ),
        for (int i = 0; i < shown.length; i++) _histRow(c, shown[i], i.isOdd),
        if (days.length > 7)
          TextButton.icon(
            onPressed: () => setState(() => showAll = !showAll),
            icon: Icon(showAll ? Icons.expand_less : Icons.expand_more, color: green),
            label: Text(showAll ? 'کم دکھائیں' : 'تمام ${days.length} ریکارڈ دیکھیں', style: const TextStyle(color: green, fontWeight: FontWeight.bold)),
          ),
        if (days.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
            child: Text('قطار دبائیں تو وہ دن کھل جائے گا، دیر تک دبائیں تو حذف ہو گا۔', style: TextStyle(fontSize: 10, color: subText(c))),
          ),
      ]),
    );
  }

  // ---------------------------------------------------------------- bottom cards
  Widget _banner(BuildContext c) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [_deep, Color(0xFF14804A)]),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: gold, width: 1.6),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => toast(c, 'اللہ تعالیٰ ہماری عبادات قبول فرمائے، آمین'),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
              child: Row(children: [
                const Icon(Icons.mosque, color: gold, size: 40),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('اللہ کی رضا کے لیے', style: TextStyle(color: gold, fontSize: 17, fontWeight: FontWeight.bold)),
                    SizedBox(height: 2),
                    Text('تراویح پڑھیں', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                  ]),
                ),
              ]),
            ),
          ),
        ),
      );

  Widget _noteCard(BuildContext c) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: _cardDeco(c),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: _showMethodInfo,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                const Row(children: [
                  Icon(Icons.star, color: _panel, size: 18),
                  SizedBox(width: 6),
                  Text('اہم یادداشت', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                ]),
                const SizedBox(height: 6),
                Text(
                  'تراویح کی رکعتوں کی تعداد میں فقہی اختلاف ہے۔ 20 رکعت حنفی فقہ میں معروف اور معمول کا طریقہ ہے۔',
                  style: TextStyle(fontSize: 11, height: 1.6, color: subText(c)),
                ),
              ]),
            ),
          ),
        ),
      );

  Widget _monthly(BuildContext c) {
    final h = toHijri(date);
    var sum = 0;
    var full = 0;
    for (final d in _recordDays()) {
      final hd = toHijri(d);
      if (hd[0] == h[0] && hd[1] == h[1]) {
        final t = _tar(d);
        sum += t;
        if (t >= 20) full++;
      }
    }
    return Material(
      color: Colors.transparent,
      child: Ink(
        decoration: _cardDeco(c),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => go(c, const ReportScreen()),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Row(children: [
                const Icon(Icons.insights, color: _panel, size: 18),
                const SizedBox(width: 6),
                Expanded(child: Text('تراویح کا ماہانہ خلاصہ', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12.5))),
              ]),
              const SizedBox(height: 2),
              Text('(${hijriMonths[clampI(h[1] - 1, 0, 11)]} ${h[0]}ھ)', style: TextStyle(fontSize: 10, color: subText(c))),
              const SizedBox(height: 6),
              Text('اس ماہ کل رکعتیں: $sum', style: const TextStyle(fontSize: 12)),
              Text('مکمل دن: $full / 30', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _ok)),
            ]),
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- bottom nav
  Widget _nav(BuildContext c) {
    const items = <List<dynamic>>[
      [Icons.home, 'ہوم'],
      [Icons.mosque, 'نمازیں'],
      [Icons.nightlight_round, 'تراویح'],
      [Icons.bar_chart, 'رپورٹس'],
      [Icons.settings, 'سیٹنگز'],
      [Icons.menu, 'مزید'],
    ];
    void act(int i) {
      switch (i) {
        case 0:
          Navigator.of(c).popUntil((r) => r.isFirst);
          break;
        case 1:
          go(c, const PrayersScreen());
          break;
        case 2:
          _toTop();
          break;
        case 3:
          go(c, const ReportScreen());
          break;
        case 4:
          go(c, const SettingsScreen());
          break;
        case 5:
          go(c, MorePage(features: allFeatures()));
          break;
      }
    }

    return Container(
      color: const Color(0xFF0B3D2A),
      padding: EdgeInsets.only(bottom: MediaQuery.of(c).padding.bottom, top: 4),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          for (int i = 0; i < items.length; i++)
            Expanded(
              child: InkWell(
                onTap: () => act(i),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  decoration: i == 2 ? BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF7CD65B), width: 1.4), color: const Color(0xFF14803F)) : null,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(items[i][0] as IconData, color: i == 2 ? gold : Colors.white, size: 24),
                    const SizedBox(height: 2),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(items[i][1] as String, style: TextStyle(color: i == 2 ? gold : Colors.white, fontSize: 11, fontWeight: FontWeight.bold))),
                  ]),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}
