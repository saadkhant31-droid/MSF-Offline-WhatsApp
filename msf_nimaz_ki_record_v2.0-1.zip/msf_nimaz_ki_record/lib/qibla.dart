import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'store.dart';
import 'widgets.dart';

const _gd = Color(0xFF0B5D3B);

String dirName(double b) {
  const n = ['شمال', 'شمال مشرق', 'مشرق', 'جنوب مشرق', 'جنوب', 'جنوب مغرب', 'مغرب', 'شمال مغرب'];
  return n[clampI((((b + 22.5) % 360) ~/ 45), 0, 7)];
}

class QiblaScreen extends StatefulWidget {
  const QiblaScreen({super.key});
  @override
  State<QiblaScreen> createState() => _QiblaState();
}

class _QiblaState extends State<QiblaScreen> {
  StreamSubscription<AccelerometerEvent>? _a;
  StreamSubscription<MagnetometerEvent>? _m;
  Timer? _wait;
  List<double>? _g, _mg;
  double? heading;
  bool live = true, waited = false, aligned = false;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _start();
  }

  void _start() {
    waited = false;
    try {
      _a = accelerometerEventStream().listen((e) {
        _g = [e.x, e.y, e.z];
        _calc();
      }, onError: (_) {});
      _m = magnetometerEventStream().listen((e) {
        _mg = [e.x, e.y, e.z];
        _calc();
      }, onError: (_) {});
    } catch (_) {}
    _wait = Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => waited = true);
    });
  }

  void _stop() {
    _a?.cancel();
    _m?.cancel();
    _wait?.cancel();
    _a = null;
    _m = null;
  }

  @override
  void dispose() {
    _stop();
    super.dispose();
  }

  void _calc() {
    final a = _g, m = _mg;
    if (a == null || m == null || !live || !mounted) return;
    final now = DateTime.now();
    if (now.difference(_last).inMilliseconds < 40) return;
    _last = now;
    var hx = m[1] * a[2] - m[2] * a[1];
    var hy = m[2] * a[0] - m[0] * a[2];
    var hz = m[0] * a[1] - m[1] * a[0];
    final nh = math.sqrt(hx * hx + hy * hy + hz * hz);
    if (nh < 0.1) return;
    hx /= nh;
    hy /= nh;
    hz /= nh;
    final na = math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
    if (na < 0.1) return;
    final ax = a[0] / na, az = a[2] / na;
    final my = az * hx - ax * hz;
    var h = math.atan2(hy, my) * 180 / math.pi;
    if (h < 0) h += 360;
    final old = heading;
    if (old == null) {
      heading = h;
    } else {
      var d = h - old;
      while (d > 180) {
        d -= 360;
      }
      while (d < -180) {
        d += 360;
      }
      heading = (old + d * 0.2 + 360) % 360;
    }
    final city = currentCity();
    final b = qiblaBearing(city.lat, city.lng);
    var diff = (heading! - b).abs() % 360;
    if (diff > 180) diff = 360 - diff;
    final al = diff < 5;
    if (al && !aligned) HapticFeedback.heavyImpact();
    setState(() => aligned = al);
  }

  void _toggle() {
    setState(() {
      live = !live;
      if (live) {
        heading = null;
        _g = null;
        _mg = null;
        _start();
      } else {
        _stop();
        heading = null;
        aligned = false;
      }
    });
  }

  void _calibrate() {
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('کمپاس کی کلیبریشن'),
        content: const Text('موبائل کو ہوا میں آنکھ کے 8 کی شکل میں 3 سے 4 بار گھمائیں، پھر اسے سیدھا (افقی) پکڑیں۔ دھاتی چیزوں، مقناطیس اور بجلی کے آلات سے دور رہیں۔', style: TextStyle(height: 1.8)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(c);
              setState(() {
                heading = null;
                _g = null;
                _mg = null;
              });
              toast(context, 'کمپاس دوبارہ ترتیب دیا جا رہا ہے');
            },
            child: const Text('ٹھیک ہے، ری سیٹ کریں'),
          ),
        ],
      ),
    );
  }

  void _sensor() {
    final ok = heading != null;
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('سینسر کی حالت'),
        content: Text(
          ok
              ? 'کمپاس (مقناطیسی) اور ایکسلرومیٹر سینسر درست کام کر رہے ہیں ✓'
              : (live
                  ? (waited ? 'سینسر کا ڈیٹا نہیں آ رہا۔ ہو سکتا ہے آپ کے موبائل میں مقناطیسی سینسر نہ ہو۔ ایسی صورت میں اوپر دیا گیا زاویہ کسی بھی کمپاس سے استعمال کریں۔' : 'سینسر کا ڈیٹا آنے کا انتظار ہے…')
                  : 'لائیو کمپاس بند ہے۔ اسے چالو کریں۔'),
          style: const TextStyle(height: 1.8),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('ٹھیک ہے'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        appHeader(context, 'قبلہ', 'قبلہ کی سمت معلوم کریں', null),
        Expanded(
          child: Rebuild((c) {
            final city = currentCity();
            final b = qiblaBearing(city.lat, city.lng);
            final dist = kaabaDistance(city.lat, city.lng);
            return ListView(padding: const EdgeInsets.fromLTRB(10, 10, 10, 16), children: [
              Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Expanded(flex: 6, child: _banner()),
                const SizedBox(width: 8),
                Expanded(flex: 4, child: _locCard(c, city.name, b)),
              ]),
              const SizedBox(height: 10),
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(flex: 6, child: _dialCard(c, b)),
                const SizedBox(width: 8),
                Expanded(flex: 4, child: _sideCards(b, dist)),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _info(c, Icons.explore, 'کمپاس کی کلیبریشن', '(درست سمت کے لیے)', _calibrate)),
                const SizedBox(width: 6),
                Expanded(child: _info(c, Icons.location_on, 'مقام کی اجازت', '(شہر منتخب کریں)', () => pickCity(c))),
                const SizedBox(width: 6),
                Expanded(child: _info(c, Icons.phone_android, 'ضروری سینسر', '(موبائل میں موجود ہوں)', _sensor)),
              ]),
              const SizedBox(height: 10),
              sectionTitle('کمپاس درست کام نہ کرے تو کیا کریں؟'),
              box(c, child: Column(children: [
                for (final e in const [
                  'موبائل کو آنکھ کی شکل میں (8) گھمائیں اور دوبارہ سیدھا کریں۔',
                  'کمپاس کے لیے صاف جگہ پر کھڑے ہوں۔',
                  'موبائل کے سینسر فعال ہونے دیں۔',
                  'اگر درست سمت نہ ملے تو دوبارہ کلیبریٹ کریں۔',
                ].asMap().entries)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(children: [
                      CircleAvatar(radius: 13, backgroundColor: _gd, child: Text('${e.key + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
                      const SizedBox(width: 10),
                      Expanded(child: Text(e.value, style: const TextStyle(fontSize: 13.5, height: 1.5))),
                    ]),
                  ),
              ])),
              box(c, color: isDark(c) ? const Color(0xFF24543A) : const Color(0xFFE6F4EA), child: Row(children: [
                const Icon(Icons.info, color: _gd),
                const SizedBox(width: 10),
                Expanded(child: Text('نوٹ: قبلے کی درست سمت دکھانے کے لیے موبائل میں ضروری سینسر اور مقام کی اجازت درکار ہو سکتی ہے۔ سمت منتخب شہر کے مرکز کے حساب سے ہے۔', style: TextStyle(fontSize: 12.5, height: 1.6, color: subText(c))))
              ])),
            ]);
          }),
        ),
      ]),
    );
  }

  Widget _banner() => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), _gd]), borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(border: Border.all(color: gold, width: 2), borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.mosque, color: gold, size: 32),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
              Text('قبلہ کی سمت', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
              Text('موبائل کے کمپاس سے قبلہ کی سمت معلوم کریں', style: TextStyle(color: Colors.white, fontSize: 11.5, height: 1.5)),
            ]),
          ),
        ]),
      );

  Widget _locCard(BuildContext c, String name, double b) => InkWell(
        onTap: () => pickCity(c),
        child: box(c, padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.location_on, color: _gd, size: 22),
            const SizedBox(width: 6),
            Expanded(child: Text('آپ کا مقام', style: TextStyle(fontSize: 12, color: subText(c)))),
            const Icon(Icons.edit, size: 15),
          ]),
          Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          const Divider(height: 10),
          Row(children: [
            const Icon(Icons.explore, color: _gd, size: 22),
            const SizedBox(width: 6),
            Text('قبلے کا زاویہ', style: TextStyle(fontSize: 12, color: subText(c))),
          ]),
          Text('${b.round()}°', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        ])),
      );

  Widget _dialCard(BuildContext c, double b) => Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: isDark(c) ? [const Color(0xFF1F2B25), const Color(0xFF16221C)] : [const Color(0xFFDDF1E8), const Color(0xFFF1FAF5)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: green.withAlpha(70)),
        ),
        child: LayoutBuilder(builder: (ctx, cons) {
          final size = cons.maxWidth - 4;
          return Column(children: [
            SizedBox(width: size, height: size, child: CustomPaint(painter: _DialPainter(heading ?? 0, b))),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 4),
              decoration: BoxDecoration(color: aligned ? Colors.green : _gd, borderRadius: BorderRadius.circular(20)),
              child: Text(heading == null ? '${b.round()}°' : '${heading!.round()}°', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 4),
            Text(
              !live ? 'لائیو کمپاس بند ہے' : (aligned ? '✓ قبلہ سامنے ہے' : (heading != null ? 'سرخ تیر کو اوپر لائیں' : (waited ? 'سینسر نہیں ملا' : 'سینسر کا انتظار…'))),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: aligned ? Colors.green : subText(c)),
            ),
            const SizedBox(height: 4),
            OutlinedButton.icon(
              onPressed: _toggle,
              icon: Icon(live ? Icons.pause_circle : Icons.play_circle, size: 18),
              label: Text(live ? 'لائیو بند' : 'لائیو چالو', style: const TextStyle(fontSize: 12)),
              style: OutlinedButton.styleFrom(foregroundColor: _gd, side: const BorderSide(color: _gd), visualDensity: VisualDensity.compact),
            ),
          ]);
        }),
      );

  Widget _sideCards(double b, double dist) {
    final d = dirName(b);
    return Column(children: [
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), _gd]), borderRadius: BorderRadius.circular(14), border: Border.all(color: gold, width: 1.5)),
        child: Column(children: [
          const Icon(Icons.mosque, color: gold, size: 40),
          const Text('قبلہ کی سمت', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
          Text('($d کی طرف)', style: const TextStyle(color: Colors.white70, fontSize: 11)),
          Text('${b.round()}°', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
        ]),
      ),
      const SizedBox(height: 8),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), _gd]), borderRadius: BorderRadius.circular(14), border: Border.all(color: gold, width: 1.5)),
        child: Column(children: [
          const Icon(Icons.location_on, color: gold, size: 24),
          Text('موجودہ مقام سے قبلہ کی سمت\n$d کی طرف ہے', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 12, height: 1.6)),
          const SizedBox(height: 4),
          Text('کعبہ تک ${dist.round()} کلومیٹر', style: const TextStyle(color: Colors.white70, fontSize: 11)),
        ]),
      ),
    ]);
  }

  Widget _info(BuildContext c, IconData ic, String t, String s, VoidCallback f) => InkWell(
        onTap: f,
        borderRadius: BorderRadius.circular(14),
        child: box(c, padding: const EdgeInsets.all(8), child: Column(children: [
          CircleAvatar(radius: 20, backgroundColor: _gd, child: Icon(ic, color: Colors.white, size: 22)),
          const SizedBox(height: 4),
          FittedBox(fit: BoxFit.scaleDown, child: Text(t, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12.5))),
          Text(s, textAlign: TextAlign.center, style: TextStyle(fontSize: 9.5, color: subText(c))),
        ])),
      );
}

class _DialPainter extends CustomPainter {
  final double heading, bearing;
  _DialPainter(this.heading, this.bearing);

  void _text(Canvas c, String t, double fs, Color col, {bool bold = false}) {
    final tp = TextPainter(text: TextSpan(text: t, style: TextStyle(color: col, fontSize: fs, fontWeight: bold ? FontWeight.bold : FontWeight.normal)), textDirection: TextDirection.ltr)..layout();
    tp.paint(c, Offset(-tp.width / 2, -tp.height / 2));
  }

  @override
  void paint(Canvas c, Size s) {
    final ctr = Offset(s.width / 2, s.height / 2);
    final r = s.width / 2;
    c.drawCircle(ctr, r, Paint()..shader = const SweepGradient(colors: [Color(0xFFE2B33C), Color(0xFFB8860B), Color(0xFFFFE08A), Color(0xFFE2B33C)]).createShader(Rect.fromCircle(center: ctr, radius: r)));
    c.drawCircle(ctr, r - r * 0.06, Paint()..color = const Color(0xFF0B4F33));
    c.drawCircle(ctr, r - r * 0.06, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = const Color(0xFFFFE08A));
    c.save();
    c.translate(ctr.dx, ctr.dy);
    c.rotate(-heading * math.pi / 180);
    final tick = Paint()..color = Colors.white70..strokeWidth = 1.2;
    final rr = r * 0.92;
    for (var i = 0; i < 72; i++) {
      final a = i * 5 * math.pi / 180;
      final len = i % 6 == 0 ? rr * 0.09 : (i % 2 == 0 ? rr * 0.055 : rr * 0.035);
      c.drawLine(Offset(math.sin(a) * rr, -math.cos(a) * rr), Offset(math.sin(a) * (rr - len), -math.cos(a) * (rr - len)), tick);
    }
    for (var d = 0; d < 360; d += 30) {
      if (d % 90 == 0) continue;
      c.save();
      c.rotate(d * math.pi / 180);
      c.translate(0, -rr * 0.76);
      _text(c, '$d', r * 0.075, Colors.white70);
      c.restore();
    }
    const names = ['N', 'E', 'S', 'W'];
    for (var i = 0; i < 4; i++) {
      c.save();
      c.rotate(i * math.pi / 2);
      c.translate(0, -rr * 0.66);
      _text(c, names[i], r * 0.13, i == 0 ? const Color(0xFFFFE08A) : Colors.white, bold: true);
      c.restore();
    }
    // compass rose
    final star = Paint()..color = const Color(0xFF7FD8A6).withAlpha(200);
    for (var i = 0; i < 4; i++) {
      c.save();
      c.rotate(i * math.pi / 2);
      final p = Path()
        ..moveTo(0, -rr * 0.50)
        ..lineTo(rr * 0.07, -rr * 0.07)
        ..lineTo(-rr * 0.07, -rr * 0.07)
        ..close();
      c.drawPath(p, star);
      c.restore();
    }
    // qibla needle
    c.save();
    c.rotate(bearing * math.pi / 180);
    final needle = Path()
      ..moveTo(0, -rr * 0.60)
      ..lineTo(rr * 0.07, 0)
      ..lineTo(-rr * 0.07, 0)
      ..close();
    c.drawPath(needle, Paint()..color = const Color(0xFFE53935));
    c.drawCircle(Offset(0, -rr * 0.60), rr * 0.035, Paint()..color = const Color(0xFFFFE08A));
    final tail = Path()
      ..moveTo(0, rr * 0.30)
      ..lineTo(rr * 0.05, 0)
      ..lineTo(-rr * 0.05, 0)
      ..close();
    c.drawPath(tail, Paint()..color = Colors.white54);
    c.restore();
    c.restore();
    // Kaaba hub
    c.drawCircle(ctr, r * 0.13, Paint()..color = const Color(0xFFE2B33C));
    c.drawCircle(ctr, r * 0.105, Paint()..color = const Color(0xFF111111));
    c.drawRect(Rect.fromCenter(center: ctr, width: r * 0.1, height: r * 0.1), Paint()..color = const Color(0xFFE2B33C));
    c.drawRect(Rect.fromCenter(center: ctr.translate(0, -r * 0.02), width: r * 0.1, height: r * 0.025), Paint()..color = const Color(0xFF111111));
  }

  @override
  bool shouldRepaint(covariant _DialPainter o) => o.heading != heading || o.bearing != bearing;
}
