import 'package:flutter/material.dart';
import 'store.dart';
import 'widgets.dart';
import 'eidain.dart' show hijriToGreg, EidainScreen;

const _gd = Color(0xFF0B5D3B);

const hijriEvents = {
  '1-1': 'اسلامی سال کا آغاز (یکم محرم)',
  '1-10': 'یومِ عاشورہ (10 محرم)',
  '3-12': '12 ربیع الاول (عید میلاد النبی ﷺ)',
  '7-27': 'شبِ معراج (27 رجب)',
  '8-15': 'شبِ برأت (15 شعبان)',
  '9-1': 'رمضان المبارک کا آغاز',
  '9-27': '27 رمضان (شبِ قدر کی ایک روایت)',
  '10-1': 'عید الفطر',
  '12-9': 'یومِ عرفہ',
  '12-10': 'عید الاضحیٰ',
};

String _eventOf(DateTime d) {
  final h = toHijri(d);
  return hijriEvents['${h[1]}-${h[2]}'] ?? '';
}

class _Ev {
  final int m, d;
  final String name, sub;
  final IconData icon;
  const _Ev(this.m, this.d, this.name, this.sub, this.icon);
}

const _evs = [
  _Ev(10, 1, 'عید الفطر', '1 شوال', Icons.mosque),
  _Ev(12, 10, 'عید الاضحیٰ', '10 ذوالحجہ', Icons.account_balance),
  _Ev(9, 1, 'رمضان المبارک', '1 رمضان', Icons.nightlight_round),
  _Ev(1, 1, 'محرم الحرام', '1 محرم', Icons.location_city),
  _Ev(1, 10, 'یومِ عاشورہ', '10 محرم', Icons.mosque),
  _Ev(3, 12, 'میلاد النبی ﷺ', '12 ربیع الاول', Icons.mosque),
  _Ev(8, 15, 'شبِ برأت', '15 شعبان', Icons.lightbulb),
  _Ev(7, 27, 'شبِ معراج', '27 رجب', Icons.auto_awesome),
];

DateTime _nextOf(int hm, int hd) {
  final t = dayOnly(DateTime.now());
  final hy = toHijri(t)[0];
  var d = hijriToGreg(hy, hm, hd);
  if (d.isBefore(t)) d = hijriToGreg(hy + 1, hm, hd);
  return d;
}

String _remain(DateTime d) {
  final n = d.difference(dayOnly(DateTime.now())).inDays;
  return n == 0 ? 'آج' : '$n دن باقی';
}

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});
  @override
  State<CalendarScreen> createState() => _CalState();
}

class _CalState extends State<CalendarScreen> {
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime sel = dayOnly(DateTime.now());
  final kCal = GlobalKey(), kMon = GlobalKey(), kEv = GlobalKey(), kRam = GlobalKey(), kEid = GlobalKey(), kAdj = GlobalKey();

  void _move(int n) => setState(() => month = DateTime(month.year, month.month + n, 1));

  void _scroll(GlobalKey k) {
    final c = k.currentContext;
    if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 400), curve: Curves.easeOut);
  }

  void _showDate(DateTime d) {
    setState(() {
      sel = dayOnly(d);
      month = DateTime(d.year, d.month, 1);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _scroll(kCal));
  }

  Future<void> _pickMonth() async {
    final p = await showDatePicker(context: context, initialDate: sel, firstDate: DateTime(1990), lastDate: DateTime(2100));
    if (p != null) _showDate(p);
  }

  void _monthSheet(int hm, int hy) {
    final start = hijriToGreg(hy, hm, 1);
    final next = hm == 12 ? hijriToGreg(hy + 1, 1, 1) : hijriToGreg(hy, hm + 1, 1);
    final len = next.difference(start).inDays;
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('${hijriMonths[hm - 1]} $hyھ', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: green)),
            const SizedBox(height: 8),
            Text('آغاز: ${fmtDate(start)}', style: const TextStyle(fontSize: 15)),
            Text('دن: $len', style: const TextStyle(fontSize: 15)),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(c);
                  _showDate(start);
                },
                icon: const Icon(Icons.calendar_month),
                label: const Text('کیلنڈر میں دیکھیں'),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _evSheet(_Ev e) {
    final d = _nextOf(e.m, e.d);
    final h = toHijri(d);
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(e.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: green)),
            const SizedBox(height: 6),
            Text('${e.sub} ${h[0]}ھ', style: const TextStyle(fontSize: 15)),
            Text(fmtDate(d), style: const TextStyle(fontSize: 15)),
            Text(_remain(d), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: _gd)),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(c);
                  _showDate(d);
                },
                icon: const Icon(Icons.calendar_month),
                label: const Text('کیلنڈر میں دیکھیں'),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _adjust() {
    var v = getI('hadj');
    showDialog<void>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('ہجری تاریخ میں تبدیلی'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('چاند کے اعلان کے مطابق دن آگے یا پیچھے کریں (-2 سے +2)', style: TextStyle(height: 1.7)),
            const SizedBox(height: 10),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton(onPressed: v > -2 ? () => setD(() => v--) : null, icon: const Icon(Icons.remove_circle, color: green, size: 32)),
                SizedBox(width: 50, child: Text(v > 0 ? '+$v' : '$v', textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
                IconButton(onPressed: v < 2 ? () => setD(() => v++) : null, icon: const Icon(Icons.add_circle, color: green, size: 32)),
              ]),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('منسوخ')),
            TextButton(
              onPressed: () {
                setI('hadj', v);
                Navigator.pop(c);
                toast(context, 'تاریخ تبدیل ہو گئی');
              },
              child: const Text('محفوظ کریں'),
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------ build
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        appHeader(context, 'اسلامی کیلنڈر', 'ہجری اور اسلامی تاریخیں', null),
        Expanded(child: Rebuild((c) => _body(c))),
      ]),
    );
  }

  Widget _body(BuildContext c) {
    final today = dayOnly(DateTime.now());
    final hy = toHijri(today)[0];
    final ht = toHijri(today);
    return ListView(padding: const EdgeInsets.fromLTRB(10, 10, 10, 16), children: [
      Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(flex: 6, child: _banner()),
        const SizedBox(width: 8),
        Expanded(flex: 5, child: _todayCard(c, today)),
      ]),
      const SizedBox(height: 10),
      _tabs(c, today),
      const SizedBox(height: 10),
      KeyedSubtree(key: kCal, child: sectionTitle('موجودہ تاریخ')),
      _calendar(c, today),
      _summary(c),
      KeyedSubtree(key: kMon, child: sectionTitle('اسلامی مہینے')),
      _months(c, ht, hy),
      KeyedSubtree(key: kEv, child: sectionTitle('اہم اسلامی تاریخیں')),
      for (final e in _evs) _evTile(c, e),
      KeyedSubtree(key: kRam, child: sectionTitle('رمضان المبارک')),
      _ramadan(c, ht),
      KeyedSubtree(key: kEid, child: sectionTitle('عیدین')),
      _eids(c),
      KeyedSubtree(key: kAdj, child: sectionTitle('تاریخ میں تبدیلی')),
      _adjCard(c),
      _quote(),
    ]);
  }

  Widget _banner() => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), _gd]), borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          const Icon(Icons.calendar_month, color: gold, size: 46),
          const SizedBox(width: 8),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
              Text('اسلامی کیلنڈر', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
              Text('ہجری اور اسلامی تاریخیں', style: TextStyle(color: Colors.white, fontSize: 12)),
            ]),
          ),
        ]),
      );

  Widget _todayCard(BuildContext c, DateTime t) => InkWell(
        onTap: () => _showDate(t),
        child: box(c, padding: const EdgeInsets.all(10), child: Column(children: [
          Row(children: const [Icon(Icons.calendar_month, color: _gd), SizedBox(width: 6), Expanded(child: Text('آج کی تاریخ', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)))]),
          const SizedBox(height: 4),
          Text('${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text(hijriText(t), style: TextStyle(fontSize: 11.5, color: subText(c))),
        ])),
      );

  Widget _tabs(BuildContext c, DateTime today) {
    final items = <List<Object>>[
      [Icons.calendar_today, 'موجودہ تاریخ', () => _showDate(today)],
      [Icons.mosque, 'اسلامی مہینے', () => _scroll(kMon)],
      [Icons.star, 'اہم تاریخیں', () => _scroll(kEv)],
      [Icons.nightlight_round, 'رمضان المبارک', () => _scroll(kRam)],
      [Icons.celebration, 'عیدین', () => _scroll(kEid)],
      [Icons.settings, 'تاریخ میں تبدیلی', () => _scroll(kAdj)],
    ];
    return SizedBox(
      height: 78,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 6),
        itemBuilder: (ctx, i) {
          final first = i == 0;
          return InkWell(
            onTap: items[i][2] as VoidCallback,
            borderRadius: BorderRadius.circular(12),
            child: Container(
              width: 88,
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: first ? _gd : cardColor(c),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: green.withAlpha(80)),
              ),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(items[i][0] as IconData, color: first ? Colors.white : _gd, size: 26),
                const SizedBox(height: 3),
                FittedBox(fit: BoxFit.scaleDown, child: Text(items[i][1] as String, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: first ? Colors.white : null))),
              ]),
            ),
          );
        },
      ),
    );
  }

  Widget _calendar(BuildContext c, DateTime today) {
    final lead = month.weekday % 7;
    final nDays = DateTime(month.year, month.month + 1, 0).day;
    final weeks = ((lead + nDays) / 7).ceil();
    const heads = ['اتوار', 'پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ'];
    return box(c, padding: const EdgeInsets.all(8), child: Directionality(
      textDirection: TextDirection.ltr,
      child: Column(children: [
        Container(
          decoration: BoxDecoration(color: isDark(c) ? const Color(0xFF24543A) : const Color(0xFFE6F4EA), borderRadius: BorderRadius.circular(10)),
          child: Row(children: [
            IconButton(onPressed: () => _move(-1), icon: const Icon(Icons.chevron_left, color: _gd, size: 28)),
            Expanded(
              child: InkWell(
                onTap: _pickMonth,
                child: Text('${month.year}  ${urduMonths[month.month - 1]}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              ),
            ),
            IconButton(onPressed: () => _move(1), icon: const Icon(Icons.chevron_right, color: _gd, size: 28)),
          ]),
        ),
        const SizedBox(height: 6),
        Row(children: [
          for (final h in heads)
            Expanded(child: Center(child: Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: FittedBox(fit: BoxFit.scaleDown, child: Text(h, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _gd)))))),
        ]),
        for (int w = 0; w < weeks; w++)
          Row(children: [
            for (int col = 0; col < 7; col++) _cell(c, w * 7 + col - lead + 1, nDays, col, today),
          ]),
      ]),
    ));
  }

  Widget _cell(BuildContext c, int day, int nDays, int col, DateTime today) {
    if (day < 1 || day > nDays) return const Expanded(child: SizedBox(height: 50));
    final d = DateTime(month.year, month.month, day);
    final h = toHijri(d);
    final isToday = sameDay(d, today);
    final isSel = sameDay(d, sel);
    final hasEv = _eventOf(d).isNotEmpty;
    final fg = isToday ? Colors.white : (col == 5 ? green : null);
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(25),
        onTap: () => setState(() => sel = d),
        child: Container(
          height: 50,
          margin: const EdgeInsets.all(1.5),
          decoration: BoxDecoration(
            color: isToday ? _gd : null,
            shape: BoxShape.circle,
            border: isSel && !isToday ? Border.all(color: _gd, width: 2) : (hasEv && !isToday ? Border.all(color: gold, width: 1.6) : null),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('$day', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: fg)),
            Text('${h[2]}', style: TextStyle(fontSize: 9.5, color: isToday ? Colors.white70 : gold.withAlpha(240), fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
    );
  }

  Widget _summary(BuildContext c) {
    final h = toHijri(sel);
    final ev = _eventOf(sel);
    final bayd = h[2] >= 13 && h[2] <= 15;
    Widget row(String a, String b) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(children: [Expanded(child: Text(a, style: TextStyle(fontSize: 12.5, color: subText(c)))), Text(b, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.bold))]),
        );
    return box(c, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: const [Icon(Icons.event_note, color: _gd), SizedBox(width: 6), Text('منتخب تاریخ کا خلاصہ', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15))]),
      const Divider(height: 14),
      row('تاریخ', fmtDate(sel)),
      row('ہجری تاریخ', hijriText(sel)),
      row('مہینے کا نام', hijriMonths[clampI(h[1] - 1, 0, 11)]),
      row('مہینے کا دن', '${h[2]}'),
      if (ev.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Row(children: [const Icon(Icons.star, color: gold, size: 20), const SizedBox(width: 6), Expanded(child: Text(ev, style: const TextStyle(fontWeight: FontWeight.bold)))])),
      if (bayd) const Padding(padding: EdgeInsets.only(top: 6), child: Text('ایامِ بیض (روزے کے مستحب دن)', style: TextStyle(color: _gd, fontWeight: FontWeight.bold))),
    ]));
  }

  Widget _months(BuildContext c, List<int> ht, int hy) => Container(
        decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(70))),
        child: Column(children: [
          for (int i = 1; i <= 12; i++)
            InkWell(
              onTap: () => _monthSheet(i, hy),
              child: Container(
                margin: const EdgeInsets.all(2),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(color: ht[1] == i ? _gd : null, borderRadius: BorderRadius.circular(8)),
                child: Row(children: [
                  Icon(i == 9 ? Icons.nightlight_round : (i == 12 ? Icons.account_balance : Icons.mosque), color: ht[1] == i ? Colors.white : _gd, size: 22),
                  const SizedBox(width: 10),
                  Expanded(child: Text(hijriMonths[i - 1], style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: ht[1] == i ? Colors.white : null))),
                  Text('$hyھ', style: TextStyle(color: ht[1] == i ? Colors.white70 : subText(c))),
                  if (ht[1] == i) const Padding(padding: EdgeInsets.only(right: 8), child: Icon(Icons.arrow_back, color: Colors.white, size: 18)),
                ]),
              ),
            ),
        ]),
      );

  Widget _evTile(BuildContext c, _Ev e) {
    final d = _nextOf(e.m, e.d);
    final h = toHijri(d);
    return InkWell(
      onTap: () => _evSheet(e),
      child: box(c, padding: const EdgeInsets.all(10), child: Row(children: [
        Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(color: _gd, borderRadius: BorderRadius.circular(10)),
          child: Icon(e.icon, color: Colors.white, size: 28),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(e.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            Text('${e.sub} ${h[0]}ھ', style: TextStyle(fontSize: 12.5, color: subText(c))),
          ]),
        ),
        Text(_remain(d), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _gd)),
      ])),
    );
  }

  Widget _ramadan(BuildContext c, List<int> ht) {
    final start = _nextOf(9, 1);
    final qadr = _nextOf(9, 27);
    final eid = _nextOf(10, 1);
    Widget row(String a, DateTime d) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [Expanded(child: Text(a)), Text(fmtDate(d), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12.5)), const SizedBox(width: 8), Text(_remain(d), style: const TextStyle(color: _gd, fontSize: 12))]),
        );
    return box(c, child: Column(children: [
      if (ht[1] == 9)
        Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), _gd]), borderRadius: BorderRadius.circular(10)),
          child: Text('رمضان جاری ہے — آج ${ht[2]} رمضان ہے 🌙', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ),
      row('رمضان کا آغاز', start),
      row('27 ویں شب', qadr),
      row('عید الفطر', eid),
    ]));
  }

  Widget _eids(BuildContext c) {
    final f = _nextOf(10, 1);
    final a = _nextOf(12, 10);
    return box(c, child: Column(children: [
      Row(children: [const Icon(Icons.mosque, color: _gd), const SizedBox(width: 8), const Expanded(child: Text('عید الفطر')), Text(fmtDate(f), style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold))]),
      const SizedBox(height: 8),
      Row(children: [const Icon(Icons.account_balance, color: _gd), const SizedBox(width: 8), const Expanded(child: Text('عید الاضحیٰ')), Text(fmtDate(a), style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold))]),
      const SizedBox(height: 10),
      SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(onPressed: () => go(c, const EidainScreen()), icon: const Icon(Icons.edit_note), label: const Text('عیدین کا ریکارڈ کھولیں')),
      ),
    ]));
  }

  Widget _adjCard(BuildContext c) {
    final adj = getI('hadj');
    return box(c, color: isDark(c) ? const Color(0xFF24543A) : const Color(0xFFF2F8E8), child: Column(children: [
      Row(children: [
        const Icon(Icons.edit_calendar, color: _gd),
        const SizedBox(width: 8),
        const Expanded(child: Text('تاریخ میں تبدیلی', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
        Text('موجودہ: ${adj > 0 ? '+$adj' : adj}', style: const TextStyle(fontWeight: FontWeight.bold, color: _gd)),
      ]),
      const SizedBox(height: 6),
      Text('مقامی چاند دیکھنے کے اعلان کے مطابق ہجری تاریخ میں ایک دن کا فرق ہو سکتا ہے۔ آپ اپنی دستی طور پر تاریخ درست کر سکتے ہیں۔', style: TextStyle(fontSize: 12.5, height: 1.7, color: subText(c))),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: _adjust, icon: const Icon(Icons.edit_calendar), label: const Text('تاریخ تبدیل کریں'))),
    ]));
  }

  Widget _quote() => Container(
        margin: const EdgeInsets.only(top: 4),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF0E6B43), Color(0xFF06331F)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
          border: Border.all(color: gold, width: 2),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(children: const [
          Text('🌙', style: TextStyle(fontSize: 32)),
          SizedBox(height: 6),
          Text('اسلامی کیلنڈر', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
          SizedBox(height: 6),
          Text('ہمارا مقصد صرف تاریخ جاننا نہیں، بلکہ ہر دن کو اللہ کی رضا کے لیے بہتر بنانا ہے۔', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, height: 1.8)),
        ]),
      );
}
