import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';

const zikrs = [
  ['سبحان اللہ', 'سُبْحَانَ اللّٰهِ'],
  ['الحمد للہ', 'اَلْحَمْدُ لِلّٰهِ'],
  ['اللہ اکبر', 'اَللّٰهُ اَكْبَرُ'],
  ['لا الہ الا اللہ', 'لَا اِلٰهَ اِلَّا اللّٰهُ'],
  ['درود شریف', 'اَللّٰهُمَّ صَلِّ عَلٰى مُحَمَّدٍ'],
  ['استغفار', 'اَسْتَغْفِرُ اللّٰهَ'],
];

class TasbeehScreen extends StatelessWidget {
  const TasbeehScreen({super.key});

  Future<void> _custom(BuildContext c) async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('اپنا ہدف لکھیں'),
        content: TextField(controller: ctrl, keyboardType: TextInputType.number, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ٹھیک ہے')),
        ],
      ),
    );
    if (ok == true) {
      final v = int.tryParse(ctrl.text.trim()) ?? 0;
      if (v > 0) {
        sp.setInt('tb_count', 0);
        setI('tb_target', v);
      }
    }
  }

  void _tap(BuildContext c) {
    final target = getI('tb_target', 33);
    var count = getI('tb_count') + 1;
    sp.setInt('tb_total', getI('tb_total') + 1);
    if (count >= target) {
      count = 0;
      sp.setInt('tb_rounds', getI('tb_rounds') + 1);
      HapticFeedback.heavyImpact();
      toast(c, 'ماشاء اللہ! ہدف مکمل ہوا');
    } else {
      HapticFeedback.lightImpact();
    }
    setI('tb_count', count);
  }

  @override
  Widget build(BuildContext context) => Screen(
        'تسبیح کاؤنٹر',
        Rebuild((c) {
          final target = getI('tb_target', 33);
          final count = getI('tb_count');
          final zi = clampI(getI('tb_zikr'), 0, zikrs.length - 1);
          return ListView(padding: const EdgeInsets.all(12), children: [
            Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
              for (int i = 0; i < zikrs.length; i++)
                ChoiceChip(
                  label: Text(zikrs[i][0]),
                  selected: zi == i,
                  onSelected: (_) {
                    sp.setInt('tb_count', 0);
                    setI('tb_zikr', i);
                  },
                ),
            ]),
            const SizedBox(height: 14),
            Center(child: Text(zikrs[zi][1], style: const TextStyle(fontSize: 26, color: green, height: 1.8), textAlign: TextAlign.center)),
            const SizedBox(height: 10),
            Center(
              child: GestureDetector(
                onTap: () => _tap(c),
                child: SizedBox(
                  width: 260,
                  height: 260,
                  child: Stack(alignment: Alignment.center, children: [
                    SizedBox(width: 260, height: 260, child: CircularProgressIndicator(value: target == 0 ? 0 : count / target, strokeWidth: 10, color: gold, backgroundColor: Colors.grey.withAlpha(60))),
                    Container(
                      width: 220,
                      height: 220,
                      decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF1E9B3F), Color(0xFF0B5D3B)])),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Text('$count', style: const TextStyle(color: Colors.white, fontSize: 64, fontWeight: FontWeight.bold)),
                        Text('ہدف: $target', style: const TextStyle(color: Colors.white70, fontSize: 15)),
                        const SizedBox(height: 4),
                        const Text('گننے کے لیے ٹیپ کریں', style: TextStyle(color: Colors.white54, fontSize: 11)),
                      ]),
                    ),
                  ]),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Wrap(spacing: 8, alignment: WrapAlignment.center, children: [
              for (final n in [33, 99, 100])
                ChoiceChip(
                  label: Text('$n'),
                  selected: target == n,
                  onSelected: (_) {
                    sp.setInt('tb_count', 0);
                    setI('tb_target', n);
                  },
                ),
              ActionChip(label: const Text('اپنا ہدف'), onPressed: () => _custom(c)),
            ]),
            const SizedBox(height: 14),
            box(
              c,
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                Column(children: [Text('${getI('tb_rounds')}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: green)), const Text('مکمل دور')]),
                Column(children: [Text('${getI('tb_total')}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: green)), const Text('کل تسبیحات')]),
              ]),
            ),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: () => setI('tb_count', 0), icon: const Icon(Icons.refresh), label: const Text('صفر کریں'))),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    if (!await confirmDialog(c, 'کل تسبیحات اور دور صفر کریں؟')) return;
                    sp.setInt('tb_total', 0);
                    sp.setInt('tb_rounds', 0);
                    setI('tb_count', 0);
                  },
                  icon: const Icon(Icons.delete_sweep),
                  label: const Text('سب صفر'),
                ),
              ),
            ]),
          ]);
        }),
      );
}
