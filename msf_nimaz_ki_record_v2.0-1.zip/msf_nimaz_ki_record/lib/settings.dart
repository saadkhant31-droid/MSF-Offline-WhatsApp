import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'timetable.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _restore(BuildContext c) async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('ڈیٹا بحال کریں'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('بیک اپ کا متن یہاں چسپاں کریں۔ موجودہ ڈیٹا بدل جائے گا۔', style: TextStyle(fontSize: 13)),
          const SizedBox(height: 8),
          TextField(controller: ctrl, maxLines: 4, decoration: const InputDecoration(border: OutlineInputBorder())),
          TextButton(
            onPressed: () async {
              final d = await Clipboard.getData('text/plain');
              ctrl.text = d?.text ?? '';
            },
            child: const Text('کلپ بورڈ سے چسپاں کریں'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('بحال کریں')),
        ],
      ),
    );
    if (ok == true) {
      final r = await importData(ctrl.text.trim());
      if (c.mounted) toast(c, r ? 'ڈیٹا بحال ہو گیا' : 'بیک اپ درست نہیں ہے');
    }
  }

  @override
  Widget build(BuildContext context) => Screen(
        'سیٹنگز',
        Rebuild((c) {
          final city = currentCity();
          final asr = getI('asr', 2);
          final adj = getI('hadj');
          return ListView(padding: const EdgeInsets.all(10), children: [
            sectionTitle('نماز کے اوقات'),
            box(
              c,
              padding: EdgeInsets.zero,
              child: ListTile(
                leading: const Icon(Icons.location_city, color: green),
                title: const Text('شہر'),
                subtitle: Text(city.name),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => pickCity(c),
              ),
            ),
            box(
              c,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('نماز اوقات کا نقشہ (کوہاٹ)', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [
                  for (int k = 0; k < 2; k++) ChoiceChip(label: Text(ttNames[k]), selected: ttMap() == k, onSelected: (_) => setI('ttmap', k)),
                ]),
              ]),
            ),
            box(
              c,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('عصر کا وقت', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [
                  ChoiceChip(label: const Text('حنفی (دو مثل)'), selected: asr == 2, onSelected: (_) => setI('asr', 2)),
                  ChoiceChip(label: const Text('شافعی / مالکی / حنبلی (ایک مثل)'), selected: asr == 1, onSelected: (_) => setI('asr', 1)),
                ]),
              ]),
            ),
            sectionTitle('ہجری تاریخ'),
            box(
              c,
              child: Row(children: [
                const Expanded(child: Text('ہجری تاریخ ایڈجسٹ کریں (دن)', style: TextStyle(fontWeight: FontWeight.bold))),
                IconButton(onPressed: adj > -2 ? () => setI('hadj', adj - 1) : null, icon: const Icon(Icons.remove_circle_outline, color: green)),
                Text(adj > 0 ? '+$adj' : '$adj', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                IconButton(onPressed: adj < 2 ? () => setI('hadj', adj + 1) : null, icon: const Icon(Icons.add_circle_outline, color: green)),
              ]),
            ),
            sectionTitle('تھیم'),
            box(
              c,
              padding: EdgeInsets.zero,
              child: SwitchListTile(
                secondary: const Icon(Icons.dark_mode, color: green),
                title: const Text('ڈارک موڈ'),
                value: getB('dark'),
                onChanged: (v) {
                  themeMode.value = v ? ThemeMode.dark : ThemeMode.light;
                  setB('dark', v);
                },
              ),
            ),
            sectionTitle('بیک اپ'),
            box(
              c,
              padding: EdgeInsets.zero,
              child: Column(children: [
                ListTile(
                  leading: const Icon(Icons.backup, color: green),
                  title: const Text('بیک اپ کاپی کریں'),
                  subtitle: const Text('سارا ریکارڈ متن کی صورت میں کاپی ہو گا، اسے کہیں محفوظ کر لیں'),
                  onTap: () => copyText(c, exportData()),
                ),
                const Divider(height: 1),
                ListTile(leading: const Icon(Icons.restore, color: green), title: const Text('بیک اپ سے بحال کریں'), onTap: () => _restore(c)),
              ]),
            ),
            sectionTitle('شیئر اور دیگر'),
            box(
              c,
              padding: EdgeInsets.zero,
              child: Column(children: [
                ListTile(
                  leading: const Icon(Icons.share, color: green),
                  title: const Text('ایپ شیئر کریں'),
                  subtitle: const Text('تعارفی پیغام کاپی ہو گا'),
                  onTap: () => copyText(c, 'MSF Nimaz ki Record (ایم ایس ایف نماز کی ریکارڈ)\nنماز، قضا، نوافل، تسبیح اور دعاؤں کا مکمل ریکارڈ رکھنے والی اردو ایپ۔'),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.delete_forever, color: Color(0xFFD32F2F)),
                  title: const Text('تمام ڈیٹا حذف کریں'),
                  onTap: () async {
                    if (!await confirmDialog(c, 'تمام ریکارڈ ہمیشہ کے لیے حذف ہو جائے گا۔ کیا آپ واقعی حذف کرنا چاہتے ہیں؟')) return;
                    await sp.clear();
                    themeMode.value = ThemeMode.light;
                    bump();
                    if (c.mounted) toast(c, 'تمام ڈیٹا حذف ہو گیا');
                  },
                ),
              ]),
            ),
          ]);
        }),
      );
}

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  @override
  Widget build(BuildContext context) {
    const steps = [
      '«پانچ وقت کی نماز» میں ہر نماز پر ٹیپ کر کے ادا، با جماعت یا قضا کا نشان لگائیں۔',
      'قضا منتخب کرنے پر وہ خود «قضا نماز» کے ریکارڈ میں شامل ہو جاتی ہے۔',
      'نفل، تراویح، تہجد، جمعہ اور عیدین میں روزانہ (یا سالانہ) چیک لسٹ بھریں۔',
      'رپورٹس میں روزانہ، ہفتہ وار اور ماہانہ کارکردگی دیکھیں۔',
      'نماز کے اوقات اور قبلہ کے لیے سیٹنگز میں اپنا شہر منتخب کریں۔',
      'سارا ڈیٹا صرف آپ کے فون میں رہتا ہے۔ سیٹنگز سے بیک اپ لیتے رہیں۔',
    ];
    return Screen(
      'ایپ کے بارے میں',
      ListView(padding: const EdgeInsets.all(14), children: [
        Center(child: ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/header.png', width: 300, fit: BoxFit.cover))),
        const SizedBox(height: 14),
        const Center(child: Text('MSF Nimaz ki Record', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: green))),
        const Center(child: Text('ایم ایس ایف نماز کی ریکارڈ', style: TextStyle(fontSize: 17))),
        const SizedBox(height: 4),
        Center(child: Text('ورژن 1.1.0', style: TextStyle(color: subText(context)))),
        const SizedBox(height: 14),
        sectionTitle('مدد: ایپ کیسے استعمال کریں'),
        for (final s in steps)
          box(context, child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.check, color: green, size: 20), const SizedBox(width: 8), Expanded(child: Text(s, style: const TextStyle(height: 1.7)))])),
        Padding(padding: const EdgeInsets.all(8), child: Center(child: Text('اللہ ہمیں نماز کی پابندی کی توفیق عطا فرمائے۔ آمین', style: TextStyle(color: subText(context))))),
      ]),
    );
  }
}
