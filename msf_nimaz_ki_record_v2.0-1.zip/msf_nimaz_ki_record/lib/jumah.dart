import 'dart:convert';
import 'package:flutter/material.dart';
import 'store.dart';
import 'widgets.dart';

const _gDark = Color(0xFF0B5D3B);
const _gMid = Color(0xFF1E8A4C);
const _gLight = Color(0xFFE6F4EA);

DateTime lastFriday(DateTime d) {
  var x = dayOnly(d);
  while (x.weekday != DateTime.friday) {
    x = addDays(x, -1);
  }
  return x;
}

String isoDate(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class JRec {
  String st = '';
  String txt = '';
  String mosque = '';
  List<bool> done = [true, true, true, false];
  List<int> rk = [4, 2, 6, 0];
  bool saved = false;

  String enc() => jsonEncode({'st': st, 'txt': txt, 'm': mosque, 'd': done, 'r': rk});

  static JRec load(DateTime d) {
    final r = JRec();
    final s = getS('jm:${dayKey(d)}');
    if (s.isEmpty) return r;
    try {
      final m = jsonDecode(s) as Map<String, dynamic>;
      r.st = (m['st'] ?? '') as String;
      r.txt = (m['txt'] ?? '') as String;
      r.mosque = (m['m'] ?? '') as String;
      r.done = (m['d'] as List).map((e) => e == true).toList();
      r.rk = (m['r'] as List).map((e) => (e as num).toInt()).toList();
      r.saved = true;
    } catch (_) {}
    return r;
  }
}

class _Stats {
  int total = 0, yes = 0, no = 0, fard = 0, sunnat = 0, nafl = 0;
}

_Stats _stats(Iterable<DateTime> fridays) {
  final s = _Stats();
  for (final f in fridays) {
    s.total++;
    final r = JRec.load(f);
    if (!r.saved) continue;
    if (r.st == 'yes') {
      s.yes++;
      if (r.done[0]) s.sunnat += r.rk[0];
      if (r.done[1]) s.fard += r.rk[1];
      if (r.done[2]) s.sunnat += r.rk[2];
      if (r.done[3]) s.nafl += r.rk[3];
    } else {
      s.no++;
    }
  }
  return s;
}

class JumahScreen extends StatefulWidget {
  final VoidCallback? onBack;
  const JumahScreen({super.key, this.onBack});
  @override
  State<JumahScreen> createState() => _JumahScreenState();
}

class _JumahScreenState extends State<JumahScreen> {
  late DateTime fri;
  late JRec r;
  final txtC = TextEditingController();
  final mosqueC = TextEditingController();
  bool editing = true;

  static const opts = [
    ['yes', 'جی ہاں\nپڑھ لی'],
    ['no', 'نہیں پڑھی'],
    ['r1', 'مسجد نہیں جا سکا'],
    ['r2', 'بیماری کی وجہ سے نہیں جا سکا'],
    ['r3', 'کام یا مصروفیت کی وجہ سے نہیں جا سکا'],
    ['r4', 'نیند یا غفلت کی وجہ سے نہیں جا سکا'],
    ['r5', 'دوسری وجہ'],
  ];
  static const optIcons = [Icons.mosque, Icons.mosque_outlined, Icons.home, Icons.healing, Icons.work, Icons.bedtime, Icons.list_alt];
  static const rowNames = ['جمعہ سے پہلے کی سنت', 'جمعہ کے فرض', 'جمعہ کے بعد کی سنت', 'اضافی نفل'];

  @override
  void initState() {
    super.initState();
    fri = lastFriday(DateTime.now());
    _load();
  }

  @override
  void dispose() {
    txtC.dispose();
    mosqueC.dispose();
    super.dispose();
  }

  void _load() {
    r = JRec.load(fri);
    txtC.text = r.txt;
    mosqueC.text = r.mosque;
    editing = !r.saved;
  }

  bool _canEdit() {
    if (!editing) toast(context, 'پہلے "ریکارڈ میں ترمیم کریں" دبائیں');
    return editing;
  }

  void _shift(int weeks) {
    setState(() {
      fri = addDays(fri, 7 * weeks);
      _load();
    });
  }

  Future<void> _pickDate() async {
    final p = await showDatePicker(
      context: context,
      initialDate: fri,
      firstDate: DateTime(2020),
      lastDate: DateTime(DateTime.now().year + 1, 12, 31),
      selectableDayPredicate: (d) => d.weekday == DateTime.friday,
    );
    if (p != null) {
      setState(() {
        fri = dayOnly(p);
        _load();
      });
    }
  }

  void _save() {
    if (r.st.isEmpty) {
      toast(context, 'پہلے بتائیں کہ جمعہ کی نماز پڑھی یا نہیں');
      return;
    }
    r.txt = txtC.text.trim();
    r.mosque = mosqueC.text.trim();
    r.saved = true;
    setS('jm:${dayKey(fri)}', r.enc());
    setState(() => editing = false);
    toast(context, 'ریکارڈ محفوظ ہو گیا ✓');
  }

  Future<void> _delete() async {
    if (!r.saved) {
      toast(context, 'اس جمعے کا کوئی محفوظ ریکارڈ نہیں');
      return;
    }
    if (!await confirmDialog(context, 'کیا اس جمعے کا ریکارڈ حذف کریں؟')) return;
    del('jm:${dayKey(fri)}');
    setState(_load);
    toast(context, 'ریکارڈ حذف ہو گیا');
  }

  int get total {
    if (r.st != 'yes') return 0;
    var t = 0;
    for (var i = 0; i < 4; i++) {
      if (r.done[i]) t += r.rk[i];
    }
    return t;
  }

  // ------------------------------------------------------------ build
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Column(children: [
        _header(context, w),
        Expanded(
          child: ListView(padding: const EdgeInsets.fromLTRB(10, 10, 10, 16), children: [
            _banner(context),
            _sec(Icons.how_to_reg, 'جمعہ کی نماز پڑھی یا نہیں؟'),
            _options(context),
            _sec(Icons.edit_note, 'جمعہ کی نماز کا ریکارڈ'),
            _recordCard(context),
            _actions(context),
            const SizedBox(height: 6),
            Rebuild((c) => _reports(c)),
          ]),
        ),
      ]),
    );
  }

  Widget _header(BuildContext c, double w) {
    final top = MediaQuery.of(c).padding.top;
    return SizedBox(
      height: w * 312 / 1024 + top,
      child: Stack(fit: StackFit.expand, children: [
        Image.asset('assets/header.png', fit: BoxFit.cover, alignment: Alignment.bottomCenter),
        Positioned(
          left: 12,
          top: top + 6,
          child: InkWell(
            onTap: () {
              if (Navigator.of(c).canPop()) {
                Navigator.of(c).pop();
              } else {
                widget.onBack?.call();
              }
            },
            borderRadius: BorderRadius.circular(30),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: _gDark.withAlpha(220),
                border: Border.all(color: const Color(0xFF55E0C0), width: 2),
                borderRadius: BorderRadius.circular(30),
              ),
              child: const Directionality(
                textDirection: TextDirection.ltr,
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.arrow_back, color: Colors.white, size: 20),
                  SizedBox(width: 6),
                  Text('واپس', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                ]),
              ),
            ),
          ),
        ),
        Positioned(
          right: 10,
          bottom: 6,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_gMid, _gDark], begin: Alignment.topCenter, end: Alignment.bottomCenter),
              border: Border.all(color: gold, width: 2.5),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: const [
              Icon(Icons.mosque, color: Colors.white, size: 20),
              Text('جمعہ', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold, height: 1.1)),
              Text('کی نماز', style: TextStyle(color: Colors.white70, fontSize: 12)),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _banner(BuildContext c) {
    final today = sameDay(fri, DateTime.now());
    return Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Expanded(
        flex: 6,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10, left: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [_gMid, _gDark]),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(today ? 'آج جمعہ ہے' : 'جمعہ کا ریکارڈ', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            const Text('اپنی نماز کا ریکارڈ درج کریں', style: TextStyle(color: Colors.white, fontSize: 13)),
          ]),
        ),
      ),
      Expanded(
        flex: 5,
        child: InkWell(
          onTap: _pickDate,
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            decoration: BoxDecoration(color: isDark(c) ? const Color(0xFF1F2B25) : _gLight, borderRadius: BorderRadius.circular(14), border: Border.all(color: _gMid.withAlpha(90))),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
                Icon(Icons.calendar_month, color: _gDark, size: 20),
                SizedBox(width: 4),
                Text('جمعہ کی تاریخ', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ]),
              const SizedBox(height: 2),
              Text(isoDate(fri), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              Text(hijriText(fri), style: TextStyle(fontSize: 11, color: subText(c))),
            ]),
          ),
        ),
      ),
    ]);
  }

  Widget _sec(IconData ic, String t) => Container(
        margin: const EdgeInsets.only(top: 4, bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [_gDark, green2]),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(children: [
          Icon(ic, color: Colors.white),
          const SizedBox(width: 8),
          Text(t, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
        ]),
      );

  Widget _options(BuildContext c) {
    return LayoutBuilder(builder: (ctx, cons) {
      final tw = (cons.maxWidth - 16) / 3;
      return Wrap(spacing: 8, runSpacing: 8, children: [
        for (var i = 0; i < opts.length; i++) _tile(c, i, tw),
      ]);
    });
  }

  Widget _tile(BuildContext c, int i, double w) {
    final key = opts[i][0];
    final sel = r.st == key;
    final badge = key == 'yes' ? Colors.green : (key == 'no' ? Colors.red : null);
    return InkWell(
      onTap: () {
        if (!_canEdit()) return;
        setState(() => r.st = key);
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: w,
        height: 96,
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: sel ? (isDark(c) ? const Color(0xFF24543A) : const Color(0xFFD5EEDC)) : cardColor(c),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: sel ? _gMid : Colors.grey.withAlpha(90), width: sel ? 2.5 : 1),
        ),
        child: Stack(children: [
          Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(optIcons[i], size: 32, color: _gDark),
              const SizedBox(height: 4),
              Text(opts[i][1], textAlign: TextAlign.center, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, height: 1.35)),
            ]),
          ),
          if (sel && badge != null)
            Positioned(top: 0, left: 0, child: Icon(key == 'yes' ? Icons.check_circle : Icons.cancel, color: badge, size: 22)),
        ]),
      ),
    );
  }

  Widget _recordCard(BuildContext c) {
    final off = r.st != 'yes';
    return Column(children: [
      box(c, child: Column(children: [
        TextField(
          controller: txtC,
          enabled: editing,
          maxLines: 2,
          decoration: const InputDecoration(
            labelText: 'اپنی وجہ خود لکھیں (اختیاری)',
            prefixIcon: Icon(Icons.edit, color: _gDark),
                      ),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: mosqueC,
          enabled: editing,
          decoration: const InputDecoration(
            labelText: 'مسجد کا نام (اختیاری)',
            prefixIcon: Icon(Icons.mosque, color: _gDark),
                      ),
        ),
      ])),
      if (off)
        box(c, child: Row(children: [
          const Icon(Icons.info_outline, color: _gDark),
          const SizedBox(width: 8),
          Expanded(child: Text('رکعات کا ریکارڈ صرف تب درج ہو گا جب "جی ہاں پڑھ لی" منتخب ہو۔', style: TextStyle(color: subText(c), fontSize: 13))),
        ]))
      else ...[
        for (var i = 0; i < 4; i++) _row(c, i),
        box(c, color: isDark(c) ? const Color(0xFF24543A) : _gLight, child: Row(children: [
          const Icon(Icons.mosque, color: _gDark, size: 36),
          const SizedBox(width: 10),
          const Expanded(child: Text('کل رکعتیں', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
          Text('$total', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: _gDark)),
        ])),
      ],
    ]);
  }

  Widget _row(BuildContext c, int i) {
    return box(c, padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8), child: Row(children: [
      Expanded(child: Text(rowNames[i], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14))),
      InkWell(
        onTap: () {
          if (!_canEdit()) return;
          setState(() => r.done[i] = !r.done[i]);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(color: r.done[i] ? Colors.green : Colors.grey, borderRadius: BorderRadius.circular(8)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(r.done[i] ? Icons.check : Icons.close, color: Colors.white, size: 18),
            const SizedBox(width: 4),
            Text(r.done[i] ? 'پڑھی' : 'نہیں', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ]),
        ),
      ),
      const SizedBox(width: 8),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          _round(Icons.remove, () {
            if (!_canEdit()) return;
            setState(() => r.rk[i] = clampI(r.rk[i] - 1, 0, 20));
          }),
          SizedBox(width: 30, child: Text('${r.rk[i]}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
          _round(Icons.add, () {
            if (!_canEdit()) return;
            setState(() => r.rk[i] = clampI(r.rk[i] + 1, 0, 20));
          }),
        ]),
      ),
    ]));
  }

  Widget _round(IconData ic, VoidCallback f) => InkWell(
        onTap: f,
        child: Container(
          width: 30,
          height: 30,
          decoration: const BoxDecoration(color: _gDark, shape: BoxShape.circle),
          child: Icon(ic, color: Colors.white, size: 18),
        ),
      );

  Widget _actions(BuildContext c) {
    Widget b(String t, IconData ic, Color col, VoidCallback f) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: ElevatedButton.icon(
              onPressed: f,
              icon: Icon(ic, size: 18),
              label: Text(t, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(backgroundColor: col, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            ),
          ),
        );
    return Row(children: [
      b('محفوظ کریں', Icons.save, _gDark, _save),
      b('ترمیم کریں', Icons.edit, _gMid, () {
        setState(() => editing = true);
        toast(c, 'اب ترمیم کر سکتے ہیں');
      }),
      b('حذف کریں', Icons.delete, const Color(0xFFD32F2F), _delete),
    ]);
  }

  // ------------------------------------------------------------ reports
  Widget _reports(BuildContext c) {
    final now = dayOnly(DateTime.now());
    final week = _stats(fri.isAfter(now) ? <DateTime>[] : [fri]);
    final yr = <DateTime>[];
    var f = lastFriday(DateTime(fri.year, 1, 7));
    while (f.year == fri.year && !f.isAfter(now)) {
      yr.add(f);
      f = addDays(f, 7);
    }
    final y = _stats(yr);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _repBox(c, 'جمعہ کی ہفتہ وار رپورٹ', Icons.bar_chart, [
        ['اس ہفتے گزرے جمعے', week.total],
        ['جمعہ کی نماز پڑھی', week.yes],
        ['نماز نہیں پڑھی', week.no],
        ['فرض کی کل رکعتیں', week.fard],
        ['سنتوں کی کل رکعتیں', week.sunnat],
        ['نفل کی کل رکعتیں', week.nafl],
      ]),
      _repBox(c, 'جمعہ کی سالانہ رپورٹ ${fri.year}', Icons.calendar_month, [
        ['کل گزرے جمعے', y.total],
        ['پڑھی گئی جمعہ نمازیں', y.yes],
        ['نہیں پڑھی', y.no],
        ['فرض کی کل رکعتیں', y.fard],
        ['سنتوں کی کل رکعتیں', y.sunnat],
        ['نفل کی کل رکعتیں', y.nafl],
      ]),
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF0E6B43), Color(0xFF06331F)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
          border: Border.all(color: gold, width: 2),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(children: const [
          Icon(Icons.mosque, color: gold, size: 40),
          SizedBox(height: 6),
          Text('جمعہ کا دن', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
          SizedBox(height: 4),
          Text('اللہ کی خاص رحمتوں اور مغفرت کا دن ہے۔\nاس دن کی نماز میں کبھی کوتاہی نہ کریں۔', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, height: 1.8)),
        ]),
      ),
    ]);
  }

  Widget _repBox(BuildContext c, String t, IconData ic, List<List<Object>> rows) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: _gMid.withAlpha(80))),
      child: Column(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: const BoxDecoration(gradient: LinearGradient(colors: [_gDark, green2]), borderRadius: BorderRadius.vertical(top: Radius.circular(11))),
          child: Row(children: [
            Icon(ic, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(t, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15))),
          ]),
        ),
        for (final x in rows)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.withAlpha(50)))),
            child: Row(children: [
              Expanded(child: Text(x[0] as String, style: const TextStyle(fontSize: 14))),
              Text('${x[1]}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: _gDark)),
            ]),
          ),
      ]),
    );
  }
}
