import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'prayers.dart';
import 'checklist.dart';
import 'qaza.dart';
import 'nafl.dart';
import 'taraweeh.dart';
import 'tahajjud.dart';
import 'reports.dart';
import 'qibla.dart';
import 'calendar.dart';
import 'duas.dart';
import 'tasbeeh.dart';
import 'jumah.dart';
import 'eidain.dart';
import 'settings.dart';

class Feature {
  final String title, sub;
  final IconData icon;
  final Color c1, c2;
  final Widget Function() page;
  Feature(this.title, this.sub, this.icon, this.c1, this.c2, this.page);
}

List<Feature> allFeatures() => [
      Feature('پانچ وقت کی نماز', 'تمام نمازوں کا مکمل ریکارڈ', Icons.mosque, const Color(0xFF1B8A45), const Color(0xFF0D5C2C), () => const PrayersScreen()),
      Feature('قضا نماز', 'وجہ، وقت اور تفصیل کے ساتھ', Icons.fact_check, const Color(0xFF1565C0), const Color(0xFF0B3F8C), () => const QazaScreen()),
      Feature('نفل نمازیں', 'تمام نوافل کا ریکارڈ', Icons.back_hand, const Color(0xFF8E24AA), const Color(0xFF5E1578), () => const NaflScreen()),
      Feature('تراویح', '20 رکعت کا مکمل ریکارڈ', Icons.mosque_outlined, const Color(0xFF136B4B), const Color(0xFF0A4733), () => const TaraweehScreen()),
      Feature('تہجد', 'رات کی نماز کا ریکارڈ', Icons.self_improvement, const Color(0xFF9A5A2B), const Color(0xFF6B3A14), () => const TahajjudScreen()),
      Feature(
        'جمعہ کی نماز',
        'سنت، فرض اور نوافل',
        Icons.mosque,
        const Color(0xFF1456A8),
        const Color(0xFF0A3470),
        () => const JumahScreen(),
      ),
      Feature(
        'عیدین کی نماز',
        'عید الفطر اور عید الاضحیٰ',
        Icons.celebration,
        const Color(0xFFD81B60),
        const Color(0xFF9C1048),
        () => const EidainScreen(),
      ),
      Feature('قبلہ', 'سمت معلوم کریں', Icons.explore, const Color(0xFF1B6B2E), const Color(0xFF0F4A1F), () => const QiblaScreen()),
      Feature('اسلامی کیلنڈر', 'ہجری اور اسلامی تاریخیں', Icons.calendar_month, const Color(0xFF1AA0B5), const Color(0xFF0F7788), () => const CalendarScreen()),
      Feature('نماز کی رپورٹس', 'روزانہ، ہفتہ وار، ماہانہ', Icons.summarize, const Color(0xFFEF7D12), const Color(0xFFC25A05), () => const ReportScreen()),
      Feature('قضا نمازوں کی رپورٹ', 'باقی قضا نمازوں کا حساب', Icons.bar_chart, const Color(0xFF4A3BC0), const Color(0xFF2F2490), () => const QazaReportScreen()),
      Feature('سیٹنگز', 'شہر، تھیم، بیک اپ وغیرہ', Icons.settings, const Color(0xFF6E8E2A), const Color(0xFF4A641A), () => const SettingsScreen()),
      Feature('دعائیں', 'روزمرہ کی اہم دعائیں', Icons.menu_book, const Color(0xFFA81E52), const Color(0xFF741136), () => const DuasScreen()),
      Feature('تسبیح کاؤنٹر', 'ڈیجیٹل تسبیح', Icons.blur_circular, const Color(0xFF1296A8), const Color(0xFF0B6877), () => const TasbeehScreen()),
      Feature('ایپ کے بارے میں', 'ورژن اور مدد', Icons.info, const Color(0xFF5B7289), const Color(0xFF3E5063), () => const AboutScreen()),
    ];

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int idx = 0;
  late final List<Feature> features = allFeatures();

  @override
  void initState() {
    super.initState();
    shellHome = () => setState(() => idx = 0);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: idx == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) setState(() => idx = 0);
      },
      child: Scaffold(
        body: IndexedStack(index: idx, children: [
          HomePage(features: features),
          const PrayersScreen(),
          JumahScreen(onBack: () => setState(() => idx = 0)),
          EidainScreen(onBack: () => setState(() => idx = 0)),
          const TaraweehScreen(),
          const TahajjudScreen(),
          const SettingsScreen(),
          MorePage(features: features),
        ]),
        bottomNavigationBar: _nav(context),
      ),
    );
  }

  Widget _nav(BuildContext context) {
    const items = [
      [Icons.home, 'ہوم'],
      [Icons.mosque, 'نمازیں'],
      [Icons.account_balance, 'جمعہ'],
      [Icons.celebration, 'عیدین'],
      [Icons.nightlight_round, 'تراویح'],
      [Icons.self_improvement, 'تہجد'],
      [Icons.settings, 'سیٹنگز'],
      [Icons.menu, 'مزید'],
    ];
    const glow = Color(0xFF3DDC84);
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0E5A3A), Color(0xFF06291B)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        border: Border(top: BorderSide(color: gold.withAlpha(140), width: 1.5)),
      ),
      padding: EdgeInsets.fromLTRB(4, 6, 4, 6 + MediaQuery.of(context).padding.bottom),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          for (int i = 0; i < items.length; i++) ...[
            if (i > 0) Container(width: 1, height: 34, color: Colors.white24),
            Expanded(
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => setState(() => idx = i),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: idx == i ? Colors.white10 : null,
                    border: Border.all(color: idx == i ? glow : Colors.transparent, width: 2),
                    boxShadow: idx == i ? [BoxShadow(color: glow.withAlpha(90), blurRadius: 8)] : null,
                  ),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(items[i][0] as IconData, color: idx == i ? gold : Colors.white, size: 22),
                    const SizedBox(height: 2),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(items[i][1] as String, style: TextStyle(color: idx == i ? gold : Colors.white, fontSize: 10.5, fontWeight: FontWeight.bold)),
                    ),
                  ]),
                ),
              ),
            ),
          ],
        ]),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final List<Feature> features;
  const HomePage({super.key, required this.features});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DateTime now = DateTime.now();
  Timer? timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) setState(() => now = DateTime.now());
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Widget _cell(BuildContext c, IconData icon, String title, String value) => FittedBox(
        fit: BoxFit.scaleDown,
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: green, size: 30),
          const SizedBox(width: 6),
          Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.center, children: [
            Text(title, style: TextStyle(fontSize: 11, color: subText(c))),
            Text(value, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
          ]),
        ]),
      );

  Widget _info(BuildContext c) => Container(
        margin: const EdgeInsets.fromLTRB(10, 10, 10, 6),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
        decoration: BoxDecoration(
          color: cardColor(c),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: green.withAlpha(110), width: 1.3),
          boxShadow: [BoxShadow(color: Colors.black.withAlpha(20), blurRadius: 6, offset: const Offset(0, 2))],
        ),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Row(children: [
            Expanded(child: _cell(c, Icons.calendar_month, 'آج کی تاریخ', '${now.day} ${urduMonths[now.month - 1]} ${now.year}\n(${urduDays[now.weekday - 1]})')),
            Container(width: 1, height: 40, color: Colors.grey.withAlpha(90)),
            Expanded(child: _cell(c, Icons.nightlight_round, 'ہجری تاریخ', hijriText(now))),
            Container(width: 1, height: 40, color: Colors.grey.withAlpha(90)),
            Expanded(child: _cell(c, Icons.access_time, 'موجودہ وقت', fmtTime(now))),
          ]),
        ),
      );

  Widget _tile(BuildContext c, Feature f) => ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Material(
          color: Colors.transparent,
          child: Ink(
            decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [f.c1, f.c2])),
            child: InkWell(
              onTap: () => go(c, f.page()),
              child: Stack(children: [
                const Positioned(right: 1, top: 0, bottom: 0, child: Center(child: Icon(Icons.chevron_right, color: Colors.white70, size: 18))),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(f.icon, color: Colors.white, size: 34),
                        const SizedBox(height: 3),
                        Text(f.title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
                        Text(f.sub, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 9.5)),
                      ]),
                    ),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    final w = MediaQuery.of(context).size.width;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
      child: SingleChildScrollView(
        child: Column(children: [
          SizedBox(
            width: double.infinity,
            height: top + w * 312 / 1024,
            child: Image.asset('assets/header.png', fit: BoxFit.cover, alignment: Alignment.bottomCenter),
          ),
          Rebuild((c) => _info(c)),
          Directionality(
            textDirection: TextDirection.ltr,
            child: GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(10, 4, 10, 8),
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 1.25,
              children: [for (final f in widget.features) _tile(context, f)],
            ),
          ),
          Image.asset('assets/footer.png', width: double.infinity, fit: BoxFit.fitWidth),
        ]),
      ),
    );
  }
}

class ListPage extends StatelessWidget {
  final List<Feature> features;
  const ListPage({super.key, required this.features});
  @override
  Widget build(BuildContext context) => Screen(
        'فہرست',
        ListView(padding: const EdgeInsets.all(10), children: [
          for (final f in features)
            InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => go(context, f.page()),
              child: box(
                context,
                child: Row(children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(gradient: LinearGradient(colors: [f.c1, f.c2]), borderRadius: BorderRadius.circular(12)),
                    child: Icon(f.icon, color: Colors.white),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(f.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      Text(f.sub, style: TextStyle(fontSize: 12, color: subText(context))),
                    ]),
                  ),
                  const Icon(Icons.chevron_left),
                ]),
              ),
            ),
        ]),
      );
}

class MorePage extends StatelessWidget {
  final List<Feature> features;
  const MorePage({super.key, required this.features});

  @override
  Widget build(BuildContext context) {
    // دعائیں, تسبیح, قبلہ, کیلنڈر, قضا رپورٹ, ایپ کے بارے میں
    final picks = [features[13], features[12], features[7], features[8], features[10], features[14]];
    return Screen(
      'مزید',
      ListView(padding: const EdgeInsets.all(10), children: [
        for (final f in picks)
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => go(context, f.page()),
            child: box(
              context,
              child: Row(children: [
                Icon(f.icon, color: green, size: 28),
                const SizedBox(width: 14),
                Expanded(child: Text(f.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                const Icon(Icons.chevron_left),
              ]),
            ),
          ),
        InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => copyText(context, 'MSF Nimaz ki Record (ایم ایس ایف نماز کی ریکارڈ)\nنماز، قضا، نوافل، تسبیح اور دعاؤں کا مکمل ریکارڈ رکھنے والی اردو ایپ۔'),
          child: box(
            context,
            child: const Row(children: [
              Icon(Icons.share, color: green, size: 28),
              SizedBox(width: 14),
              Expanded(child: Text('ایپ شیئر کریں', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
            ]),
          ),
        ),
      ]),
    );
  }
}
