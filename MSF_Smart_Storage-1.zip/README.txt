MSF Smart Storage - real Flutter app.
1) GitHub repository me sari files upload karein (.github folder samet).
2) Actions tab -> Build APK -> Artifacts se APK download karein.
Note: abhi files phone ke andar "cloud" folder me save hoti hain. Asli online storage (Cloudflare R2 / Storj) agla marhala hai.
