import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MsfApp());

const kTotalMb = 45 * 1024.0;
const cats = <String, List<dynamic>>{
  'Images': [Icons.image, Color(0xFFFF2BD6), Color(0xFFE0149A)],
  'Videos': [Icons.play_circle_fill, Color(0xFFFFB000), Color(0xFFFF6A00)],
  'Audio': [Icons.music_note, Color(0xFF1E90FF), Color(0xFF1456E8)],
  'Documents': [Icons.description, Color(0xFF1FD14A), Color(0xFF0F9A35)],
  'Downloads': [Icons.download, Color(0xFFA63CFF), Color(0xFF6A1DE0)],
  'ZIP / RAR': [Icons.folder_zip, Color(0xFF12E0B0), Color(0xFF0AA6B8)],
};

String catOf(String n) {
  final e = n.split('.').last.toLowerCase();
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'heic'].contains(e)) return 'Images';
  if (['mp4', 'mkv', 'avi', 'mov', '3gp', 'webm'].contains(e)) return 'Videos';
  if (['mp3', 'wav', 'm4a', 'aac', 'ogg', 'flac'].contains(e)) return 'Audio';
  if (['zip', 'rar', '7z'].contains(e)) return 'ZIP / RAR';
  return 'Documents';
}

String sz(double m) => m >= 1024
    ? '${(m / 1024).toStringAsFixed(2)} GB'
    : '${m < 10 ? m.toStringAsFixed(1) : m.round()} MB';

String ago(int ms) {
  final d = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms)).inDays;
  return d == 0 ? 'Today' : d == 1 ? 'Yesterday' : '$d days ago';
}

class Item {
  String id, name, cat;
  double mb;
  int ts;
  bool off, fav;
  Item(this.id, this.name, this.cat, this.mb, this.ts, {this.off = false, this.fav = false});
  Map<String, dynamic> toJson() =>
      {'id': id, 'n': name, 'c': cat, 'mb': mb, 'ts': ts, 'off': off, 'fav': fav};
  factory Item.fromJson(Map<String, dynamic> j) => Item(j['id'], j['n'], j['c'],
      (j['mb'] as num).toDouble(), j['ts'], off: j['off'], fav: j['fav']);
}

class MsfApp extends StatelessWidget {
  const MsfApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'MSF Smart Storage',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF1E7BFF),
          scaffoldBackgroundColor: const Color(0xFF050B3A),
        ),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  late SharedPreferences sp;
  late Directory cloud, offd;
  List<Item> items = [];
  String view = 'home', cat = 'All', q = '';
  bool offMode = false, wifi = true, ready = false;
  final busy = <String>{};

  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {
    sp = await SharedPreferences.getInstance();
    final docs = await getApplicationDocumentsDirectory();
    cloud = Directory('${docs.path}/cloud')..createSync(recursive: true);
    offd = Directory('${docs.path}/offline')..createSync(recursive: true);
    final s = sp.getString('files');
    if (s != null) {
      items = (jsonDecode(s) as List).map((e) => Item.fromJson(e)).toList();
    }
    offMode = sp.getBool('offMode') ?? false;
    wifi = sp.getBool('wifi') ?? true;
    setState(() => ready = true);
  }

  Future<void> save() async {
    await sp.setString('files', jsonEncode(items.map((e) => e.toJson()).toList()));
    await sp.setBool('offMode', offMode);
    await sp.setBool('wifi', wifi);
  }

  String cp(Item i) => '${cloud.path}/${i.id}-${i.name}';
  String op(Item i) => '${offd.path}/${i.id}-${i.name}';
  void msg(String t) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(t)));
  void go(String v, [String c = 'All']) => setState(() {
        view = v;
        cat = c;
        q = '';
      });
  double get used => items.fold(0.0, (s, e) => s + e.mb);
  int count(String c) => c == 'Downloads'
      ? items.where((e) => e.off).length
      : items.where((e) => e.cat == c).length;

  Future<void> upload() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (r == null) return;
    for (final f in r.files) {
      if (f.path == null) continue;
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      final it = Item(id, f.name, catOf(f.name), f.size / 1048576,
          DateTime.now().millisecondsSinceEpoch);
      await File(f.path!).copy(cp(it));
      items.insert(0, it);
    }
    await save();
    setState(() => view = 'files');
    msg('فائلیں اپ لوڈ ہو گئیں ✓');
  }

  Future<void> download(Item i) async {
    if (i.off) {
      final f = File(op(i));
      if (f.existsSync()) f.deleteSync();
      i.off = false;
      await save();
      setState(() {});
      msg('موبائل سے ہٹا دی، کلاؤڈ میں محفوظ ہے');
      return;
    }
    setState(() => busy.add(i.id));
    await File(cp(i)).copy(op(i));
    i.off = true;
    busy.remove(i.id);
    await save();
    setState(() {});
    msg('ڈاؤن لوڈ مکمل ✓');
  }

  Future<void> openIt(Item i) async {
    if (offMode && !i.off) {
      msg('انٹرنیٹ بند ہے، پہلے ڈاؤن لوڈ کریں');
      return;
    }
    final r = await OpenFilex.open(i.off ? op(i) : cp(i));
    if (r.type != ResultType.done) msg('اس فائل کے لیے کوئی ایپ نہیں ملی');
  }

  Future<void> delete(Item i) async {
    for (final p in [cp(i), op(i)]) {
      final f = File(p);
      if (f.existsSync()) f.deleteSync();
    }
    items.remove(i);
    await save();
    setState(() {});
    msg('فائل حذف ہو گئی');
  }

  void sheet(String t, List<List<dynamic>> opts) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF0F1A5C),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
              padding: const EdgeInsets.all(12),
              child: Text(t, style: const TextStyle(fontWeight: FontWeight.bold))),
          for (final o in opts)
            ListTile(
              title: Text(o[0] as String),
              onTap: () {
                Navigator.pop(context);
                (o[1] as VoidCallback)();
              },
            ),
        ]),
      ),
    );
  }

  void menu(Item i) => sheet(i.name, [
        ['▶️ Open / Play', () => openIt(i)],
        [i.off ? '📱❌ Remove from phone' : '⬇️ Download', () => download(i)],
        [i.fav ? '💔 Remove favorite' : '⭐ Add to favorites', () async {
          i.fav = !i.fav;
          await save();
          setState(() {});
        }],
        ['🗑️ Delete', () => delete(i)],
      ]);

  void plans() => sheet('Storage Plans', [
        for (final p in ['Free • 5 GB', '50 GB', '500 GB', '1000 GB', '5000 GB (5 TB)'])
          [p, () => msg('جلد آ رہا ہے')]
      ]);

  Future<void> clearCache() async {
    final t = await getTemporaryDirectory();
    for (final e in t.listSync()) {
      try {
        e.deleteSync(recursive: true);
      } catch (_) {}
    }
    msg('Cache صاف ہو گیا ✓');
  }

  void topMore() => sheet('More', [
        ['⬆️ Upload files', upload],
        ['🔤 Sort by name', () {
          setState(() => items.sort((a, b) => a.name.compareTo(b.name)));
        }],
        ['📏 Sort by size', () {
          setState(() => items.sort((a, b) => b.mb.compareTo(a.mb)));
        }],
        ['🧹 Clear cache', clearCache],
      ]);

  void toggleOff() {
    setState(() => offMode = !offMode);
    save();
    msg(offMode ? 'Offline Mode آن' : 'Online Mode آن');
  }

  // ---------- widgets ----------
  Widget ib(IconData ic, String t, Color c, VoidCallback f) => Padding(
        padding: const EdgeInsets.only(left: 4),
        child: Column(children: [
          InkWell(
            onTap: f,
            customBorder: const CircleBorder(),
            child: CircleAvatar(radius: 20, backgroundColor: c, child: Icon(ic, size: 20)),
          ),
          Text(t, style: const TextStyle(fontSize: 10)),
        ]),
      );

  Widget header() => Row(children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFF22D3EE), width: 3),
            image: const DecorationImage(
                image: AssetImage('assets/logo.png'), fit: BoxFit.cover),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('MSF', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              const Text.rich(TextSpan(
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
                  children: [
                    TextSpan(text: 'Smart '),
                    TextSpan(text: 'Storage', style: TextStyle(color: Color(0xFFFFD400))),
                  ])),
              const Text('Your Files, Your Control', style: TextStyle(fontSize: 12)),
              GestureDetector(
                onTap: toggleOff,
                child: Container(
                  margin: const EdgeInsets.only(top: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(
                      color: offMode ? const Color(0xFF16C93D) : Colors.grey,
                      borderRadius: BorderRadius.circular(14)),
                  child: Text(offMode ? '✔ Offline Mode' : 'Online Mode',
                      style: const TextStyle(fontSize: 12)),
                ),
              ),
            ]),
          ),
        ),
        ib(Icons.settings, 'Settings', const Color(0xFF1E7BFF), () => go('set')),
        ib(Icons.search, 'Search', const Color(0xFFA63CFF), () => go('search')),
        ib(Icons.more_horiz, 'More', const Color(0xFF16C93D), topMore),
      ]);

  BoxDecoration card() => BoxDecoration(
      color: const Color(0xCC0C1650),
      border: Border.all(color: const Color(0xFF4A5CFF), width: 1.5),
      borderRadius: BorderRadius.circular(18));

  Widget storageCard() {
    final p = (used / kTotalMb).clamp(0.02, 1.0);
    Widget col(String a, String b, Color c) => Column(children: [
          Text(a, style: const TextStyle(fontSize: 12, color: Color(0xFFA9B8FF))),
          Text(b, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: c)),
        ]);
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(12),
      decoration: card(),
      child: Column(children: [
        Row(children: [
          const Icon(Icons.storage, size: 42, color: Color(0xFF29B6F6)),
          const SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
            Text('Total Storage', style: TextStyle(fontSize: 12, color: Color(0xFFA9B8FF))),
            Text('45 GB',
                style: TextStyle(
                    fontSize: 30, fontWeight: FontWeight.w900, color: Color(0xFFFFD400))),
          ]),
          const Spacer(),
          col('Used', sz(used), const Color(0xFF9BE15D)),
          const SizedBox(width: 14),
          col('Available', sz(kTotalMb - used), const Color(0xFF22D3EE)),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                  value: p,
                  minHeight: 12,
                  color: const Color(0xFF00E639),
                  backgroundColor: const Color(0xFF3B4BB8)),
            ),
          ),
          const SizedBox(width: 8),
          Text('${(p * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.bold)),
        ]),
      ]),
    );
  }

  Widget tiles() => GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 1.05,
        children: [
          for (final k in cats.keys)
            InkWell(
              onTap: () => k == 'Downloads' ? go('dl') : go('files', k),
              borderRadius: BorderRadius.circular(16),
              child: Ink(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(
                      colors: [cats[k]![1] as Color, cats[k]![2] as Color]),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(cats[k]![0] as IconData, size: 30),
                  Text(k, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  Text('${count(k)} Files', style: const TextStyle(fontSize: 11)),
                ]),
              ),
            ),
        ],
      );

  Widget row(Item i) {
    final c = cats[i.cat]!;
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
          color: const Color(0xFF0A1240),
          border: Border.all(color: const Color(0xFF4A5CFF)),
          borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () => openIt(i),
        child: Row(children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                gradient: LinearGradient(colors: [c[1] as Color, c[2] as Color])),
            child: Icon(c[0] as IconData),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${i.name}${i.fav ? ' ⭐' : ''}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(
                  '${i.cat} • ${sz(i.mb)}${busy.contains(i.id) ? ' • ⏳' : i.off ? ' • ✅ Offline' : ''}',
                  style: const TextStyle(fontSize: 12, color: Color(0xFFA9B8FF))),
            ]),
          ),
          Text(ago(i.ts), style: const TextStyle(fontSize: 11, color: Color(0xFFA9B8FF))),
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () => menu(i)),
        ]),
      ),
    );
  }

  Widget list(List<Item> a, String empty) => a.isEmpty
      ? Padding(
          padding: const EdgeInsets.all(40),
          child: Center(child: Text(empty, textAlign: TextAlign.center)))
      : Column(children: a.map(row).toList());

  Widget title(String t) => Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(t, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)));

  Widget homeV() => Column(children: [
        header(),
        storageCard(),
        const SizedBox(height: 12),
        tiles(),
        Container(
          margin: const EdgeInsets.only(top: 12),
          padding: const EdgeInsets.all(12),
          decoration: card(),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('🕒 Recent Files',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              GestureDetector(
                  onTap: () => go('files'),
                  child: const Text('View All ›', style: TextStyle(color: Color(0xFF22D3EE)))),
            ]),
            list(items.take(3).toList(), 'ابھی کوئی فائل نہیں۔ Upload دبائیں'),
          ]),
        ),
      ]);

  Widget filesV() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        title('📁 ${cat == 'All' ? 'Files' : cat}'),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            for (final k in ['All', ...cats.keys.where((e) => e != 'Downloads')])
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(
                    label: Text(k), selected: cat == k, onSelected: (_) => go('files', k)),
              ),
          ]),
        ),
        list(items.where((e) => cat == 'All' || e.cat == cat).toList(), 'یہاں کوئی فائل نہیں'),
        const SizedBox(height: 12),
        FilledButton.icon(
            onPressed: upload, icon: const Icon(Icons.upload), label: const Text('Upload')),
      ]);

  Widget dlV() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        title('⬇️ Downloads (Offline)'),
        const Text('یہ فائلیں موبائل میں محفوظ ہیں، انٹرنیٹ کے بغیر چلیں گی',
            style: TextStyle(fontSize: 13, color: Color(0xFFA9B8FF))),
        list(items.where((e) => e.off).toList(), 'کوئی ڈاؤن لوڈ شدہ فائل نہیں'),
      ]);

  Widget favV() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        title('⭐ Favorites'),
        list(items.where((e) => e.fav).toList(), 'ابھی کوئی پسندیدہ فائل نہیں'),
      ]);

  Widget searchV() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        title('🔍 Search'),
        TextField(
          autofocus: true,
          decoration: const InputDecoration(
              hintText: 'Search files...', border: OutlineInputBorder()),
          onChanged: (v) => setState(() => q = v),
        ),
        list(
            q.isEmpty
                ? []
                : items.where((e) => e.name.toLowerCase().contains(q.toLowerCase())).toList(),
            q.isEmpty ? 'فائل کا نام لکھیں' : 'کچھ نہیں ملا'),
      ]);

  Widget setV() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        title('⚙️ Settings'),
        SwitchListTile(
            title: const Text('Offline Mode'), value: offMode, onChanged: (_) => toggleOff()),
        SwitchListTile(
            title: const Text('Download on Wi-Fi only'),
            value: wifi,
            onChanged: (v) {
              setState(() => wifi = v);
              save();
            }),
        ListTile(title: const Text('🧹 Clear cache'), onTap: clearCache),
        ListTile(title: const Text('💳 Storage plans'), onTap: plans),
        ListTile(title: const Text('ℹ️ About'), onTap: () => msg('MSF Smart Storage v1.0')),
      ]);

  Widget moreV() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        title('☰ More'),
        ListTile(title: const Text('⬆️ Upload files'), onTap: upload),
        ListTile(title: const Text('⚙️ Settings'), onTap: () => go('set')),
        ListTile(title: const Text('💳 Storage plans'), onTap: plans),
        ListTile(title: const Text('🧹 Clear cache'), onTap: clearCache),
      ]);

  Widget nav() {
    final cur = (view == 'search' || view == 'set') ? 'home' : view;
    Widget b(String v, IconData ic, String t) => InkWell(
          onTap: () => go(v),
          borderRadius: BorderRadius.circular(20),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
                color: cur == v ? const Color(0xFF1E7BFF) : null,
                borderRadius: BorderRadius.circular(20)),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(ic),
              Text(t, style: const TextStyle(fontSize: 11)),
            ]),
          ),
        );
    return Container(
      color: const Color(0xFF0A1240),
      padding: const EdgeInsets.all(6),
      child: SafeArea(
        top: false,
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          b('home', Icons.home, 'Home'),
          b('files', Icons.folder, 'Files'),
          b('dl', Icons.download, 'Downloads'),
          b('fav', Icons.star, 'Favorites'),
          b('more', Icons.person, 'More'),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final views = {
      'home': homeV, 'files': filesV, 'dl': dlV, 'fav': favV,
      'search': searchV, 'set': setV, 'more': moreV,
    };
    return PopScope(
      canPop: view == 'home',
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) go('home');
      },
      child: Scaffold(
        bottomNavigationBar: nav(),
        body: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF0B1A8A), Color(0xFF050B3A)])),
          child: SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              child: views[view]!(),
            ),
          ),
        ),
      ),
    );
  }
}
