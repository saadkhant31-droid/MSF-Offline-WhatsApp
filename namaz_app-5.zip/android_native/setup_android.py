#!/usr/bin/env python3
"""
چلانے کا طریقہ (پروجیکٹ فولڈر میں، flutter create . کے بعد):
    python3 android_native/setup_android.py
یہ لائیو وال پیپر کی اینڈرائیڈ فائلیں خود جگہ پر رکھ دیتا ہے اور AndroidManifest.xml میں سروس شامل کر دیتا ہے۔
"""
import pathlib, re, shutil, sys

here = pathlib.Path(__file__).resolve().parent
root = here.parent
app = root / "android" / "app"
if not app.exists():
    sys.exit("android فولڈر نہیں ملا۔ پہلے یہ چلائیں: flutter create . --org com.yourname --project-name namaz_app")

gradle = ""
for name in ("build.gradle.kts", "build.gradle"):
    f = app / name
    if f.exists():
        gradle = f.read_text()
        break
m = re.search(r'namespace\s*=?\s*["\']([\w.]+)["\']', gradle)
if not m:
    sys.exit("پیکج کا نام (namespace) build.gradle میں نہیں ملا")
pkg = m.group(1)
print("پیکج:", pkg)

main = app / "src" / "main"
existing = list(main.glob("**/MainActivity.*"))
kdir = existing[0].parent if existing else main / "kotlin" / pkg.replace(".", "/")
kdir.mkdir(parents=True, exist_ok=True)

for old in existing:
    if old.suffix != ".kt":          # پرانی java/MainActivity ہٹا دیں
        old.rename(old.with_suffix(old.suffix + ".bak"))
    else:
        shutil.copy(old, str(old) + ".bak")

for fn in ("ClockWallpaperService.kt", "MainActivity.kt"):
    (kdir / fn).write_text((here / fn).read_text().replace("__PACKAGE__", pkg))

(main / "res" / "xml").mkdir(parents=True, exist_ok=True)
(main / "res" / "values").mkdir(parents=True, exist_ok=True)
shutil.copy(here / "clock_wallpaper.xml", main / "res" / "xml" / "clock_wallpaper.xml")
shutil.copy(here / "msf_wallpaper_strings.xml", main / "res" / "values" / "msf_wallpaper_strings.xml")

mf = main / "AndroidManifest.xml"
text = mf.read_text()
if "ClockWallpaperService" in text:
    print("مینی فیسٹ میں سروس پہلے سے موجود ہے")
else:
    service = '''
        <service
            android:name=".ClockWallpaperService"
            android:exported="true"
            android:label="MSF Prayer App"
            android:permission="android.permission.BIND_WALLPAPER">
            <intent-filter>
                <action android:name="android.service.wallpaper.WallpaperService" />
            </intent-filter>
            <meta-data
                android:name="android.service.wallpaper"
                android:resource="@xml/clock_wallpaper" />
        </service>
    '''
    feature = '    <uses-feature android:name="android.software.live_wallpaper" android:required="false" />\n'
    text = text.replace("</application>", service + "</application>", 1)
    text = text.replace("<application", feature + "    <application", 1)
    mf.write_text(text)
    print("مینی فیسٹ اپڈیٹ ہو گیا")
# اجازتیں، نقشے کا queries اور ایپ کا نام
text = mf.read_text()
perms = ""
for perm in ("ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION"):
    if perm not in text:
        perms += '    <uses-permission android:name="android.permission.%s" />\n' % perm
if "android.intent.action.VIEW" not in text.split("<application")[0]:
    perms += """    <queries>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
    </queries>
"""
if perms:
    text = text.replace("<application", perms + "    <application", 1)
text = text.replace('android:label="namaz_app"', 'android:label="MSF Prayer App"')
mf.write_text(text)
print("اجازتیں شامل ہو گئیں")
print("مکمل۔ اب: flutter pub get && flutter run")
