package __PACKAGE__

import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import io.flutter.FlutterInjector
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.embedding.engine.renderer.FlutterRenderer

/**
 * لائیو وال پیپر: فلٹر کا انجن وال پیپر کی سطح پر "wallpaperMain" (lib/wallpaper_entry.dart) چلاتا ہے،
 * اس لیے ایپ والے نو کے نو ڈیزائن وہی نظر آتے ہیں۔
 */
class ClockWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ClockEngine()

    inner class ClockEngine : Engine() {
        private var flutterEngine: FlutterEngine? = null
        private var rendering = false

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            val loader = FlutterInjector.instance().flutterLoader()
            loader.startInitialization(applicationContext)
            loader.ensureInitializationComplete(applicationContext, null)
            val engine = FlutterEngine(applicationContext)
            engine.dartExecutor.executeDartEntrypoint(
                DartExecutor.DartEntrypoint(loader.findAppBundlePath(), "wallpaperMain")
            )
            engine.lifecycleChannel.appIsResumed()
            flutterEngine = engine
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            val renderer = flutterEngine?.renderer ?: return
            if (!rendering) {
                renderer.startRenderingToSurface(holder.surface, false)
                rendering = true
            }
            val m = FlutterRenderer.ViewportMetrics()
            m.devicePixelRatio = resources.displayMetrics.density
            m.width = width
            m.height = height
            renderer.setViewportMetrics(m)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            flutterEngine?.renderer?.stopRenderingToSurface()
            rendering = false
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            val ch = flutterEngine?.lifecycleChannel ?: return
            if (visible) ch.appIsResumed() else ch.appIsPaused()
        }

        override fun onDestroy() {
            flutterEngine?.destroy()
            flutterEngine = null
            super.onDestroy()
        }
    }
}
