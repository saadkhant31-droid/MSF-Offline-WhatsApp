import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// پوری ایپ کی سیٹنگز۔ تبدیل ہوتے ہی خود محفوظ ہو جاتی ہیں۔
class AppSettings extends ChangeNotifier {
  // مقام
  String country = 'پاکستان';
  String province = 'پنجاب';
  String city = 'لاہور';
  double latitude = 31.5204;
  double longitude = 74.3587;
  bool autoGps = false;

  // نماز کے اوقات
  bool hanafi = true;
  String method = 'muslimWorldLeague';
  bool use24h = false;
  bool adhanEnabled = true;
  String adhanSound = 'urdu_male';
  int hijriAdjust = 0;
  String wallpaperStyle = 'style1';

  // ڈسپلے
  String language = 'ur';
  String theme = 'green';
  double fontSize = 16;
  bool vibration = true;
  bool background = true;

  // نوٹیفکیشن
  bool notificationsOn = true;
  Set<String> notifyPrayers = {'fajr', 'dhuhr', 'asr', 'maghrib', 'isha'};

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    await p.reload();
    country = p.getString('country') ?? country;
    province = p.getString('province') ?? province;
    city = p.getString('city') ?? city;
    latitude = p.getDouble('latitude') ?? latitude;
    longitude = p.getDouble('longitude') ?? longitude;
    autoGps = p.getBool('autoGps') ?? autoGps;
    hanafi = p.getBool('hanafi') ?? hanafi;
    method = p.getString('method') ?? method;
    use24h = p.getBool('use24h') ?? use24h;
    adhanEnabled = p.getBool('adhanEnabled') ?? adhanEnabled;
    adhanSound = p.getString('adhanSound') ?? adhanSound;
    hijriAdjust = p.getInt('hijriAdjust') ?? hijriAdjust;
    wallpaperStyle = p.getString('wallpaperStyle') ?? wallpaperStyle;
    language = p.getString('language') ?? language;
    theme = p.getString('theme') ?? theme;
    if (theme != 'dark') theme = 'green';
    fontSize = p.getDouble('fontSize') ?? fontSize;
    vibration = p.getBool('vibration') ?? vibration;
    background = p.getBool('background') ?? background;
    notificationsOn = p.getBool('notificationsOn') ?? notificationsOn;
    notifyPrayers =
        (p.getStringList('notifyPrayers') ?? notifyPrayers.toList()).toSet();
  }

  /// کوئی بھی سیٹنگ بدلنے کے لیے: appSettings.update(() => appSettings.hanafi = false);
  Future<void> update(VoidCallback change) async {
    change();
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setString('country', country);
    await p.setString('province', province);
    await p.setString('city', city);
    await p.setDouble('latitude', latitude);
    await p.setDouble('longitude', longitude);
    await p.setBool('autoGps', autoGps);
    await p.setBool('hanafi', hanafi);
    await p.setString('method', method);
    await p.setBool('use24h', use24h);
    await p.setBool('adhanEnabled', adhanEnabled);
    await p.setString('adhanSound', adhanSound);
    await p.setInt('hijriAdjust', hijriAdjust);
    await p.setString('wallpaperStyle', wallpaperStyle);
    await p.setString('language', language);
    await p.setString('theme', theme);
    await p.setDouble('fontSize', fontSize);
    await p.setBool('vibration', vibration);
    await p.setBool('background', background);
    await p.setBool('notificationsOn', notificationsOn);
    await p.setStringList('notifyPrayers', notifyPrayers.toList());
  }
}

final appSettings = AppSettings();
