import 'dart:math';

/// کسی بھی مقام سے خانہ کعبہ کی سمت (شمال سے ڈگری میں)
double qiblaBearing(double lat, double lng) {
  const kaabaLat = 21.4225;
  const kaabaLng = 39.8262;
  final phi1 = lat * pi / 180;
  final phi2 = kaabaLat * pi / 180;
  final dl = (kaabaLng - lng) * pi / 180;
  final y = sin(dl) * cos(phi2);
  final x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(dl);
  return (atan2(y, x) * 180 / pi + 360) % 360;
}

/// دو مقامات کے درمیان فاصلہ کلومیٹر میں (Haversine)
double distanceKm(double lat1, double lng1, double lat2, double lng2) {
  const r = 6371.0;
  final dLat = (lat2 - lat1) * pi / 180;
  final dLng = (lng2 - lng1) * pi / 180;
  final a = pow(sin(dLat / 2), 2) +
      cos(lat1 * pi / 180) * cos(lat2 * pi / 180) * pow(sin(dLng / 2), 2);
  return 2 * r * asin(sqrt(a));
}

const _abbr = [
  'N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
  'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'
];
const _urdu = [
  'شمال', 'شمال-شمال مشرق', 'شمال مشرق', 'مشرق-شمال مشرق',
  'مشرق', 'مشرق-جنوب مشرق', 'جنوب مشرق', 'جنوب-جنوب مشرق',
  'جنوب', 'جنوب-جنوب مغرب', 'جنوب مغرب', 'مغرب-جنوب مغرب',
  'مغرب', 'مغرب-شمال مغرب', 'شمال مغرب', 'شمال-شمال مغرب'
];

int _windIndex(double deg) => ((deg + 11.25) / 22.5).floor() % 16;
String compassAbbr(double deg) => _abbr[_windIndex(deg)];
String compassUrdu(double deg) => _urdu[_windIndex(deg)];

String fmtLat(double v) => '${v.abs().toStringAsFixed(4)}° ${v >= 0 ? 'N' : 'S'}';
String fmtLng(double v) => '${v.abs().toStringAsFixed(4)}° ${v >= 0 ? 'E' : 'W'}';
