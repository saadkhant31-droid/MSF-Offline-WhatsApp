import 'package:flutter/material.dart';
import 'app_settings.dart';
import 'wallpaper_styles.dart';

/// اینڈرائیڈ کے لائیو وال پیپر سروس کا ڈارٹ داخلی نقطہ
/// (ClockWallpaperService.kt اسی نام "wallpaperMain" کو چلاتا ہے)
@pragma('vm:entry-point')
Future<void> wallpaperMain() async {
  WidgetsFlutterBinding.ensureInitialized();
  await appSettings.load();
  runApp(const _WallpaperApp());
}

class _WallpaperApp extends StatelessWidget {
  const _WallpaperApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, brightness: Brightness.dark),
      home: const Scaffold(
        backgroundColor: Colors.black,
        body: TickingWallpaper(),
      ),
    );
  }
}
