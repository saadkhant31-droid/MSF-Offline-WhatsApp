import 'dart:math';
import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import 'app_settings.dart';

const _green = Color(0xFF0B3D2E);
const _greenMid = Color(0xFF0B6E4F);
const _gold = Color(0xFFE6B94D);

class _MonthInfo {
  final DateTime start; // اس مہینے کی پہلی تاریخ (عیسوی)
  final int days;
  _MonthInfo(this.start, this.days);
}

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});
  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  AppSettings get s => appSettings;
  late int hYear;
  final Map<int, Map<int, _MonthInfo>> _cache = {};
  int _cacheAdjust = 999;

  static const monthsAr = [
    'محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة',
    'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'
  ];
  static const monthsEn = [
    'Muharram', 'Safar', "Rabi' al-Awwal", "Rabi' al-Thani",
    'Jumada al-Awwal', 'Jumada al-Thani', 'Rajab', "Sha'ban", 'Ramadan',
    'Shawwal', 'Dhu al-Qadah', 'Dhu al-Hijjah'
  ];
  static const monthsUr = [
    'محرم', 'صفر', 'ربیع الاول', 'ربیع الآخر', 'جمادی الاول', 'جمادی الآخر',
    'رجب', 'شعبان', 'رمضان', 'شوال', 'ذوالقعدہ', 'ذوالحجہ'
  ];
  static const wdEn = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  static const wdUr = ['اتوار', 'پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ'];
  static const gMonthsUr = [
    'جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون',
    'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'
  ];

  /// مہینہ ← دن ← تقریب (رویتِ ہلال سے ایک دن کا فرق ہو سکتا ہے)
  static const events = <int, Map<int, String>>{
    1: {1: 'اسلامی نیا سال', 10: 'یومِ عاشوراء'},
    3: {12: 'میلاد النبی ﷺ'},
    7: {27: 'شبِ معراج'},
    8: {15: 'شبِ برات'},
    9: {1: 'رمضان کا آغاز (روزہ)', 27: 'شبِ قدر (ممکنہ)'},
    10: {1: 'عید الفطر'},
    12: {9: 'یومِ عرفہ', 10: 'عید الاضحیٰ'},
  };

  HijriCalendar _hijriOf(DateTime d) => HijriCalendar.fromDate(
      DateTime(d.year, d.month, d.day + s.hijriAdjust, 12));

  @override
  void initState() {
    super.initState();
    hYear = _hijriOf(DateTime.now()).hYear;
  }

  /// ہجری سال کے ہر مہینے کی پہلی عیسوی تاریخ اور دن
  Map<int, _MonthInfo> _year(int y) {
    if (_cacheAdjust != s.hijriAdjust) {
      _cache.clear();
      _cacheAdjust = s.hijriAdjust;
    }
    return _cache.putIfAbsent(y, () {
      final est = DateTime(2025, 6, 26)
          .add(Duration(days: ((y - 1447) * 354.367).round()));
      final starts = <int, DateTime>{};
      final lens = <int, int>{};
      for (int i = -45; i < 405; i++) {
        final d = DateTime(est.year, est.month, est.day + i, 12);
        try {
          final h = _hijriOf(d);
          if (h.hYear != y) continue;
          starts.putIfAbsent(h.hMonth, () => d);
          lens[h.hMonth] = max(lens[h.hMonth] ?? 0, h.hDay);
        } catch (_) {}
      }
      return {
        for (final e in starts.entries)
          e.key: _MonthInfo(e.value, lens[e.key] ?? 30)
      };
    });
  }

  String _arabicDigits(String t) {
    const a = '٠١٢٣٤٥٦٧٨٩';
    return t.split('').map((c) {
      final i = int.tryParse(c);
      return i == null ? c : a[i];
    }).join();
  }

  IconData _monthIcon(int m) {
    if (m == 8) return Icons.nightlight_round;
    if (m == 9) return Icons.nights_stay;
    if (m == 7 || m == 11 || m == 12) return Icons.view_in_ar;
    return Icons.mosque;
  }

  // ================= بناوٹ =================
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) {
        final dark = Theme.of(context).brightness == Brightness.dark;
        final info = _year(hYear);
        final today = _hijriOf(DateTime.now());
        return Scaffold(
          backgroundColor: dark ? null : const Color(0xFFF5F2E6),
          body: ListView(padding: EdgeInsets.zero, children: [
            _header(info),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 12, 10, 0),
              child: Column(children: [
                for (int m = 1; m <= 12; m += 2)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(child: _monthCard(m, info, today, dark)),
                          const SizedBox(width: 8),
                          Expanded(child: _monthCard(m + 1, info, today, dark)),
                        ]),
                  ),
              ]),
            ),
            _bottom(dark),
            const SizedBox(height: 16),
          ]),
        );
      },
    );
  }

  // ---------- اوپر کا حصہ ----------
  Widget _header(Map<int, _MonthInfo> info) {
    final topPad = MediaQuery.of(context).padding.top;
    final first = info[1];
    final last = info[12];
    final gy1 = first?.start.year;
    final gy2 = last == null
        ? null
        : DateTime(last.start.year, last.start.month,
                last.start.day + last.days - 1)
            .year;
    final gText = gy1 == null
        ? ''
        : (gy2 == null || gy2 == gy1 ? '$gy1' : '$gy1 - $gy2');
    final currentYear = _hijriOf(DateTime.now()).hYear;

    Widget chip(double w, List<Widget> kids) => Container(
          width: w,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          decoration: BoxDecoration(
            color: _green.withOpacity(0.92),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _gold, width: 1.2),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: kids),
        );

    Widget fit(String t, double size,
            {Color color = Colors.white, bool bold = false}) =>
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(t,
              style: TextStyle(
                  color: color,
                  fontSize: size,
                  fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
        );

    return Stack(children: [
      Positioned.fill(
        child: Stack(fit: StackFit.expand, children: [
          // اختیاری پس منظر: assets/calendar_bg.jpg
          Image.asset(
            'assets/calendar_bg.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF2B6E8F), Color(0xFFE9D9A8)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.15)),
        ]),
      ),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Padding(
          padding: EdgeInsets.fromLTRB(8, topPad + 12, 8, 12),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            chip(78, [
              fit('اسلامی تاریخ', 11, color: _gold, bold: true),
              const SizedBox(height: 4),
              fit('ہجری سال', 11),
              fit('$hYear', 20, bold: true),
              const SizedBox(height: 4),
              fit('عیسوی سال', 11),
              fit(gText, 13, bold: true),
            ]),
            const SizedBox(width: 6),
            Expanded(
              child: Container(
                padding: const EdgeInsets.fromLTRB(8, 14, 8, 10),
                decoration: BoxDecoration(
                  color: _green.withOpacity(0.95),
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(36), bottom: Radius.circular(16)),
                  border: Border.all(color: _gold, width: 1.5),
                ),
                child: Column(children: [
                  fit('التقویم الاسلامي', 26, bold: true),
                  fit('Islamic Calendar', 19, bold: true),
                  const SizedBox(height: 6),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.chevron_left, color: _gold),
                      onPressed: hYear > 1400
                          ? () => setState(() => hYear--)
                          : null,
                    ),
                    Text('$hYear ھ',
                        style: const TextStyle(
                            color: _gold,
                            fontSize: 18,
                            fontWeight: FontWeight.bold)),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      icon: const Icon(Icons.chevron_right, color: _gold),
                      onPressed: hYear < 1498
                          ? () => setState(() => hYear++)
                          : null,
                    ),
                  ]),
                  if (hYear != currentYear)
                    TextButton(
                      onPressed: () => setState(() => hYear = currentYear),
                      child: const Text('آج کا سال',
                          style: TextStyle(color: Colors.white)),
                    ),
                  const SizedBox(height: 2),
                  fit('الشَّمْسُ وَالْقَمَرُ بِحُسْبَانٍ', 16),
                  fit('سورج اور چاند ایک حساب کے پابند ہیں (الرحمٰن: 5)', 11,
                      color: Colors.white70),
                ]),
              ),
            ),
            const SizedBox(width: 6),
            chip(76, [
              fit('${_arabicDigits('$hYear')}ھ', 22, color: _gold, bold: true),
              fit('$hYear Hijri', 12, bold: true),
              const SizedBox(height: 4),
              fit(gText, 12, color: _gold),
              fit('Islamic Calendar', 10, color: Colors.white70),
            ]),
          ]),
        ),
      ),
    ]);
  }

  // ---------- ایک مہینے کا کارڈ ----------
  Widget _monthCard(int m, Map<int, _MonthInfo> info, HijriCalendar today, bool dark) {
    final mi = info[m];
    final isCurrent = today.hYear == hYear && today.hMonth == m;
    final ev = events[m] ?? {};
    final lead = mi == null ? 0 : mi.start.weekday % 7; // اتوار = 0

    Widget cell(String t,
        {bool isToday = false, bool isEvent = false, bool isFri = false}) {
      return Expanded(
        child: Container(
          height: 22,
          margin: const EdgeInsets.all(1),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isToday ? _gold : null,
            border: isEvent && !isToday
                ? Border.all(color: _greenMid, width: 1.2)
                : null,
          ),
          child: Text(t,
              style: TextStyle(
                  fontSize: 11,
                  fontWeight: isToday || isEvent ? FontWeight.bold : null,
                  color: isToday
                      ? Colors.black
                      : (isFri ? _greenMid : null))),
        ),
      );
    }

    final body = Directionality(
      textDirection: TextDirection.ltr,
      child: Column(children: [
        Row(children: [
          for (int i = 0; i < 7; i++)
            Expanded(
              child: Column(children: [
                Text(wdEn[i],
                    style: const TextStyle(fontSize: 7.5, color: Colors.grey)),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(wdUr[i],
                      style: const TextStyle(fontSize: 7.5, color: Colors.grey)),
                ),
              ]),
            ),
        ]),
        const SizedBox(height: 2),
        for (int r = 0; r < 6; r++)
          Row(children: [
            for (int c = 0; c < 7; c++)
              Builder(builder: (_) {
                final idx = r * 7 + c - lead;
                if (mi == null || idx < 0 || idx >= mi.days) {
                  return const Expanded(child: SizedBox(height: 24));
                }
                final day = idx + 1;
                return cell('$day',
                    isToday: isCurrent && today.hDay == day,
                    isEvent: ev.containsKey(day),
                    isFri: c == 5);
              }),
          ]),
      ]),
    );

    return InkWell(
      onTap: mi == null ? null : () => _openMonth(m, info),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        decoration: BoxDecoration(
          color: dark ? const Color(0xFF1E2A25) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _gold, width: isCurrent ? 2.5 : 1.2),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [_green, _greenMid]),
            ),
            child: Row(children: [
              CircleAvatar(
                radius: 15,
                backgroundColor: _gold.withOpacity(0.22),
                child: Icon(_monthIcon(m), color: _gold, size: 17),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(monthsAr[m - 1],
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold)),
                      ),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(monthsEn[m - 1],
                            style: const TextStyle(
                                color: Colors.white70, fontSize: 10)),
                      ),
                    ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('$hYear',
                    style: const TextStyle(color: _gold, fontSize: 11)),
                Text(mi == null ? '' : '${mi.start.year}',
                    style: const TextStyle(color: Colors.white70, fontSize: 11)),
              ]),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 6, 4, 2),
            child: body,
          ),
          Container(
            height: 30,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(
              ev.isEmpty
                  ? '—'
                  : ev.entries
                      .map((e) => '${e.key} ${monthsUr[m - 1]}: ${e.value}')
                      .join('\n'),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.w600),
            ),
          ),
        ]),
      ),
    );
  }

  // ---------- مہینے کی تفصیل (ہجری + عیسوی) ----------
  void _openMonth(int m, Map<int, _MonthInfo> info) {
    final mi = info[m]!;
    final today = _hijriOf(DateTime.now());
    final isCurrent = today.hYear == hYear && today.hMonth == m;
    final lead = mi.start.weekday % 7;
    final endDate = DateTime(
        mi.start.year, mi.start.month, mi.start.day + mi.days - 1);
    String g(DateTime d) => '${d.day} ${gMonthsUr[d.month - 1]} ${d.year}';
    final ev = events[m] ?? {};

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('${monthsUr[m - 1]} $hYear ھ',
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold)),
              Text('${monthsAr[m - 1]} • ${monthsEn[m - 1]}',
                  style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 4),
              Text('عیسوی: ${g(mi.start)} تا ${g(endDate)}',
                  style: const TextStyle(fontSize: 13)),
              const SizedBox(height: 10),
              Directionality(
                textDirection: TextDirection.ltr,
                child: Column(children: [
                  Row(children: [
                    for (int i = 0; i < 7; i++)
                      Expanded(
                        child: Column(children: [
                          Text(wdEn[i],
                              style: const TextStyle(
                                  fontSize: 11, fontWeight: FontWeight.bold)),
                          Text(wdUr[i],
                              style: const TextStyle(
                                  fontSize: 10, color: Colors.grey)),
                        ]),
                      ),
                  ]),
                  const SizedBox(height: 4),
                  for (int r = 0; r < 6; r++)
                    Row(children: [
                      for (int c = 0; c < 7; c++)
                        Builder(builder: (_) {
                          final idx = r * 7 + c - lead;
                          if (idx < 0 || idx >= mi.days) {
                            return const Expanded(child: SizedBox(height: 46));
                          }
                          final day = idx + 1;
                          final gd = DateTime(mi.start.year, mi.start.month,
                              mi.start.day + idx);
                          final isToday = isCurrent && today.hDay == day;
                          final isEvent = ev.containsKey(day);
                          return Expanded(
                            child: Container(
                              height: 46,
                              margin: const EdgeInsets.all(1.5),
                              decoration: BoxDecoration(
                                color: isToday
                                    ? _gold
                                    : (isEvent
                                        ? _greenMid.withOpacity(0.15)
                                        : null),
                                borderRadius: BorderRadius.circular(8),
                                border: isEvent
                                    ? Border.all(color: _greenMid)
                                    : null,
                              ),
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text('$day',
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: isToday
                                                ? Colors.black
                                                : (c == 5 ? _greenMid : null))),
                                    FittedBox(
                                      fit: BoxFit.scaleDown,
                                      child: Text(
                                          gd.day == 1
                                              ? '1 ${gMonthsUr[gd.month - 1]}'
                                              : '${gd.day}',
                                          style: TextStyle(
                                              fontSize: 10,
                                              color: isToday
                                                  ? Colors.black87
                                                  : Colors.grey)),
                                    ),
                                  ]),
                            ),
                          );
                        }),
                    ]),
                ]),
              ),
              const SizedBox(height: 10),
              if (ev.isNotEmpty)
                ...ev.entries.map((e) => ListTile(
                      dense: true,
                      leading: const Icon(Icons.event, color: _greenMid),
                      title: Text('${e.key} ${monthsUr[m - 1]}'),
                      subtitle: Text(e.value),
                    )),
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text(
                    'نوٹ: چاند کی رویت کے مطابق تاریخ میں ایک دن کا فرق ہو سکتا ہے۔ سیٹنگز میں "ہجری تاریخ میں تبدیلی" سے درست کریں۔',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 11, color: Colors.grey)),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  // ---------- نیچے کے حصے ----------
  Widget _bottom(bool dark) {
    Widget panel(String title, Widget child) => Container(
          margin: const EdgeInsets.fromLTRB(10, 4, 10, 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [_green, Color(0xFF0B5A3C)]),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _gold, width: 1.2),
          ),
          child: Column(children: [
            Text(title,
                style: const TextStyle(
                    color: _gold, fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            child,
          ]),
        );

    Widget feature(IconData i, String t) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(children: [
            Icon(i, color: _gold, size: 20),
            const SizedBox(width: 8),
            Expanded(
                child: Text(t,
                    style: const TextStyle(color: Colors.white, fontSize: 13))),
          ]),
        );

    Widget monthsCol(int from) => Expanded(
          child: Column(children: [
            for (int i = from; i < from + 6; i++)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(children: [
                  Text('$i.',
                      style: const TextStyle(color: _gold, fontSize: 13)),
                  const SizedBox(width: 6),
                  Text(monthsUr[i - 1],
                      style:
                          const TextStyle(color: Colors.white, fontSize: 14)),
                ]),
              ),
          ]),
        );

    return Column(children: [
      panel(
        'اہم خصوصیات',
        Column(children: [
          feature(Icons.calendar_month, 'مکمل اسلامی کیلنڈر'),
          feature(Icons.swap_horiz, 'ہجری و عیسوی تاریخ'),
          feature(Icons.edit_calendar, 'ہجری تاریخ میں ±دن کی تبدیلی'),
          feature(Icons.celebration, 'مناسک اور اسلامی تہوار'),
        ]),
      ),
      Container(
        margin: const EdgeInsets.fromLTRB(10, 0, 10, 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [_green, _greenMid]),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _gold, width: 1.2),
        ),
        child: const Column(children: [
          Text('شَهْرُ رَمَضَانَ الَّذِي أُنزِلَ فِيهِ الْقُرْآنُ',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 19, height: 1.6)),
          SizedBox(height: 4),
          Text('رمضان وہ مہینہ ہے جس میں قرآن اتارا گیا (البقرہ: 185)',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 12)),
        ]),
      ),
      panel(
        'اسلامی مہینوں کی ترتیب',
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          monthsCol(1),
          monthsCol(7),
        ]),
      ),
      Container(
        margin: const EdgeInsets.fromLTRB(10, 0, 10, 0),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: _green,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: _gold),
        ),
        child: const Text(
            'اللہ ہم سب کو اپنے فضل و کرم سے اسلام کی روشنی میں زندگی گزارنے کی توفیق عطا فرمائے۔ آمین',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white, fontSize: 12.5)),
      ),
    ]);
  }
}
