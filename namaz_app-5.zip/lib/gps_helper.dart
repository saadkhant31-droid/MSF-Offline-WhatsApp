import 'package:geolocator/geolocator.dart';
import 'app_settings.dart';

/// موجودہ مقام معلوم کرکے سیٹنگز میں محفوظ کرتا ہے۔
/// کامیاب ہو تو null، ورنہ اردو میں خرابی کا پیغام واپس کرتا ہے۔
Future<String?> useCurrentLocation() async {
  try {
    if (!await Geolocator.isLocationServiceEnabled()) {
      return 'براہِ کرم موبائل کی لوکیشن آن کریں';
    }
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      return 'مقام کی اجازت نہیں ملی۔ شہر دستی منتخب کریں';
    }
    final pos = await Geolocator.getCurrentPosition();
    await appSettings.update(() {
      appSettings.autoGps = true;
      appSettings.latitude = pos.latitude;
      appSettings.longitude = pos.longitude;
      appSettings.city = 'موجودہ مقام';
    });
    return null;
  } catch (_) {
    return 'مقام معلوم نہیں ہو سکا';
  }
}
