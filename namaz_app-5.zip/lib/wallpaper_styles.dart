import 'dart:async';
import 'dart:math';
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:intl/intl.dart';
import 'app_settings.dart';
import 'prayer_service.dart';
import 'qibla_math.dart';

const _gold = Color(0xFFE6B94D);
const _green = Color(0xFF0B3D2E);
const _greenMid = Color(0xFF0B6E4F);
const _ok = Color(0xFF1E9E55);
const _kalima = 'لَا إِلَٰهَ إِلَّا اللَّهُ مُحَمَّدٌ رَسُولُ اللَّهِ';

const _wdUr = ['پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ', 'اتوار'];
const _gUr = [
  'جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون',
  'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'
];
const _hUr = [
  'محرم', 'صفر', 'ربیع الاول', 'ربیع الآخر', 'جمادی الاول', 'جمادی الآخر',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذوالقعدہ', 'ذوالحجہ'
];
const _hEn = [
  'Muharram', 'Safar', "Rabi' al-Awwal", "Rabi' al-Thani", 'Jumada al-Awwal',
  'Jumada al-Thani', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal',
  'Dhu al-Qadah', 'Dhu al-Hijjah'
];
const _pName = {
  'fajr': 'فجر', 'dhuhr': 'ظہر', 'asr': 'عصر', 'maghrib': 'مغرب', 'isha': 'عشاء'
};
const _pEn = {
  'fajr': 'Fajr', 'dhuhr': 'Dhuhr', 'asr': 'Asr', 'maghrib': 'Maghrib', 'isha': 'Isha'
};

IconData _pIcon(String k) {
  switch (k) {
    case 'fajr':
      return Icons.wb_twilight;
    case 'dhuhr':
      return Icons.wb_sunny;
    case 'asr':
      return Icons.wb_cloudy;
    case 'maghrib':
      return Icons.wb_twilight;
    default:
      return Icons.nightlight_round;
  }
}

// ======================= ڈیٹا =======================
class WData {
  final DateTime now;
  final AppSettings s;
  late final List<PrayerSlot> slots5;
  late final PrayerSlot? current;
  late final PrayerEntry next;
  late final Duration remaining;
  late final HijriCalendar h;

  WData(this.now, this.s) {
    final all = PrayerService.slots(now, s);
    slots5 = all.where((p) => p.key != 'sunrise').toList();
    current = PrayerService.current(now, all);
    next = PrayerService.next(now, s);
    remaining = next.time.difference(now);
    h = HijriCalendar.fromDate(
        DateTime(now.year, now.month, now.day + s.hijriAdjust, 12));
  }

  bool get h24 => s.use24h;
  String get ampm => h24 ? '' : DateFormat('a').format(now);
  String get hm => DateFormat(h24 ? 'HH:mm' : 'hh:mm').format(now);
  String get ss => DateFormat('ss').format(now);
  String get time3 => '$hm:$ss';
  String hmOf(DateTime t) => DateFormat(h24 ? 'HH:mm' : 'hh:mm').format(t);
  String fullOf(DateTime t) => DateFormat(h24 ? 'HH:mm' : 'hh:mm a').format(t);
  String get weekdayUr => _wdUr[now.weekday - 1];
  String get weekdayEn => DateFormat('EEEE').format(now);
  String get gregUr => '${now.day} ${_gUr[now.month - 1]} ${now.year}';
  String get gregEn => DateFormat('d MMM yyyy').format(now);
  String get hijriUr => '${h.hDay} ${_hUr[h.hMonth - 1]} ${h.hYear}';
  String get hijriEn => '${h.hDay} ${_hEn[h.hMonth - 1]} ${h.hYear}';
  String get city => s.city;
  String get country => s.country;
  double get qibla => qiblaBearing(s.latitude, s.longitude);
  String get gmt {
    final m = now.timeZoneOffset.inMinutes;
    final a = m.abs();
    return 'GMT${m < 0 ? '-' : '+'}${a ~/ 60}${a % 60 == 0 ? '' : ':${(a % 60).toString().padLeft(2, '0')}'}';
  }

  String dur(Duration x) {
    String two(int n) => n.toString().padLeft(2, '0');
    final t = x.isNegative ? Duration.zero : x;
    return '${two(t.inHours)}:${two(t.inMinutes % 60)}:${two(t.inSeconds % 60)}';
  }

  String get countdown => dur(remaining);

  /// اس نماز کے حوالے سے باقی وقت
  Duration untilSlot(PrayerSlot p) {
    if (now.isBefore(p.start)) return p.start.difference(now);
    if (p.end != null && now.isBefore(p.end!)) return p.end!.difference(now);
    return p.start.add(const Duration(days: 1)).difference(now);
  }
}

(String, Color) _status(WData d, PrayerSlot p, {bool en = false}) {
  const grey = Color(0xFF3A4A44);
  if (d.current?.key == p.key) return (en ? 'Now' : 'داخل ہو چکا ہے', _ok);
  if (d.next.name == p.name) return (en ? 'Next' : 'اگلی', _ok);
  if (p.end != null && d.now.isAfter(p.end!)) return (en ? 'Done' : 'مکمل', grey);
  return (en ? 'Later' : 'آنے والی', grey);
}

// ======================= چھوٹے ویجٹس =======================
Widget _txt(String t, double size,
        {Color c = Colors.white, bool bold = false}) =>
    Text(t,
        textAlign: TextAlign.center,
        style: TextStyle(
            color: c,
            fontSize: size,
            fontWeight: bold ? FontWeight.bold : FontWeight.w500,
            height: 1.15,
            decoration: TextDecoration.none));

Widget _fit(Widget w) => FittedBox(fit: BoxFit.scaleDown, child: w);

Widget _at(double l, double t, double w, double h, Widget c) =>
    Positioned(left: l, top: t, width: w, height: h, child: c);

Widget _pill(Widget child,
        {double r = 18,
        Color? color,
        bool circle = false,
        EdgeInsets pad = const EdgeInsets.symmetric(horizontal: 8, vertical: 4)}) =>
    Container(
      padding: pad,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color ?? _green.withOpacity(0.92),
        shape: circle ? BoxShape.circle : BoxShape.rectangle,
        borderRadius: circle ? null : BorderRadius.circular(r),
        border: Border.all(color: _gold, width: 1.4),
      ),
      child: child,
    );

/// ہر ڈیزائن کے اوپر "MSF Islamic App" ضرور لکھا ہوتا ہے
Widget _msfTitle(double size, {String? tag}) => Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text.rich(
          TextSpan(children: [
            TextSpan(
                text: 'MSF ',
                style: TextStyle(
                    color: _gold,
                    fontSize: size,
                    fontWeight: FontWeight.w900,
                    decoration: TextDecoration.none)),
            TextSpan(
                text: 'Islamic App',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: size * 0.8,
                    fontWeight: FontWeight.bold,
                    decoration: TextDecoration.none)),
          ]),
        ),
        if (tag != null) _txt(tag, size * 0.45, c: Colors.white70),
      ],
    );

Widget _digital(WData d, double size,
    {Color c = Colors.white, bool sec = true}) {
  return FittedBox(
    fit: BoxFit.scaleDown,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(sec ? d.time3 : d.hm,
            style: TextStyle(
                color: c,
                fontSize: size,
                fontWeight: FontWeight.bold,
                height: 1,
                decoration: TextDecoration.none,
                fontFeatures: const [FontFeature.tabularFigures()])),
        if (d.ampm.isNotEmpty)
          Padding(
            padding: EdgeInsets.only(left: 4, bottom: size * 0.06),
            child: Text(d.ampm,
                style: TextStyle(
                    color: _gold,
                    fontSize: size * 0.3,
                    fontWeight: FontWeight.bold,
                    height: 1,
                    decoration: TextDecoration.none)),
          ),
      ],
    ),
  );
}

Widget _bg(String file, List<Color> colors, {double photoFrac = 0.5}) {
  return Stack(fit: StackFit.expand, children: [
    Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: colors,
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter),
      ),
    ),
    Align(
      alignment: Alignment.topCenter,
      child: FractionallySizedBox(
        heightFactor: photoFrac,
        widthFactor: 1,
        child: Image.asset('assets/wallpaper/$file',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const SizedBox.shrink()),
      ),
    ),
    Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Colors.transparent, colors.last],
          stops: [photoFrac * 0.55, min(photoFrac + 0.05, 1.0)],
        ),
      ),
    ),
  ]);
}

Widget _photo(String file, {double r = 20}) => ClipRRect(
      borderRadius: BorderRadius.circular(r),
      child: Image.asset(
        'assets/wallpaper/$file',
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (_, __, ___) => Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                colors: [Color(0xFF1B6B8F), Color(0xFF0B4A33)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter),
          ),
          child: Center(
              child: Icon(Icons.mosque, size: 56, color: _gold.withOpacity(0.5))),
        ),
      ),
    );

Widget _canvas(Widget bg, List<Widget> kids) => Stack(fit: StackFit.expand, children: [
      bg,
      Directionality(
        textDirection: TextDirection.ltr,
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(width: 360, height: 760, child: Stack(children: kids)),
        ),
      ),
    ]);

Widget _row5(WData d, double gap, Widget Function(PrayerSlot p, int i) b) => Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (int i = 0; i < 5; i++) ...[
          if (i > 0) SizedBox(width: gap),
          Expanded(child: b(d.slots5[i], i)),
        ],
      ],
    );

Widget _analog(WData d, double size,
        {bool all12 = false,
        bool numerals = true,
        bool hands = true,
        Color face = const Color(0xFF0B4A33),
        Widget? inner}) =>
    SizedBox(
      width: size,
      height: size,
      child: Stack(alignment: Alignment.center, children: [
        CustomPaint(
            size: Size(size, size),
            painter: _ClockPainter(d.now,
                all12: all12, numerals: numerals, hands: hands, face: face)),
        if (inner != null) inner,
      ]),
    );

Widget _compass(double size, double bearing) => SizedBox(
    width: size, height: size, child: CustomPaint(painter: _CompassPainter(bearing)));

Widget _card(WData d, PrayerSlot p,
    {required BoxDecoration deco,
    Color tc = Colors.white,
    Color sc = Colors.white70,
    Color ic = _gold,
    bool range = true,
    String? chip,
    Color chipBg = _ok,
    bool en = false,
    String? under,
    Color? underColor,
    double isz = 26,
    double nameSize = 16,
    double timeSize = 14,
    bool ampm = true}) {
  return Container(
    decoration: deco,
    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 6),
    child: Center(
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(_pIcon(p.key), color: ic, size: isz),
          const SizedBox(height: 2),
          _txt(_pName[p.key]!, nameSize, c: tc, bold: true),
          if (en) _txt(_pEn[p.key]!, 10, c: sc),
          const SizedBox(height: 3),
          _txt(ampm ? d.fullOf(p.start) : d.hmOf(p.start), timeSize,
              c: tc, bold: true),
          if (under != null) _txt(under, 10, c: underColor ?? sc),
          if (range) ...[
            const SizedBox(height: 4),
            _txt('داخل  ${d.hmOf(p.start)}', 10, c: sc),
            _txt('ختم  ${d.hmOf(p.end!)}', 10, c: sc),
          ],
          if (chip != null)
            Container(
              margin: const EdgeInsets.only(top: 5),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                  color: chipBg, borderRadius: BorderRadius.circular(8)),
              child: _txt(chip, 10),
            ),
        ]),
      ),
    ),
  );
}

BoxDecoration _grad(List<Color> c, {double r = 16}) => BoxDecoration(
      gradient: LinearGradient(
          colors: c, begin: Alignment.topCenter, end: Alignment.bottomCenter),
      borderRadius: BorderRadius.circular(r),
      border: Border.all(color: _gold, width: 1.4),
    );

BoxDecoration _arch({Color color = const Color(0xFF0B3D2E)}) => BoxDecoration(
      gradient: LinearGradient(
          colors: [color, const Color(0xFF062A1F)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter),
      borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(34),
          topRight: Radius.circular(34),
          bottomLeft: Radius.circular(12),
          bottomRight: Radius.circular(12)),
      border: Border.all(color: _gold, width: 1.4),
    );

// ======================= پینٹرز =======================
class _ClockPainter extends CustomPainter {
  final DateTime now;
  final bool all12, numerals, hands;
  final Color face;
  _ClockPainter(this.now,
      {this.all12 = false,
      this.numerals = true,
      this.hands = true,
      this.face = const Color(0xFF0B4A33)});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = const SweepGradient(colors: [
            _gold,
            Color(0xFFFFE9A8),
            _gold,
            Color(0xFFB8860B),
            _gold
          ]).createShader(Rect.fromCircle(center: c, radius: r)));
    canvas.drawCircle(c, r * 0.95, Paint()..color = const Color(0xFF062A1F));
    canvas.drawCircle(c, r * 0.91, Paint()..color = face);

    for (int i = 0; i < 60; i++) {
      final a = (i * 6 - 90) * pi / 180;
      final major = i % 5 == 0;
      final len = major ? r * 0.09 : r * 0.04;
      final dir = Offset(cos(a), sin(a));
      canvas.drawLine(
          c + dir * (r * 0.87),
          c + dir * (r * 0.87 - len),
          Paint()
            ..color = (major ? Colors.white : Colors.white54)
            ..strokeWidth = major ? 2.4 : 1);
    }

    if (numerals) {
      final list = all12 ? [for (int i = 1; i <= 12; i++) i] : [12, 3, 6, 9];
      for (final n in list) {
        final a = (n * 30 - 90) * pi / 180;
        final tp = TextPainter(
          text: TextSpan(
              text: '$n',
              style: TextStyle(
                  color: all12 ? _gold : Colors.white,
                  fontSize: r * 0.2,
                  fontWeight: FontWeight.bold)),
          textDirection: TextDirection.ltr,
        )..layout();
        final pos = c +
            Offset(cos(a), sin(a)) * (r * 0.66) -
            Offset(tp.width / 2, tp.height / 2);
        tp.paint(canvas, pos);
      }
    }

    if (!hands) return;
    void hand(double deg, double len, double w, Color col) {
      final a = (deg - 90) * pi / 180;
      final dir = Offset(cos(a), sin(a));
      canvas.drawLine(
          c - dir * (r * 0.08),
          c + dir * (r * len),
          Paint()
            ..color = col
            ..strokeWidth = w
            ..strokeCap = StrokeCap.round);
    }

    final hh = now.hour % 12 + now.minute / 60;
    final mm = now.minute + now.second / 60;
    hand(hh * 30, 0.46, r * 0.045, _gold);
    hand(mm * 6, 0.68, r * 0.032, _gold);
    hand(now.second * 6.0, 0.8, r * 0.012, const Color(0xFF3DDC84));
    canvas.drawCircle(c, r * 0.045, Paint()..color = _gold);
  }

  @override
  bool shouldRepaint(covariant _ClockPainter old) => old.now != now;
}

class _CompassPainter extends CustomPainter {
  final double bearing;
  _CompassPainter(this.bearing);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    canvas.drawCircle(c, r, Paint()..color = _gold);
    canvas.drawCircle(c, r * 0.92, Paint()..color = const Color(0xFF0B4A33));
    const labels = {'N': 0.0, 'E': 90.0, 'S': 180.0, 'W': 270.0};
    for (final e in labels.entries) {
      final a = (e.value - 90) * pi / 180;
      final tp = TextPainter(
        text: TextSpan(
            text: e.key,
            style: TextStyle(
                color: Colors.white,
                fontSize: r * 0.24,
                fontWeight: FontWeight.bold)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(
          canvas,
          c +
              Offset(cos(a), sin(a)) * (r * 0.72) -
              Offset(tp.width / 2, tp.height / 2));
    }
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.rotate(bearing * pi / 180);
    final path = Path()
      ..moveTo(0, -r * 0.66)
      ..lineTo(-r * 0.11, 0)
      ..lineTo(r * 0.11, 0)
      ..close();
    canvas.drawPath(path, Paint()..color = const Color(0xFFE53935));
    canvas.restore();
    canvas.drawCircle(c, r * 0.27, Paint()..color = Colors.white);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromCenter(center: c, width: r * 0.28, height: r * 0.28),
            const Radius.circular(2)),
        Paint()..color = const Color(0xFF111111));
  }

  @override
  bool shouldRepaint(covariant _CompassPainter old) => old.bearing != bearing;
}

// ======================= ڈیزائن 1: کعبہ اینالاگ گھڑی =======================
Widget _s1(WData d) {
  Widget info(IconData ic, String t, String big, String small) => _pill(
      Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(ic, color: _gold, size: 26),
        _fit(_txt(t, 13)),
        _fit(_txt(big, 14, bold: true)),
        _fit(_txt(small, 11, c: Colors.white70)),
      ]),
      r: 26);
  const grads = [
    [Color(0xFFE6F4FC), Color(0xFF9CD0EA)],
    [Color(0xFFFFF1C2), Color(0xFFE7B84A)],
    [Color(0xFFFBD99C), Color(0xFFE59A2B)],
    [Color(0xFF7A2E7A), Color(0xFFC76FA8)],
    [Color(0xFF1B2F78), Color(0xFF4A6CC0)],
  ];
  return _canvas(
    _bg('style1.jpg', const [Color(0xFF0E5A41), Color(0xFF062A1F)], photoFrac: 0.5),
    [
      _at(75, 22, 210, 62, _pill(_fit(_msfTitle(20, tag: 'اللہ کی رضا ہی کامیابی ہے')), r: 22)),
      _at(8, 30, 62, 46, _pill(_fit(_txt(d.city, 12, bold: true)), r: 16)),
      _at(65, 98, 230, 230,
          _analog(d, 230,
              inner: Align(
                alignment: const Alignment(0, 0.5),
                child: SizedBox(
                    width: 130,
                    height: 40,
                    child: _pill(_digital(d, 20), r: 14)),
              ))),
      _at(6, 238, 108, 112, info(Icons.calendar_month, 'عیسوی تاریخ', d.gregUr, d.weekdayEn)),
      _at(246, 238, 108, 112, info(Icons.nightlight_round, 'ہجری تاریخ', d.hijriUr, d.weekdayUr)),
      _at(15, 360, 330, 40,
          _pill(Row(children: [
            const Icon(Icons.location_on, color: _gold),
            const SizedBox(width: 8),
            Expanded(child: _txt('${d.city} - ${d.country}', 14, bold: true)),
            const Icon(Icons.arrow_drop_down, color: Colors.white),
          ]), r: 20)),
      _at(15, 412, 330, 196,
          _row5(d, 5, (p, i) {
            final dark = i < 3;
            return _card(d, p,
                deco: _grad(grads[i]),
                tc: dark ? _green : Colors.white,
                sc: dark ? Colors.black54 : Colors.white70,
                ic: dark ? const Color(0xFFB8860B) : _gold);
          })),
      _at(10, 622, 340, 62,
          Row(children: [
            Expanded(
                flex: 4,
                child: _pill(Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  _compass(34, d.qibla),
                  const SizedBox(width: 6),
                  Column(mainAxisSize: MainAxisSize.min, children: [
                    _txt('قبلہ کی سمت', 11, c: Colors.white70),
                    _txt('${d.qibla.round()}°', 17, bold: true),
                  ]),
                ]))),
            const SizedBox(width: 6),
            Expanded(flex: 5, child: _pill(_fit(_txt(_kalima, 14, c: _gold)))),
            const SizedBox(width: 6),
            Expanded(
                flex: 4,
                child: _pill(Column(mainAxisSize: MainAxisSize.min, children: [
                  _fit(_txt('اگلی نماز تک باقی وقت', 9, c: Colors.white70)),
                  _fit(_txt(d.countdown, 16, bold: true)),
                ]))),
          ])),
    ],
  );
}

// ======================= ڈیزائن 2: بڑا ڈیجیٹل =======================
Widget _s2(WData d) {
  final cream = BoxDecoration(
    color: const Color(0xFFFBF6E8),
    borderRadius: BorderRadius.circular(14),
    border: Border.all(color: _gold.withOpacity(0.6)),
  );
  return _canvas(
    _bg('style2.jpg', const [Color(0xFF0B4A33), Color(0xFF052418)], photoFrac: 0.4),
    [
      _at(
          0,
          0,
          360,
          68,
          Container(
            decoration: const BoxDecoration(
              color: _green,
              border: Border(bottom: BorderSide(color: _gold, width: 2)),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(children: [
              const Icon(Icons.mosque, color: _gold, size: 34),
              const SizedBox(width: 8),
              Expanded(
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: _fit(_msfTitle(20, tag: 'Quran • Hadith • Prayer Times • Qibla')))),
              SizedBox(
                  width: 92,
                  height: 40,
                  child: _pill(
                      Column(mainAxisSize: MainAxisSize.min, children: [
                        _fit(_txt(d.country, 11, bold: true)),
                        _fit(_txt(d.city, 10, c: Colors.white70)),
                      ]),
                      r: 20)),
            ]),
          )),
      _at(
          75,
          76,
          210,
          210,
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _green,
              border: Border.all(color: _gold, width: 5),
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _txt('الوقت الآن', 14, c: Colors.white70),
              const SizedBox(height: 4),
              SizedBox(width: 170, child: _digital(d, 46, sec: false)),
              const SizedBox(height: 6),
              _fit(Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.calendar_month, color: _gold, size: 16),
                const SizedBox(width: 4),
                _txt(d.gregEn, 13),
              ])),
              const SizedBox(height: 2),
              _fit(Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.nightlight_round, color: _gold, size: 16),
                const SizedBox(width: 4),
                _txt(d.hijriUr, 12),
              ])),
            ]),
          )),
      _at(8, 236, 104, 96,
          _pill(Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            _txt('اگلی نماز', 11, c: Colors.white70),
            _fit(_txt(d.next.name, 20, bold: true)),
            _fit(_txt(d.countdown, 15, bold: true)),
            _txt('بقیہ وقت', 10, c: Colors.white70),
          ]), r: 22)),
      _at(248, 236, 104, 96,
          _pill(Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            _txt('قبلہ کی سمت', 11, c: Colors.white70),
            const SizedBox(height: 2),
            _compass(46, d.qibla),
            const SizedBox(height: 2),
            _txt('${d.qibla.round()}°', 14, bold: true),
          ]), r: 22)),
      _at(10, 344, 340, 56,
          _pill(Row(children: [
            Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _txt('Gregorian Date', 10, c: Colors.white70),
              _fit(_txt(d.gregEn, 14, bold: true)),
            ])),
            Expanded(child: _fit(_txt('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', 15, c: _gold))),
            Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _txt('Hijri Date', 10, c: Colors.white70),
              _fit(_txt(d.hijriUr, 13, bold: true)),
            ])),
          ]), r: 24)),
      _at(10, 412, 340, 262,
          _pill(
              Column(children: [
                _txt('نماز کے اوقات', 18, bold: true),
                const SizedBox(height: 8),
                Expanded(
                  child: _row5(d, 5, (p, i) => _card(d, p,
                      deco: cream,
                      tc: _green,
                      sc: Colors.black54,
                      ic: _greenMid,
                      isz: 24,
                      timeSize: 13,
                      chip: _status(d, p).$1,
                      chipBg: _status(d, p).$2)),
                ),
              ]),
              r: 22,
              pad: const EdgeInsets.all(10))),
    ],
  );
}

// ======================= ڈیزائن 3: گول فریم =======================
Widget _s3(WData d) {
  Widget circleInfo(IconData ic, String t, String v) => _pill(
      Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(ic, color: _gold, size: 22),
        _txt(t, 10, c: Colors.white70),
        _fit(_txt(v, 14, bold: true)),
      ]),
      circle: true,
      pad: const EdgeInsets.all(6));
  Widget col(PrayerSlot p) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: Column(children: [
            _pill(_fit(Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(_pIcon(p.key), color: _gold, size: 14),
              const SizedBox(width: 3),
              _txt(_pName[p.key]!, 14, bold: true),
            ])), r: 10, pad: const EdgeInsets.symmetric(horizontal: 4, vertical: 6)),
            const SizedBox(height: 6),
            _txt('وقت داخل', 9, c: Colors.black54),
            _fit(_txt(d.fullOf(p.start), 12, c: _green, bold: true)),
            const SizedBox(height: 4),
            _txt('وقت ختم', 9, c: Colors.black54),
            _fit(_txt(d.fullOf(p.end!), 12, c: _green, bold: true)),
            const Spacer(),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 4),
              decoration: BoxDecoration(
                  color: _green, borderRadius: BorderRadius.circular(10)),
              child: Column(children: [
                _txt('باقی وقت', 9, c: Colors.white70),
                _fit(_txt(d.dur(d.untilSlot(p)), 11, c: _gold, bold: true)),
              ]),
            ),
          ]),
        ),
      );
  return _canvas(
    _bg('style3.jpg', const [Color(0xFF0B4A33), Color(0xFF052418)], photoFrac: 0.4),
    [
      _at(8, 16, 344, 710,
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(48),
              border: Border.all(color: _gold, width: 3),
            ),
          )),
      _at(110, 26, 140, 100,
          _pill(Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.mosque, color: _gold, size: 22),
            _fit(_msfTitle(18)),
            _txt('اللہ اکبر', 12, c: _gold),
          ]), r: 40)),
      _at(28, 64, 80, 80, circleInfo(Icons.public, 'ملک', d.country)),
      _at(252, 64, 80, 80, circleInfo(Icons.location_on, 'شہر', d.city)),
      _at(100, 150, 160, 20, _txt('موجودہ وقت', 13, c: Colors.white70)),
      _at(24, 170, 312, 74, _digital(d, 62)),
      _at(20, 254, 320, 76,
          _pill(Row(children: [
            Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _fit(_txt(d.gregUr, 16, bold: true)),
              _txt('(${d.weekdayUr})', 12, c: Colors.white70),
              _fit(_txt(d.gregEn, 10)),
            ])),
            const Icon(Icons.calendar_month, color: _gold, size: 36),
            Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _fit(_txt(d.hijriUr, 16, c: const Color(0xFF9BE3B0), bold: true)),
              _txt('(ہجری)', 12, c: Colors.white70),
              _fit(_txt(d.hijriEn, 10)),
            ])),
          ]), r: 34)),
      _at(22, 346, 316, 200,
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
                color: const Color(0xFFFBF6E8),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _gold)),
            child: Row(children: [for (final p in d.slots5) col(p)]),
          )),
      _at(22, 562, 316, 70,
          Row(children: [
            Expanded(
                child: _pill(Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              _compass(44, d.qibla),
              const SizedBox(width: 8),
              Column(mainAxisSize: MainAxisSize.min, children: [
                _txt('قبلہ کی سمت', 11, c: Colors.white70),
                _txt('${d.qibla.round()}°', 20, bold: true),
              ]),
            ]), r: 24)),
            const SizedBox(width: 8),
            Expanded(
                child: _pill(Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _fit(_txt('اگلی نماز: ${d.next.name}', 13, bold: true)),
              _fit(_txt(d.countdown, 20, c: _gold, bold: true)),
            ]), r: 24)),
          ])),
    ],
  );
}

// ======================= ڈیزائن 4: سنہری رنگ (ہندسوں والی انگوٹھی) =======================
Widget _s4(WData d) {
  Widget mark(String t, double l, double tp) =>
      _at(l, tp, 30, 28, Center(child: _txt(t, 18, bold: true)));
  return _canvas(
    _bg('style4.jpg', const [Color(0xFFE9C58A), Color(0xFF0B3D2E)], photoFrac: 0.7),
    [
      _at(10, 30, 340, 340,
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _green,
              border: Border.all(color: _gold, width: 5),
            ),
          )),
      mark('12', 165, 34),
      mark('3', 316, 186),
      mark('6', 165, 330),
      mark('9', 14, 186),
      _at(60, 50, 240, 70,
          Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.mosque, color: _gold, size: 26),
            _fit(_msfTitle(21, tag: 'Quran • Hadith • Prayer Times • Qibla')),
          ])),
      _at(45, 126, 270, 58, _pill(_digital(d, 40), r: 28)),
      _at(35, 194, 290, 46,
          _pill(Row(children: [
            const Icon(Icons.calendar_month, color: _gold, size: 22),
            Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _fit(_txt(d.gregEn, 13, bold: true)),
              _fit(_txt('${d.weekdayEn} (Gregorian)', 9, c: Colors.white70)),
            ])),
            Container(width: 1, color: _gold),
            const SizedBox(width: 4),
            const Icon(Icons.nightlight_round, color: _gold, size: 22),
            Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _fit(_txt(d.hijriEn, 12, bold: true)),
              _txt('(Hijri)', 9, c: Colors.white70),
            ])),
          ]), r: 22, pad: const EdgeInsets.symmetric(horizontal: 8, vertical: 2))),
      _at(40, 248, 280, 60, _photo('style4.jpg', r: 14)),
      _at(70, 316, 220, 40,
          _pill(Row(children: [
            const Icon(Icons.location_on, color: _gold, size: 20),
            const SizedBox(width: 6),
            Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _fit(_txt('${d.city}, ${d.country}', 12, bold: true)),
              _fit(_txt('${fmtLat(d.s.latitude)}  ${fmtLng(d.s.longitude)} | ${d.gmt}', 9, c: Colors.white70)),
            ])),
          ]), r: 20)),
      _at(12, 392, 336, 190,
          _row5(d, 5, (p, i) {
            final st = _status(d, p, en: true);
            return _card(d, p,
                deco: _arch(),
                range: false,
                en: true,
                under: '(Start)',
                chip: st.$1,
                chipBg: st.$2,
                ampm: false);
          })),
      _at(90, 600, 180, 40, _fit(_txt('اللہ اکبر', 28, c: _gold, bold: true))),
    ],
  );
}

// ======================= ڈیزائن 5: ڈیش بورڈ =======================
Widget _s5(WData d) {
  Widget locRow(IconData ic, String t) => Expanded(
        child: Row(children: [
          Icon(ic, color: _gold, size: 18),
          const SizedBox(width: 6),
          Expanded(child: _fit(_txt(t, 13, bold: true))),
          const Icon(Icons.chevron_right, color: Colors.white70, size: 16),
        ]),
      );
  const pastel = [
    Color(0xFFE3F2FB), Color(0xFFFFF3D6), Color(0xFFE5F5E3),
    Color(0xFFFDE3E0), Color(0xFFE8E4F8)
  ];
  return _canvas(
    _bg('style5.jpg', const [Color(0xFF1B6B8F), Color(0xFFF5F2E6)], photoFrac: 0.38),
    [
      _at(0, 0, 360, 78,
          Container(
            color: _green.withOpacity(0.94),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(children: [
              const Icon(Icons.mosque, color: _gold, size: 40),
              const SizedBox(width: 8),
              Expanded(
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: _fit(_msfTitle(26, tag: 'Quran - Hadith - Prayer Times - Qibla')))),
              SizedBox(width: 90, child: _fit(_txt(_kalima, 12, c: _gold))),
            ]),
          )),
      _at(6, 92, 104, 108,
          _pill(Column(children: [
            locRow(Icons.location_on, d.country),
            const Divider(color: Colors.white24, height: 1),
            locRow(Icons.map, d.s.province),
            const Divider(color: Colors.white24, height: 1),
            locRow(Icons.location_city, d.city),
          ]), r: 14)),
      _at(105, 84, 150, 150,
          _analog(d, 150,
              numerals: false,
              inner: Align(
                alignment: const Alignment(0, 0.45),
                child: _txt(d.gregEn, 10),
              ))),
      _at(250, 92, 104, 108,
          _pill(Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            _txt('Gregorian Date', 9, c: Colors.white70),
            _fit(_txt(d.gregEn, 12, bold: true)),
            const Divider(color: Colors.white24, height: 8),
            _txt('Hijri Date', 9, c: Colors.white70),
            _fit(_txt(d.hijriEn, 11, bold: true)),
            _fit(_txt(d.hijriUr, 10, c: Colors.white70)),
          ]), r: 14)),
      _at(6, 250, 348, 392,
          Container(
            decoration: BoxDecoration(
              color: _green,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _gold, width: 1.4),
            ),
          )),
      _at(100, 240, 160, 36, _pill(_txt('اوقات نماز', 20, bold: true), r: 14)),
      _at(14, 288, 332, 172,
          _row5(d, 4, (p, i) => _card(d, p,
              deco: BoxDecoration(color: pastel[i], borderRadius: BorderRadius.circular(12)),
              tc: _green,
              sc: Colors.black54,
              ic: _greenMid,
              en: true,
              timeSize: 13,
              ampm: true))),
      _at(14, 468, 332, 44,
          _pill(Row(children: [
            const SizedBox(width: 6),
            const Icon(Icons.mosque, color: _gold, size: 26),
            const SizedBox(width: 8),
            Expanded(child: _fit(_txt('اگلی نماز: ${d.next.name}', 15, bold: true))),
            _digital(d, 22, sec: false),
            const SizedBox(width: 6),
          ]), r: 14)),
      _at(14, 524, 332, 100,
          Row(children: [
            _compass(88, d.qibla),
            const SizedBox(width: 14),
            Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _txt('قبلہ کی سمت', 14, c: Colors.white70),
              _txt('${d.qibla.round()}°', 34, c: _gold, bold: true),
              _txt('(${compassUrdu(d.qibla)})', 12),
            ])),
            Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _txt('باقی وقت', 12, c: Colors.white70),
              _fit(_txt(d.countdown, 22, bold: true)),
            ])),
          ])),
      _at(0, 660, 360, 70,
          Container(
            color: _green,
            alignment: Alignment.center,
            child: _fit(_txt('نماز وقت پر کامیابی کی کنجی ہے', 20, c: _gold, bold: true)),
          )),
    ],
  );
}

// ======================= ڈیزائن 6: مکہ و مدینہ =======================
Widget _s6(WData d) {
  return _canvas(
    _bg('style6.jpg', const [Color(0xFF0B4A33), Color(0xFF041B13)], photoFrac: 0.3),
    [
      _at(10, 14, 340, 730,
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(60),
              border: Border.all(color: _gold, width: 3),
            ),
          )),
      _at(24, 28, 312, 150,
          Stack(children: [
            Positioned.fill(child: _photo('style6.jpg', r: 40)),
            Align(
              alignment: const Alignment(0, -0.75),
              child: _fit(_msfTitle(22)),
            ),
            Align(
              alignment: const Alignment(0, 0.7),
              child: _txt('الله', 30, c: Colors.white, bold: true),
            ),
          ])),
      _at(24, 186, 312, 150,
          _pill(
              Column(children: [
                Expanded(
                    child: Row(children: [
                  const Icon(Icons.access_time, color: _gold, size: 34),
                  const SizedBox(width: 8),
                  Expanded(child: _digital(d, 54)),
                ])),
                const Divider(color: _gold, height: 6),
                Expanded(
                    child: Row(children: [
                  Expanded(
                      child: Row(children: [
                    const Icon(Icons.calendar_month, color: _gold, size: 26),
                    const SizedBox(width: 6),
                    Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      _fit(_txt(d.gregEn, 14, bold: true)),
                      _txt('(Gregorian)', 10, c: Colors.white70),
                    ])),
                  ])),
                  Container(width: 1, color: _gold),
                  Expanded(
                      child: Row(children: [
                    const SizedBox(width: 6),
                    const Icon(Icons.nightlight_round, color: _gold, size: 26),
                    const SizedBox(width: 6),
                    Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      _fit(_txt(d.hijriEn, 13, bold: true)),
                      _txt('(Hijri)', 10, c: Colors.white70),
                    ])),
                  ])),
                ])),
              ]),
              r: 40,
              pad: const EdgeInsets.symmetric(horizontal: 14, vertical: 8))),
      _at(80, 346, 200, 38,
          _pill(Row(children: [
            const Icon(Icons.location_on, color: _gold, size: 20),
            const SizedBox(width: 6),
            Expanded(child: _fit(_txt('${d.city} (${d.country})', 14, bold: true))),
            const Icon(Icons.arrow_drop_down, color: Colors.white),
          ]), r: 18)),
      _at(20, 398, 320, 132,
          _row5(d, 5, (p, i) => _card(d, p,
              deco: _arch(),
              range: false,
              under: '(آغاز)',
              underColor: Colors.white,
              ampm: false,
              timeSize: 16))),
      _at(24, 548, 312, 130,
          _pill(Row(children: [
            Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.explore, color: _gold, size: 22),
              _txt('Qibla Direction', 11, c: Colors.white70),
              _txt('${d.qibla.round()}°', 28, bold: true),
              _txt('قبلہ کی سمت', 12),
            ])),
            _compass(100, d.qibla),
            Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.location_on, color: _gold, size: 22),
              _txt('Latitude', 10, c: Colors.white70),
              _fit(_txt(fmtLat(21.4225), 12, bold: true)),
              _txt('Longitude', 10, c: Colors.white70),
              _fit(_txt(fmtLng(39.8262), 12, bold: true)),
            ])),
          ]), r: 26)),
    ],
  );
}

// ======================= ڈیزائن 7: ٹک مارکس والی بڑی گھڑی =======================
Widget _s7(WData d) {
  Widget box(IconData ic, String title, String l1, String l2) => Expanded(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 3),
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _ok.withOpacity(0.8)),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            _fit(Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(ic, color: _gold, size: 16),
              const SizedBox(width: 4),
              _txt(title, 11, c: Colors.white70),
            ])),
            _fit(_txt(l1, 14, bold: true)),
            _fit(_txt(l2, 11)),
          ]),
        ),
      );
  return _canvas(
    _bg('style7.jpg', const [Color(0xFF0B4A33), Color(0xFF052418)], photoFrac: 0.62),
    [
      _at(20, 16, 320, 76, _fit(_msfTitle(30, tag: 'Prayer Times • Qibla • Islamic Calendar'))),
      _at(
          30,
          100,
          300,
          300,
          _analog(d, 300,
              numerals: false,
              hands: false,
              face: const Color(0xFF062A1F),
              inner: Padding(
                padding: const EdgeInsets.fromLTRB(22, 22, 22, 22),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  _txt('الله', 30, c: _gold, bold: true),
                  _digital(d, 42),
                  _txt(d.weekdayUr, 22, bold: true),
                  const SizedBox(height: 6),
                  SizedBox(
                    height: 62,
                    child: Row(children: [
                      box(Icons.nightlight_round, 'Hijri Date', d.hijriEn.split(' ').first, d.hijriEn.substring(d.hijriEn.indexOf(' ') + 1)),
                      box(Icons.calendar_month, 'Gregorian Date', d.gregEn, d.weekdayEn),
                    ]),
                  ),
                  const SizedBox(height: 6),
                  _fit(Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.location_on, color: _gold, size: 16),
                    const SizedBox(width: 4),
                    _txt('${d.city}, ${d.country}', 12),
                  ])),
                ]),
              ))),
      _at(14, 416, 332, 156,
          _pill(
              _row5(d, 4, (p, i) {
                final st = _status(d, p);
                return _card(d, p,
                    deco: const BoxDecoration(),
                    range: false,
                    en: true,
                    ampm: true,
                    timeSize: 13,
                    isz: 28,
                    chip: st.$1,
                    chipBg: st.$2);
              }),
              r: 24,
              pad: const EdgeInsets.all(6))),
      _at(14, 588, 332, 60,
          Row(children: [
            Expanded(
                child: _pill(Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              _compass(38, d.qibla),
              const SizedBox(width: 8),
              _txt('Qibla  ${d.qibla.round()}°', 16, bold: true),
            ]), r: 24)),
            const SizedBox(width: 8),
            Expanded(
                child: _pill(Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _fit(_txt('اگلی نماز: ${d.next.name}', 12)),
              _fit(_txt(d.countdown, 18, c: _gold, bold: true)),
            ]), r: 24)),
          ])),
    ],
  );
}

// ======================= ڈیزائن 8: کلاسک اینالاگ =======================
Widget _s8(WData d) {
  Widget dateBox(IconData ic, String t, String big, String small) => Expanded(
        child: Row(children: [
          const SizedBox(width: 8),
          Icon(ic, color: _gold, size: 34),
          const SizedBox(width: 8),
          Expanded(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                _txt(t, 11, c: Colors.white70),
                _fit(_txt(big, 17, bold: true)),
                _txt(small, 12),
              ])),
        ]),
      );
  return _canvas(
    _bg('style8.jpg', const [Color(0xFF0B4A33), Color(0xFF052418)], photoFrac: 0.62),
    [
      _at(0, 0, 360, 66,
          Container(
            color: _green,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(children: [
              const Icon(Icons.public, color: _gold, size: 36),
              const SizedBox(width: 8),
              Expanded(
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: _fit(_msfTitle(20, tag: 'Quran • Hadith • Prayer Times')))),
              Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                _fit(_txt(d.city, 14, bold: true)),
                _fit(_txt(d.country, 11, c: Colors.white70)),
              ]),
              const SizedBox(width: 4),
              const Icon(Icons.location_on, color: _gold),
            ]),
          )),
      _at(70, 80, 220, 220,
          _analog(d, 220,
              all12: true,
              inner: Align(
                  alignment: const Alignment(0, -0.45),
                  child: _txt('الله', 26, c: Colors.white, bold: true)))),
      _at(30, 312, 300, 82,
          _pill(Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            SizedBox(width: 250, child: _digital(d, 40)),
            _fit(_txt('${d.weekdayEn}, ${now4(d)}', 14)),
          ]), r: 30)),
      _at(14, 408, 332, 92,
          _pill(Row(children: [
            dateBox(Icons.calendar_month, 'Gregorian Date', d.gregEn, d.weekdayEn),
            Container(width: 1, height: 56, color: _gold),
            dateBox(Icons.nightlight_round, 'Hijri Date', d.hijriEn, d.weekdayEn),
          ]), r: 24)),
      _at(14, 516, 332, 96,
          _row5(d, 4, (p, i) => _card(d, p,
              deco: BoxDecoration(
                  color: _green.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _gold.withOpacity(0.7))),
              range: false,
              isz: 20,
              nameSize: 13,
              timeSize: 12))),
    ],
  );
}

String now4(WData d) => DateFormat('d MMMM yyyy').format(d.now);

// ======================= ڈیزائن 9: سادہ رنگ =======================
Widget _s9(WData d) {
  Widget chipBox(IconData ic, String l1, String l2) => Expanded(
        child: Row(children: [
          const SizedBox(width: 8),
          Icon(ic, color: _gold, size: 28),
          const SizedBox(width: 6),
          Expanded(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            _fit(_txt(l1, 14, bold: true)),
            _txt(l2, 10, c: Colors.white70),
          ])),
        ]),
      );
  return _canvas(
    _bg('style9.jpg', const [Color(0xFF0B4A33), Color(0xFF041B13)], photoFrac: 0.3),
    [
      _at(8, 16, 344, 730,
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(70),
              border: Border.all(color: _gold, width: 3),
            ),
          )),
      _at(80, 26, 200, 44, _fit(_msfTitle(24))),
      _at(18, 80, 100, 56,
          _pill(Row(children: [
            const Icon(Icons.public, color: _gold, size: 22),
            const SizedBox(width: 4),
            Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _fit(_txt(d.country, 12, bold: true)),
              _fit(_txt(d.city, 11, c: Colors.white70)),
            ])),
          ]), r: 22)),
      _at(242, 80, 100, 56,
          _pill(Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            _fit(_txt('Qibla Direction', 10)),
            _fit(_txt('Kaaba ${d.qibla.round()}°', 14, bold: true)),
          ]), r: 22)),
      _at(100, 142, 160, 28, _txt('الوقت الآن', 18, c: Colors.white70)),
      _at(20, 168, 320, 90, _digital(d, 76, c: const Color(0xFFF4D98C))),
      _at(24, 268, 312, 62,
          _pill(Row(children: [
            chipBox(Icons.calendar_month, d.gregEn, '${d.weekdayEn} (Gregorian)'),
            Container(width: 1, height: 40, color: _gold),
            chipBox(Icons.nightlight_round, d.hijriUr, '(Hijri Date)'),
          ]), r: 18)),
      _at(24, 342, 312, 120, _photo('style9.jpg', r: 20)),
      _at(60, 424, 240, 66,
          _pill(Row(children: [
            const SizedBox(width: 8),
            const Icon(Icons.mosque, color: _gold, size: 30),
            const SizedBox(width: 8),
            Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              _fit(_txt('اگلی نماز: ${d.next.name}', 15, bold: true)),
              _fit(_txt(d.countdown, 22, bold: true)),
            ])),
          ]), r: 18)),
      _at(24, 508, 312, 104,
          Row(children: [
            for (int i = 0; i < 5; i++) ...[
              if (i > 0) Container(width: 1, color: _gold.withOpacity(0.5)),
              Expanded(
                child: _card(d, d.slots5[i],
                    deco: const BoxDecoration(),
                    range: false,
                    ampm: false,
                    under: 'داخل',
                    underColor: const Color(0xFF3DDC84),
                    nameSize: 15,
                    timeSize: 15),
              ),
            ],
          ])),
      _at(50, 630, 260, 46, _pill(_fit(_txt(_kalima, 16, c: _gold)), r: 22)),
    ],
  );
}

// ======================= فہرست اور ویجٹس =======================
class WallpaperStyle {
  final String id;
  final String name;
  final Widget Function(WData d) build;
  const WallpaperStyle(this.id, this.name, this.build);
}

final wallpaperStyles = <WallpaperStyle>[
  WallpaperStyle('style1', 'کعبہ اینالاگ', _s1),
  WallpaperStyle('style2', 'بڑا ڈیجیٹل', _s2),
  WallpaperStyle('style3', 'گول فریم', _s3),
  WallpaperStyle('style4', 'سنہری انگوٹھی', _s4),
  WallpaperStyle('style5', 'ڈیش بورڈ', _s5),
  WallpaperStyle('style6', 'مکہ و مدینہ', _s6),
  WallpaperStyle('style7', 'ٹک مارکس', _s7),
  WallpaperStyle('style8', 'کلاسک اینالاگ', _s8),
  WallpaperStyle('style9', 'سادہ سنہری', _s9),
];

/// ایک مقررہ وقت کے ساتھ ڈیزائن بناتا ہے
class WallpaperView extends StatelessWidget {
  final String styleId;
  final DateTime now;
  const WallpaperView({super.key, required this.styleId, required this.now});

  @override
  Widget build(BuildContext context) {
    final st = wallpaperStyles.firstWhere((e) => e.id == styleId,
        orElse: () => wallpaperStyles.first);
    return st.build(WData(now, appSettings));
  }
}

/// ہر سیکنڈ خود چلنے والی گھڑی (پوری اسکرین اور لائیو وال پیپر کے لیے)
class TickingWallpaper extends StatefulWidget {
  final String? styleId; // null ہو تو سیٹنگز میں محفوظ ڈیزائن
  const TickingWallpaper({super.key, this.styleId});
  @override
  State<TickingWallpaper> createState() => _TickingWallpaperState();
}

class _TickingWallpaperState extends State<TickingWallpaper> {
  late Timer _t;
  DateTime now = DateTime.now();
  int _n = 0;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) async {
      _n++;
      if (widget.styleId == null && _n % 20 == 0) {
        await appSettings.load(); // ایپ میں بدلا ہوا ڈیزائن/شہر اٹھا لیتا ہے
      }
      if (mounted) setState(() => now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _t.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => WallpaperView(
      styleId: widget.styleId ?? appSettings.wallpaperStyle, now: now);
}
