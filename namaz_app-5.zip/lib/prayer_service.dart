import 'package:adhan_dart/adhan_dart.dart';
import 'app_settings.dart';

class PrayerEntry {
  final String name;
  final DateTime time;
  PrayerEntry(this.name, this.time);
}

class PrayerSlot {
  final String key;
  final String name;
  final DateTime start;
  final DateTime? end;
  PrayerSlot(this.key, this.name, this.start, this.end);
}

class PrayerService {
  /// سیٹنگز میں دکھائے جانے والے حسابی طریقے
  static const methodLabels = {
    'muslimWorldLeague': 'Muslim World League',
    'karachi': 'University of Islamic Sciences, Karachi',
    'egyptian': 'Egyptian General Authority',
    'ummAlQura': 'Umm al-Qura, Makkah',
    'dubai': 'Dubai',
    'qatar': 'Qatar',
    'kuwait': 'Kuwait',
    'singapore': 'Singapore',
    'northAmerica': 'ISNA (North America)',
    'moonsightingCommittee': 'Moonsighting Committee',
    'tehran': 'Tehran',
  };

  static CalculationParameters _params(AppSettings s) {
    final CalculationParameters p;
    switch (s.method) {
      case 'karachi':
        p = CalculationMethodParameters.karachi();
        break;
      case 'egyptian':
        p = CalculationMethodParameters.egyptian();
        break;
      case 'ummAlQura':
        p = CalculationMethodParameters.ummAlQura();
        break;
      case 'dubai':
        p = CalculationMethodParameters.dubai();
        break;
      case 'qatar':
        p = CalculationMethodParameters.qatar();
        break;
      case 'kuwait':
        p = CalculationMethodParameters.kuwait();
        break;
      case 'singapore':
        p = CalculationMethodParameters.singapore();
        break;
      case 'northAmerica':
        p = CalculationMethodParameters.northAmerica();
        break;
      case 'moonsightingCommittee':
        p = CalculationMethodParameters.moonsightingCommittee();
        break;
      case 'tehran':
        p = CalculationMethodParameters.tehran();
        break;
      default:
        p = CalculationMethodParameters.muslimWorldLeague();
    }
    p.madhab = s.hanafi ? Madhab.hanafi : Madhab.shafi;
    return p;
  }

  static List<PrayerEntry> forDay(DateTime date, AppSettings s) {
    final pt = PrayerTimes(
      coordinates: Coordinates(s.latitude, s.longitude),
      date: date,
      calculationParameters: _params(s),
      precision: true,
    );
    return [
      PrayerEntry('فجر', pt.fajr.toLocal()),
      PrayerEntry('طلوعِ آفتاب', pt.sunrise.toLocal()),
      PrayerEntry('ظہر', pt.dhuhr.toLocal()),
      PrayerEntry('عصر', pt.asr.toLocal()),
      PrayerEntry('مغرب', pt.maghrib.toLocal()),
      PrayerEntry('عشاء', pt.isha.toLocal()),
    ];
  }

  static PrayerEntry next(DateTime now, AppSettings s) {
    for (final e in forDay(now, s).where((e) => e.name != 'طلوعِ آفتاب')) {
      if (e.time.isAfter(now)) return e;
    }
    return forDay(now.add(const Duration(days: 1)), s).first;
  }

  /// ہر نماز کا آغاز اور اختتام۔
  /// فجر ← طلوع تک، ظہر ← عصر تک، عصر ← مغرب تک، مغرب ← عشاء تک،
  /// عشاء ← رات کے اسلامی نصف (مغرب اور اگلی فجر کا درمیان) تک۔
  static List<PrayerSlot> slots(DateTime date, AppSettings s) {
    final t = forDay(date, s);
    final nextFajr = forDay(date.add(const Duration(days: 1)), s).first.time;
    final maghrib = t[4].time;
    final ishaEnd = maghrib
        .add(Duration(milliseconds: nextFajr.difference(maghrib).inMilliseconds ~/ 2));
    return [
      PrayerSlot('fajr', 'فجر', t[0].time, t[1].time),
      PrayerSlot('sunrise', 'طلوعِ آفتاب', t[1].time, null),
      PrayerSlot('dhuhr', 'ظہر', t[2].time, t[3].time),
      PrayerSlot('asr', 'عصر', t[3].time, t[4].time),
      PrayerSlot('maghrib', 'مغرب', t[4].time, t[5].time),
      PrayerSlot('isha', 'عشاء', t[5].time, ishaEnd),
    ];
  }

  /// جس نماز کا وقت ابھی چل رہا ہے (نہ ہو تو null)
  static PrayerSlot? current(DateTime now, List<PrayerSlot> slots) {
    for (final p in slots) {
      if (p.end != null && !now.isBefore(p.start) && now.isBefore(p.end!)) {
        return p;
      }
    }
    return null;
  }
}
