import 'package:flutter/material.dart';
import 'app_settings.dart';
import 'location_data.dart';

/// ملک کے حساب سے گروپ کی ہوئی شہروں کی فہرست
Future<void> showLocationPicker(BuildContext context) {
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      final cs = Theme.of(ctx).colorScheme;
      final items = <Widget>[];
      locationData.forEach((country, provinces) {
        items.add(Container(
          color: cs.primaryContainer,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(country,
              style: const TextStyle(fontWeight: FontWeight.bold)),
        ));
        provinces.forEach((province, cities) {
          for (final c in cities) {
            final selected =
                appSettings.country == country && appSettings.city == c.name;
            items.add(ListTile(
              dense: true,
              title: Text(c.name),
              subtitle: province == 'عام' ? null : Text(province),
              trailing: selected
                  ? Icon(Icons.check_circle, color: cs.primary)
                  : null,
              onTap: () {
                appSettings.update(() {
                  appSettings.country = country;
                  appSettings.province = province;
                  appSettings.city = c.name;
                  appSettings.latitude = c.lat;
                  appSettings.longitude = c.lng;
                  appSettings.autoGps = false;
                });
                Navigator.pop(ctx);
              },
            ));
          }
        });
      });
      return Directionality(
        textDirection: TextDirection.rtl,
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.8,
          maxChildSize: 0.95,
          builder: (_, controller) => Column(children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('مقام منتخب کریں',
                  style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            Expanded(child: ListView(controller: controller, children: items)),
          ]),
        ),
      );
    },
  );
}
