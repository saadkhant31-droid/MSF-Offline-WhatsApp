import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_settings.dart';
import 'wallpaper_styles.dart';

const _channel = MethodChannel('msf/wallpaper');

/// گھڑی کے 9 ڈیزائن دیکھنے، منتخب کرنے اور وال پیپر لگانے کی اسکرین
class WallpaperScreen extends StatefulWidget {
  const WallpaperScreen({super.key});
  @override
  State<WallpaperScreen> createState() => _WallpaperScreenState();
}

class _WallpaperScreenState extends State<WallpaperScreen> {
  late final PageController _pc;
  late int index;
  late Timer _t;
  DateTime now = DateTime.now();

  @override
  void initState() {
    super.initState();
    index = wallpaperStyles
        .indexWhere((e) => e.id == appSettings.wallpaperStyle)
        .clamp(0, wallpaperStyles.length - 1);
    _pc = PageController(viewportFraction: 0.66, initialPage: index);
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _t.cancel();
    _pc.dispose();
    super.dispose();
  }

  void _snack(String m) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(m)));

  Future<void> _apply() async {
    final st = wallpaperStyles[index];
    await appSettings.update(() => appSettings.wallpaperStyle = st.id);
    if (!Platform.isAndroid) {
      _snack('لائیو وال پیپر صرف اینڈرائیڈ پر لگتا ہے');
      return;
    }
    try {
      final ok = await _channel.invokeMethod<bool>('setLiveWallpaper');
      if (ok != true && mounted) _snack('وال پیپر کی اسکرین نہیں کھل سکی');
    } on MissingPluginException {
      _snack('اینڈرائیڈ کا لائیو وال پیپر حصہ ابھی شامل نہیں ہوا (README دیکھیں)');
    } catch (_) {
      _snack('وال پیپر لگانے میں مسئلہ آیا');
    }
  }

  void _fullScreen() {
    final st = wallpaperStyles[index];
    Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => _FullScreenClock(styleId: st.id)));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('گھڑی وال پیپر')),
      body: Column(children: [
        const SizedBox(height: 12),
        Expanded(
          child: PageView.builder(
            controller: _pc,
            itemCount: wallpaperStyles.length,
            onPageChanged: (i) => setState(() => index = i),
            itemBuilder: (_, i) {
              final selected = i == index;
              return AnimatedScale(
                scale: selected ? 1 : 0.9,
                duration: const Duration(milliseconds: 200),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                  child: AspectRatio(
                    aspectRatio: 360 / 760,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                            color: selected ? const Color(0xFFE6B94D) : Colors.transparent,
                            width: 3),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: WallpaperView(
                          styleId: wallpaperStyles[i].id, now: now),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Text('${wallpaperStyles[index].name}  •  ${index + 1}/${wallpaperStyles.length}',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (int i = 0; i < wallpaperStyles.length; i++)
            Container(
              width: i == index ? 18 : 7,
              height: 7,
              margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(
                color: i == index ? cs.primary : cs.outlineVariant,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
        ]),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _fullScreen,
                icon: const Icon(Icons.fullscreen),
                label: const Text('پوری اسکرین'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: FilledButton.icon(
                onPressed: _apply,
                icon: const Icon(Icons.wallpaper),
                label: const Text('وال پیپر لگائیں'),
              ),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _FullScreenClock extends StatefulWidget {
  final String styleId;
  const _FullScreenClock({required this.styleId});
  @override
  State<_FullScreenClock> createState() => _FullScreenClockState();
}

class _FullScreenClockState extends State<_FullScreenClock> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: TickingWallpaper(styleId: widget.styleId),
        ),
      );
}
