MSF Offline WhatsApp
1. Open this folder in Android Studio (Hedgehog or newer) and let Gradle sync.
2. Run on two phones (or build an APK and install it on both).
3. Phone 1: turn on Hotspot, open the app, tap Host.
4. Phone 2: connect to Phone 1's hotspot, open the app, enter Phone 1's IP, tap Join.
   (Both phones on the same Wi-Fi router also works.)
Keep the app open on both phones during chats and calls.
