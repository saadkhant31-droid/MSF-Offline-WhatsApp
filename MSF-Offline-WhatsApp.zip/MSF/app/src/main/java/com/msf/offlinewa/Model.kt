package com.msf.offlinewa

import android.Manifest
import android.content.Context
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.*
import java.net.Inet4Address
import java.net.NetworkInterface

fun localIps(): List<String> = runCatching {
    NetworkInterface.getNetworkInterfaces().toList().flatMap { ni ->
        ni.inetAddresses.toList()
            .filter { !it.isLoopbackAddress && it is Inet4Address }
            .map { it.hostAddress ?: "" }
    }
}.getOrDefault(emptyList())

class Model(private val act: MainActivity) : Net.Listener {
    val store = Store(act)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val net = Net(this)

    var state by mutableStateOf("Not connected")
    var peerName by mutableStateOf(store.peerName)
    var myName by mutableStateOf(store.myName)
    var blocked by mutableStateOf(store.blocked)
    val msgs = mutableStateListOf<Msg>().also { it.addAll(store.loadChat()) }
    val calls = mutableStateListOf<CallRec>().also { it.addAll(store.loadCalls()) }
    val statuses = mutableStateListOf<Status>().also { it.addAll(store.loadStatuses()) }

    var callState by mutableStateOf("idle") // idle, ringing_out, ringing_in, active
    var callVideo by mutableStateOf(false)
    var seconds by mutableIntStateOf(0)
    var remoteFrame by mutableStateOf<ImageBitmap?>(null)

    private var outgoing = false
    private var callStart = 0L
    private var ticker: Job? = null
    private var audio: AudioEngine? = null
    private var video: VideoEngine? = null
    private val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun main(f: () -> Unit) { scope.launch { f() } }
    private fun now() = System.currentTimeMillis()
    fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    // ---- connection ----
    fun host() { store.lastIp = store.lastIp; net.host() }
    fun join(ip: String) { store.lastIp = ip.trim(); net.join(ip) }

    override fun onState(s: String) {
        main {
            state = s
            if (s == "Disconnected" || s.startsWith("Error") || s.startsWith("Could not")) {
                if (callState != "idle") finishCall()
            }
        }
        if (s == "Connected") net.send(T.HELLO, store.myName.toByteArray())
    }

    override fun onFrame(type: Int, data: ByteArray) {
        when (type) {
            T.HELLO -> main { peerName = String(data); store.peerName = peerName }
            T.TEXT -> {
                val text = String(data)
                main { if (!blocked) { msgs.add(Msg(false, now(), text)); store.saveChat(msgs) } }
            }
            T.STATUS -> {
                val text = String(data)
                main { if (!blocked) { statuses.add(Status(false, now(), text)); store.saveStatuses(statuses) } }
            }
            T.CALL_REQ -> main {
                if (blocked || callState != "idle") net.send(T.CALL_REJ)
                else { outgoing = false; callVideo = data.isNotEmpty() && data[0].toInt() == 1; callState = "ringing_in" }
            }
            T.CALL_ACC -> main { if (callState == "ringing_out") beginMedia() }
            T.CALL_REJ, T.CALL_END -> main { if (callState != "idle") finishCall() }
            T.AUDIO -> audio?.play(data)
            T.VIDEO -> {
                val bmp = BitmapFactory.decodeByteArray(data, 0, data.size)
                if (bmp != null) main { remoteFrame = bmp.asImageBitmap() }
            }
        }
    }

    // ---- chat ----
    fun sendMsg(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (blocked) { toast("Unblock this contact to send messages"); return }
        if (!net.connected) { toast("Not connected"); return }
        msgs.add(Msg(true, now(), t)); store.saveChat(msgs)
        net.send(T.TEXT, t.toByteArray())
    }
    fun clearChat() { msgs.clear(); store.saveChat(msgs) }
    fun toggleBlock() { blocked = !blocked; store.blocked = blocked }

    // ---- status ----
    fun postStatus(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        statuses.add(Status(true, now(), t)); store.saveStatuses(statuses)
        net.send(T.STATUS, t.toByteArray())
    }
    fun clearStatuses() { statuses.clear(); store.saveStatuses(statuses) }

    // ---- settings ----
    fun saveName(n: String) {
        val t = n.trim()
        if (t.isEmpty()) return
        myName = t; store.myName = t
        net.send(T.HELLO, t.toByteArray())
    }
    fun clearCalls() { calls.clear(); store.saveCalls(calls) }

    // ---- calls ----
    private fun perms(video: Boolean) =
        if (video) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        else arrayOf(Manifest.permission.RECORD_AUDIO)

    fun startCall(video: Boolean) {
        if (blocked) { toast("Unblock this contact to call"); return }
        if (!net.connected) { toast("Not connected"); return }
        if (callState != "idle") return
        act.ensurePerms(perms(video)) {
            outgoing = true; callVideo = video; callState = "ringing_out"
            net.send(T.CALL_REQ, byteArrayOf(if (video) 1 else 0))
        }
    }

    fun accept() {
        act.ensurePerms(perms(callVideo)) {
            net.send(T.CALL_ACC)
            beginMedia()
        }
    }

    fun decline() { net.send(T.CALL_REJ); finishCall() }
    fun hangup() { net.send(T.CALL_END); finishCall() }

    private fun beginMedia() {
        callState = "active"; callStart = now(); seconds = 0; remoteFrame = null
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = callVideo
        audio = AudioEngine { net.send(T.AUDIO, it) }.also { it.start() }
        if (callVideo) video = VideoEngine(act, act) { net.send(T.VIDEO, it) }.also { it.start() }
        ticker = scope.launch {
            while (callState == "active") { delay(1000); seconds = ((now() - callStart) / 1000).toInt() }
        }
    }

    private fun finishCall() {
        val was = callState
        val secs = if (was == "active") ((now() - callStart) / 1000).toInt() else 0
        val dir = when { outgoing -> "out"; was == "active" -> "in"; else -> "missed" }
        ticker?.cancel(); ticker = null
        audio?.stop(); audio = null
        video?.stop(); video = null
        runCatching { am.mode = AudioManager.MODE_NORMAL; am.isSpeakerphoneOn = false }
        callState = "idle"; remoteFrame = null
        if (was != "idle") { calls.add(CallRec(callVideo, dir, now(), secs)); store.saveCalls(calls) }
    }

    fun shutdown() { net.close(); scope.cancel(); audio?.stop(); video?.stop() }
}
