package com.msf.offlinewa

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.*
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/** Microphone -> chunks, and incoming chunks -> speaker (16 kHz mono PCM). */
class AudioEngine(private val onChunk: (ByteArray) -> Unit) {
    private val rate = 16000
    @Volatile private var running = false
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null

    @SuppressLint("MissingPermission")
    fun start() {
        running = true
        val minRec = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minRec, 4096)
        )
        val minTr = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(minTr, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        rec = r; track = t
        t.play(); r.startRecording()
        thread {
            val buf = ByteArray(1280)
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) onChunk(buf.copyOf(n)) else if (n < 0) break
            }
        }
    }

    fun play(data: ByteArray) { runCatching { track?.write(data, 0, data.size) } }

    fun stop() {
        running = false
        runCatching { rec?.stop(); rec?.release() }
        runCatching { track?.stop(); track?.release() }
        rec = null; track = null
    }
}

/** Front camera -> small JPEG frames (about 10 per second). */
class VideoEngine(
    private val ctx: Context,
    private val owner: LifecycleOwner,
    private val onJpeg: (ByteArray) -> Unit
) {
    private var provider: ProcessCameraProvider? = null
    private val exec = Executors.newSingleThreadExecutor()
    private var last = 0L

    fun start() {
        val f = ProcessCameraProvider.getInstance(ctx)
        f.addListener({
            val p = f.get()
            provider = p
            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(480, 360))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(exec) { img ->
                val now = System.currentTimeMillis()
                if (now - last >= 100) {
                    last = now
                    try {
                        val bmp = img.toBitmap()
                        val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()) }
                        val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                        val bos = ByteArrayOutputStream()
                        rot.compress(Bitmap.CompressFormat.JPEG, 45, bos)
                        onJpeg(bos.toByteArray())
                    } catch (_: Exception) {}
                }
                img.close()
            }
            p.unbindAll()
            try {
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (_: Exception) {
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, analysis)
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    fun stop() { runCatching { provider?.unbindAll() } }
}
