package com.msf.offlinewa

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

val Bg = Color(0xFF0B141A)
val Panel = Color(0xFF202C33)
val Green = Color(0xFF21C063)
val Out = Color(0xFF144D37)
val Sub = Color(0xFF8696A0)
val Red = Color(0xFFE5484D)

fun fmt(ts: Long): String {
    val d = Date(ts)
    val day = SimpleDateFormat("yyyyMMdd", Locale.US)
    return if (day.format(d) == day.format(Date())) SimpleDateFormat("h:mm a", Locale.getDefault()).format(d)
    else SimpleDateFormat("dd/MM/yyyy, h:mm a", Locale.getDefault()).format(d)
}
fun dur(s: Int) = "%d:%02d".format(s / 60, s % 60)

@Composable
fun Logo(size: Dp) = Image(
    painterResource(R.drawable.logo), "MSF Offline WhatsApp",
    Modifier.size(size).clip(CircleShape)
)

@Composable
fun Root(m: Model) {
    var screen by remember { mutableStateOf("connect") }
    var tab by remember { mutableIntStateOf(0) }
    BackHandler(screen == "chat" || screen == "settings") { screen = "main" }
    MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Panel, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
                when (screen) {
                    "connect" -> ConnectScreen(m) { screen = "main" }
                    "main" -> MainScreen(m, tab, { tab = it }, { screen = it })
                    "chat" -> ChatScreen(m) { screen = "main" }
                    "settings" -> SettingsScreen(m) { screen = "main" }
                }
                if (m.callState != "idle") CallScreen(m)
            }
        }
    }
}

@Composable
fun ConnectScreen(m: Model, done: () -> Unit) {
    var ip by remember { mutableStateOf(m.store.lastIp) }
    val ips = remember { localIps() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Logo(120.dp)
        Text("MSF Offline WhatsApp", fontSize = 24.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Your IP: " + if (ips.isEmpty()) "not on any network" else ips.joinToString(", "), color = Sub)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Phone 1: turn on Hotspot, then tap Host", color = Color.White)
                Button(onClick = { m.host(); done() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Host") }
            }
        }
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Phone 2: join that hotspot, enter Phone 1's IP, tap Join", color = Color.White)
                OutlinedTextField(ip, { ip = it }, label = { Text("Host IP") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = { m.join(ip); done() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Join") }
            }
        }
        TextButton(onClick = done) { Text("Open app", color = Green) }
        Text(m.state, color = Sub)
    }
}

@Composable
fun MainScreen(m: Model, tab: Int, setTab: (Int) -> Unit, go: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var showStatusDialog by remember { mutableStateOf(false) }
    val titles = listOf("MSF Offline WhatsApp", "Updates", "Calls", "You")
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, top = 12.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(titles[tab], fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
            Box {
                TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 24.sp, color = Color.White) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Connection") }, onClick = { menu = false; go("connect") })
                    DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; go("settings") })
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> ChatsTab(m) { go("chat") }
                1 -> UpdatesTab(m) { showStatusDialog = true }
                2 -> CallsTab(m)
                else -> YouTab(m) { go("settings") }
            }
        }
        Row(Modifier.fillMaxWidth().background(Bg).padding(vertical = 8.dp)) {
            listOf("💬" to "Chats", "◎" to "Updates", "📞" to "Calls", "👤" to "You").forEachIndexed { i, (ic, label) ->
                Column(Modifier.weight(1f).clickable { setTab(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.clip(RoundedCornerShape(16.dp)).background(if (tab == i) Out else Color.Transparent)
                            .padding(horizontal = 20.dp, vertical = 4.dp)
                    ) { Text(ic, fontSize = 20.sp) }
                    Text(label, fontSize = 12.sp, color = if (tab == i) Color.White else Sub)
                }
            }
        }
    }
    if (showStatusDialog) {
        var t by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showStatusDialog = false },
            title = { Text("New status") },
            text = { OutlinedTextField(t, { t = it }, placeholder = { Text("What's on your mind?") }) },
            confirmButton = { TextButton(onClick = { m.postStatus(t); showStatusDialog = false }) { Text("Post", color = Green) } },
            dismissButton = { TextButton(onClick = { showStatusDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ChatsTab(m: Model, open: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        val ok = m.state == "Connected"
        Card(Modifier.fillMaxWidth().padding(14.dp), colors = CardDefaults.cardColors(containerColor = if (ok) Out else Panel)) {
            Text(m.state, color = if (ok) Color.White else Sub, modifier = Modifier.padding(14.dp))
        }
        Row(Modifier.fillMaxWidth().clickable { open() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Logo(50.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(m.peerName, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (m.blocked) "Blocked" else m.msgs.lastOrNull()?.text ?: "Tap to chat",
                    color = Sub, fontSize = 14.sp, maxLines = 1
                )
            }
            m.msgs.lastOrNull()?.let { Text(fmt(it.ts), color = Sub, fontSize = 12.sp) }
        }
    }
}

@Composable
fun UpdatesTab(m: Model, add: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(Modifier.fillMaxWidth().clickable { add() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box { Logo(50.dp) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("My status", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text("Tap to add a status update", color = Sub, fontSize = 14.sp)
                }
            }
            Text("Recent updates", color = Sub, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        }
        items(m.statuses.sortedByDescending { it.ts }) { s ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    Text(if (s.mine) "You" else m.peerName, color = Green, fontWeight = FontWeight.SemiBold)
                    Text(s.text, color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(vertical = 4.dp))
                    Text(fmt(s.ts), color = Sub, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun CallsTab(m: Model) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button({ m.startCall(false) }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("📞  Audio call", color = Color(0xFF06210F)) }
                Button({ m.startCall(true) }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("🎥  Video call", color = Color(0xFF06210F)) }
            }
            Text("Recent", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            if (m.calls.isEmpty()) Text("No calls yet. Audio and video calls will appear here.", color = Sub, modifier = Modifier.padding(16.dp))
        }
        items(m.calls.sortedByDescending { it.ts }) { c ->
            Row(Modifier.fillMaxWidth().clickable { m.startCall(c.video) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Logo(46.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(m.peerName, color = if (c.dir == "missed") Red else Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    val arrow = when (c.dir) { "out" -> "↗"; "in" -> "↙"; else -> "↙ Missed" }
                    Text("$arrow  ${fmt(c.ts)}" + if (c.secs > 0) "  ·  ${dur(c.secs)}" else "", color = Sub, fontSize = 13.sp)
                }
                Text(if (c.video) "🎥" else "📞", fontSize = 22.sp)
            }
        }
    }
}

@Composable
fun YouTab(m: Model, settings: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Logo(120.dp)
        Text(m.myName, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth().clickable { settings() }.padding(20.dp)) {
            Text("⚙", fontSize = 22.sp, color = Color.White)
            Spacer(Modifier.width(18.dp))
            Column {
                Text("Settings", color = Color.White, fontSize = 17.sp)
                Text("Name, block, clear history", color = Sub, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun ChatScreen(m: Model, back: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    LaunchedEffect(m.msgs.size) { if (m.msgs.isNotEmpty()) list.animateScrollToItem(m.msgs.size - 1) }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("←", fontSize = 22.sp, color = Color.White) }
            Logo(40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(m.peerName, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(m.state, color = if (m.state == "Connected") Green else Sub, fontSize = 12.sp, maxLines = 1)
            }
            TextButton({ m.startCall(true) }) { Text("🎥", fontSize = 20.sp) }
            TextButton({ m.startCall(false) }) { Text("📞", fontSize = 20.sp) }
            Box {
                TextButton({ menu = true }) { Text("⋮", fontSize = 22.sp, color = Color.White) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(if (m.blocked) "Unblock" else "Block", color = if (m.blocked) Color.White else Red) },
                        onClick = { menu = false; m.toggleBlock() }
                    )
                    DropdownMenuItem(text = { Text("Clear chat") }, onClick = { menu = false; m.clearChat() })
                }
            }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item {
                Text(
                    "Messages stay on your local network. Nothing goes through the internet.",
                    color = Color(0xFFE8C36A), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(8.dp)
                )
            }
            items(m.msgs) { x ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (x.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Column(
                        Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (x.mine) Out else Panel).padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(x.text, color = Color.White, fontSize = 16.sp)
                        Text(fmt(x.ts), color = Sub, fontSize = 11.sp, modifier = Modifier.align(Alignment.End))
                    }
                }
            }
        }
        if (m.blocked) {
            Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("You blocked ${m.peerName}.", color = Sub, modifier = Modifier.weight(1f))
                TextButton({ m.toggleBlock() }) { Text("Unblock", color = Green) }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(text, { text = it }, placeholder = { Text("Message") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(28.dp), maxLines = 4)
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { m.sendMsg(text); text = "" }, shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Green),
                    contentPadding = PaddingValues(0.dp), modifier = Modifier.size(52.dp)
                ) { Text("➤", fontSize = 20.sp, color = Color(0xFF06210F)) }
            }
        }
    }
}

@Composable
fun SettingsScreen(m: Model, back: () -> Unit) {
    var name by remember { mutableStateOf(m.myName) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("←", fontSize = 22.sp, color = Color.White) }
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Logo(64.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text("MSF Offline WhatsApp", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text("Version 1.0", color = Sub, fontSize = 13.sp)
            }
        }
        OutlinedTextField(name, { name = it }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button({ m.saveName(name); m.toast("Saved") }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Save name", color = Color(0xFF06210F)) }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Block ${m.peerName}", color = Color.White, fontSize = 16.sp)
                Text("No messages, status, or calls", color = Sub, fontSize = 13.sp)
            }
            Switch(m.blocked, { m.toggleBlock() })
        }
        OutlinedButton({ m.clearChat(); m.toast("Chat cleared") }) { Text("Clear chat", color = Color.White) }
        OutlinedButton({ m.clearCalls(); m.toast("Call history cleared") }) { Text("Clear call history", color = Color.White) }
        OutlinedButton({ m.clearStatuses(); m.toast("Status cleared") }) { Text("Clear status updates", color = Color.White) }
    }
}

@Composable
fun CallScreen(m: Model) {
    val frame = m.remoteFrame
    val showVideo = m.callVideo && m.callState == "active" && frame != null
    Box(Modifier.fillMaxSize().background(Color(0xFF05100F)).clickable(enabled = false) {}) {
        if (showVideo) Image(frame!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(32.dp))
            if (!showVideo) { Logo(120.dp); Spacer(Modifier.height(16.dp)) }
            Text(m.peerName, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(
                when (m.callState) {
                    "ringing_out" -> "Calling..."
                    "ringing_in" -> if (m.callVideo) "Incoming video call" else "Incoming audio call"
                    else -> dur(m.seconds)
                },
                color = Sub, fontSize = 16.sp
            )
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(48.dp), modifier = Modifier.padding(bottom = 32.dp)) {
                if (m.callState == "ringing_in") {
                    CallBtn("✕", "Decline", Red) { m.decline() }
                    CallBtn("✓", "Accept", Green) { m.accept() }
                } else CallBtn("✕", "End", Red) { m.hangup() }
            }
        }
    }
}

@Composable
fun CallBtn(icon: String, label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Button(onClick, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = color), contentPadding = PaddingValues(0.dp), modifier = Modifier.size(68.dp)) {
            Text(icon, fontSize = 26.sp, color = Color.White)
        }
        Text(label, color = Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
}
