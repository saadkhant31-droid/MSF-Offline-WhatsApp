package com.msf.offlinewa

import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var model: Model
    private var pending: ((Boolean) -> Unit)? = null
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            pending?.invoke(r.values.all { it }); pending = null
        }

    fun ensurePerms(perms: Array<String>, then: () -> Unit) {
        if (perms.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            then()
        } else {
            pending = { ok ->
                if (ok) then() else Toast.makeText(this, "Permission needed for calls", Toast.LENGTH_SHORT).show()
            }
            permLauncher.launch(perms)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        model = Model(this)
        setContent { Root(model) }
    }

    override fun onDestroy() { model.shutdown(); super.onDestroy() }
}
