package com.msf.offlinewa

import android.content.Context
import android.util.Base64

data class Msg(val mine: Boolean, val ts: Long, val text: String)
data class CallRec(val video: Boolean, val dir: String, val ts: Long, val secs: Int)
data class Status(val mine: Boolean, val ts: Long, val text: String)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("msf", Context.MODE_PRIVATE)

    var myName: String
        get() = p.getString("name", "Me") ?: "Me"
        set(v) { p.edit().putString("name", v).apply() }
    var peerName: String
        get() = p.getString("peer", "Friend") ?: "Friend"
        set(v) { p.edit().putString("peer", v).apply() }
    var blocked: Boolean
        get() = p.getBoolean("blocked", false)
        set(v) { p.edit().putBoolean("blocked", v).apply() }
    var lastIp: String
        get() = p.getString("ip", "192.168.43.1") ?: "192.168.43.1"
        set(v) { p.edit().putString("ip", v).apply() }

    private fun enc(s: String) = Base64.encodeToString(s.toByteArray(), Base64.NO_WRAP)
    private fun dec(s: String) = String(Base64.decode(s, Base64.NO_WRAP))
    private fun lines(k: String) = (p.getString(k, "") ?: "").split("\n").filter { it.isNotBlank() }
    private fun save(k: String, l: List<String>) { p.edit().putString(k, l.joinToString("\n")).apply() }

    fun loadChat() = lines("chat").mapNotNull { l ->
        val s = l.split("|")
        if (s.size == 3) Msg(s[0] == "1", s[1].toLongOrNull() ?: 0L, dec(s[2])) else null
    }
    fun saveChat(l: List<Msg>) = save("chat", l.takeLast(500).map { "${if (it.mine) 1 else 0}|${it.ts}|${enc(it.text)}" })

    fun loadCalls() = lines("calls").mapNotNull { l ->
        val s = l.split("|")
        if (s.size == 4) CallRec(s[0] == "1", s[1], s[2].toLongOrNull() ?: 0L, s[3].toIntOrNull() ?: 0) else null
    }
    fun saveCalls(l: List<CallRec>) = save("calls", l.takeLast(200).map { "${if (it.video) 1 else 0}|${it.dir}|${it.ts}|${it.secs}" })

    fun loadStatuses() = lines("status").mapNotNull { l ->
        val s = l.split("|")
        if (s.size == 3) Status(s[0] == "1", s[1].toLongOrNull() ?: 0L, dec(s[2])) else null
    }
    fun saveStatuses(l: List<Status>) = save("status", l.takeLast(100).map { "${if (it.mine) 1 else 0}|${it.ts}|${enc(it.text)}" })
}
