package com.msf.offlinewa

import java.io.*
import java.net.*
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

const val PORT = 8888

object T {
    const val TEXT = 1
    const val HELLO = 2
    const val CALL_REQ = 3
    const val CALL_ACC = 4
    const val CALL_END = 5
    const val AUDIO = 6
    const val VIDEO = 7
    const val STATUS = 8
    const val CALL_REJ = 9
}

/** One TCP connection over hotspot / shared Wi-Fi. Frame = type(1) + length(4) + payload. */
class Net(private val l: Listener) {
    interface Listener {
        fun onState(s: String)
        fun onFrame(type: Int, data: ByteArray)
    }

    private var server: ServerSocket? = null
    private var sock: Socket? = null
    private var dout: DataOutputStream? = null
    private val writer = Executors.newSingleThreadExecutor()
    private val pending = AtomicInteger(0)
    private var gen = 0
    @Volatile var connected = false

    private fun closeSockets() {
        runCatching { sock?.close() }
        runCatching { server?.close() }
    }

    fun host() {
        val g = ++gen
        closeSockets()
        thread {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(PORT))
                server = ss
                while (g == gen) {
                    l.onState("Waiting for the other phone...")
                    val s = ss.accept()
                    attach(s)
                }
            } catch (e: Exception) {
                if (g == gen) l.onState("Error: ${e.message}")
            }
        }
    }

    fun join(ip: String) {
        val g = ++gen
        closeSockets()
        thread {
            try {
                l.onState("Connecting...")
                val s = Socket()
                s.connect(InetSocketAddress(ip.trim(), PORT), 8000)
                attach(s)
            } catch (e: Exception) {
                if (g == gen) l.onState("Could not connect: ${e.message}")
            }
        }
    }

    private fun attach(s: Socket) {
        s.tcpNoDelay = true
        sock = s
        dout = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
        connected = true
        l.onState("Connected")
        try {
            val din = DataInputStream(BufferedInputStream(s.getInputStream()))
            while (true) {
                val type = din.readUnsignedByte()
                val len = din.readInt()
                if (len < 0 || len > 4_000_000) break
                val buf = ByteArray(len)
                din.readFully(buf)
                l.onFrame(type, buf)
            }
        } catch (_: Exception) {}
        connected = false
        runCatching { s.close() }
        l.onState("Disconnected")
    }

    fun send(type: Int, data: ByteArray = ByteArray(0)) {
        if (!connected) return
        if (type == T.VIDEO && pending.get() > 3) return
        pending.incrementAndGet()
        writer.execute {
            try {
                synchronized(this) {
                    dout?.let { it.writeByte(type); it.writeInt(data.size); it.write(data); it.flush() }
                }
            } catch (_: Exception) {
            } finally { pending.decrementAndGet() }
        }
    }

    fun close() { gen++; connected = false; closeSockets() }
}
