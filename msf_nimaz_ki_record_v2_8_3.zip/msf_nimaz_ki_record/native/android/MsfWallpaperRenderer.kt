package com.msf.msf_nimaz_ki_record

import android.content.Context
import android.graphics.*
import org.json.JSONObject
import java.util.Calendar
import java.util.Random
import kotlin.math.*

/** One wallpaper design. layout: 0 grid5x2, 1 grid6x2, 2 list, 3 side cards, 4 row of 7, 5 clock only.
 *  face: 0 cream, 1 green, 2 navy. card: 0 dark green, 1 cream, 2 navy glass. */
class WpTheme(
    val name: String, val sky: IntArray, val face: Int, val layout: Int, val card: Int,
    val tagline: String, val dates: Boolean = true,
    val img: String? = null, val kind: Int = 0
)

object WpThemes {
    private fun c(s: String) = Color.parseColor(s)
    val list: List<WpTheme> = listOf(
        WpTheme("کلاسک کریم", intArrayOf(c("#16224F"), c("#6B4A7A"), c("#F2A65A")), 0, 0, 1, "اللہ کی رضا ہی اصل کامیابی ہے"),
        WpTheme("نماز ڈیش بورڈ", intArrayOf(c("#0B1A3A"), c("#2B3C78"), c("#E58A4B")), 1, 2, 0, "وقت کی پابندی ایمان کی علامت ہے"),
        WpTheme("سادہ گھڑی", intArrayOf(c("#10285E"), c("#3E5C9A"), c("#F6B66B")), 0, 5, 0, "اللہ کی رضا ہی اصل کامیابی ہے", false),
        WpTheme("سبز کارڈ", intArrayOf(c("#071B33"), c("#1E3E6E"), c("#D98A4C")), 1, 3, 1, "نماز ایمان کی شہادت ہے"),
        WpTheme("ہجری تاریخ", intArrayOf(c("#0A1030"), c("#33407F"), c("#E8995A")), 1, 0, 0, "اللہ کی رضا ہی اصل کامیابی ہے"),
        WpTheme("بارہ اوقات", intArrayOf(c("#1A1F4D"), c("#7A4F86"), c("#F4A261")), 0, 1, 1, "نماز کی پابندی ہی کامیابی کی کنجی ہے"),
        WpTheme("اطراف کارڈ", intArrayOf(c("#0F2557"), c("#5B5A9C"), c("#F7B267")), 0, 3, 0, "اللہ کی رضا ہی اصل کامیابی ہے"),
        WpTheme("ڈیسک گھڑی", intArrayOf(c("#102B52"), c("#4F6AA3"), c("#FFC477")), 1, 4, 1, "اللہ کے حضور وقت کی پابندی"),
        WpTheme("نیوی گولڈ", intArrayOf(c("#050B24"), c("#1B2A5E"), c("#C97B4A")), 2, 4, 2, "آج کے اوقات"),
        WpTheme("نماز ریکارڈ", intArrayOf(c("#081633"), c("#233A73"), c("#E39A57")), 1, 2, 0, "اللہ کے ذکر سے ہی دلوں کو سکون ملتا ہے"),
        WpTheme("ریکارڈ ڈبل", intArrayOf(c("#1B1650"), c("#62478F"), c("#F2A05A")), 1, 3, 2, "وقت کی پابندی ایمان کی علامت ہے"),
        WpTheme("مکمل ڈیش بورڈ", intArrayOf(c("#06122E"), c("#1F3A6F"), c("#D4894F")), 2, 2, 2, "اپنی نمازوں کا مکمل ریکارڈ رکھیں"),
        WpTheme("اسلامک ایپ ۱", intArrayOf(c("#06122E"), c("#1F3A6F"), c("#D4894F")), 1, 2, 0, "", true, "wp_a.jpg", 0),
        WpTheme("اسلامک ایپ ۲", intArrayOf(c("#06122E"), c("#1F3A6F"), c("#D4894F")), 1, 2, 0, "", true, "wp_b.jpg", 1)
    )
}

private object WpBmpCache {
    val bmp = HashMap<String, Bitmap?>()
    val top = HashMap<String, Int>()
    val bot = HashMap<String, Int>()
}

object WpDims {
    // 0 = auto (device), others are design sizes (width, height)
    val sizes = arrayOf(intArrayOf(0, 0), intArrayOf(480, 854), intArrayOf(720, 1280), intArrayOf(1080, 1920), intArrayOf(1440, 3120))
}

class WpRenderer(private val ctx: Context) {
    var themeIdx = 0
    var dimIdx = 0
    var showSec = true
    private var data: JSONObject? = null
    private var urdu: Typeface = Typeface.DEFAULT_BOLD
    private val sans: Typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    private val serif: Typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gold = Color.parseColor("#E2B33C")
    private val deepGreen = Color.parseColor("#0B3D2A")
    private val green = Color.parseColor("#0B5D3B")
    private val cream = Color.parseColor("#F6EDD2")

    private val urduMonths = arrayOf("جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر")
    private val urduDays = arrayOf("اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ") // Calendar.SUNDAY = 1
    private val stLabels = arrayOf("باقی", "ادا", "با جماعت", "قضا")

    init {
        try {
            urdu = Typeface.createFromAsset(ctx.assets, "flutter_assets/assets/fonts/jameel_noori_kasheeda.ttf")
        } catch (e: Throwable) {
            urdu = Typeface.DEFAULT_BOLD
        }
    }

    fun reload() {
        val sp = ctx.getSharedPreferences("msf_wp", Context.MODE_PRIVATE)
        themeIdx = sp.getInt("theme", 0).coerceIn(0, WpThemes.list.size - 1)
        dimIdx = sp.getInt("dim", 0).coerceIn(0, WpDims.sizes.size - 1)
        showSec = sp.getBoolean("sec", true)
        data = try { JSONObject(sp.getString("data", "") ?: "") } catch (e: Throwable) { null }
    }

    // ------------------------------------------------------------ data helpers
    private fun todayKey(cal: Calendar) = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.MONTH) + 1}-${cal.get(Calendar.DAY_OF_MONTH)}"

    private fun dayObj(key: String): JSONObject? {
        val arr = data?.optJSONArray("days") ?: return null
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("k") == key) return o
        }
        return null
    }

    private fun tm(t: JSONObject?, i: Int): Int = t?.optJSONArray("t")?.optInt(i, -1) ?: -1

    private fun p12(min: Int): String {
        if (min < 0) return "--:--"
        val h24 = (min / 60) % 24
        val h = if (h24 % 12 == 0) 12 else h24 % 12
        return "%02d:%02d %s".format(h, min % 60, if (h24 >= 12) "PM" else "AM")
    }

    // t order: 0 sehri,1 fajr,2 sunrise,3 ishraq,4 chasht,5 zawal,6 zuhr,7 asr1,8 asr2,9 maghrib,10 isha,11 asr(chosen)
    private val fiveIdx = intArrayOf(1, 6, 11, 9, 10)
    private val fiveNames = arrayOf("فجر", "ظہر", "عصر", "مغرب", "عشاء")

    private fun nextPrayer(t: JSONObject?, nowMin: Int): Int {
        for (i in 0..4) {
            val m = tm(t, fiveIdx[i])
            if (m >= 0 && m > nowMin) return i
        }
        return 0
    }

    // ------------------------------------------------------------ public draw
    fun draw(canvas: Canvas, sw: Int, sh: Int, now: Long) {
        val d = WpDims.sizes[dimIdx]
        val vw = 1080f
        val vh = if (d[0] == 0) vw * sh / sw else vw * d[1] / d[0]
        val s = max(sw / vw, sh / vh)
        canvas.save()
        canvas.translate((sw - vw * s) / 2f, (sh - vh * s) / 2f)
        canvas.scale(s, s)
        canvas.clipRect(0f, 0f, vw, vh)
        try {
            scene(canvas, vw, vh, now)
        } catch (e: Throwable) {
            canvas.drawColor(deepGreen)
        }
        canvas.restore()
    }

    // ------------------------------------------------------------ text
    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, face: Typeface = sans,
                    align: Paint.Align = Paint.Align.CENTER, maxW: Float = 0f) {
        p.reset(); p.isAntiAlias = true
        p.typeface = face; p.color = color; p.textAlign = align; p.textSize = size
        if (maxW > 0f) {
            val w = p.measureText(s)
            if (w > maxW) p.textSize = size * maxW / w
        }
        val fm = p.fontMetrics
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, p)   // y = vertical centre
    }

    private fun ur(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, maxW: Float = 0f) =
        txt(c, s, x, y, size, color, urdu, Paint.Align.CENTER, maxW)

    private fun fillRR(c: Canvas, r: RectF, rad: Float, color: Int) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = color
        c.drawRoundRect(r, rad, rad, p)
    }

    private fun strokeRR(c: Canvas, r: RectF, rad: Float, color: Int, w: Float) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = w
        c.drawRoundRect(r, rad, rad, p)
    }

    // ------------------------------------------------------------ scene
    private fun scene(c: Canvas, vw: Float, vh: Float, now: Long) {
        val th = WpThemes.list[themeIdx]
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val day = dayObj(todayKey(cal))
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

        if (th.img != null) { imageTheme(c, vw, vh, th, day, cal, now); return }
        background(c, vw, vh, th, now)

        val top = 70f
        logo(c, vw / 2f, top + 110f, 1f)
        // tagline pill
        val tagR = RectF(vw / 2f - 330f, top + 250f, vw / 2f + 330f, top + 320f)
        fillRR(c, tagR, 35f, Color.argb(225, 11, 61, 42)); strokeRR(c, tagR, 35f, gold, 3f)
        ur(c, th.tagline, vw / 2f, tagR.centerY(), 38f, Color.WHITE, 600f)

        val bottom = vh - 70f
        when (th.layout) {
            0, 1 -> layoutGrid(c, vw, vh, th, day, cal, nowMin, now, top + 350f, bottom)
            2 -> layoutList(c, vw, vh, th, day, cal, nowMin, now, top + 350f, bottom)
            3 -> layoutSide(c, vw, vh, th, day, cal, nowMin, now, top + 350f, bottom)
            4 -> layoutRow(c, vw, vh, th, day, cal, nowMin, now, top + 350f, bottom)
            else -> layoutClockOnly(c, vw, vh, th, day, cal, nowMin, now, top + 350f, bottom)
        }
    }

    // ------------------------------------------------------------ background art
    private fun background(c: Canvas, vw: Float, vh: Float, th: WpTheme, now: Long) {
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(0f, 0f, 0f, vh * 0.72f, th.sky, floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, vw, vh, p)
        p.reset()
        // stars
        val rnd = Random(11)
        for (i in 0 until 90) {
            val x = rnd.nextFloat() * vw; val y = rnd.nextFloat() * vh * 0.42f
            val tw = 0.55f + 0.45f * sin(now / 900.0 + i).toFloat()
            p.isAntiAlias = true; p.color = Color.argb((200 * tw).toInt(), 255, 250, 225)
            c.drawCircle(x, y, 1.5f + rnd.nextFloat() * 2.5f, p)
        }
        // crescent moon
        val mx = vw * 0.82f; val my = vh * 0.075f
        val moon = Path().apply { addCircle(mx, my, 62f, Path.Direction.CW) }
        val cut = Path().apply { addCircle(mx + 30f, my - 12f, 56f, Path.Direction.CW) }
        moon.op(cut, Path.Op.DIFFERENCE)
        p.reset(); p.isAntiAlias = true
        p.setShadowLayer(30f, 0f, 0f, Color.argb(160, 255, 240, 190)); p.color = Color.parseColor("#FFF4CF")
        c.drawPath(moon, p); p.clearShadowLayer()

        // horizon + mosques
        val hy = vh * 0.60f
        val sil = Color.argb(235, 18, 24, 48)
        mosque(c, vw * 0.78f, hy, 1.25f, sil, now)
        mosque(c, vw * 0.17f, hy, 0.85f, sil, now)

        // water
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(0f, hy, 0f, vh, intArrayOf(Color.argb(255, 40, 52, 96), Color.argb(255, 8, 22, 40)), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, hy, vw, vh, p)
        p.reset(); p.isAntiAlias = true
        val rnd2 = Random(5)
        for (i in 0 until 26) {
            val x = vw * 0.55f + rnd2.nextFloat() * vw * 0.45f
            val w = 4f + rnd2.nextFloat() * 10f
            val off = sin(now / 700.0 + i * 1.7).toFloat() * 6f
            p.color = Color.argb(60 + rnd2.nextInt(60), 255, 196, 110)
            c.drawRect(x + off, hy + 8f, x + off + w, hy + 90f + rnd2.nextFloat() * 120f, p)
        }

        // foliage corners
        foliage(c, 0f, vh * 0.28f, 1f)
        foliage(c, vw, vh * 0.30f, -1f)
        // lanterns
        lantern(c, 105f, 0f, 250f, now, 0)
        lantern(c, vw - 105f, 0f, 190f, now, 1)

        // scrim so the cards stay readable
        p.reset()
        p.shader = LinearGradient(0f, vh * 0.35f, 0f, vh, intArrayOf(Color.TRANSPARENT, Color.argb(190, 4, 24, 16)), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, vh * 0.35f, vw, vh, p)
    }

    private fun mosque(c: Canvas, cx: Float, base: Float, s: Float, col: Int, now: Long) {
        p.reset(); p.isAntiAlias = true; p.color = col; p.style = Paint.Style.FILL
        // body
        c.drawRect(cx - 150 * s, base - 70 * s, cx + 150 * s, base, p)
        // main dome
        c.drawArc(RectF(cx - 105 * s, base - 230 * s, cx + 105 * s, base - 20 * s), 180f, 180f, true, p)
        c.drawRect(cx - 105 * s, base - 125 * s, cx + 105 * s, base - 70 * s, p)
        // finial
        c.drawRect(cx - 3 * s, base - 270 * s, cx + 3 * s, base - 228 * s, p)
        // side domes
        for (k in intArrayOf(-1, 1)) {
            c.drawArc(RectF(cx + k * 128 * s - 38 * s, base - 140 * s, cx + k * 128 * s + 38 * s, base - 60 * s), 180f, 180f, true, p)
        }
        // minarets
        for (k in intArrayOf(-1, 1, -2, 2)) {
            val mx = cx + k * (if (abs(k) == 1) 190f else 245f) * s
            val h = (if (abs(k) == 1) 380f else 290f) * s
            c.drawRect(mx - 14 * s, base - h, mx + 14 * s, base, p)
            c.drawRect(mx - 22 * s, base - h * 0.80f, mx + 22 * s, base - h * 0.80f + 10 * s, p)
            val tip = Path().apply { moveTo(mx - 18 * s, base - h); lineTo(mx, base - h - 70 * s); lineTo(mx + 18 * s, base - h); close() }
            c.drawPath(tip, p)
        }
        // glowing windows
        val glow = 0.7f + 0.3f * sin(now / 1100.0).toFloat()
        p.color = Color.argb((230 * glow).toInt(), 255, 205, 110)
        for (i in -4..4) {
            if (i == 0) continue
            c.drawRoundRect(RectF(cx + i * 30 * s - 6 * s, base - 48 * s, cx + i * 30 * s + 6 * s, base - 14 * s), 6f, 6f, p)
        }
    }

    private fun foliage(c: Canvas, x: Float, y: Float, dir: Float) {
        val rnd = Random(if (dir > 0) 3 else 9)
        for (i in 0 until 26) {
            val px = x + dir * rnd.nextFloat() * 170f
            val py = y - 100f + rnd.nextFloat() * (y + 140f)
            val r = 26f + rnd.nextFloat() * 46f
            p.reset(); p.isAntiAlias = true
            p.color = if (rnd.nextBoolean()) Color.argb(235, 18, 74, 40) else Color.argb(235, 36, 110, 50)
            c.drawOval(RectF(px - r, py - r * 0.6f, px + r, py + r * 0.6f), p)
        }
        // few jasmine flowers
        for (i in 0 until 5) {
            val px = x + dir * (20f + rnd.nextFloat() * 120f)
            val py = y + 40f + rnd.nextFloat() * 280f
            p.reset(); p.isAntiAlias = true; p.color = Color.argb(240, 255, 248, 240)
            for (k in 0 until 5) {
                val a = k * 72.0 * PI / 180.0
                c.drawCircle(px + (cos(a) * 11).toFloat(), py + (sin(a) * 11).toFloat(), 9f, p)
            }
            p.color = Color.parseColor("#F4C542"); c.drawCircle(px, py, 6f, p)
        }
    }

    private fun lantern(c: Canvas, cx: Float, top: Float, len: Float, now: Long, seed: Int) {
        val flick = 0.85f + 0.15f * sin(now / 260.0 + seed * 2).toFloat()
        p.reset(); p.isAntiAlias = true; p.color = gold; p.style = Paint.Style.STROKE; p.strokeWidth = 4f
        c.drawLine(cx, top, cx, top + len, p)
        val ly = top + len
        // glow
        p.reset(); p.isAntiAlias = true
        p.shader = RadialGradient(cx, ly + 70f, 130f, Color.argb((150 * flick).toInt(), 255, 200, 90), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(cx, ly + 70f, 130f, p)
        p.reset(); p.isAntiAlias = true; p.color = Color.parseColor("#7A4E12")
        val cap = Path().apply { moveTo(cx - 42f, ly + 24f); lineTo(cx, ly - 14f); lineTo(cx + 42f, ly + 24f); close() }
        c.drawPath(cap, p)
        val body = RectF(cx - 36f, ly + 24f, cx + 36f, ly + 130f)
        p.color = Color.argb(255, (255 * flick).toInt(), (190 * flick).toInt(), 80); c.drawRoundRect(body, 14f, 14f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = gold; c.drawRoundRect(body, 14f, 14f, p)
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#7A4E12")
        c.drawRect(cx - 40f, ly + 130f, cx + 40f, ly + 146f, p)
    }

    // ------------------------------------------------------------ image based themes (reference artwork + live text)
    private fun avgColor(b: Bitmap, y0: Int): Int {
        val strip = Bitmap.createBitmap(b, 0, y0, b.width, 6)
        val one = Bitmap.createScaledBitmap(strip, 1, 1, true)
        return one.getPixel(0, 0) or (0xFF shl 24)
    }

    private fun loadBmp(name: String): Bitmap? {
        synchronized(WpBmpCache) {
            if (WpBmpCache.bmp.containsKey(name)) return WpBmpCache.bmp[name]
            var b: Bitmap? = null
            try {
                ctx.assets.open("flutter_assets/assets/wp/" + name).use { b = BitmapFactory.decodeStream(it) }
            } catch (e: Throwable) {
                b = null
            }
            WpBmpCache.bmp[name] = b
            val bb = b
            if (bb != null) {
                WpBmpCache.top[name] = avgColor(bb, 0)
                WpBmpCache.bot[name] = avgColor(bb, bb.height - 6)
            }
            return bb
        }
    }

    private fun fit(c: Canvas, s: String, cx: Float, cy: Float, w: Float, size: Float, color: Int, face: Typeface, sc: Float) {
        p.reset(); p.isAntiAlias = true; p.typeface = face; p.color = color
        p.textAlign = Paint.Align.CENTER; p.textSize = size * sc
        val mw = p.measureText(s)
        val target = w * sc
        if (mw > target && mw > 0f) p.textSize = p.textSize * target / mw
        val fm = p.fontMetrics
        c.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, p)
    }

    private fun tx(base: Int, delta: Int): String =
        if (base < 0) "--:--" else p12((((base + delta) % 1440) + 1440) % 1440)

    private val aRow1X = floatArrayOf(91f, 236f, 383f, 526f, 666f, 808f, 944f)
    private val aRow2X = floatArrayOf(118f, 283f, 440f, 593f, 748f, 905f)
    private val bRow1X = floatArrayOf(114f, 279f, 441f, 600f, 760f, 918f)
    private val bRow2X = floatArrayOf(115f, 280f, 440f, 600f, 760f, 915f)
    // {time index, shift (minutes), duration (minutes)}
    private val aRow1 = arrayOf(intArrayOf(1, 0, 50), intArrayOf(3, 0, 50), intArrayOf(6, 0, 60), intArrayOf(7, 0, 60), intArrayOf(8, 0, 60), intArrayOf(9, 0, 40), intArrayOf(10, 0, 60))
    private val aRow2 = arrayOf(intArrayOf(4, 0, 50), intArrayOf(0, -4, 60), intArrayOf(0, -70, 70), intArrayOf(5, -20, 60), intArrayOf(6, 40, 60), intArrayOf(6, -20, 60))
    private val bRow1 = arrayOf(intArrayOf(1, 0, 50), intArrayOf(3, 0, 50), intArrayOf(6, 0, 60), intArrayOf(11, 0, 60), intArrayOf(9, 0, 40), intArrayOf(10, 0, 60))
    private val bRow2 = arrayOf(intArrayOf(4, 0, 50), intArrayOf(0, -4, 60), intArrayOf(0, 0, 70), intArrayOf(5, 0, 60), intArrayOf(6, 60, 60), intArrayOf(6, 0, 60))

    private fun imageTheme(c: Canvas, vw: Float, vh: Float, th: WpTheme, day: JSONObject?, cal: Calendar, now: Long) {
        val name = th.img ?: return
        val bmp = loadBmp(name)
        if (bmp == null) { c.drawColor(deepGreen); return }
        val s = vw / bmp.width
        val ih = bmp.height * s
        val offY = max(0f, (vh - ih) * 0.22f)
        val topCol = WpBmpCache.top[name] ?: deepGreen
        val botCol = WpBmpCache.bot[name] ?: deepGreen
        if (offY > 0f) {
            p.reset()
            val dk = Color.rgb((Color.red(topCol) * 0.45f).toInt(), (Color.green(topCol) * 0.45f).toInt(), (Color.blue(topCol) * 0.45f).toInt())
            p.shader = LinearGradient(0f, 0f, 0f, offY + 2f, dk, topCol, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, vw, offY + 2f, p)
        }
        val botY = offY + ih
        if (botY < vh) {
            p.reset(); p.color = botCol
            c.drawRect(0f, botY - 2f, vw, vh, p)
        }
        p.reset(); p.isFilterBitmap = true
        c.drawBitmap(bmp, null, RectF(0f, offY, vw, offY + ih), p)

        val dark = Color.parseColor("#12302A")
        val white = Color.parseColor("#FFF8E8")
        val b = { i: Int -> tm(day, i) }
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        val mm = cal.get(Calendar.MINUTE)
        val ap = if (h24 >= 12) "PM" else "AM"
        val big = "%02d:%02d".format(h12, mm)
        val small = "( %d:%02d %s )".format(h12, mm, ap)
        val enDay = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, java.util.Locale.ENGLISH) ?: ""
        val hs = (day?.optString("hs", "") ?: "") + " ہجری"
        val g1 = "${cal.get(Calendar.YEAR)} ، ${cal.get(Calendar.DAY_OF_MONTH)} ${urduMonths[cal.get(Calendar.MONTH)]}"
        val yr = cal.get(Calendar.YEAR).toString()
        val dm = "${cal.get(Calendar.DAY_OF_MONTH)} ${urduMonths[cal.get(Calendar.MONTH)]}"

        if (th.kind == 0) {
            fit(c, big, s * 505f, offY + 345f * s, 300f, 128f, white, sans, s)
            fit(c, ap, s * 686f, offY + 368f * s, 46f, 40f, white, sans, s)
            fit(c, small, s * 512f, offY + 414f * s, 175f, 30f, white, sans, s)
            fit(c, enDay, s * 200f, offY + 487f * s, 100f, 30f, white, sans, s)
            fit(c, dayName(cal), s * 200f, offY + 523f * s, 90f, 36f, white, urdu, s)
            fit(c, hs, s * 515f, offY + 483f * s, 330f, 42f, white, urdu, s)
            fit(c, g1, s * 515f, offY + 522f * s, 330f, 38f, white, urdu, s)
            fit(c, yr, s * 893f, offY + 487f * s, 70f, 36f, white, sans, s)
            fit(c, dm, s * 893f, offY + 523f * s, 120f, 42f, white, urdu, s)
            for ((i, d) in aRow1.withIndex()) {
                fit(c, tx(b(d[0]), d[1]), s * aRow1X[i], offY + 794f * s, 96f, 27f, dark, sans, s)
                fit(c, tx(b(d[0]), d[1] + d[2]), s * aRow1X[i], offY + 851f * s, 96f, 27f, dark, sans, s)
            }
            for ((i, d) in aRow2.withIndex()) {
                if (i == 1) {
                    fit(c, tx(b(d[0]), d[1]), s * aRow2X[i], offY + 1146f * s, 96f, 27f, dark, sans, s)
                } else {
                    fit(c, tx(b(d[0]), d[1]), s * aRow2X[i], offY + 1141f * s, 96f, 27f, dark, sans, s)
                    fit(c, tx(b(d[0]), d[1] + d[2]), s * aRow2X[i], offY + 1189f * s, 96f, 27f, dark, sans, s)
                }
            }
        } else {
            fit(c, big, s * 512f, offY + 340f * s, 340f, 130f, white, sans, s)
            fit(c, ap, s * 716f, offY + 375f * s, 50f, 42f, white, sans, s)
            fit(c, small, s * 512f, offY + 420f * s, 135f, 30f, white, sans, s)
            fit(c, enDay, s * 193f, offY + 498f * s, 100f, 30f, white, sans, s)
            fit(c, dayName(cal), s * 193f, offY + 530f * s, 90f, 36f, white, urdu, s)
            fit(c, hs, s * 495f, offY + 488f * s, 320f, 42f, white, urdu, s)
            fit(c, g1, s * 495f, offY + 528f * s, 320f, 38f, white, urdu, s)
            fit(c, yr, s * 892f, offY + 495f * s, 70f, 36f, white, sans, s)
            fit(c, dm, s * 892f, offY + 528f * s, 120f, 42f, white, urdu, s)
            for ((i, d) in bRow1.withIndex()) {
                fit(c, tx(b(d[0]), d[1]), s * bRow1X[i], offY + 790f * s, 98f, 28f, white, sans, s)
                fit(c, tx(b(d[0]), d[1] - 20), s * bRow1X[i], offY + 849f * s, 98f, 28f, dark, sans, s)
                fit(c, tx(b(d[0]), d[1] - 20 + d[2]), s * bRow1X[i], offY + 901f * s, 98f, 28f, dark, sans, s)
            }
            for ((i, d) in bRow2.withIndex()) {
                fit(c, tx(b(d[0]), d[1]), s * bRow2X[i], offY + 1177f * s, 98f, 28f, white, sans, s)
                fit(c, tx(b(d[0]), d[1] - 20), s * bRow2X[i], offY + 1225f * s, 98f, 28f, dark, sans, s)
                fit(c, tx(b(d[0]), d[1] - 20 + d[2]), s * bRow2X[i], offY + 1272f * s, 98f, 28f, dark, sans, s)
            }
        }
    }

    // ------------------------------------------------------------ logo & clock
    private fun mosqueIcon(c: Canvas, cx: Float, cy: Float, s: Float, col: Int) {
        p.reset(); p.isAntiAlias = true; p.color = col
        c.drawArc(RectF(cx - 40 * s, cy - 48 * s, cx + 40 * s, cy + 32 * s), 180f, 180f, true, p)
        c.drawRect(cx - 40 * s, cy - 8 * s, cx + 40 * s, cy + 30 * s, p)
        for (k in intArrayOf(-1, 1)) {
            val mx = cx + k * 62 * s
            c.drawRect(mx - 8 * s, cy - 40 * s, mx + 8 * s, cy + 30 * s, p)
            val tip = Path().apply { moveTo(mx - 10 * s, cy - 40 * s); lineTo(mx, cy - 66 * s); lineTo(mx + 10 * s, cy - 40 * s); close() }
            c.drawPath(tip, p)
        }
    }

    private fun logo(c: Canvas, cx: Float, cy: Float, s: Float) {
        val r = RectF(cx - 190f * s, cy - 120f * s, cx + 190f * s, cy + 130f * s)
        fillRR(c, r, 70f, Color.argb(240, 11, 61, 42)); strokeRR(c, r, 70f, gold, 5f)
        mosqueIcon(c, cx, cy - 60f * s, 1.15f * s, gold)
        txt(c, "MSF", cx, cy + 22f * s, 100f * s, gold, serif)
        ur(c, "نماز", cx, cy + 92f * s, 56f * s, gold)
    }

    private fun clock(c: Canvas, cx: Float, cy: Float, r: Float, face: Int, now: Long) {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val h = cal.get(Calendar.HOUR) + cal.get(Calendar.MINUTE) / 60f
        val m = cal.get(Calendar.MINUTE) + cal.get(Calendar.SECOND) / 60f
        val sec = cal.get(Calendar.SECOND).toFloat()
        val faceCol = when (face) { 0 -> cream; 1 -> Color.parseColor("#0E4A31"); else -> Color.parseColor("#0C1B3D") }
        val ink = if (face == 0) Color.parseColor("#14281E") else Color.parseColor("#F1D58A")
        // shadow + outer gold ring
        p.reset(); p.isAntiAlias = true; p.color = Color.argb(110, 0, 0, 0)
        c.drawCircle(cx + 6f, cy + 12f, r + 8f, p)
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, intArrayOf(Color.parseColor("#FFE9A0"), gold, Color.parseColor("#8A6416")), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
        // green ornamental band
        p.reset(); p.isAntiAlias = true; p.color = deepGreen
        c.drawCircle(cx, cy, r * 0.93f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = gold
        for (i in 0 until 48) {
            val a = i * 7.5 * PI / 180.0
            val x1 = cx + cos(a).toFloat() * r * 0.90f; val y1 = cy + sin(a).toFloat() * r * 0.90f
            c.drawCircle(x1, y1, r * 0.018f, p)
        }
        p.reset(); p.isAntiAlias = true; p.color = faceCol
        c.drawCircle(cx, cy, r * 0.84f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = gold
        c.drawCircle(cx, cy, r * 0.84f, p)
        // ticks
        for (i in 0 until 60) {
            val a = (i * 6 - 90) * PI / 180.0
            val big = i % 5 == 0
            val r1 = r * 0.84f - 6f; val r2 = r * (if (big) 0.72f else 0.78f)
            p.reset(); p.isAntiAlias = true; p.color = ink; p.strokeWidth = if (big) 5f else 2f
            c.drawLine(cx + cos(a).toFloat() * r1, cy + sin(a).toFloat() * r1, cx + cos(a).toFloat() * r2, cy + sin(a).toFloat() * r2, p)
        }
        // numerals
        for (n in 1..12) {
            val a = (n * 30 - 90) * PI / 180.0
            txt(c, n.toString(), cx + cos(a).toFloat() * r * 0.60f, cy + sin(a).toFloat() * r * 0.60f, r * 0.17f, ink, serif)
        }
        // brand
        mosqueIcon(c, cx, cy - r * 0.34f, r * 0.0045f, ink)
        txt(c, "MSF", cx, cy - r * 0.20f, r * 0.12f, ink, serif)
        // hands
        fun hand(angleDeg: Float, len: Float, w: Float, col: Int, tail: Float = 0f) {
            val a = (angleDeg - 90f) * PI / 180.0
            p.reset(); p.isAntiAlias = true; p.color = col; p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND
            c.drawLine(cx - cos(a).toFloat() * tail, cy - sin(a).toFloat() * tail, cx + cos(a).toFloat() * len, cy + sin(a).toFloat() * len, p)
        }
        val handCol = if (face == 0) Color.parseColor("#0B3D2A") else Color.parseColor("#F4DFA0")
        hand(h * 30f, r * 0.45f, r * 0.045f, handCol)
        hand(m * 6f, r * 0.68f, r * 0.032f, handCol)
        if (showSec) hand(sec * 6f, r * 0.74f, r * 0.012f, Color.parseColor("#E0A800"), r * 0.16f)
        p.reset(); p.isAntiAlias = true; p.color = Color.parseColor("#E0A800"); c.drawCircle(cx, cy, r * 0.035f, p)
    }

    // ------------------------------------------------------------ cards
    private class Item(val name: String, val min: Int, val sub: String, val next: Boolean = false)

    private fun card(c: Canvas, r: RectF, it: Item, style: Int, nameSize: Float, timeSize: Float) {
        val dark = style != 1
        val bg = when (style) { 0 -> Color.argb(235, 11, 61, 42); 1 -> Color.argb(245, 246, 237, 210); else -> Color.argb(225, 12, 27, 61) }
        fillRR(c, r, 26f, bg)
        strokeRR(c, r, 26f, if (it.next) Color.parseColor("#7CD65B") else gold, if (it.next) 6f else 3f)
        val txtCol = if (dark) Color.WHITE else Color.parseColor("#0B3D2A")
        ur(c, it.name, r.centerX(), r.top + r.height() * 0.27f, nameSize, txtCol, r.width() - 16f)
        val pill = RectF(r.left + 10f, r.top + r.height() * 0.46f, r.right - 10f, r.top + r.height() * 0.46f + timeSize * 1.7f)
        fillRR(c, pill, pill.height() / 2f, if (style == 1) deepGreen else Color.argb(255, 8, 40, 28))
        txt(c, p12(it.min), pill.centerX(), pill.centerY(), timeSize, Color.WHITE, sans, Paint.Align.CENTER, pill.width() - 14f)
        if (it.sub.isNotEmpty()) ur(c, it.sub, r.centerX(), r.bottom - r.height() * 0.15f, nameSize * 0.62f, if (dark) Color.parseColor("#E8D9A0") else Color.parseColor("#3C5A48"), r.width() - 16f)
    }

    private fun grid(c: Canvas, items: List<Item>, cols: Int, x0: Float, x1: Float, y0: Float, y1: Float, style: Int) {
        val rows = (items.size + cols - 1) / cols
        val gap = 12f
        val w = (x1 - x0 - gap * (cols - 1)) / cols
        val h = min(min(w * 1.35f, 300f), (y1 - y0 - gap * (rows - 1)) / rows)
        val tot = h * rows + gap * (rows - 1)
        val ys = y0 + (y1 - y0 - tot) / 2f
        for ((i, it) in items.withIndex()) {
            val rr = i / cols; val cc = i % cols
            val rc = RectF(x0 + cc * (w + gap), ys + rr * (h + gap), x0 + cc * (w + gap) + w, ys + rr * (h + gap) + h)
            card(c, rc, it, style, min(46f, w * 0.30f), min(34f, w * 0.17f))
        }
    }

    private fun allItems(t: JSONObject?, next: Int): Map<String, Item> {
        fun it(n: String, i: Int, sub: String, nx: Boolean = false) = Item(n, tm(t, i), sub, nx)
        val m = LinkedHashMap<String, Item>()
        m["fajr"] = it("فجر", 1, "صبح کی نماز", next == 0)
        m["ishraq"] = it("اشراق", 3, "اشراق کی نماز")
        m["chasht"] = it("چاشت", 4, "چاشت کی نماز")
        m["zuhr"] = it("ظہر", 6, "دوپہر کی نماز", next == 1)
        m["asr1"] = it("عصر اول", 7, "عصر کی پہلی نماز")
        m["asr2"] = it("عصر ثانی", 8, "عصر کی دوسری نماز")
        m["asr"] = it("عصر", 11, "عصر کی نماز", next == 2)
        m["maghrib"] = it("مغرب", 9, "مغرب کی نماز", next == 3)
        m["isha"] = it("عشاء", 10, "عشاء کی نماز", next == 4)
        m["sehri"] = it("سحری ختم", 0, "سحری کا اختتام")
        m["zawal"] = it("زوال", 5, "زوال کا وقت")
        m["sunrise"] = it("طلوع", 2, "سورج نکلنے کا وقت")
        return m
    }

    // ------------------------------------------------------------ date info
    private fun gregText(cal: Calendar) = "${cal.get(Calendar.DAY_OF_MONTH)} ${urduMonths[cal.get(Calendar.MONTH)]} ${cal.get(Calendar.YEAR)}"
    private fun dayName(cal: Calendar) = urduDays[cal.get(Calendar.DAY_OF_WEEK) - 1]
    private fun cityName() = data?.optString("city", "") ?: ""

    private fun infoCard(c: Canvas, r: RectF, title: String, value: String, style: Int) {
        val dark = style != 1
        fillRR(c, r, 24f, if (dark) Color.argb(235, 11, 61, 42) else Color.argb(245, 246, 237, 210))
        strokeRR(c, r, 24f, gold, 3f)
        ur(c, title, r.centerX(), r.top + r.height() * 0.26f, 34f, gold, r.width() - 14f)
        ur(c, value, r.centerX(), r.top + r.height() * 0.68f, 38f, if (dark) Color.WHITE else deepGreen, r.width() - 18f)
    }

    private fun digital(c: Canvas, cx: Float, cy: Float, now: Long) {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val h = if (h24 % 12 == 0) 12 else h24 % 12
        val s = "%02d:%02d %s".format(h, cal.get(Calendar.MINUTE), if (h24 >= 12) "PM" else "AM")
        val r = RectF(cx - 260f, cy - 55f, cx + 260f, cy + 55f)
        fillRR(c, r, 50f, Color.argb(235, 11, 61, 42)); strokeRR(c, r, 50f, gold, 4f)
        ur(c, "موجودہ وقت", cx + 150f, cy - 22f, 30f, gold)
        txt(c, s, cx - 25f, cy + 14f, 52f, Color.WHITE, sans, Paint.Align.CENTER, 300f)
    }

    private fun sectionBar(c: Canvas, cx: Float, y: Float, w: Float, title: String) {
        val r = RectF(cx - w / 2f, y - 38f, cx + w / 2f, y + 38f)
        fillRR(c, r, 38f, Color.argb(235, 11, 61, 42)); strokeRR(c, r, 38f, gold, 3f)
        ur(c, title, cx, y, 46f, Color.WHITE, w - 40f)
    }

    // ------------------------------------------------------------ layouts
    private fun datesAround(c: Canvas, vw: Float, cy: Float, r: Float, th: WpTheme, cal: Calendar, day: JSONObject?) {
        val cw = 290f; val ch = 150f
        val lx = 20f; val rx = vw - 20f - cw
        infoCard(c, RectF(lx, cy - r * 0.9f, lx + cw, cy - r * 0.9f + ch), "اسلامی تاریخ", day?.optString("hs", "") ?: "--", th.card)
        infoCard(c, RectF(lx, cy + r * 0.9f - ch, lx + cw, cy + r * 0.9f), "شہر", cityName(), th.card)
        infoCard(c, RectF(rx, cy - r * 0.9f, rx + cw, cy - r * 0.9f + ch), "عیسوی تاریخ", gregText(cal), th.card)
        infoCard(c, RectF(rx, cy + r * 0.9f - ch, rx + cw, cy + r * 0.9f), "آج کا دن", dayName(cal), th.card)
    }

    private fun layoutGrid(c: Canvas, vw: Float, vh: Float, th: WpTheme, day: JSONObject?, cal: Calendar, nowMin: Int, now: Long, top: Float, bottom: Float) {
        val r = 215f
        val cy = top + r + 10f
        clock(c, vw / 2f, cy, r, th.face, now)
        if (th.dates) datesAround(c, vw, cy, r, th, cal, day)
        digital(c, vw / 2f, cy + r + 85f, now)
        val hy = cy + r + 190f
        sectionBar(c, vw / 2f, hy, 640f, "نمازوں کے اوقات")
        val m = allItems(day, nextPrayer(day, nowMin))
        val keys = if (th.layout == 0) listOf("fajr", "ishraq", "zuhr", "asr1", "asr2", "maghrib", "isha", "chasht", "sehri", "zawal")
        else listOf("fajr", "ishraq", "zuhr", "asr1", "asr2", "maghrib", "isha", "chasht", "sehri", "zawal", "sunrise", "asr")
        val items = keys.mapNotNull { m[it] }
        grid(c, items, if (th.layout == 0) 5 else 6, 18f, vw - 18f, hy + 60f, bottom, th.card)
    }

    private fun layoutList(c: Canvas, vw: Float, vh: Float, th: WpTheme, day: JSONObject?, cal: Calendar, nowMin: Int, now: Long, top: Float, bottom: Float) {
        val r = 205f
        val cy = top + r + 10f
        clock(c, vw / 2f, cy, r, th.face, now)
        val nx = nextPrayer(day, nowMin)
        val datePill = RectF(vw / 2f - 330f, cy + r + 25f, vw / 2f + 330f, cy + r + 105f)
        fillRR(c, datePill, 40f, Color.argb(235, 11, 61, 42)); strokeRR(c, datePill, 40f, gold, 3f)
        ur(c, dayName(cal) + "، " + gregText(cal) + "  |  " + (day?.optString("hs", "") ?: ""), vw / 2f, datePill.centerY(), 34f, Color.WHITE, 620f)
        val y0 = datePill.bottom + 26f
        sectionBar(c, vw / 2f, y0 + 38f, 640f, "نمازوں کے اوقات")
        val st = day?.optJSONArray("st")
        val names = listOf("fajr", "ishraq", "chasht", "zuhr", "asr", "maghrib", "isha")
        val m = allItems(day, nx)
        val panelTop = y0 + 100f
        val avail = bottom - panelTop - 20f
        val rowH = min(105f, avail / (names.size + 2))
        val fiveMap = mapOf("fajr" to 0, "zuhr" to 1, "asr" to 2, "maghrib" to 3, "isha" to 4)
        for ((i, k) in names.withIndex()) {
            val it = m[k] ?: continue
            val rc = RectF(60f, panelTop + i * (rowH + 8f), vw - 60f, panelTop + i * (rowH + 8f) + rowH)
            fillRR(c, rc, rowH / 2.4f, Color.argb(235, 11, 61, 42))
            strokeRR(c, rc, rowH / 2.4f, if (it.next) Color.parseColor("#7CD65B") else gold, if (it.next) 5f else 2.5f)
            ur(c, it.name, rc.right - 150f, rc.centerY(), rowH * 0.5f, Color.WHITE)
            txt(c, p12(it.min), vw / 2f, rc.centerY(), rowH * 0.42f, Color.WHITE)
            val fi = fiveMap[k]
            val label: String; val col: Int
            if (fi != null) {
                val s = st?.optInt(fi, 0) ?: 0
                label = if (s == 0) (if (it.min in 0..nowMin) "وقت ہو گیا" else "باقی") else stLabels[s.coerceIn(0, 3)]
                col = when (s) { 1, 2 -> Color.parseColor("#2E9E57"); 3 -> Color.parseColor("#D32F2F"); else -> Color.parseColor("#5F6B66") }
            } else { label = "نفل"; col = Color.parseColor("#5F6B66") }
            val chip = RectF(rc.left + 20f, rc.centerY() - rowH * 0.3f, rc.left + 210f, rc.centerY() + rowH * 0.3f)
            fillRR(c, chip, chip.height() / 2f, col)
            ur(c, label, chip.centerX(), chip.centerY(), rowH * 0.36f, Color.WHITE, chip.width() - 16f)
        }
        // sehri / iftar strip
        val sy = panelTop + names.size * (rowH + 8f) + 6f
        val a = RectF(60f, sy, vw / 2f - 6f, sy + rowH * 1.4f)
        val b = RectF(vw / 2f + 6f, sy, vw - 60f, sy + rowH * 1.4f)
        infoCard(c, a, "سحری ختم", p12(tm(day, 0)), 0)
        infoCard(c, b, "افطاری", p12(tm(day, 9)), 0)
    }

    private fun layoutSide(c: Canvas, vw: Float, vh: Float, th: WpTheme, day: JSONObject?, cal: Calendar, nowMin: Int, now: Long, top: Float, bottom: Float) {
        val r = 205f
        val cy = top + 360f
        clock(c, vw / 2f, cy, r, th.face, now)
        val m = allItems(day, nextPrayer(day, nowMin))
        val left = listOf("ishraq", "zuhr", "maghrib").mapNotNull { m[it] }
        val right = listOf("fajr", "asr", "isha").mapNotNull { m[it] }
        val cw = 270f; val ch = 215f; val gap = 14f
        for (i in 0 until 3) {
            val y = cy + (i - 1) * (ch + gap)
            card(c, RectF(20f, y - ch / 2f, 20f + cw, y + ch / 2f), left[i], th.card, 44f, 30f)
            card(c, RectF(vw - 20f - cw, y - ch / 2f, vw - 20f, y + ch / 2f), right[i], th.card, 44f, 30f)
        }
        digital(c, vw / 2f, cy + 1.5f * ch + 20f + 70f, now)
        val y1 = cy + 1.5f * ch + 20f + 150f
        val bot = listOf("chasht", "sehri", "asr2").mapNotNull { m[it] }
        grid(c, bot, 3, 20f, vw - 20f, y1, min(bottom, y1 + 300f), th.card)
        if (th.dates) {
            ur(c, dayName(cal) + "  •  " + gregText(cal) + "  •  " + (day?.optString("hs", "") ?: ""), vw / 2f, bottom - 5f, 34f, Color.WHITE, vw - 80f)
        }
    }

    private fun layoutRow(c: Canvas, vw: Float, vh: Float, th: WpTheme, day: JSONObject?, cal: Calendar, nowMin: Int, now: Long, top: Float, bottom: Float) {
        val r = 285f
        val cy = top + r + 10f
        clock(c, vw / 2f, cy, r, th.face, now)
        val dy = cy + r + 60f
        val w = 480f
        val l = RectF(vw / 2f - w - 8f, dy - 45f, vw / 2f - 8f, dy + 45f)
        val rr = RectF(vw / 2f + 8f, dy - 45f, vw / 2f + w + 8f, dy + 45f)
        for ((rc, s) in listOf(l to (day?.optString("hs", "") ?: ""), rr to gregText(cal))) {
            fillRR(c, rc, 45f, Color.argb(235, 11, 61, 42)); strokeRR(c, rc, 45f, gold, 3f)
            ur(c, s, rc.centerX(), rc.centerY(), 36f, Color.WHITE, rc.width() - 30f)
        }
        val m = allItems(day, nextPrayer(day, nowMin))
        val seven = listOf("fajr", "ishraq", "zuhr", "asr", "maghrib", "isha", "chasht").mapNotNull { m[it] }
        val y0 = dy + 80f
        val ch = min(250f, (bottom - y0) * 0.5f)
        grid(c, seven, 7, 8f, vw - 8f, y0, y0 + ch, th.card)
        val y1 = y0 + ch + 20f
        val a = RectF(30f, y1, vw / 2f - 10f, min(bottom, y1 + 190f))
        val b = RectF(vw / 2f + 10f, y1, vw - 30f, min(bottom, y1 + 190f))
        infoCard(c, a, "سحری کا وقت (ختم)", p12(tm(day, 0)), th.card)
        infoCard(c, b, "افطاری کا وقت", p12(tm(day, 9)), th.card)
    }

    private fun layoutClockOnly(c: Canvas, vw: Float, vh: Float, th: WpTheme, day: JSONObject?, cal: Calendar, nowMin: Int, now: Long, top: Float, bottom: Float) {
        val r = 390f
        val cy = top + r + 40f
        clock(c, vw / 2f, cy, r, th.face, now)
        val nx = nextPrayer(day, nowMin)
        val m = tm(day, fiveIdx[nx])
        val pill = RectF(vw / 2f - 400f, cy + r + 60f, vw / 2f + 400f, cy + r + 200f)
        fillRR(c, pill, 60f, Color.argb(235, 11, 61, 42)); strokeRR(c, pill, 60f, gold, 4f)
        ur(c, "اگلی نماز: " + fiveNames[nx], vw / 2f, pill.top + 48f, 46f, gold, 740f)
        txt(c, p12(m), vw / 2f, pill.bottom - 44f, 54f, Color.WHITE)
        ur(c, dayName(cal) + "، " + gregText(cal) + "  |  " + (day?.optString("hs", "") ?: ""), vw / 2f, pill.bottom + 60f, 38f, Color.WHITE, vw - 60f)
    }
}
