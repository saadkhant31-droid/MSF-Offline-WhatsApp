import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'app_settings.dart';
import 'location_data.dart';
import 'prayer_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  AppSettings get s => appSettings;
  String _cacheSize = '...';

  @override
  void initState() {
    super.initState();
    _calcCache();
  }

  Future<int> _dirSize(Directory d) async {
    var total = 0;
    try {
      if (!await d.exists()) return 0;
      await for (final e in d.list(recursive: true, followLinks: false)) {
        if (e is File) {
          try {
            total += await e.length();
          } catch (_) {}
        }
      }
    } catch (_) {}
    return total;
  }

  Future<void> _calcCache() async {
    try {
      final bytes = await _dirSize(await getTemporaryDirectory());
      if (!mounted) return;
      setState(() => _cacheSize = bytes < 1024 * 1024
          ? '${(bytes / 1024).toStringAsFixed(0)} KB'
          : '${(bytes / 1048576).toStringAsFixed(1)} MB');
    } catch (_) {
      if (mounted) setState(() => _cacheSize = '-');
    }
  }

  Future<void> _clearCache() async {
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    try {
      final dir = await getTemporaryDirectory();
      if (await dir.exists()) {
        await for (final e in dir.list()) {
          try {
            await e.delete(recursive: true);
          } catch (_) {}
        }
      }
    } catch (_) {}
    await _calcCache();
  }

  static const gold = Color(0xFFE6B94D);
  static const darkGreen = Color(0xFF0B3D2E);

  static const adhanSounds = {
    'urdu_male': 'اردو (مرد)',
    'makkah': 'عربی (مکہ)',
    'madinah': 'عربی (مدینہ)',
    'silent': 'خاموش',
  };
  static const languages = {'ur': 'اردو', 'en': 'English', 'ar': 'العربية'};
  static const themes = {'green': 'سبز (ڈیفالٹ)', 'dark': 'ڈارک'};
  static final fontSizes = <double, String>{
    14.0: 'چھوٹا (14)',
    16.0: 'درمیانہ (16)',
    18.0: 'بڑا (18)',
    20.0: 'بہت بڑا (20)',
    24.0: 'انتہائی بڑا (24)',
  };
  static const prayerNames = {
    'fajr': 'فجر',
    'dhuhr': 'ظہر',
    'asr': 'عصر',
    'maghrib': 'مغرب',
    'isha': 'عشاء',
  };

  // ---------- مددگار ----------
  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg)));

  Future<T?> _pick<T>(String title, Map<T, String> options, T current) {
    return showModalBottomSheet<T>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(title,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),
            ),
            Flexible(
              child: ListView(
                shrinkWrap: true,
                children: options.entries
                    .map((e) => ListTile(
                          title: Text(e.value),
                          trailing: e.key == current
                              ? const Icon(Icons.check_circle,
                                  color: Color(0xFF0B6E4F))
                              : null,
                          onTap: () => Navigator.pop(ctx, e.key),
                        ))
                    .toList(),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  static const _lightGreen = Color(0xFFDCEBDD);

  bool get _dark => Theme.of(context).brightness == Brightness.dark;
  Color get _ic =>
      _dark ? Theme.of(context).colorScheme.primary : darkGreen;

  Widget _section(IconData icon, String title, List<Widget> children) {
    final cs = Theme.of(context).colorScheme;
    final rows = <Widget>[];
    for (var i = 0; i < children.length; i++) {
      if (i > 0) rows.add(Divider(height: 1, color: cs.outlineVariant));
      rows.add(children[i]);
    }
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      decoration: BoxDecoration(
        color: _dark ? cs.surface : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: _dark ? cs.outlineVariant : const Color(0xFFCFE0D2)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(children: [
        Container(
          color: _dark ? cs.primaryContainer : _lightGreen,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(children: [
            Icon(icon, color: _ic),
            const SizedBox(width: 10),
            Text(title,
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.bold)),
          ]),
        ),
        ...rows,
      ]),
    );
  }

  Widget _tile(IconData icon, String title,
      {String? value, String? subtitle, Widget? trailing, VoidCallback? onTap}) {
    return ListTile(
      dense: true,
      leading: Icon(icon, color: _ic),
      title: Text(title),
      subtitle: subtitle == null ? null : Text(subtitle),
      trailing: trailing ??
          Row(mainAxisSize: MainAxisSize.min, children: [
            if (value != null)
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 170),
                child: Text(value,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13)),
              ),
            const Icon(Icons.chevron_right),
          ]),
      onTap: onTap,
    );
  }

  Widget _switch(IconData icon, String title, bool value,
      ValueChanged<bool> onChanged,
      {String? subtitle}) {
    return ListTile(
      dense: true,
      leading: Icon(icon, color: _ic),
      title: Text(title),
      subtitle: subtitle == null ? null : Text(subtitle),
      trailing: Switch(value: value, onChanged: onChanged),
    );
  }

  // ---------- مقام ----------
  Future<void> _pickCountry() async {
    final v = await _pick<String>('ملک منتخب کریں',
        {for (final k in locationData.keys) k: k}, s.country);
    if (v == null) return;
    final province = locationData[v]!.keys.first;
    final city = locationData[v]![province]!.first;
    s.update(() {
      s.country = v;
      s.province = province;
      s.city = city.name;
      s.latitude = city.lat;
      s.longitude = city.lng;
      s.autoGps = false;
    });
  }

  Future<void> _pickProvince() async {
    final provinces = locationData[s.country]!.keys;
    final v = await _pick<String>(
        'صوبہ منتخب کریں', {for (final k in provinces) k: k}, s.province);
    if (v == null) return;
    final city = locationData[s.country]![v]!.first;
    s.update(() {
      s.province = v;
      s.city = city.name;
      s.latitude = city.lat;
      s.longitude = city.lng;
      s.autoGps = false;
    });
  }

  Future<void> _pickCity() async {
    final cities = locationData[s.country]![s.province]!;
    final v = await _pick<String>('شہر منتخب کریں',
        {for (final c in cities) c.name: c.name}, s.city);
    if (v == null) return;
    final c = cities.firstWhere((c) => c.name == v);
    s.update(() {
      s.city = c.name;
      s.latitude = c.lat;
      s.longitude = c.lng;
      s.autoGps = false;
    });
  }

  Future<void> _toggleGps(bool on) async {
    if (!on) {
      s.update(() => s.autoGps = false);
      return;
    }
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        _snack('براہِ کرم موبائل کی لوکیشن آن کریں');
        return;
      }
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        _snack('مقام کی اجازت نہیں ملی۔ شہر دستی منتخب کریں');
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      s.update(() {
        s.autoGps = true;
        s.latitude = pos.latitude;
        s.longitude = pos.longitude;
        s.city = 'موجودہ مقام';
      });
    } catch (_) {
      _snack('مقام معلوم نہیں ہو سکا');
    }
  }

  // ---------- نوٹیفکیشن ----------
  void _openNotificationSettings() {
    showModalBottomSheet(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              SwitchListTile(
                title: const Text('تمام نوٹیفکیشنز'),
                value: s.notificationsOn,
                onChanged: (v) {
                  s.update(() => s.notificationsOn = v);
                  setSheet(() {});
                },
              ),
              const Divider(),
              ...prayerNames.entries.map((e) => SwitchListTile(
                    title: Text(e.value),
                    value: s.notifyPrayers.contains(e.key),
                    onChanged: s.notificationsOn
                        ? (v) {
                            s.update(() => v
                                ? s.notifyPrayers.add(e.key)
                                : s.notifyPrayers.remove(e.key));
                            setSheet(() {});
                          }
                        : null,
                  )),
            ]),
          ),
        ),
      ),
    );
  }

  void _info(String title, String body) {
    showDialog(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(title),
          content: Text(body),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('ٹھیک ہے'))
          ],
        ),
      ),
    );
  }

  Future<void> _confirmClearCache() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('کیشے صاف کریں'),
          content: const Text('عارضی فائلیں ختم ہو جائیں گی۔ آپ کی سیٹنگز محفوظ رہیں گی۔'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('منسوخ')),
            TextButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('صاف کریں')),
          ],
        ),
      ),
    );
    if (ok == true) {
      await _clearCache();
      _snack('کیشے صاف ہو گیا');
    }
  }

  // ---------- اسکرین ----------
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) => Directionality(
        textDirection: TextDirection.ltr,
        child: Scaffold(
        body: Column(children: [
          _header(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.only(top: 12, bottom: 12),
              children: [
                _versionCard(),
                _section(Icons.location_on, 'مقام کی ترتیبات', [
                  _tile(Icons.public, 'ملک منتخب کریں',
                      value: s.country, onTap: _pickCountry),
                  _tile(Icons.map, 'صوبہ منتخب کریں',
                      value: s.province, onTap: _pickProvince),
                  _tile(Icons.location_city, 'شہر منتخب کریں',
                      value: s.city, onTap: _pickCity),
                  _switch(Icons.my_location, 'مقام کی خودکار شناخت (GPS)',
                      s.autoGps, _toggleGps),
                ]),
                _section(Icons.mosque, 'نماز کے اوقات کی ترتیبات', [
                  _tile(Icons.calculate, 'فقہی مسلک منتخب کریں',
                      value: s.hanafi ? 'حنفی' : 'شافعی', onTap: () async {
                    final v = await _pick<bool>('فقہی مسلک',
                        {true: 'حنفی', false: 'شافعی'}, s.hanafi);
                    if (v != null) s.update(() => s.hanafi = v);
                  }),
                  _tile(Icons.event_note, 'اوقاتِ نماز کا حسابی طریقہ',
                      value: PrayerService.methodLabels[s.method],
                      onTap: () async {
                    final v = await _pick<String>('حسابی طریقہ',
                        PrayerService.methodLabels, s.method);
                    if (v != null) s.update(() => s.method = v);
                  }),
                  _tile(Icons.access_time, 'وقت کی فارمیٹ',
                      value: s.use24h ? '24 گھنٹے' : '12 گھنٹے (AM/PM)',
                      onTap: () async {
                    final v = await _pick<bool>('وقت کی فارمیٹ',
                        {false: '12 گھنٹے (AM/PM)', true: '24 گھنٹے'}, s.use24h);
                    if (v != null) s.update(() => s.use24h = v);
                  }),
                  _tile(Icons.edit_calendar, 'ہجری تاریخ میں تبدیلی',
                      value: '${s.hijriAdjust} دن', onTap: () async {
                    final v = await _pick<int>('ہجری تاریخ',
                        {-2: '2 دن پیچھے', -1: '1 دن پیچھے', 0: 'کوئی تبدیلی نہیں', 1: '1 دن آگے', 2: '2 دن آگے'},
                        s.hijriAdjust);
                    if (v != null) s.update(() => s.hijriAdjust = v);
                  }),
                  _switch(Icons.notifications_active, 'نماز کی اطلاع (اذان)',
                      s.adhanEnabled,
                      (v) => s.update(() => s.adhanEnabled = v)),
                  _tile(Icons.volume_up, 'اذان کی آواز',
                      value: adhanSounds[s.adhanSound], onTap: () async {
                    final v = await _pick<String>(
                        'اذان کی آواز', adhanSounds, s.adhanSound);
                    if (v != null) s.update(() => s.adhanSound = v);
                  }),
                ]),
                _section(Icons.desktop_windows, 'ڈسپلے اور ایپ کی ترتیبات', [
                  _tile(Icons.translate, 'زبان منتخب کریں',
                      value: languages[s.language], onTap: () async {
                    final v = await _pick<String>(
                        'زبان منتخب کریں', languages, s.language);
                    if (v != null) {
                      s.update(() => s.language = v);
                      if (v != 'ur') _snack('دوسری زبانیں جلد شامل کی جائیں گی');
                    }
                  }),
                  _tile(Icons.palette, 'تھیم',
                      value: themes[s.theme], onTap: () async {
                    final v = await _pick<String>('تھیم', themes, s.theme);
                    if (v != null) s.update(() => s.theme = v);
                  }),
                  _tile(Icons.format_size, 'فونٹ سائز',
                      value: fontSizes[s.fontSize] ?? '${s.fontSize}',
                      onTap: () async {
                    final v = await _pick<double>(
                        'فونٹ سائز', fontSizes, s.fontSize);
                    if (v != null) s.update(() => s.fontSize = v);
                  }),
                  _switch(Icons.vibration, 'وائبریشن', s.vibration, (v) {
                    s.update(() => s.vibration = v);
                    if (v) HapticFeedback.mediumImpact();
                  }),
                  _switch(Icons.autorenew, 'بیک گراؤنڈ میں چلنا', s.background,
                      (v) => s.update(() => s.background = v),
                      subtitle: 'ایپ کو بیک گراؤنڈ میں چلانے کی اجازت دیں'),
                ]),
                _section(Icons.cloud, 'ڈیٹا اور اسٹوریج', [
                  _tile(Icons.storage, 'کیشے صاف کریں',
                      value: _cacheSize, onTap: _confirmClearCache),
                  _tile(Icons.download, 'آف لائن ڈیٹا',
                      value: 'فعال',
                      onTap: () => _info('آف لائن ڈیٹا',
                          'نماز کے اوقات، قبلہ اور ہجری تاریخ کا حساب آپ کے موبائل پر ہی ہوتا ہے، اس لیے انٹرنیٹ کے بغیر بھی یہ سب چلتا ہے۔ شہروں کی فہرست ایپ کے اندر موجود ہے۔')),
                ]),
                _section(Icons.notifications, 'نوٹیفکیشن سیٹنگز', [
                  _tile(Icons.notifications_active, 'تمام نوٹیفکیشنز',
                      value: s.notificationsOn ? 'آن' : 'آف',
                      onTap: _openNotificationSettings),
                ]),
                _section(Icons.info, 'ایپ کے بارے میں', [
                  _tile(Icons.description, 'رازداری کی پالیسی',
                      onTap: () => _info('رازداری کی پالیسی',
                          'یہ ایپ آپ کا مقام صرف نماز کے اوقات اور قبلہ کے حساب کے لیے آپ کے موبائل پر استعمال کرتی ہے۔ آپ کا ڈیٹا کسی کو نہیں بھیجا جاتا۔')),
                  _tile(Icons.shield, 'شرائط و ضوابط',
                      onTap: () => _info('شرائط و ضوابط',
                          'نماز کے اوقات حسابی طریقوں پر مبنی ہیں۔ احتیاط کے لیے اپنے علاقے کی مسجد یا مستند ادارے کے اوقات سے بھی ملا لیں۔')),
                  _tile(Icons.mail, 'ہم سے رابطہ کریں',
                      onTap: () => _info('ہم سے رابطہ کریں',
                          'رابطے کی تفصیل یہاں شامل کی جائے گی۔')),
                ]),
              ],
            ),
          ),
        ]),
      )),
    );
  }

  Widget _header() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
            colors: [Color(0xFF082B20), Color(0xFF0B4A33)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight),
        border: Border(bottom: BorderSide(color: gold, width: 2)),
      ),
      padding: EdgeInsets.fromLTRB(
          8, MediaQuery.of(context).padding.top + 8, 16, 12),
      child: Row(children: [
        if (Navigator.of(context).canPop())
          IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white, size: 28),
            onPressed: () => Navigator.pop(context),
          )
        else
          const SizedBox(width: 8),
        Container(
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: gold, width: 2)),
          child: ClipOval(
              child: Image.asset('assets/logo.png', width: 54, height: 54)),
        ),
        const SizedBox(width: 10),
        const Expanded(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('MSF Islamic App',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 19,
                        fontWeight: FontWeight.bold)),
                Text('اللہ کی رضا، ہماری کوشش',
                    style: TextStyle(color: gold, fontSize: 14)),
              ]),
        ),
        const Text('سیٹنگز',
            style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold)),
        const SizedBox(width: 8),
        const Icon(Icons.settings, color: Colors.white, size: 30),
      ]),
    );
  }

  Widget _versionCard() {
    final cs = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _dark ? cs.surface : const Color(0xFFF1F6EE),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: gold.withOpacity(0.7)),
      ),
      child: Row(children: [
        Container(
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: gold, width: 3)),
          child: ClipOval(
              child: Image.asset('assets/logo.png', width: 80, height: 80)),
        ),
        const SizedBox(width: 12),
        Expanded(
          flex: 5,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('MSF Islamic App',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Text('Version 1.0.0'),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: const Color(0xFF0B8A4F),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.check_circle, color: Colors.white, size: 18),
                SizedBox(width: 6),
                Text('تازہ ترین ورژن',
                    style: TextStyle(color: Colors.white, fontSize: 13)),
              ]),
            ),
          ]),
        ),
        Container(
            width: 1,
            height: 64,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            color: gold),
        const Expanded(
          flex: 4,
          child: Text('اسلامی زندگی کے لیے بہترین سہولتیں',
              textAlign: TextAlign.center, style: TextStyle(fontSize: 15)),
        ),
      ]),
    );
  }
}
