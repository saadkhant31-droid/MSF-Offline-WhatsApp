import 'dart:async';
import 'package:flutter/material.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'app_settings.dart';
import 'location_picker.dart';
import 'prayer_service.dart';
import 'qibla_math.dart';
import 'settings_screen.dart';
import 'wallpaper_screen.dart';

const _green = Color(0xFF0B3D2E);
const _greenMid = Color(0xFF0B6E4F);
const _gold = Color(0xFFE6B94D);

class HomeScreen extends StatefulWidget {
  /// نچلی بار کے ٹیب پر جانے کے لیے (0 ہوم، 1 اوقات، 2 قبلہ، 3 کیلنڈر، 4 کتابیں، 5 مزید)
  final void Function(int) onNavigate;
  const HomeScreen({super.key, required this.onNavigate});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Timer _timer;
  DateTime now = DateTime.now();
  AppSettings get s => appSettings;

  static const weekdays = [
    'پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ', 'اتوار'
  ];
  static const months = [
    'جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون',
    'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'
  ];

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  String _t(DateTime t) =>
      DateFormat(s.use24h ? 'HH:mm' : 'hh:mm a').format(t);

  String _countdown(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
  }

  void _soon(String what) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text('$what جلد شامل ہوگا')));

  void _openSettings() => Navigator.of(context)
      .push(MaterialPageRoute(builder: (_) => const SettingsScreen()));

  // ================= بناوٹ =================
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return ListenableBuilder(
      listenable: appSettings,
      builder: (context, _) => Scaffold(
        backgroundColor: dark ? null : const Color(0xFFF5F2E6),
        body: ListView(
          padding: EdgeInsets.zero,
          children: [
            _header(),
            _prayerCard(dark),
            _quickGrid(dark),
            _ayahBanner(),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  // ---------- اوپر کا حصہ ----------
  Widget _header() {
    final bearing = qiblaBearing(s.latitude, s.longitude).round();
    final badge = s.notificationsOn ? s.notifyPrayers.length : 0;

    return Stack(children: [
      Positioned.fill(
        child: Stack(fit: StackFit.expand, children: [
          // اگر assets/header_bg.jpg رکھ دیں تو یہ پس منظر بن جائے گا
          Image.asset(
            'assets/header_bg.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [_green, _greenMid],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.35)),
        ]),
      ),
      Directionality(
        textDirection: TextDirection.ltr,
        child: Padding(
          padding: EdgeInsets.fromLTRB(
              12, MediaQuery.of(context).padding.top + 10, 12, 14),
          child: Column(children: [
            // لوگو، عنوان، بسم اللہ، بٹن
            Row(children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset('assets/logo.png', width: 56, height: 56),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text.rich(TextSpan(children: [
                        TextSpan(
                            text: 'MSF ',
                            style: TextStyle(
                                color: _gold,
                                fontSize: 24,
                                fontWeight: FontWeight.w800)),
                        TextSpan(
                            text: 'Islamic App',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.bold)),
                      ])),
                      Text('Quran • Hadith • Prayer • Qibla',
                          style:
                              TextStyle(color: Colors.white70, fontSize: 10)),
                    ]),
              ),
              const Text('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
                  style: TextStyle(color: _gold, fontSize: 12)),
              const SizedBox(width: 8),
              _circleBtn(Icons.settings, _openSettings),
              const SizedBox(width: 8),
              _circleBtn(Icons.notifications_none, _openSettings,
                  badge: badge),
            ]),
            const SizedBox(height: 12),
            // مقام اور قبلہ کی سمت
            Row(children: [
              Expanded(
                flex: 6,
                child: InkWell(
                  onTap: () => showLocationPicker(context),
                  borderRadius: BorderRadius.circular(30),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: _green.withOpacity(0.92),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: _gold.withOpacity(0.6)),
                    ),
                    child: Row(children: [
                      const Icon(Icons.location_on, color: _gold),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(s.city,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold)),
                              Text(s.country,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      color: Colors.white70, fontSize: 11)),
                            ]),
                      ),
                      const Icon(Icons.arrow_drop_down, color: Colors.white),
                    ]),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 4,
                child: InkWell(
                  onTap: () => widget.onNavigate(2),
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: _green.withOpacity(0.92),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: _gold.withOpacity(0.6)),
                    ),
                    child: Row(children: [
                      const Icon(Icons.explore, color: _gold, size: 34),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('قبلہ کی سمت',
                                  style: TextStyle(
                                      color: Colors.white, fontSize: 11)),
                              Text('$bearing°',
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold)),
                            ]),
                      ),
                    ]),
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            _clockCard(),
          ]),
        ),
      ),
    ]);
  }

  Widget _circleBtn(IconData icon, VoidCallback onTap, {int badge = 0}) {
    return InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: Stack(clipBehavior: Clip.none, children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _green.withOpacity(0.9),
            border: Border.all(color: _gold, width: 1.5),
          ),
          child: Icon(icon, color: Colors.white),
        ),
        if (badge > 0)
          Positioned(
            right: -2,
            top: -2,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(
                  color: Colors.red, shape: BoxShape.circle),
              child: Text('$badge',
                  style: const TextStyle(color: Colors.white, fontSize: 10)),
            ),
          ),
      ]),
    );
  }

  // ---------- گھڑی اور تاریخیں ----------
  Widget _clockCard() {
    final h = HijriCalendar.fromDate(now.add(Duration(days: s.hijriAdjust)));
    final mainTime = DateFormat(s.use24h ? 'HH:mm' : 'hh:mm').format(now);
    final ampm = DateFormat('a').format(now);
    final sec = DateFormat('ss').format(now);

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _green.withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _gold, width: 1.5),
      ),
      child: Row(children: [
        Expanded(
          flex: 5,
          child: Column(children: [
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(mainTime,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 40,
                          fontWeight: FontWeight.bold)),
                  const SizedBox(width: 4),
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Column(children: [
                      if (!s.use24h)
                        Text(ampm,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w600)),
                      Text(':$sec',
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 14)),
                    ]),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 2),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                '${weekdays[now.weekday - 1]}، ${now.day} ${months[now.month - 1]} ${now.year}',
                style: const TextStyle(color: Colors.white, fontSize: 13),
              ),
            ),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(DateFormat('EEEE, d MMMM yyyy').format(now),
                  style: const TextStyle(color: Colors.white70, fontSize: 11)),
            ),
          ]),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 3,
          child: _dateBox('${now.day} ${months[now.month - 1]}', '${now.year}',
              Icons.calendar_month, 'عیسوی تاریخ'),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 3,
          child: _dateBox('${h.hDay} ${h.longMonthName}', '${h.hYear}',
              Icons.nightlight_round, 'ہجری تاریخ'),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 3,
          child: _dateBox(weekdays[now.weekday - 1], s.city,
              Icons.today, 'آج کا دن'),
        ),
      ]),
    );
  }

  Widget _dateBox(String top, String mid, IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _gold.withOpacity(0.7)),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(top,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold)),
        ),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(mid,
              style: const TextStyle(color: Colors.white, fontSize: 13)),
        ),
        const SizedBox(height: 2),
        Icon(icon, color: _gold, size: 16),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(label,
              style: const TextStyle(color: Colors.white70, fontSize: 10)),
        ),
      ]),
    );
  }

  // ---------- اوقاتِ نماز ----------
  Widget _prayerCard(bool dark) {
    final cs = Theme.of(context).colorScheme;
    final slots = PrayerService.slots(now, s);
    final current = PrayerService.current(now, slots);
    final next = PrayerService.next(now, s);
    final remaining = next.time.difference(now);

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF1E2A25) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _gold.withOpacity(0.5)),
      ),
      child: Column(children: [
        Row(children: [
          CircleAvatar(
            radius: 18,
            backgroundColor: _greenMid,
            child: const Icon(Icons.access_time, color: Colors.white),
          ),
          const SizedBox(width: 8),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('اگلی نماز: ${next.name}',
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.bold)),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Text('باقی: ${_countdown(remaining)}',
                  style: TextStyle(
                      fontSize: 13,
                      color: cs.primary,
                      fontWeight: FontWeight.w600)),
            ),
          ]),
          const Spacer(),
          const Text('اوقاتِ نماز',
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: _greenMid)),
          const SizedBox(width: 6),
          const Icon(Icons.mosque, color: _greenMid, size: 30),
        ]),
        const SizedBox(height: 10),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final p in slots)
              Expanded(child: _prayerTile(p, current, dark)),
          ],
        ),
      ]),
    );
  }

  static const _icons = {
    'fajr': Icons.wb_twilight,
    'sunrise': Icons.light_mode_outlined,
    'dhuhr': Icons.wb_sunny,
    'asr': Icons.wb_cloudy,
    'maghrib': Icons.wb_twilight,
    'isha': Icons.nightlight_round,
  };

  Widget _prayerTile(PrayerSlot p, PrayerSlot? current, bool dark) {
    final cs = Theme.of(context).colorScheme;
    final isCurrent = current?.key == p.key;
    final done = p.end != null && now.isAfter(p.end!);
    final isSunrise = p.key == 'sunrise';
    final txt = isCurrent ? Colors.black87 : cs.onSurface;

    Widget small(String t, {double size = 10, FontWeight? w}) => FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(t,
              style: TextStyle(fontSize: size, color: txt, fontWeight: w)),
        );

    Widget chip(String t, Color bg, Color fg) => Container(
          width: double.infinity,
          margin: const EdgeInsets.only(top: 6),
          padding: const EdgeInsets.symmetric(vertical: 2),
          decoration:
              BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(t, style: TextStyle(fontSize: 9, color: fg)),
          ),
        );

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 3),
      decoration: BoxDecoration(
        color: isCurrent
            ? const Color(0xFFFFF1C9)
            : (dark ? const Color(0xFF24332D) : const Color(0xFFEAF3EC)),
        borderRadius: BorderRadius.circular(12),
        border: isCurrent ? Border.all(color: _gold, width: 1.5) : null,
      ),
      child: Column(children: [
        Icon(_icons[p.key],
            size: 26, color: isCurrent ? const Color(0xFFE09F00) : _greenMid),
        const SizedBox(height: 4),
        small(p.name, size: 13, w: FontWeight.bold),
        const SizedBox(height: 4),
        if (isSunrise) ...[
          small(_t(p.start), size: 11),
          small('-'),
        ] else ...[
          small('شروع', size: 9),
          small(_t(p.start), size: 11),
          const SizedBox(height: 2),
          small('ختم', size: 9),
          small(_t(p.end!), size: 11),
        ],
        if (isCurrent)
          chip('داخل ہو چکا ہے', _gold, Colors.black87)
        else if (done)
          chip('مکمل', _green, Colors.white),
      ]),
    );
  }

  // ---------- فیچرز کا گرڈ ----------
  Widget _quickGrid(bool dark) {
    final items = <_Quick>[
      _Quick(Icons.menu_book, 'حدیث', 'مستند احادیث', () => _soon('احادیث')),
      _Quick(Icons.auto_stories, 'قرآن پاک', 'آن لائن تلاوت',
          () => _soon('قرآن پاک')),
      _Quick(Icons.calendar_month, 'اسلامی کیلنڈر', 'ہجری اور عیسوی تاریخ',
          () => widget.onNavigate(3)),
      _Quick(Icons.explore, 'قبلہ کمپاس', 'قبلہ کی سمت معلوم کریں',
          () => widget.onNavigate(2)),
      _Quick(Icons.mosque, 'مکہ کی زیارت', 'آن لائن زیارت',
          () => _soon('مکہ کی زیارت')),
      _Quick(Icons.wallpaper, 'گھڑی وال پیپر', 'خوبصورت ڈیزائن',
          () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const WallpaperScreen()))),
      _Quick(Icons.settings, 'سیٹنگز', 'ایپ کی ترتیبات', _openSettings),
      _Quick(Icons.notifications_active, 'اذان کی ترتیبات',
          'نماز کی یاد دہانی اور اذان', _openSettings),
      _Quick(Icons.location_on, 'مقام منتخب کریں', 'دنیا کے کسی بھی شہر کا وقت',
          () => showLocationPicker(context)),
      _Quick(Icons.public, '57 اسلامی ممالک', 'ملک، صوبے اور شہر',
          () => showLocationPicker(context)),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      child: GridView.count(
        crossAxisCount: 5,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 8,
        crossAxisSpacing: 6,
        childAspectRatio: 0.66,
        children: [
          for (final q in items)
            InkWell(
              onTap: q.onTap,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: dark ? const Color(0xFF1E2A25) : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _gold.withOpacity(0.4)),
                ),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(q.icon, color: _greenMid, size: 32),
                      const SizedBox(height: 6),
                      Text(q.title,
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          style: const TextStyle(
                              fontSize: 11, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 2),
                      Text(q.subtitle,
                          textAlign: TextAlign.center,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 8.5, color: Colors.grey)),
                    ]),
              ),
            ),
        ],
      ),
    );
  }

  // ---------- آیت کا بینر ----------
  Widget _ayahBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [_green, _greenMid]),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _gold, width: 1.2),
      ),
      child: const Column(children: [
        Text('إِنَّ الصَّلَاةَ تَنْهَىٰ عَنِ الْفَحْشَاءِ وَالْمُنكَرِ',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white, fontSize: 19, height: 1.6)),
        SizedBox(height: 4),
        Text('بے شک نماز بے حیائی اور برائی سے روکتی ہے  (العنکبوت: 45)',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70, fontSize: 12)),
      ]),
    );
  }
}

class _Quick {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  _Quick(this.icon, this.title, this.subtitle, this.onTap);
}
