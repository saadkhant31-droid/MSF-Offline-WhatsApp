package com.msf.wireless;

/** Small IMA ADPCM codec for low-bitrate RF voice. 8 kHz mono, 4 bits/sample. */
public final class AdpcmCodec {
    private static final int[] INDEX = {-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8};
    private static final int[] STEP = {7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,66,73,80,88,97,107,118,130,143,157,173,190,209,230,253,279,307,337,371,408,449,494,544,599,659,725,798,878,966,1063,1169,1285,1414,1554,1707,1876,2066,2272,2499,2749,3024,3327};
    private AdpcmCodec() {}
    public static byte[] encode(short[] pcm, int[] state) {
        int pred=state[0], idx=state[1]; byte[] out=new byte[(pcm.length+1)/2]; int oi=0; boolean high=false; int cur=0;
        for(short sample:pcm){ int step=STEP[idx], diff=sample-pred, code=0; if(diff<0){code=8; diff=-diff;} if(diff>=step){code|=4; diff-=step;} if(diff>=step/2){code|=2; diff-=step/2;} if(diff>=step/4)code|=1;
            int delta=step>>3; if((code&4)!=0)delta+=step; if((code&2)!=0)delta+=step>>1; if((code&1)!=0)delta+=step>>2; pred += (code&8)!=0 ? -delta : delta; if(pred>32767)pred=32767; if(pred<-32768)pred=-32768;
            idx += INDEX[code]; if(idx<0)idx=0; if(idx>63)idx=63; if(!high){cur=code;high=true;}else{out[oi++]=(byte)(cur | (code<<4));high=false;}
        }
        if(high)out[oi]=(byte)cur; state[0]=pred;state[1]=idx;return out;
    }
    public static short[] decode(byte[] data,int samples,int[] state){ short[] out=new short[samples];int pred=state[0],idx=state[1],oi=0;
        for(byte bb:data){int b=bb&255; for(int n=0;n<2&&oi<samples;n++){int code=(n==0)?(b&15):((b>>4)&15);int step=STEP[idx],delta=step>>3;if((code&4)!=0)delta+=step;if((code&2)!=0)delta+=step>>1;if((code&1)!=0)delta+=step>>2;pred+=(code&8)!=0?-delta:delta;if(pred>32767)pred=32767;if(pred<-32768)pred=-32768;idx+=INDEX[code];if(idx<0)idx=0;if(idx>63)idx=63;out[oi++]=(short)pred;}}
        state[0]=pred;state[1]=idx;return out;
    }
}
