package com.msf.wireless;

import android.media.*;
import java.util.*;

/** Captures 8 kHz mono microphone audio and decodes received RF voice. */
public class VoiceAudioEngine {
    public interface Listener { void onVoicePacket(byte[] data,int sampleCount); }
    private AudioRecord record; private AudioTrack track; private Thread thread; private volatile boolean running; private final Listener listener;
    private final int[] encState={0,0}, decState={0,0}; private short[] pending=new short[160]; private int pendingCount;
    public VoiceAudioEngine(Listener l){listener=l;}
    public synchronized void start(){if(running)return;int min=AudioRecord.getMinBufferSize(8000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);int size=Math.max(min,4096);record=new AudioRecord(MediaRecorder.AudioSource.MIC,8000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,size);record.startRecording();running=true;thread=new Thread(()->{short[] buf=new short[320];while(running){int n=record.read(buf,0,buf.length);if(n<=0)continue;int off=0;while(off<n){int take=Math.min(160-pendingCount,n-off);System.arraycopy(buf,off,pending,pendingCount,take);pendingCount+=take;off+=take;if(pendingCount==160){byte[] compressed=AdpcmCodec.encode(pending,encState);listener.onVoicePacket(compressed,160);pendingCount=0;}}}});thread.start();}
    public synchronized void stop(){running=false;pendingCount=0;if(record!=null){try{record.stop();}catch(Exception ignored){}record.release();record=null;}if(thread!=null){try{thread.join(250);}catch(Exception ignored){}thread=null;}}
    public synchronized void playRf(byte[] compressed,int sampleCount){short[] pcm=AdpcmCodec.decode(compressed,sampleCount,decState);if(track==null){int min=AudioTrack.getMinBufferSize(8000,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);track=new AudioTrack(AudioManager.STREAM_MUSIC,8000,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT,Math.max(min,4096),AudioTrack.MODE_STREAM);track.play();}track.write(pcm,0,pcm.length);}
    public synchronized void releasePlayback(){if(track!=null){try{track.stop();}catch(Exception ignored){}track.release();track=null;}decState[0]=decState[1]=0;}
}
