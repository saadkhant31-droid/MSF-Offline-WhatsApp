package com.msf.wireless;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.content.*;

public class SettingsActivity extends Activity {
    private android.content.SharedPreferences prefs;
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("msf",MODE_PRIVATE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,32,32,32); root.setBackgroundColor(Color.rgb(3,14,26));
        TextView title=new TextView(this); title.setText("MSF Wireless Settings"); title.setTextColor(Color.WHITE); title.setTextSize(26); title.setTypeface(Typeface.DEFAULT_BOLD); title.setPadding(0,0,0,28); root.addView(title);
        TextView n=new TextView(this); n.setText("Your Name"); n.setTextColor(Color.LTGRAY); n.setTextSize(16); root.addView(n);
        EditText name=new EditText(this); name.setText(prefs.getString("name","")); name.setHint("Enter your wireless name"); name.setTextColor(Color.WHITE); name.setHintTextColor(Color.GRAY); root.addView(name,new LinearLayout.LayoutParams(-1,-2));
        TextView ch=new TextView(this); ch.setText("Channel"); ch.setTextColor(Color.LTGRAY); ch.setTextSize(16); ch.setPadding(0,24,0,0); root.addView(ch);
        EditText channel=new EditText(this); channel.setInputType(2); channel.setText(String.valueOf(prefs.getInt("channel",1))); channel.setTextColor(Color.WHITE); root.addView(channel,new LinearLayout.LayoutParams(-1,-2));
        TextView info=new TextView(this); info.setText("USB-OTG radio: enabled when a supported radio is connected.\nUser names appear only when a radio peer announces itself."); info.setTextColor(Color.GRAY); info.setTextSize(14); info.setPadding(0,24,0,24); root.addView(info);
        Button save=new Button(this); save.setText("SAVE SETTINGS"); save.setOnClickListener(v->{int c=1;try{c=Integer.parseInt(channel.getText().toString());}catch(Exception ignored){} prefs.edit().putString("name",name.getText().toString().trim()).putInt("channel",Math.max(1,Math.min(99,c))).apply(); Toast.makeText(this,"Settings saved",Toast.LENGTH_SHORT).show();}); root.addView(save);
        Button back=new Button(this); back.setText("BACK TO HOME"); back.setOnClickListener(v->finish()); root.addView(back);
        setContentView(root);
    }
}
