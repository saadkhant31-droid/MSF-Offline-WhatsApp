package com.msf.wireless;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/** Binary protocol shared by two MSF Wireless phones over a transparent UART RF link. */
public final class RfVoiceProtocol {
    public static final short MAGIC=(short)0x4D53;
    public static final byte HELLO=1, LEAVE=2, VOICE=3, CHANNEL=4, SCAN=5, SCAN_REPLY=6;
    private RfVoiceProtocol(){}
    public static byte[] packet(byte type,int channel,int seq,byte[] payload){
        int len=payload==null?0:payload.length; ByteBuffer b=ByteBuffer.allocate(10+len).order(ByteOrder.BIG_ENDIAN);
        b.putShort(MAGIC).put(type).put((byte)channel).putShort((short)seq).putShort((short)len).put(payload==null?new byte[0]:payload); return b.array();
    }
    public static byte[] hello(int channel,String name){return packet(HELLO,channel,0,name.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    public static byte[] leave(int channel,String name){return packet(LEAVE,channel,0,name.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    public static byte[] voice(int channel,int seq,byte[] payload){return packet(VOICE,channel,seq,payload);}
    public static Header header(byte[] data,int off){if(data.length-off<8)return null;ByteBuffer b=ByteBuffer.wrap(data,off,8).order(ByteOrder.BIG_ENDIAN);if(b.getShort()!=MAGIC)return null;Header h=new Header();h.type=b.get();h.channel=b.get()&255;h.seq=b.getShort()&65535;h.length=b.getShort()&65535;return h;}
    public static class Header{public byte type;public int channel,seq,length;}
}
