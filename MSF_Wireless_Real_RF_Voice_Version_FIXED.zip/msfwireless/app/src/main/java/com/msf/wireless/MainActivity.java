package com.msf.wireless;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Window;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.widget.Toast;
import java.util.*;

public class MainActivity extends Activity implements HomeTouchOverlay.Listener, UsbRadioManager.Listener {
    private static final String USB_PERMISSION = "com.msf.wireless.USB_PERMISSION";
    private final BroadcastReceiver usbReceiver = new BroadcastReceiver(){ @Override public void onReceive(Context c, Intent i){ if(USB_PERMISSION.equals(i.getAction())){ radio.openFirst(); } } };
    private VoiceAudioEngine audio; private UsbRadioManager radio; private int channel=1; private boolean transmitting; private int voiceSeq; private String myName; private ConnectedUsersView usersView;
    @Override public void onCreate(Bundle b){super.onCreate(b); requestWindowFeature(Window.FEATURE_NO_TITLE); setContentView(R.layout.activity_main);
        usersView=findViewById(R.id.connectedUsers); radio=new UsbRadioManager(this); radio.setListener(this);
        channel=getSharedPreferences("msf",MODE_PRIVATE).getInt("channel",1); myName=getSharedPreferences("msf",MODE_PRIVATE).getString("name","MSF User"); radio.setChannel(channel);
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);
        audio=new VoiceAudioEngine((data,len)->{if(transmitting) radio.sendVoice(voiceSeq++,Arrays.copyOf(data,len));});
        if (android.os.Build.VERSION.SDK_INT >= 33) { registerReceiver(usbReceiver, new IntentFilter(USB_PERMISSION), Context.RECEIVER_NOT_EXPORTED); } else { registerReceiver(usbReceiver, new IntentFilter(USB_PERMISSION)); } requestUsbPermission(); radio.openFirst(); radio.hello(myName);
        ((HomeTouchOverlay)findViewById(R.id.homeTouch)).setListener(this);
    }
    private void requestUsbPermission(){ UsbManager um=(UsbManager)getSystemService(Context.USB_SERVICE); for(UsbDevice d:um.getDeviceList().values()){ if(!um.hasPermission(d)){ Intent pi=new Intent(USB_PERMISSION); PendingIntent p=PendingIntent.getBroadcast(this,0,pi,PendingIntent.FLAG_IMMUTABLE); um.requestPermission(d,p); break; } } }
    @Override public void onRadioUser(String name,int signal){runOnUiThread(()->usersView.addOrUpdate(name,signal));}
    @Override public void onRadioUserLeft(String name){runOnUiThread(()->usersView.remove(name));}
    @Override public void onVoice(byte[] data,int samples){if(!transmitting) audio.playRf(data,samples);}
    @Override public void onChannelMinus(){channel=Math.max(1,channel-1);getSharedPreferences("msf",0).edit().putInt("channel",channel).apply();radio.setChannel(channel);radio.hello(myName);Toast.makeText(this,"Channel "+String.format(Locale.US,"%02d",channel),Toast.LENGTH_SHORT).show();}
    @Override public void onChannelPlus(){channel=Math.min(99,channel+1);getSharedPreferences("msf",0).edit().putInt("channel",channel).apply();radio.setChannel(channel);radio.hello(myName);Toast.makeText(this,"Channel "+String.format(Locale.US,"%02d",channel),Toast.LENGTH_SHORT).show();}
    @Override public void onScan(){Toast.makeText(this,"Scanning available radio channels…",Toast.LENGTH_SHORT).show(); radio.scan();}
    @Override public void onOneToOne(){Toast.makeText(this,"One-to-One mode selected",Toast.LENGTH_SHORT).show();}
    @Override public void onGroup(){Toast.makeText(this,"Group mode selected",Toast.LENGTH_SHORT).show();}
    @Override public void onHome(){Toast.makeText(this,"Home",Toast.LENGTH_SHORT).show();}
    @Override public void onSettings(){startActivity(new Intent(this,SettingsActivity.class));}
    @Override public void onPttDown(){if(transmitting)return;if(android.os.Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){Toast.makeText(this,"Microphone permission required",Toast.LENGTH_SHORT).show();return;}try{transmitting=true;audio.start();}catch(Exception e){transmitting=false;Toast.makeText(this,"Microphone start failed: "+e.getMessage(),Toast.LENGTH_SHORT).show();}}
    @Override public void onPttUp(){if(!transmitting)return;transmitting=false;audio.stop();}
    @Override protected void onDestroy(){if(audio!=null)audio.stop();if(radio!=null){radio.leave(myName);radio.close();} try{unregisterReceiver(usbReceiver);}catch(Exception ignored){}if(audio!=null)audio.releasePlayback();super.onDestroy();}
}
