package com.msf.wireless;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;
import java.util.*;

/** Draws only live connected-user data over the supplied Home Screen artwork. */
public class ConnectedUsersView extends View {
    private final List<User> users = new ArrayList<>();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float sx, sy;
    public static class User {
        public String name; public int signal;
        public User(String name, int signal){this.name=name;this.signal=signal;}
    }
    public ConnectedUsersView(Context c, AttributeSet a){super(c,a); setWillNotDraw(false);}
    private float x(float v){return v*sx;} private float y(float v){return v*sy;}
    public synchronized void setUsers(Collection<User> list){users.clear(); users.addAll(list); postInvalidate();}
    public synchronized void addOrUpdate(String name,int signal){
        for(User u:users) if(u.name.equals(name)){u.signal=signal;postInvalidate();return;}
        if(users.size()<5) users.add(new User(name,signal)); postInvalidate();
    }
    public synchronized void remove(String name){for(Iterator<User> it=users.iterator();it.hasNext();)if(it.next().name.equals(name))it.remove();postInvalidate();}
    public synchronized List<User> snapshot(){return new ArrayList<>(users);}
    @Override protected void onDraw(Canvas c){super.onDraw(c); sx=getWidth()/866f; sy=getHeight()/1536f;
        p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); p.setTextSize(y(18));
        // live count
        p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(y(24));
        c.drawText(String.valueOf(users.size()),x(430),y(765),p);
        p.setTypeface(Typeface.DEFAULT);
        int i=0; synchronized(this){ for(User u:users){
            float yy=825+i*65;
            p.setColor(Color.rgb(0,230,80)); c.drawCircle(x(82),y(yy-5),y(10),p);
            p.setColor(new int[]{Color.rgb(0,125,255),Color.rgb(155,30,230),Color.rgb(255,145,0),Color.rgb(245,35,65),Color.rgb(0,210,190)}[i%5]);
            c.drawCircle(x(145),y(yy-14),y(12),p); c.drawRoundRect(x(126),y(yy),x(164),y(yy+22),y(12),y(12),p);
            p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(y(21));
            String n=u.name.length()>18?u.name.substring(0,18):u.name; c.drawText(n,x(188),y(yy-2),p);
            p.setTypeface(Typeface.DEFAULT); p.setColor(Color.rgb(0,180,255)); p.setTextSize(y(16));
            c.drawText(u.signal>=4?"Online • Strong":(u.signal>=2?"Online • Weak":"Online"),x(188),y(yy+22),p);
            i++; }
        }
    }
}
