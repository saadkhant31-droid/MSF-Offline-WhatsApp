package com.msf.wireless;
import android.content.*; import android.hardware.usb.*; import java.util.*; import java.nio.charset.StandardCharsets;

/** USB bulk transport for CP2102/CH340-style UART bridges connected to a transparent RF module. */
public class UsbRadioManager {
 public interface Listener{void onRadioUser(String name,int signal);void onRadioUserLeft(String name);void onVoice(byte[] data,int samples);}
 private final Context context; private UsbDeviceConnection connection; private UsbEndpoint out,in; private Listener listener; private Thread reader; private volatile boolean reading; private int channel=1;
 public UsbRadioManager(Context c){context=c.getApplicationContext();}
 public void setListener(Listener l){listener=l;}
 public void setChannel(int c){channel=c;}
 public List<UsbDevice> devices(){return new ArrayList<>(((UsbManager)context.getSystemService(Context.USB_SERVICE)).getDeviceList().values());}
 public boolean openFirst(){UsbManager m=(UsbManager)context.getSystemService(Context.USB_SERVICE);for(UsbDevice d:devices()){if(!m.hasPermission(d))continue;for(int i=0;i<d.getInterfaceCount();i++){UsbInterface ui=d.getInterface(i);UsbDeviceConnection c=m.openDevice(d);if(c==null||!c.claimInterface(ui,true))continue;UsbEndpoint o=null,ii=null;for(int e=0;e<ui.getEndpointCount();e++){UsbEndpoint ep=ui.getEndpoint(e);if(ep.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK){if(ep.getDirection()==UsbConstants.USB_DIR_OUT)o=ep;else ii=ep;}}if(o!=null&&ii!=null){connection=c;out=o;in=ii;startReader();return true;}c.close();}}return false;}
 private void startReader(){if(reading)return;reading=true;reader=new Thread(()->{byte[] b=new byte[512];byte[] buf=new byte[8192];int used=0;while(reading&&connection!=null&&in!=null){int n=connection.bulkTransfer(in,b,b.length,500);if(n<=0)continue;if(used+n>buf.length)used=0;System.arraycopy(b,0,buf,used,n);used+=n;int pos=0;while(used-pos>=8){RfVoiceProtocol.Header h=RfVoiceProtocol.header(buf,pos);if(h==null){pos++;continue;}int total=8+h.length;if(h.length>4096||used-pos<total)break;byte[] payload=Arrays.copyOfRange(buf,pos+8,pos+total);handle(h,payload);pos+=total;}if(pos>0){System.arraycopy(buf,pos,buf,0,used-pos);used-=pos;}}},"MSF-RF-Reader");reader.start();}
 private void handle(RfVoiceProtocol.Header h,byte[] p){if(h.channel!=channel)return;if(h.type==RfVoiceProtocol.HELLO){String n=new String(p,StandardCharsets.UTF_8);if(listener!=null)listener.onRadioUser(n,4);}else if(h.type==RfVoiceProtocol.LEAVE){String n=new String(p,StandardCharsets.UTF_8);if(listener!=null)listener.onRadioUserLeft(n);}else if(h.type==RfVoiceProtocol.VOICE&&listener!=null){listener.onVoice(p,160);}}
 public int send(byte[] data,int timeout){if(connection==null||out==null)return -1;return connection.bulkTransfer(out,data,data.length,timeout);}
 public void hello(String name){send(RfVoiceProtocol.hello(channel,name),500);}
 public void leave(String name){send(RfVoiceProtocol.leave(channel,name),500);}
 public void sendVoice(int seq,byte[] data){send(RfVoiceProtocol.voice(channel,seq,data),500);}
 public void scan(){send(RfVoiceProtocol.packet(RfVoiceProtocol.SCAN,channel,0,new byte[0]),500);}
 public void close(){reading=false;if(connection!=null){connection.close();connection=null;}if(reader!=null){try{reader.join(250);}catch(Exception ignored){}reader=null;}}
}
