package com.msf.wireless;

import android.content.Context;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Transparent touch layer mapped to the supplied 866x1536 home-screen artwork. */
public class HomeTouchOverlay extends View {
    public interface Listener {
        void onChannelMinus();
        void onChannelPlus();
        void onScan();
        void onOneToOne();
        void onGroup();
        void onPttDown();
        void onPttUp();
        void onHome();
        void onSettings();
    }
    private Listener listener;
    private boolean pttDown;
    public HomeTouchOverlay(Context c, AttributeSet a){ super(c,a); setBackgroundColor(0x00000000); }
    public void setListener(Listener l){ listener=l; }
    private float sx(){ return getWidth()/866f; }
    private float sy(){ return getHeight()/1536f; }
    private boolean hit(float x,float y,float l,float t,float r,float b){ return new RectF(l*sx(),t*sy(),r*sx(),b*sy()).contains(x,y); }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(listener==null)return true;
        float x=e.getX(), y=e.getY();
        if(e.getAction()==MotionEvent.ACTION_DOWN){
            if(hit(x,y,45,330,160,450)){ listener.onChannelMinus(); return true; }
            if(hit(x,y,410,330,520,450)){ listener.onChannelPlus(); return true; }
            if(hit(x,y,540,320,820,470)){ listener.onScan(); return true; }
            if(hit(x,y,45,490,410,690)){ listener.onOneToOne(); return true; }
            if(hit(x,y,415,490,820,690)){ listener.onGroup(); return true; }
            if(hit(x,y,300,1180,565,1480)){ pttDown=true; listener.onPttDown(); return true; }
            if(hit(x,y,0,1400,280,1536)){ listener.onHome(); return true; }
            if(hit(x,y,590,1400,866,1536)){ listener.onSettings(); return true; }
            return true;
        }
        if((e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) && pttDown){
            pttDown=false; listener.onPttUp(); return true;
        }
        return true;
    }
}
