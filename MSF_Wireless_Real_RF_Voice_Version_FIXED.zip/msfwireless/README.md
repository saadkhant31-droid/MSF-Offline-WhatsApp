# MSF Wireless — Real RF Voice Version

This Android project is a phone-side RF voice application. It does **not** use Wi-Fi, hotspot, Bluetooth, NFC, or the Internet for voice transport.

## Hardware path
Phone A -> USB-C OTG -> USB-UART bridge (CP2102/CH340/FTDI) -> UART RF module -> antenna )) RF (( antenna -> UART RF module -> USB-UART -> OTG -> Phone B

Recommended starting hardware: two compatible UART RF/LoRa transceiver modules such as an E22-class 410–493 MHz module, two USB-UART bridges, suitable antennas, power supplies, and OTG adapters. The exact module voltage, UART settings, frequency, bandwidth and legal operating parameters must be followed from its datasheet and local regulations.

## Voice transport
- 8 kHz mono microphone capture
- IMA ADPCM 4-bit compression (about 32 kbps before packet overhead)
- 160 audio samples per RF voice packet (20 ms)
- Binary framed protocol with magic, packet type, channel, sequence and payload length
- RF receive packets are decoded and played through the phone speaker/headset
- PTT starts/stops microphone transmission

## Important
The APK alone cannot create a long-range radio. The external RF modules and their configuration are required. This build supplies the Android USB transport, voice codec, packet framing, PTT transmit path, receive playback, channel handling and peer-name announcements. A specific RF module may still require UART configuration (baud rate/air data rate/frequency) and a matching firmware/configuration.

The current codec is intentionally simple. For very low-bitrate LoRa settings, a speech codec such as Codec2 would be preferable; that requires adding and testing a native codec library.
