package com.islamic.app

import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.*

data class PrayerTime(val name: String, val time: LocalTime)

object PrayerCalculator {
    private const val RAD = Math.PI / 180.0

    // Approximate solar-position calculation. Verify with the local mosque timetable.
    fun calculate(date: LocalDate, city: City, hanafiAsr: Boolean = true): List<PrayerTime> {
        val n = date.dayOfYear.toDouble()
        val lngHour = city.longitude / 15.0
        fun solarTime(angle: Double, morning: Boolean): Double {
            val t = n + ((if (morning) 6.0 else 18.0) - lngHour) / 24.0
            val m = (0.9856 * t) - 3.289
            var l = m + 1.916 * sin(m * RAD) + 0.020 * sin(2 * m * RAD) + 282.634
            l = (l % 360 + 360) % 360
            var ra = atan(0.91764 * tan(l * RAD)) / RAD
            ra = (ra % 360 + 360) % 360
            ra += floor(l / 90.0) * 90.0 - floor(ra / 90.0) * 90.0
            ra /= 15.0
            val sinDec = 0.39782 * sin(l * RAD)
            val cosDec = cos(asin(sinDec))
            val cosH = (cos(angle * RAD) - sinDec * sin(city.latitude * RAD)) /
                    (cosDec * cos(city.latitude * RAD))
            if (cosH < -1 || cosH > 1) return if (morning) 5.0 else 19.0
            val h = (if (morning) 360.0 - acos(cosH) / RAD else acos(cosH) / RAD) / 15.0
            return h + ra - (0.06571 * t) - 6.622 + lngHour
        }

        val sunrise = solarTime(90.833, true)
        val sunset = solarTime(90.833, false)
        val fajr = solarTime(18.0, true)
        val isha = solarTime(17.0, false)
        val noon = ((sunrise + sunset) / 2.0)
        val asrAngle = atan(1.0 / (if (hanafiAsr) 2.0 else 1.0) /
                (tan(abs(city.latitude - 0.0) * RAD) + 0.01)) / RAD
        val asr = (noon + 12.0 - (asrAngle / 90.0) * 2.0).coerceIn(noon + 1.0, sunset - 0.2)

        fun toTime(hours: Double): LocalTime {
            val localHours = hours + city.utcOffsetHours
            val mins = (localHours * 60.0).roundToInt()
            return LocalTime.MIDNIGHT.plusMinutes(mins.toLong())
        }
        return listOf(
            PrayerTime("فجر", toTime(fajr)),
            PrayerTime("طلوعِ آفتاب", toTime(sunrise)),
            PrayerTime("ظہر", toTime(noon)),
            PrayerTime("عصر", toTime(asr)),
            PrayerTime("مغرب", toTime(sunset)),
            PrayerTime("عشاء", toTime(isha))
        )
    }

    fun qiblaBearing(latitude: Double, longitude: Double): Double {
        val kaabaLat = 21.4225 * RAD
        val kaabaLon = 39.8262 * RAD
        val lat = latitude * RAD
        val lon = longitude * RAD
        val y = sin(kaabaLon - lon)
        val x = cos(lat) * tan(kaabaLat) - sin(lat) * cos(kaabaLon - lon)
        return (atan2(y, x) / RAD + 360.0) % 360.0
    }
}
