package com.islamic.app

data class City(
    val country: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val utcOffsetHours: Double
) {
    override fun toString(): String = "$name، $country"
}
