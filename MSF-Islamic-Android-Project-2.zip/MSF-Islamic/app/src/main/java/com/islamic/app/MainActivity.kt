package com.islamic.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.chrono.HijrahDate
import java.time.format.DecimalStyle
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var clock: TextView
    private lateinit var dates: TextView
    private lateinit var citySpinner: Spinner
    private lateinit var coords: TextView
    private lateinit var nextPrayer: TextView
    private lateinit var prayerList: LinearLayout
    private lateinit var qibla: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val cities = listOf(
        City("پاکستان", "اسلام آباد", 33.6844, 73.0479, 5.0),
        City("پاکستان", "کراچی", 24.8607, 67.0011, 5.0),
        City("پاکستان", "لاہور", 31.5204, 74.3587, 5.0),
        City("پاکستان", "پشاور", 34.0151, 71.5249, 5.0),
        City("پاکستان", "کوئٹہ", 30.1798, 66.9750, 5.0),
        City("سعودی عرب", "مکہ مکرمہ", 21.3891, 39.8579, 3.0),
        City("سعودی عرب", "مدینہ منورہ", 24.4672, 39.6024, 3.0),
        City("ترکیہ", "استنبول", 41.0082, 28.9784, 3.0),
        City("متحدہ عرب امارات", "دبئی", 25.2048, 55.2708, 4.0),
        City("بنگلہ دیش", "ڈھاکہ", 23.8103, 90.4125, 6.0),
        City("ملائیشیا", "کوالالمپور", 3.1390, 101.6869, 8.0),
        City("انڈونیشیا", "جکارتہ", -6.2088, 106.8456, 7.0),
        City("مصر", "قاہرہ", 30.0444, 31.2357, 2.0),
        City("برطانیہ", "لندن", 51.5072, -0.1276, 1.0),
        City("امریکہ", "نیویارک", 40.7128, -74.0060, -4.0)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        clock = findViewById(R.id.txtClock)
        dates = findViewById(R.id.txtDates)
        citySpinner = findViewById(R.id.spinnerCity)
        coords = findViewById(R.id.txtCoordinates)
        nextPrayer = findViewById(R.id.txtNextPrayer)
        prayerList = findViewById(R.id.prayerList)
        qibla = findViewById(R.id.txtQibla)

        citySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cities)
        citySpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                refreshPrayerData()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        handler.post(clockUpdater)
    }

    private val clockUpdater = object : Runnable {
        override fun run() {
            val now = LocalDateTime.now()
            clock.text = now.format(DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.ENGLISH))
            val hijri = HijrahDate.from(now.toLocalDate())
            dates.text = "${now.toLocalDate()}  •  ہجری: $hijri"
            handler.postDelayed(this, 1000)
        }
    }

    private fun refreshPrayerData() {
        if (!::prayerList.isInitialized || cities.isEmpty()) return
        val city = cities[citySpinner.selectedItemPosition.coerceIn(cities.indices)]
        coords.text = "مقام: ${city.latitude}, ${city.longitude}  •  UTC ${if (city.utcOffsetHours >= 0) "+" else ""}${city.utcOffsetHours}"
        val prayers = PrayerCalculator.calculate(LocalDate.now(), city)
        prayerList.removeAllViews()
        prayers.forEach { prayer ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 14, 14, 14)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val name = TextView(this).apply {
                text = prayer.name
                textSize = 18f
                setTextColor(0xFF183B34.toInt())
            }
            val time = TextView(this).apply {
                text = prayer.time.format(DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH))
                textSize = 18f
                setTextColor(0xFF075E54.toInt())
                gravity = Gravity.END
            }
            row.addView(name, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(time, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = 5
            prayerList.addView(row, params)
        }
        val now = LocalTimeNow.minutesNow()
        val next = prayers.firstOrNull { it.time.hour * 60 + it.time.minute > now }
        nextPrayer.text = if (next != null) "اگلی نماز: ${next.name} — ${next.time}" else "اگلی نماز: فجر (اگلے دن)"
        val bearing = PrayerCalculator.qiblaBearing(city.latitude, city.longitude)
        qibla.text = "قبلہ کی سمت: ${"%.1f".format(Locale.ENGLISH, bearing)}° شمال سے گھڑی کی سمت"
    }

    override fun onDestroy() {
        handler.removeCallbacks(clockUpdater)
        super.onDestroy()
    }
}

private object LocalTimeNow {
    fun minutesNow(): Int {
        val t = java.time.LocalTime.now()
        return t.hour * 60 + t.minute
    }
}
