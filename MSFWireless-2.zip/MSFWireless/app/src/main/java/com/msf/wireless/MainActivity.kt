package com.msf.wireless

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.random.Random

class MainActivity : Activity() {

    companion object {
        const val PORT = 50505
        const val RATE = 8000
        const val FRAME = 160                 // 20 ms
        const val HEADER = 6                  // 'M', group, 4-byte sender id
        const val PACKET = HEADER + FRAME * 2
    }

    private val myId = Random.nextInt()
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var connected = false
    @Volatile private var transmitting = false
    @Volatile private var recording = false
    @Volatile private var playing = false
    @Volatile private var group = 1

    private var socket: DatagramSocket? = null
    private var track: AudioTrack? = null
    private var mcLock: WifiManager.MulticastLock? = null
    private var hsRes: WifiManager.LocalOnlyHotspotReservation? = null
    private lateinit var wifi: WifiManager

    private val recLock = Any()
    private var recStream: FileOutputStream? = null
    private var recFile: File? = null
    private var recBytes = 0L

    private lateinit var tvStatus: TextView
    private lateinit var tvRx: TextView
    private lateinit var btnConnect: Button
    private lateinit var btnHotspot: Button
    private lateinit var btnGroup: Button
    private lateinit var btnPtt: Button
    private lateinit var btnRec: Button

    private val tone by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 70) }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun styled(b: Button, color: Int, radius: Int = 14): Button {
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.isAllCaps = false
        b.typeface = Typeface.DEFAULT_BOLD
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        b.background = g
        return b
    }

    private fun setColor(b: Button, color: Int) {
        (b.background as GradientDrawable).setColor(color)
    }

    private fun mk(text: String, color: Int) = styled(Button(this).also { it.text = text }, color)

    private fun row(vararg views: Button): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(0, dp(56), 1f)
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            r.addView(v, lp)
        }
        return r
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#10161C"))
        root.setPadding(dp(14), dp(28), dp(14), dp(14))

        val title = TextView(this)
        title.text = "📻 MSF Wireless"
        title.textSize = 26f
        title.setTextColor(Color.parseColor("#4CE08A"))
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        root.addView(title)

        tvStatus = TextView(this)
        tvStatus.text = "⚪ Not connected"
        tvStatus.textSize = 14f
        tvStatus.setTextColor(Color.parseColor("#B8C4CE"))
        tvStatus.gravity = Gravity.CENTER
        tvStatus.setPadding(0, dp(8), 0, dp(4))
        root.addView(tvStatus)

        tvRx = TextView(this)
        tvRx.text = " "
        tvRx.textSize = 18f
        tvRx.setTextColor(Color.parseColor("#FFC247"))
        tvRx.typeface = Typeface.DEFAULT_BOLD
        tvRx.gravity = Gravity.CENTER
        root.addView(tvRx)

        btnConnect = mk("📻 CONNECT", Color.parseColor("#1F8A4C"))
        btnHotspot = mk("📡 HOTSPOT", Color.parseColor("#2A6FDB"))
        root.addView(row(btnConnect, btnHotspot))

        btnGroup = mk("👥 GROUP: 1", Color.parseColor("#6B4FBB"))
        root.addView(row(btnGroup))

        btnPtt = styled(Button(this).also { it.text = "🎙️ PTT\nدبا کر بات کریں" },
            Color.parseColor("#394650"), 40)
        btnPtt.textSize = 22f
        val pl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        pl.setMargins(dp(8), dp(10), dp(8), dp(10))
        root.addView(btnPtt, pl)

        btnRec = mk("🔴 REC", Color.parseColor("#C0392B"))
        val btnStop = mk("⏹️ STOP", Color.parseColor("#7F8C8D"))
        val btnPlay = mk("▶️ PLAY", Color.parseColor("#E08A1E"))
        root.addView(row(btnRec, btnStop, btnPlay))

        setContentView(root)

        btnConnect.setOnClickListener { if (connected) disconnect() else connect() }
        btnHotspot.setOnClickListener { toggleHotspot() }
        btnGroup.setOnClickListener {
            group = if (group >= 9) 1 else group + 1
            btnGroup.text = "👥 GROUP: $group"
            refreshStatus()
        }
        btnPtt.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> startTx()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> stopTx()
            }
            true
        }
        btnRec.setOnClickListener { startRec() }
        btnStop.setOnClickListener { stopAll() }
        btnPlay.setOnClickListener { play() }

        askPermissions()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun refreshStatus() {
        tvStatus.text = if (connected)
            "🟢 Connected • IP: ${localIp()} • Group $group"
        else "⚪ Not connected"
    }

    // ------------------------------------------------------- permissions

    private fun askPermissions() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        val need = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------ network

    private fun localIp(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: ""
                }
            }
        } catch (_: Exception) {}
        return "—"
    }

    private fun broadcastAddrs(): List<InetAddress> {
        val list = mutableListOf<InetAddress>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) ia.broadcast?.let { list.add(it) }
            }
        } catch (_: Exception) {}
        try { list.add(InetAddress.getByName("255.255.255.255")) } catch (_: Exception) {}
        return list
    }

    private fun connect() {
        if (!hasMic()) { askPermissions(); toast("Mic permission دیں"); return }
        connected = true
        btnConnect.text = "⛔ DISCONNECT"
        setColor(btnConnect, Color.parseColor("#B03A2E"))
        mcLock = wifi.createMulticastLock("msf").also { it.setReferenceCounted(false); it.acquire() }
        refreshStatus()

        Thread {
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                s.broadcast = true
                s.bind(InetSocketAddress(PORT))
                socket = s

                val fmt = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                val minBuf = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT)
                val at = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(maxOf(minBuf, FRAME * 2 * 10))
                    .setTransferMode(AudioTrack.MODE_STREAM).build()
                track = at
                at.play()

                val fx = RadioFx()
                val buf = ByteArray(2048)
                val dp = DatagramPacket(buf, buf.size)
                val pcm = ShortArray(FRAME)
                val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)

                while (connected) {
                    dp.length = buf.size
                    try { s.receive(dp) } catch (e: Exception) { break }
                    if (dp.length != PACKET || buf[0] != 'M'.code.toByte()) continue
                    if (bb.getInt(2) == myId) continue          // میری اپنی آواز
                    if (buf[1].toInt() != group) continue       // دوسرا گروپ
                    if (transmitting) continue                  // بولتے وقت نہیں سنتے
                    for (i in 0 until FRAME) pcm[i] = bb.getShort(HEADER + i * 2)
                    fx.process(pcm)
                    at.write(pcm, 0, FRAME)
                    if (recording) writeRec(pcm)
                    ui.post {
                        tvRx.text = "🔊 RX …"
                        ui.removeCallbacks(clearRx)
                        ui.postDelayed(clearRx, 400)
                    }
                }
            } catch (e: Exception) {
                ui.post { toast("Connect error: ${e.message}"); disconnect() }
            }
        }.start()
    }

    private val clearRx = Runnable { tvRx.text = " " }

    private fun disconnect() {
        connected = false
        transmitting = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        track = null
        try { mcLock?.release() } catch (_: Exception) {}
        btnConnect.text = "📻 CONNECT"
        setColor(btnConnect, Color.parseColor("#1F8A4C"))
        refreshStatus()
    }

    // ---------------------------------------------------------------- PTT

    private fun startTx() {
        if (!connected) { toast("پہلے CONNECT دبائیں"); return }
        if (!hasMic()) { askPermissions(); return }
        if (transmitting) return
        transmitting = true
        setColor(btnPtt, Color.parseColor("#D62828"))
        btnPtt.text = "🎙️ TALKING…"
        try { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 80) } catch (_: Exception) {}

        Thread {
            try { Thread.sleep(130) } catch (_: Exception) {}   // بیپ مائیک میں نہ جائے
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, FRAME * 2 * 8))
            } catch (e: SecurityException) { transmitting = false; return@Thread }
            rec.startRecording()

            val pcm = ShortArray(FRAME)
            val pkt = ByteArray(PACKET)
            val bb = ByteBuffer.wrap(pkt).order(ByteOrder.LITTLE_ENDIAN)
            pkt[0] = 'M'.code.toByte()
            bb.putInt(2, myId)
            val addrs = broadcastAddrs()
            val s = socket

            while (transmitting && s != null && !s.isClosed) {
                var read = 0
                while (read < FRAME && transmitting) {
                    val r = rec.read(pcm, read, FRAME - read)
                    if (r <= 0) break
                    read += r
                }
                if (read < FRAME) break
                pkt[1] = group.toByte()
                for (i in 0 until FRAME) bb.putShort(HEADER + i * 2, pcm[i])
                for (a in addrs) {
                    try { s.send(DatagramPacket(pkt, PACKET, a, PORT)) } catch (_: Exception) {}
                }
                if (recording) writeRec(pcm)
            }
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
        }.start()
    }

    private fun stopTx() {
        if (!transmitting) return
        transmitting = false
        setColor(btnPtt, Color.parseColor("#394650"))
        btnPtt.text = "🎙️ PTT\nدبا کر بات کریں"
        try { tone.startTone(ToneGenerator.TONE_PROP_ACK, 80) } catch (_: Exception) {}
    }

    // ---------------------------------------------------------- recording

    private fun recDir(): File =
        getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: filesDir

    private fun wavHeader(dataLen: Long): ByteArray {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt((36 + dataLen).toInt())
        b.put("WAVE".toByteArray()); b.put("fmt ".toByteArray())
        b.putInt(16); b.putShort(1); b.putShort(1)
        b.putInt(RATE); b.putInt(RATE * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataLen.toInt())
        return b.array()
    }

    private fun startRec() {
        if (recording) return
        synchronized(recLock) {
            val f = File(recDir(), "MSF_${System.currentTimeMillis()}.wav")
            val s = FileOutputStream(f)
            s.write(wavHeader(0))
            recFile = f; recStream = s; recBytes = 0
            recording = true
        }
        btnRec.text = "🔴 REC…"
        toast("ریکارڈنگ شروع")
    }

    private fun writeRec(pcm: ShortArray) {
        synchronized(recLock) {
            val s = recStream ?: return
            val bb = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (v in pcm) bb.putShort(v)
            try { s.write(bb.array()); recBytes += pcm.size * 2 } catch (_: Exception) {}
        }
    }

    private fun stopRec() {
        synchronized(recLock) {
            if (!recording) return
            recording = false
            try { recStream?.flush(); recStream?.close() } catch (_: Exception) {}
            recStream = null
            recFile?.let { f ->
                try {
                    RandomAccessFile(f, "rw").use { it.seek(0); it.write(wavHeader(recBytes)) }
                } catch (_: Exception) {}
            }
        }
        btnRec.text = "🔴 REC"
        toast("محفوظ: ${recFile?.name}")
    }

    private fun stopAll() {
        stopRec()
        playing = false
    }

    private fun play() {
        if (recording) stopRec()
        if (playing) return
        val f = recFile ?: recDir().listFiles { x -> x.name.startsWith("MSF_") }
            ?.maxByOrNull { it.lastModified() }
        if (f == null || !f.exists()) { toast("کوئی ریکارڈنگ نہیں"); return }
        playing = true
        Thread {
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            val at = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(RATE * 2)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            at.play()
            try {
                FileInputStream(f).use {
                    it.skip(44)
                    val b = ByteArray(1600)
                    while (playing) {
                        val n = it.read(b)
                        if (n <= 0) break
                        at.write(b, 0, n)
                    }
                }
            } catch (_: Exception) {}
            try { at.stop() } catch (_: Exception) {}
            at.release()
            playing = false
        }.start()
    }

    // ------------------------------------------------------------ hotspot

    @Suppress("DEPRECATION")
    private fun toggleHotspot() {
        if (hsRes != null) {
            hsRes?.close(); hsRes = null
            btnHotspot.text = "📡 HOTSPOT"
            toast("Hotspot بند")
            return
        }
        try {
            wifi.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    hsRes = r
                    var ssid = ""
                    var pass = ""
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration
                        ssid = c.ssid ?: ""; pass = c.passphrase ?: ""
                    } else {
                        val c = r.wifiConfiguration
                        ssid = c?.SSID ?: ""; pass = c?.preSharedKey ?: ""
                    }
                    ui.post {
                        btnHotspot.text = "📡 HOTSPOT ON"
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("📡 Hotspot چالو")
                            .setMessage("نام: $ssid\nپاس ورڈ: $pass\n\nدوسرے موبائل کے Wi-Fi میں یہی نام منتخب کر کے پاس ورڈ ڈالیں، پھر وہاں CONNECT دبائیں۔")
                            .setPositiveButton("OK", null).show()
                        if (!connected) connect()
                    }
                }
                override fun onStopped() { hsRes = null }
                override fun onFailed(reason: Int) { ui.post { openTether() } }
            }, ui)
        } catch (e: Exception) {
            openTether()
        }
    }

    private fun openTether() {
        toast("Hotspot خود چالو کریں، پھر CONNECT دبائیں")
        try {
            startActivity(Intent("android.settings.TETHER_SETTINGS"))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }
    }

    override fun onDestroy() {
        stopAll()
        disconnect()
        hsRes?.close()
        super.onDestroy()
    }
}
