package com.msf.wireless

import kotlin.math.tanh
import kotlin.random.Random

/** Walkie-talkie sound: band-pass (300Hz-2.5kHz), drive/soft-clip, light static. */
class RadioFx {
    private var hpIn = 0f
    private var hpOut = 0f
    private var lp = 0f

    fun process(buf: ShortArray) {
        val hpA = 0.81f
        val lpA = 0.66f
        for (i in buf.indices) {
            val x = buf[i] / 32768f
            val hp = hpA * (hpOut + x - hpIn)
            hpIn = x
            hpOut = hp
            lp += lpA * (hp - lp)
            var y = tanh(lp * 3.2f)
            y += (Random.nextFloat() - 0.5f) * 0.012f
            val v = (y * 0.85f * 32767f).toInt().coerceIn(-32768, 32767)
            buf[i] = v.toShort()
        }
    }
}
