package com.msf.wireless

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.net.wifi.WifiManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.random.Random

class MainActivity : Activity() {

    companion object {
        const val PORT = 50505
        const val RATE = 8000
        const val FRAME = 160                 // 20 ms
        const val HEADER = 6                  // 'M', group, 4-byte sender id
        const val PACKET = HEADER + FRAME * 2
    }

    private val myId = Random.nextInt()
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var connected = false
    @Volatile private var transmitting = false
    @Volatile private var recording = false
    @Volatile private var playing = false
    @Volatile private var group = 1

    private var socket: DatagramSocket? = null
    private var track: AudioTrack? = null
    private var mcLock: WifiManager.MulticastLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val peers = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private var hsRes: WifiManager.LocalOnlyHotspotReservation? = null
    private lateinit var wifi: WifiManager

    private val recLock = Any()
    private var recStream: FileOutputStream? = null
    private var recFile: File? = null
    private var recBytes = 0L

    private lateinit var tvStatus: TextView
    private lateinit var tvRx: TextView
    private lateinit var btnConnect: Button
    private lateinit var btnHotspot: Button
    private lateinit var btnGroup: Button
    private lateinit var btnPtt: Button
    private lateinit var btnRec: Button
    private lateinit var btnFolder: Button
    private lateinit var btnVoice: Button
    private var folderUri: Uri? = null

    private val tone by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 70) }

    // ---------------------------------------------------------------- UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun styled(b: Button, color: Int, radius: Int = 14): Button {
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.isAllCaps = false
        b.typeface = Typeface.DEFAULT_BOLD
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        b.background = g
        return b
    }

    private fun setColor(b: Button, color: Int) {
        (b.background as GradientDrawable).setColor(color)
    }

    private fun mk(text: String, color: Int) = styled(Button(this).also { it.text = text }, color)

    private fun row(vararg views: Button): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) {
            val lp = LinearLayout.LayoutParams(0, dp(56), 1f)
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            r.addView(v, lp)
        }
        return r
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#10161C"))
        root.setPadding(dp(14), dp(28), dp(14), dp(14))

        val picId = resources.getIdentifier("profile", "drawable", packageName)
        if (picId != 0) {
            val iv = ImageView(this)
            iv.setImageResource(picId)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
            iv.clipToOutline = true
            val ilp = LinearLayout.LayoutParams(dp(110), dp(110))
            ilp.gravity = Gravity.CENTER_HORIZONTAL
            ilp.bottomMargin = dp(6)
            root.addView(iv, ilp)
        }

        val title = TextView(this)
        title.text = "📻 MSF Wireless"
        title.textSize = 26f
        title.setTextColor(Color.parseColor("#4CE08A"))
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        root.addView(title)

        tvStatus = TextView(this)
        tvStatus.text = "⚪ Not connected"
        tvStatus.textSize = 14f
        tvStatus.setTextColor(Color.parseColor("#B8C4CE"))
        tvStatus.gravity = Gravity.CENTER
        tvStatus.setPadding(0, dp(8), 0, dp(4))
        root.addView(tvStatus)

        tvRx = TextView(this)
        tvRx.text = " "
        tvRx.textSize = 18f
        tvRx.setTextColor(Color.parseColor("#FFC247"))
        tvRx.typeface = Typeface.DEFAULT_BOLD
        tvRx.gravity = Gravity.CENTER
        root.addView(tvRx)

        btnConnect = mk("📻 CONNECT", Color.parseColor("#1F8A4C"))
        btnHotspot = mk("📡 HOTSPOT", Color.parseColor("#2A6FDB"))
        root.addView(row(btnConnect, btnHotspot))

        btnGroup = mk("👥 GROUP: 1", Color.parseColor("#6B4FBB"))
        btnFolder = mk("📁 FOLDER", Color.parseColor("#2E7D8C"))
        getSharedPreferences("msf", 0).getString("folder", null)?.let {
            folderUri = Uri.parse(it)
            btnFolder.text = "📁 FOLDER ✓"
        }
        root.addView(row(btnGroup, btnFolder))

        RadioFx.style = getSharedPreferences("msf", 0).getInt("voice", 0)
        btnVoice = mk("🎚️ VOICE: ${RadioFx.NAMES[RadioFx.style]}", Color.parseColor("#8A5A2B"))
        root.addView(row(btnVoice))

        btnPtt = styled(Button(this).also { it.text = "🎙️ PTT\nدبا کر بات کریں" },
            Color.parseColor("#394650"), 40)
        btnPtt.textSize = 22f
        val pl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150))
        pl.setMargins(dp(8), dp(10), dp(8), dp(10))
        root.addView(btnPtt, pl)

        btnRec = mk("🔴 REC", Color.parseColor("#C0392B"))
        val btnStop = mk("⏹️ STOP", Color.parseColor("#7F8C8D"))
        val btnPlay = mk("▶️ PLAY", Color.parseColor("#E08A1E"))
        root.addView(row(btnRec, btnStop, btnPlay))

        val sv = android.widget.ScrollView(this)
        sv.isFillViewport = true
        sv.setBackgroundColor(Color.parseColor("#10161C"))
        sv.addView(root)
        setContentView(sv)

        btnConnect.setOnClickListener { if (connected) disconnect() else connect() }
        btnHotspot.setOnClickListener { toggleHotspot() }
        btnGroup.setOnClickListener {
            group = if (group >= 9) 1 else group + 1
            btnGroup.text = "👥 GROUP: $group"
            refreshStatus()
        }
        btnPtt.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> startTx()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> stopTx()
            }
            true
        }
        btnFolder.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            startActivityForResult(i, 77)
        }
        btnVoice.setOnClickListener {
            RadioFx.style = (RadioFx.style + 1) % RadioFx.NAMES.size
            getSharedPreferences("msf", 0).edit().putInt("voice", RadioFx.style).apply()
            btnVoice.text = "🎚️ VOICE: ${RadioFx.NAMES[RadioFx.style]}"
        }
        btnRec.setOnClickListener { startRec() }
        btnStop.setOnClickListener { stopAll() }
        btnPlay.setOnClickListener { play() }

        askPermissions()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun refreshStatus() {
        tvStatus.text = if (connected)
            "🟢 Connected • IP: ${localIp()} • Group $group"
        else "⚪ Not connected"
    }

    // ------------------------------------------------------- permissions

    private fun askPermissions() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        val need = p.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ------------------------------------------------------------ network

    private fun localIp(): String {
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: ""
                }
            }
        } catch (_: Exception) {}
        return "—"
    }

    private fun broadcastAddrs(): List<InetAddress> {
        val list = mutableListOf<InetAddress>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) ia.broadcast?.let { list.add(it) }
            }
        } catch (_: Exception) {}
        try { list.add(InetAddress.getByName("255.255.255.255")) } catch (_: Exception) {}
        return list
    }

    @Suppress("DEPRECATION")
    private fun gatewayAddr(): InetAddress? {
        val g = wifi.dhcpInfo?.gateway ?: 0
        if (g == 0) return null
        return try {
            InetAddress.getByAddress(byteArrayOf(
                (g and 0xff).toByte(), (g shr 8 and 0xff).toByte(),
                (g shr 16 and 0xff).toByte(), (g shr 24 and 0xff).toByte()))
        } catch (_: Exception) { null }
    }

    private fun targets(): List<InetAddress> {
        val now = System.currentTimeMillis()
        val l = mutableListOf<InetAddress>()
        gatewayAddr()?.let { l.add(it) }
        for ((ip, t) in peers) {
            if (now - t < 15000) try { l.add(InetAddress.getByName(ip)) } catch (_: Exception) {}
        }
        return l.distinct()
    }

    /** Unicast to known phones (reliable); broadcast only until a peer is discovered. */
    private fun sendPkt(s: DatagramSocket, pkt: ByteArray, len: Int) {
        val t = targets()
        val dests = if (t.isEmpty()) broadcastAddrs() else t
        for (a in dests) {
            try { s.send(DatagramPacket(pkt, len, a, PORT)) } catch (_: Exception) {}
        }
    }

    private fun connect() {
        if (!hasMic()) { askPermissions(); toast("Mic permission دیں"); return }
        connected = true
        btnConnect.text = "⛔ DISCONNECT"
        setColor(btnConnect, Color.parseColor("#B03A2E"))
        try {
            mcLock = wifi.createMulticastLock("msf").also { it.setReferenceCounted(false); it.acquire() }
        } catch (_: Exception) {}
        try {
            @Suppress("DEPRECATION")
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                       else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock = wifi.createWifiLock(mode, "msf").also { it.setReferenceCounted(false); it.acquire() }
        } catch (_: Exception) {}
        peers.clear()
        refreshStatus()

        Thread {
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                s.broadcast = true
                s.bind(InetSocketAddress(PORT))
                s.soTimeout = 250
                socket = s

                val fmt = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                val minBuf = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT)
                val at = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(maxOf(minBuf, FRAME * 2 * 25))
                    .setTransferMode(AudioTrack.MODE_STREAM).build()
                track = at

                // hello beacon: ہر سیکنڈ اپنا پتہ بتاتا ہے تاکہ فون ایک دوسرے کو پہچانیں
                Thread {
                    val hb = ByteArray(6)
                    hb[0] = 'H'.code.toByte()
                    ByteBuffer.wrap(hb).order(ByteOrder.LITTLE_ENDIAN).putInt(2, myId)
                    while (connected && !s.isClosed) {
                        try {
                            val dests = mutableListOf<InetAddress>()
                            dests.addAll(broadcastAddrs())
                            gatewayAddr()?.let { dests.add(it) }
                            for (a in dests) {
                                try { s.send(DatagramPacket(hb, hb.size, a, PORT)) } catch (_: Exception) {}
                            }
                            Thread.sleep(1000)
                        } catch (_: Exception) { break }
                    }
                }.start()

                val fx = RadioFx()
                var rxActive = false
                var started = false
                val pre = ArrayList<ShortArray>()
                val buf = ByteArray(2048)
                val dp = DatagramPacket(buf, buf.size)
                val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)

                while (connected) {
                    dp.length = buf.size
                    try { s.receive(dp) }
                    catch (e: java.net.SocketTimeoutException) {
                        if (rxActive) {                        // بات ختم
                            rxActive = false
                            if (!started) {
                                for (x in pre) at.write(x, 0, FRAME)
                                pre.clear()
                                at.play()
                            }
                            started = false
                            val q = RadioFx.squelch()
                            if (recording) writeRec(q)
                            at.write(q, 0, q.size)
                            try { at.stop() } catch (_: Exception) {}
                        }
                        continue
                    } catch (e: Exception) { break }

                    if (bb.getInt(2) == myId) continue          // میری اپنی آواز
                    val src = dp.address?.hostAddress ?: continue
                    if (buf[0] == 'H'.code.toByte() && dp.length == 6) {
                        peers[src] = System.currentTimeMillis()
                        continue
                    }
                    if (dp.length != PACKET || buf[0] != 'M'.code.toByte()) continue
                    peers[src] = System.currentTimeMillis()

                    // ہاٹ اسپاٹ والا فون باقی سب فونوں تک آواز آگے بھیجتا ہے
                    if (gatewayAddr() == null) {
                        for (a in targets()) {
                            if (a.hostAddress != src) {
                                try { s.send(DatagramPacket(buf, dp.length, a, PORT)) } catch (_: Exception) {}
                            }
                        }
                    }

                    if (buf[1].toInt() != group) continue       // دوسرا گروپ
                    if (transmitting) continue                  // بولتے وقت نہیں سنتے
                    if (!rxActive) {
                        rxActive = true
                        started = false
                        pre.clear()
                        val q = RadioFx.squelch()
                        if (recording) writeRec(q)
                        at.write(q, 0, q.size)
                    }
                    val f = ShortArray(FRAME)
                    for (i in 0 until FRAME) f[i] = bb.getShort(HEADER + i * 2)
                    fx.process(f)
                    if (recording) writeRec(f)                  // سامنے والے کی آواز ریکارڈ
                    if (!started) {
                        pre.add(f)
                        if (pre.size >= 4) {                    // 80 ms بفر، پھر چلاؤ
                            for (x in pre) at.write(x, 0, FRAME)
                            pre.clear()
                            at.play()
                            started = true
                        }
                    } else {
                        at.write(f, 0, FRAME)
                    }
                    ui.post {
                        tvRx.text = "🔊 RX …"
                        ui.removeCallbacks(clearRx)
                        ui.postDelayed(clearRx, 400)
                    }
                }
            } catch (e: Exception) {
                ui.post { toast("Connect error: ${e.message}"); disconnect() }
            }
        }.start()
    }

    private val clearRx = Runnable { tvRx.text = " " }

    private fun disconnect() {
        connected = false
        transmitting = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        track = null
        try { mcLock?.release() } catch (_: Exception) {}
        try { wifiLock?.release() } catch (_: Exception) {}
        btnConnect.text = "📻 CONNECT"
        setColor(btnConnect, Color.parseColor("#1F8A4C"))
        refreshStatus()
    }

    // ---------------------------------------------------------------- PTT

    private fun startTx() {
        if (!connected) { toast("پہلے CONNECT دبائیں"); return }
        if (!hasMic()) { askPermissions(); return }
        if (transmitting) return
        transmitting = true
        setColor(btnPtt, Color.parseColor("#D62828"))
        btnPtt.text = "🎙️ TALKING…"
        try { tone.startTone(ToneGenerator.TONE_PROP_BEEP, 80) } catch (_: Exception) {}

        Thread {
            try { Thread.sleep(130) } catch (_: Exception) {}   // بیپ مائیک میں نہ جائے
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, FRAME * 2 * 8))
            } catch (e: SecurityException) { transmitting = false; return@Thread }
            rec.startRecording()

            val pcm = ShortArray(FRAME)
            val pkt = ByteArray(PACKET)
            val bb = ByteBuffer.wrap(pkt).order(ByteOrder.LITTLE_ENDIAN)
            pkt[0] = 'M'.code.toByte()
            bb.putInt(2, myId)
            val txFx = RadioFx()
            val s = socket

            while (transmitting && s != null && !s.isClosed) {
                var read = 0
                while (read < FRAME && transmitting) {
                    val r = rec.read(pcm, read, FRAME - read)
                    if (r <= 0) break
                    read += r
                }
                if (read < FRAME) break
                pkt[1] = group.toByte()
                for (i in 0 until FRAME) bb.putShort(HEADER + i * 2, pcm[i])
                sendPkt(s, pkt, PACKET)
                if (recording) { val cp = pcm.copyOf(); txFx.process(cp); writeRec(cp) }
            }
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
        }.start()
    }

    private fun stopTx() {
        if (!transmitting) return
        transmitting = false
        setColor(btnPtt, Color.parseColor("#394650"))
        btnPtt.text = "🎙️ PTT\nدبا کر بات کریں"
        try { tone.startTone(ToneGenerator.TONE_PROP_ACK, 80) } catch (_: Exception) {}
    }

    // ---------------------------------------------------------- recording

    private fun recDir(): File =
        getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC) ?: filesDir

    private fun wavHeader(dataLen: Long): ByteArray {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt((36 + dataLen).toInt())
        b.put("WAVE".toByteArray()); b.put("fmt ".toByteArray())
        b.putInt(16); b.putShort(1); b.putShort(1)
        b.putInt(RATE); b.putInt(RATE * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataLen.toInt())
        return b.array()
    }

    private fun startRec() {
        if (recording) return
        synchronized(recLock) {
            val f = File(recDir(), "MSF_${System.currentTimeMillis()}.wav")
            val s = FileOutputStream(f)
            s.write(wavHeader(0))
            recFile = f; recStream = s; recBytes = 0
            recording = true
        }
        btnRec.text = "🔴 REC…"
        toast("ریکارڈنگ شروع")
    }

    private fun writeRec(pcm: ShortArray) {
        synchronized(recLock) {
            val s = recStream ?: return
            val bb = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (v in pcm) bb.putShort(v)
            try { s.write(bb.array()); recBytes += pcm.size * 2 } catch (_: Exception) {}
        }
    }

    private fun stopRec() {
        synchronized(recLock) {
            if (!recording) return
            recording = false
            try { recStream?.flush(); recStream?.close() } catch (_: Exception) {}
            recStream = null
            recFile?.let { f ->
                try {
                    RandomAccessFile(f, "rw").use { it.seek(0); it.write(wavHeader(recBytes)) }
                } catch (_: Exception) {}
            }
        }
        btnRec.text = "🔴 REC"
        exportToMusic(recFile)
        toast(if (folderUri != null) "محفوظ: آپ کے چنے ہوئے فولڈر میں" else "محفوظ: Music/MSFWireless/${recFile?.name}")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (_: Exception) {}
            folderUri = uri
            getSharedPreferences("msf", 0).edit().putString("folder", uri.toString()).apply()
            btnFolder.text = "📁 FOLDER ✓"
            val name = try {
                DocumentsContract.getTreeDocumentId(uri).substringAfter(':')
            } catch (_: Exception) { "" }
            toast("ریکارڈنگ اب یہاں محفوظ ہوگی: $name")
        }
    }

    private fun saveToChosenFolder(f: File): Boolean {
        val tree = folderUri ?: return false
        return try {
            val docId = DocumentsContract.getTreeDocumentId(tree)
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
            val doc = DocumentsContract.createDocument(contentResolver, parent, "audio/x-wav", f.name)
                ?: return false
            contentResolver.openOutputStream(doc)?.use { out ->
                FileInputStream(f).use { it.copyTo(out) }
            }
            true
        } catch (_: Exception) { false }
    }

    private fun exportToMusic(f: File?) {
        if (f == null) return
        if (saveToChosenFolder(f)) return
        if (Build.VERSION.SDK_INT < 29) return
        try {
            val v = android.content.ContentValues()
            v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "audio/wav")
            v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Music/MSFWireless")
            val uri = contentResolver.insert(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v) ?: return
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(f).use { it.copyTo(out) }
            }
        } catch (_: Exception) {}
    }

    private fun stopAll() {
        stopRec()
        playing = false
    }

    private fun play() {
        if (recording) stopRec()
        if (playing) return
        val f = recFile ?: recDir().listFiles { x -> x.name.startsWith("MSF_") }
            ?.maxByOrNull { it.lastModified() }
        if (f == null || !f.exists()) { toast("کوئی ریکارڈنگ نہیں"); return }
        playing = true
        Thread {
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            val at = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(RATE * 2)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            at.play()
            try {
                FileInputStream(f).use {
                    it.skip(44)
                    val b = ByteArray(1600)
                    while (playing) {
                        val n = it.read(b)
                        if (n <= 0) break
                        at.write(b, 0, n)
                    }
                }
            } catch (_: Exception) {}
            try { at.stop() } catch (_: Exception) {}
            at.release()
            playing = false
        }.start()
    }

    // ------------------------------------------------------------ hotspot

    @Suppress("DEPRECATION")
    private fun toggleHotspot() {
        if (hsRes != null) {
            hsRes?.close(); hsRes = null
            btnHotspot.text = "📡 HOTSPOT"
            toast("Hotspot بند")
            return
        }
        try {
            wifi.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    hsRes = r
                    var ssid = ""
                    var pass = ""
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration
                        ssid = c.ssid ?: ""; pass = c.passphrase ?: ""
                    } else {
                        val c = r.wifiConfiguration
                        ssid = c?.SSID ?: ""; pass = c?.preSharedKey ?: ""
                    }
                    ui.post {
                        btnHotspot.text = "📡 HOTSPOT ON"
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("📡 Hotspot چالو")
                            .setMessage("نام: $ssid\nپاس ورڈ: $pass\n\nدوسرے موبائل کے Wi-Fi میں یہی نام منتخب کر کے پاس ورڈ ڈالیں، پھر وہاں CONNECT دبائیں۔")
                            .setPositiveButton("OK", null).show()
                        if (!connected) connect()
                    }
                }
                override fun onStopped() { hsRes = null }
                override fun onFailed(reason: Int) { ui.post { openTether() } }
            }, ui)
        } catch (e: Exception) {
            openTether()
        }
    }

    private fun openTether() {
        toast("Hotspot خود چالو کریں، پھر CONNECT دبائیں")
        try {
            startActivity(Intent("android.settings.TETHER_SETTINGS"))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }
    }

    override fun onDestroy() {
        stopAll()
        disconnect()
        hsRes?.close()
        super.onDestroy()
    }
}
