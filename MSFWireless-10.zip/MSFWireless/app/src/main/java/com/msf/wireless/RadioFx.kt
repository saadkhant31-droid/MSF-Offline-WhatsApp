package com.msf.wireless

import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

/** Radio voice styles: 0 POLICE/CB, 1 DIGITAL, 2 ARMY, 3 ROBOT. */
class RadioFx {
    private var hpIn = 0f
    private var hpOut = 0f
    private var lp1 = 0f
    private var lp2 = 0f
    private var n = 0L

    private class P(
        val hp: Float, val lp: Float, val drive: Float,
        val levels: Float, val noise: Float, val ring: Float, val gain: Float
    )

    fun process(buf: ShortArray) {
        val p = PARAMS[style.coerceIn(0, PARAMS.size - 1)]
        for (i in buf.indices) {
            val x = buf[i] / 32768f
            val hp = p.hp * (hpOut + x - hpIn)
            hpIn = x
            hpOut = hp
            lp1 += p.lp * (hp - lp1)
            lp2 += p.lp * (lp1 - lp2)
            var y = tanh(lp2 * p.drive)
            if (p.levels > 0f) y = Math.round(y * p.levels) / p.levels
            if (p.ring > 0f) {
                val m = sin(2.0 * PI * p.ring * n / MainActivity.RATE).toFloat()
                y *= (0.35f + 0.65f * m)
            }
            n++
            y += (Random.nextFloat() - 0.5f) * p.noise
            val v = (y * p.gain * 32767f).toInt().coerceIn(-32768, 32767)
            buf[i] = v.toShort()
        }
    }

    companion object {
        @Volatile var style = 0
        val NAMES = arrayOf("POLICE", "DIGITAL", "ARMY", "ROBOT")

        private val PARAMS = arrayOf(
            P(0.68f, 0.52f, 8.0f, 16f, 0.09f, 0f, 0.90f),   // POLICE / CB: thin, harsh, lots of static
            P(0.81f, 0.66f, 2.5f, 0f, 0.012f, 0f, 0.85f),   // DIGITAL: light radio
            P(0.80f, 0.45f, 6.0f, 32f, 0.04f, 0f, 0.90f),   // ARMY: muffled, heavy
            P(0.76f, 0.60f, 3.0f, 0f, 0.015f, 60f, 0.90f)   // ROBOT: ring-mod
        )

        /** "kshh" squelch burst at start/end of a transmission. */
        fun squelch(): ShortArray {
            val len = 720
            val out = ShortArray(len)
            val a0 = if (style == 0) 0.45f else 0.30f
            var lp = 0f
            for (i in 0 until len) {
                val amp = a0 * (1f - i / len.toFloat())
                val noise = (Random.nextFloat() - 0.5f) * 2f
                lp += 0.55f * (noise - lp)
                out[i] = (lp * amp * 32767f).toInt().toShort()
            }
            return out
        }
    }
}
