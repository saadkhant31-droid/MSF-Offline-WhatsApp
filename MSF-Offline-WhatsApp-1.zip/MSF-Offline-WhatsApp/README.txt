MSF Offline WhatsApp v2
- Chats (text, photos, videos, voice messages, audio, documents/any file), groups, status (text/photo/video/voice/audio),
  audio + video calls (front/back camera, mute, speaker), call history, block, profile photo, settings.
- Works over a phone hotspot or the same Wi-Fi. No internet needed.

Setup
1. Phone 1: turn on Hotspot, open the app, tap Host.
2. Other phones: join that hotspot, open the app, enter Phone 1's IP (shown on Phone 1), tap Join.
3. Keep the app open on all phones.

Build: open in Android Studio, or push the zip to GitHub and run the "Build APK" workflow.
