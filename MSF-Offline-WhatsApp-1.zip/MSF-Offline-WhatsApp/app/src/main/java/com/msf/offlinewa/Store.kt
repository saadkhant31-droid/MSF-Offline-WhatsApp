package com.msf.offlinewa

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Contact(val uid: String, val name: String, val about: String, val avatar: String, val blocked: Boolean)
data class Group(val gid: String, val name: String, val members: List<String>)

/** kind: text, image, video, audio, voice, file. state: done, sending, downloading. */
data class Msg(
    val id: String, val chat: String, val from: String, val ts: Long,
    val kind: String, val text: String, val name: String, val path: String,
    val size: Long, val dur: Long, val state: String
)

data class CallRec(val peer: String, val video: Boolean, val dir: String, val ts: Long, val secs: Int)
data class Status(val id: String, val from: String, val ts: Long, val kind: String, val text: String, val path: String, val color: Long)

class Snapshot(
    val contacts: List<Contact>, val groups: List<Group>, val msgs: List<Msg>,
    val calls: List<CallRec>, val statuses: List<Status>
)

class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("msf2", Context.MODE_PRIVATE)
    private val file = File(ctx.filesDir, "data.json")
    val dir: File = File(ctx.filesDir, "media").also { it.mkdirs() }
    val avatarFile: File = File(ctx.filesDir, "avatar.jpg")

    val uid: String = prefs.getString("uid", null) ?: UUID.randomUUID().toString().also {
        prefs.edit().putString("uid", it).apply()
    }
    var myName: String
        get() = prefs.getString("name", "Me") ?: "Me"
        set(v) { prefs.edit().putString("name", v).apply() }
    var myAbout: String
        get() = prefs.getString("about", "Hey there! I am using MSF Offline WhatsApp") ?: ""
        set(v) { prefs.edit().putString("about", v).apply() }
    var myAvatarThumb: String
        get() = prefs.getString("thumb", "") ?: ""
        set(v) { prefs.edit().putString("thumb", v).apply() }
    var lastIp: String
        get() = prefs.getString("ip", "192.168.43.1") ?: "192.168.43.1"
        set(v) { prefs.edit().putString("ip", v).apply() }

    fun save(contacts: List<Contact>, groups: List<Group>, msgs: List<Msg>, calls: List<CallRec>, statuses: List<Status>) {
        try {
            val o = JSONObject()
            o.put("contacts", JSONArray().also { a ->
                contacts.forEach { a.put(JSONObject().put("u", it.uid).put("n", it.name).put("a", it.about).put("p", it.avatar).put("b", it.blocked)) }
            })
            o.put("groups", JSONArray().also { a ->
                groups.forEach { a.put(JSONObject().put("g", it.gid).put("n", it.name).put("m", JSONArray(it.members))) }
            })
            o.put("msgs", JSONArray().also { a ->
                msgs.takeLast(2000).forEach {
                    a.put(JSONObject().put("i", it.id).put("c", it.chat).put("f", it.from).put("t", it.ts).put("k", it.kind)
                        .put("x", it.text).put("n", it.name).put("p", it.path).put("s", it.size).put("d", it.dur)
                        .put("st", if (it.state == "done") "done" else "failed"))
                }
            })
            o.put("calls", JSONArray().also { a ->
                calls.takeLast(300).forEach {
                    a.put(JSONObject().put("p", it.peer).put("v", it.video).put("d", it.dir).put("t", it.ts).put("s", it.secs))
                }
            })
            o.put("statuses", JSONArray().also { a ->
                statuses.takeLast(200).forEach {
                    a.put(JSONObject().put("i", it.id).put("f", it.from).put("t", it.ts).put("k", it.kind)
                        .put("x", it.text).put("p", it.path).put("c", it.color))
                }
            })
            file.writeText(o.toString())
        } catch (e: Exception) {}
    }

    fun load(): Snapshot {
        try {
            if (!file.exists()) return Snapshot(emptyList(), emptyList(), emptyList(), emptyList(), emptyList())
            val o = JSONObject(file.readText())
            val contacts = ArrayList<Contact>()
            o.optJSONArray("contacts")?.let { a ->
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    contacts.add(Contact(j.getString("u"), j.optString("n"), j.optString("a"), j.optString("p"), j.optBoolean("b")))
                }
            }
            val groups = ArrayList<Group>()
            o.optJSONArray("groups")?.let { a ->
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    val m = j.getJSONArray("m")
                    groups.add(Group(j.getString("g"), j.optString("n"), (0 until m.length()).map { m.getString(it) }))
                }
            }
            val msgs = ArrayList<Msg>()
            o.optJSONArray("msgs")?.let { a ->
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    msgs.add(Msg(j.getString("i"), j.getString("c"), j.getString("f"), j.getLong("t"), j.getString("k"),
                        j.optString("x"), j.optString("n"), j.optString("p"), j.optLong("s"), j.optLong("d"), j.optString("st", "done")))
                }
            }
            val calls = ArrayList<CallRec>()
            o.optJSONArray("calls")?.let { a ->
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    calls.add(CallRec(j.getString("p"), j.optBoolean("v"), j.optString("d"), j.getLong("t"), j.optInt("s")))
                }
            }
            val statuses = ArrayList<Status>()
            o.optJSONArray("statuses")?.let { a ->
                for (i in 0 until a.length()) {
                    val j = a.getJSONObject(i)
                    statuses.add(Status(j.getString("i"), j.getString("f"), j.getLong("t"), j.getString("k"), j.optString("x"), j.optString("p"), j.optLong("c")))
                }
            }
            return Snapshot(contacts, groups, msgs, calls, statuses)
        } catch (e: Exception) {
            return Snapshot(emptyList(), emptyList(), emptyList(), emptyList(), emptyList())
        }
    }
}
