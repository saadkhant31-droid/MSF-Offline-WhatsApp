package com.msf.offlinewa

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

val Bg = Color(0xFF0B141A)
val Panel = Color(0xFF202C33)
val Green = Color(0xFF21C063)
val Out = Color(0xFF144D37)
val Sub = Color(0xFF8696A0)
val Red = Color(0xFFE5484D)
val OnGreen = Color(0xFF06210F)

fun fmt(ts: Long): String {
    val d = Date(ts)
    val day = SimpleDateFormat("yyyyMMdd", Locale.US)
    return if (day.format(d) == day.format(Date())) SimpleDateFormat("h:mm a", Locale.getDefault()).format(d)
    else SimpleDateFormat("dd/MM/yyyy, h:mm a", Locale.getDefault()).format(d)
}
fun timeOf(ts: Long): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(ts))
fun dur(s: Int) = "%d:%02d".format(s / 60, s % 60)
fun durMs(ms: Long) = dur((ms / 1000).toInt())
fun sizeText(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1048576 -> "${b / 1024} KB"
    else -> "%.1f MB".format(b / 1048576.0)
}

fun previewOf(m: Model, x: Msg?): String {
    if (x == null) return "Tap to chat"
    val pre = when {
        x.from == m.myUid -> "You: "
        x.chat.startsWith("g:") -> m.nameOf(x.from) + ": "
        else -> ""
    }
    val body = when (x.kind) {
        "text" -> x.text
        "image" -> "📷 Photo"
        "video" -> "🎥 Video"
        "voice" -> "🎤 Voice message"
        "audio" -> "🎵 " + x.name
        else -> "📄 " + x.name
    }
    return pre + body
}

@Composable
fun Logo(size: Dp) = Image(
    painterResource(R.drawable.logo), "MSF Offline WhatsApp",
    Modifier.size(size).clip(CircleShape)
)

@Composable
fun Av(m: Model, id: String, size: Dp) {
    when {
        id == m.myUid -> {
            val b = m.myAvatar
            if (b != null) Image(b, null, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
            else Logo(size)
        }
        id.startsWith("g:") -> Box(
            Modifier.size(size).clip(CircleShape).background(Color(0xFF3B4A54)),
            contentAlignment = Alignment.Center
        ) { Text("👥", fontSize = (size.value * 0.45f).sp) }
        else -> {
            val c = m.contacts.firstOrNull { it.uid == id }
            val bmp = remember(c?.avatar) { FileUtil.b64ToBitmap(c?.avatar ?: "") }
            if (bmp != null) Image(bmp, null, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
            else {
                val colors = listOf(0xFF7A3F2E, 0xFF2E5F7A, 0xFF5B3F7A, 0xFF3F7A5B, 0xFF7A6A2E, 0xFF7A2E4F)
                Box(
                    Modifier.size(size).clip(CircleShape).background(Color(colors[(id.hashCode() and 0x7fffffff) % 6])),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        (c?.name?.firstOrNull() ?: '?').uppercase(), color = Color.White,
                        fontSize = (size.value * 0.4f).sp, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun Root(m: Model) {
    var screen by remember { mutableStateOf("connect") }
    var tab by remember { mutableIntStateOf(0) }
    val goChat: (String) -> Unit = { id -> m.openChat = id; m.unread.remove(id); screen = "chat" }
    BackHandler(screen != "main" && screen != "connect" && m.callState == "idle") {
        screen = if (screen == "newgroup") "contacts" else if (screen == "blocked") "settings" else "main"
        if (screen == "main") m.openChat = null
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Panel, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
                when (screen) {
                    "connect" -> ConnectScreen(m) { screen = "main" }
                    "main" -> MainScreen(m, tab, { tab = it }, { screen = it }, goChat)
                    "chat" -> ChatScreen(m, m.openChat ?: "") { m.openChat = null; screen = "main" }
                    "contacts" -> ContactsScreen(m, { screen = "main" }, { screen = "newgroup" }, goChat)
                    "newgroup" -> NewGroupScreen(m, { screen = "contacts" }, goChat)
                    "settings" -> SettingsScreen(m, { screen = "main" }, { screen = it })
                    "blocked" -> BlockedScreen(m) { screen = "settings" }
                }
                m.viewer?.let { MediaViewer(m, it) }
                m.statusList?.let { StatusViewer(m, it) }
                if (m.callState != "idle") CallScreen(m)
            }
        }
    }
}

@Composable
fun ConnectScreen(m: Model, done: () -> Unit) {
    var ip by remember { mutableStateOf(m.store.lastIp) }
    val ips = remember { localIps() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Logo(120.dp)
        Text("MSF Offline WhatsApp", fontSize = 24.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Your IP: " + if (ips.isEmpty()) "not on any network" else ips.joinToString(", "), color = Sub)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Phone 1: turn on Hotspot, then tap Host. Everyone else joins this phone.", color = Color.White)
                Button(onClick = { m.host(); done() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Host", color = OnGreen) }
            }
        }
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Other phones: join Phone 1's hotspot (or the same Wi-Fi), enter Phone 1's IP, tap Join", color = Color.White)
                OutlinedTextField(ip, { ip = it }, label = { Text("Host IP") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = { m.join(ip); done() }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Join", color = OnGreen) }
            }
        }
        TextButton(onClick = done) { Text("Open app", color = Green) }
        Text(m.state, color = Sub)
    }
}

@Composable
fun MainScreen(m: Model, tab: Int, setTab: (Int) -> Unit, go: (String) -> Unit, goChat: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var newStatus by remember { mutableStateOf(false) }
    val titles = listOf("MSF Offline WhatsApp", "Updates", "Calls", "You")
    val totalUnread = m.unread.values.sum()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, top = 12.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(titles[tab], fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
            Box {
                TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 24.sp, color = Color.White) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("New group") }, onClick = { menu = false; go("newgroup") })
                    DropdownMenuItem(text = { Text("Connection") }, onClick = { menu = false; go("connect") })
                    DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; go("settings") })
                }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> ChatsTab(m, goChat)
                1 -> UpdatesTab(m) { newStatus = true }
                2 -> CallsTab(m)
                else -> YouTab(m, { go("settings") }, { go("connect") })
            }
            if (tab != 3) {
                Button(
                    onClick = { if (tab == 1) newStatus = true else go("contacts") },
                    shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Green),
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp).size(60.dp)
                ) { Text(if (tab == 0) "＋" else if (tab == 1) "✎" else "📞", fontSize = 24.sp, color = OnGreen) }
            }
        }
        Row(Modifier.fillMaxWidth().background(Bg).padding(vertical = 8.dp)) {
            listOf("💬" to "Chats", "◎" to "Updates", "📞" to "Calls", "👤" to "You").forEachIndexed { i, (ic, label) ->
                Column(Modifier.weight(1f).clickable { setTab(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.clip(RoundedCornerShape(16.dp)).background(if (tab == i) Out else Color.Transparent)
                            .padding(horizontal = 20.dp, vertical = 4.dp)
                    ) { Text(ic, fontSize = 20.sp) }
                    Text(
                        if (i == 0 && totalUnread > 0) "$label ($totalUnread)" else label,
                        fontSize = 12.sp, color = if (tab == i) Color.White else Sub
                    )
                }
            }
        }
    }
    if (newStatus) NewStatusDialog(m) { newStatus = false }
}

@Composable
fun ChatsTab(m: Model, open: (String) -> Unit) {
    val ids = (m.msgs.map { it.chat } + m.groups.map { it.gid }).distinct()
        .sortedByDescending { id -> m.msgs.lastOrNull { it.chat == id }?.ts ?: 0L }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            val ok = m.linked
            Card(Modifier.fillMaxWidth().padding(14.dp), colors = CardDefaults.cardColors(containerColor = if (ok) Out else Panel)) {
                Text(
                    m.state + if (ok) "  ·  ${m.online.size} online" else "",
                    color = if (ok) Color.White else Sub, modifier = Modifier.padding(14.dp)
                )
            }
        }
        if (ids.isEmpty()) item {
            Text("No chats yet. Tap ＋ to message a friend or start a group.", color = Sub, modifier = Modifier.padding(20.dp))
        }
        items(ids) { id ->
            val last = m.msgs.lastOrNull { it.chat == id }
            val n = m.unread[id] ?: 0
            Row(Modifier.fillMaxWidth().clickable { open(id) }.padding(horizontal = 16.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Av(m, id, 52.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(m.nameOf(id), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(
                        if (!id.startsWith("g:") && m.isBlocked(id)) "Blocked" else previewOf(m, last),
                        color = Sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    if (last != null) Text(fmt(last.ts), color = if (n > 0) Green else Sub, fontSize = 12.sp)
                    if (n > 0) Box(Modifier.padding(top = 4.dp).clip(CircleShape).background(Green).padding(horizontal = 7.dp, vertical = 2.dp)) {
                        Text("$n", color = OnGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CallsTab(m: Model) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Text("Recent", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
            if (m.calls.isEmpty()) Text("No calls yet. Tap 📞 to call a friend.", color = Sub, modifier = Modifier.padding(horizontal = 16.dp))
        }
        items(m.calls.sortedByDescending { it.ts }) { c ->
            Row(Modifier.fillMaxWidth().clickable { m.startCall(c.peer, c.video) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Av(m, c.peer, 46.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(m.nameOf(c.peer), color = if (c.dir == "missed") Red else Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    val arrow = when (c.dir) { "out" -> "↗ Outgoing"; "in" -> "↙ Incoming"; else -> "↙ Missed" }
                    Text("$arrow  ·  ${fmt(c.ts)}" + if (c.secs > 0) "  ·  ${dur(c.secs)}" else "", color = Sub, fontSize = 13.sp)
                }
                Text(if (c.video) "🎥" else "📞", fontSize = 22.sp)
            }
        }
    }
}

@Composable
fun YouTab(m: Model, settings: () -> Unit, connection: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Av(m, m.myUid, 120.dp)
        Text(m.myName, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text(m.myAbout, color = Sub, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp))
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().clickable { settings() }.padding(20.dp)) {
            Text("⚙", fontSize = 22.sp, color = Color.White)
            Spacer(Modifier.width(18.dp))
            Column {
                Text("Settings", color = Color.White, fontSize = 17.sp)
                Text("Profile photo, name, privacy, storage", color = Sub, fontSize = 14.sp)
            }
        }
        Row(Modifier.fillMaxWidth().clickable { connection() }.padding(20.dp)) {
            Text("📶", fontSize = 22.sp, color = Color.White)
            Spacer(Modifier.width(18.dp))
            Column {
                Text("Connection", color = Color.White, fontSize = 17.sp)
                Text(m.state, color = Sub, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun ContactsScreen(m: Model, back: () -> Unit, newGroup: () -> Unit, open: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("←", fontSize = 22.sp, color = Color.White) }
            Text("Select contact", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Row(Modifier.fillMaxWidth().clickable { newGroup() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Av(m, "g:new", 46.dp)
                    Spacer(Modifier.width(14.dp))
                    Text("New group", color = Color.White, fontSize = 17.sp)
                }
                if (m.contacts.isEmpty()) Text(
                    "No contacts yet. Friends appear here after they join the same host.",
                    color = Sub, modifier = Modifier.padding(16.dp)
                )
            }
            items(m.contacts.toList()) { c ->
                val on = m.online[c.uid] == true
                Row(Modifier.fillMaxWidth().clickable { open(c.uid) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Av(m, c.uid, 46.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (c.blocked) "Blocked" else if (on) "online" else "offline", color = if (on && !c.blocked) Green else Sub, fontSize = 13.sp)
                    }
                    TextButton({ m.startCall(c.uid, false) }) { Text("📞", fontSize = 22.sp) }
                    TextButton({ m.startCall(c.uid, true) }) { Text("🎥", fontSize = 22.sp) }
                }
            }
        }
    }
}

@Composable
fun NewGroupScreen(m: Model, back: () -> Unit, open: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    val picked = remember { mutableStateListOf<String>() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("←", fontSize = 22.sp, color = Color.White) }
            Text("New group", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        OutlinedTextField(name, { name = it }, label = { Text("Group name") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        Text("Add members", color = Sub, modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(m.contacts.filter { !it.blocked }) { c ->
                Row(
                    Modifier.fillMaxWidth().clickable { if (c.uid in picked) picked.remove(c.uid) else picked.add(c.uid) }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(c.uid in picked, { if (it) picked.add(c.uid) else picked.remove(c.uid) })
                    Av(m, c.uid, 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(c.name, color = Color.White, fontSize = 16.sp)
                }
            }
        }
        Button(
            onClick = {
                if (name.isBlank()) m.toast("Enter a group name")
                else if (picked.isEmpty()) m.toast("Pick at least one member")
                else open(m.createGroup(name, picked.toList()))
            },
            colors = ButtonDefaults.buttonColors(containerColor = Green),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) { Text("Create group", color = OnGreen) }
    }
}

@Composable
fun BlockedScreen(m: Model, back: () -> Unit) {
    val list = m.contacts.filter { it.blocked }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("←", fontSize = 22.sp, color = Color.White) }
            Text("Blocked contacts", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        if (list.isEmpty()) Text("No blocked contacts.", color = Sub, modifier = Modifier.padding(16.dp))
        LazyColumn {
            items(list) { c ->
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Av(m, c.uid, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(c.name, color = Color.White, fontSize = 17.sp, modifier = Modifier.weight(1f))
                    TextButton({ m.toggleBlock(c.uid) }) { Text("Unblock", color = Green) }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(m: Model, back: () -> Unit, go: (String) -> Unit) {
    var name by remember { mutableStateOf(m.myName) }
    var about by remember { mutableStateOf(m.myAbout) }
    var confirm by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("←", fontSize = 22.sp, color = Color.White) }
            Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.clickable { m.act.pick("image") { m.setAvatar(it) } }) { Av(m, m.myUid, 120.dp) }
            Row {
                TextButton({ m.act.pick("image") { m.setAvatar(it) } }) { Text("Change photo", color = Green) }
                TextButton({ m.removeAvatar() }) { Text("Remove", color = Red) }
            }
        }
        OutlinedTextField(name, { name = it }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(about, { about = it }, label = { Text("About") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button({ m.saveProfile(name, about); m.toast("Profile saved") }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Save profile", color = OnGreen) }
        HorizontalDivider(color = Panel)
        Row(Modifier.fillMaxWidth().clickable { go("blocked") }.padding(vertical = 12.dp)) {
            Text("🚫", fontSize = 20.sp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Blocked contacts", color = Color.White, fontSize = 16.sp)
                Text("${m.contacts.count { it.blocked }} blocked", color = Sub, fontSize = 13.sp)
            }
        }
        Row(Modifier.fillMaxWidth().clickable { go("connect") }.padding(vertical = 12.dp)) {
            Text("📶", fontSize = 20.sp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Connection", color = Color.White, fontSize = 16.sp)
                Text(m.state, color = Sub, fontSize = 13.sp)
            }
        }
        HorizontalDivider(color = Panel)
        OutlinedButton({ confirm = "chats" }) { Text("Clear all chats", color = Color.White) }
        OutlinedButton({ m.clearCalls(); m.toast("Call history cleared") }) { Text("Clear call history", color = Color.White) }
        OutlinedButton({ m.clearStatuses(); m.toast("Status updates cleared") }) { Text("Clear status updates", color = Color.White) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Logo(48.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("MSF Offline WhatsApp", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Version 2.0  ·  works on hotspot and Wi-Fi, no internet", color = Sub, fontSize = 12.sp)
            }
        }
    }
    if (confirm == "chats") AlertDialog(
        onDismissRequest = { confirm = "" },
        title = { Text("Clear all chats?") },
        text = { Text("All messages and received files in the app will be deleted.") },
        confirmButton = { TextButton({ m.clearAllChats(); confirm = "" }) { Text("Clear", color = Red) } },
        dismissButton = { TextButton({ confirm = "" }) { Text("Cancel") } }
    )
}
