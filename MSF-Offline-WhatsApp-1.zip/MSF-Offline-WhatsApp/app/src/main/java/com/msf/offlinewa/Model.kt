package com.msf.offlinewa

import android.Manifest
import android.content.Context
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ThreadLocalRandom
import kotlin.concurrent.thread

fun localIps(): List<String> = runCatching {
    NetworkInterface.getNetworkInterfaces().toList().flatMap { ni ->
        ni.inetAddresses.toList()
            .filter { !it.isLoopbackAddress && it is Inet4Address }
            .map { it.hostAddress ?: "" }
    }
}.getOrDefault(emptyList())

/** Something shown full screen: an image, a video, or a text status. */
data class Viewable(val kind: String, val path: String, val title: String, val text: String = "", val color: Long = 0L)

private class Incoming(
    val msgId: String, val ctx: String, val out: FileOutputStream, val file: File,
    val size: Long, val from: String, val kind: String, val name: String, val text: String
) {
    var got = 0L
    var lastUi = 0L
}

class Model(val act: MainActivity) : Net.Listener {
    val store = Store(act)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val myUid: String = store.uid
    val net = Net({ myUid }, this)
    val player = Player()
    val recorder = VoiceRecorder(act)

    var myName by mutableStateOf(store.myName)
    var myAbout by mutableStateOf(store.myAbout)
    var myAvatar by mutableStateOf<ImageBitmap?>(null)
    var state by mutableStateOf("Not connected")
    var linked by mutableStateOf(false)

    val contacts = mutableStateListOf<Contact>()
    val groups = mutableStateListOf<Group>()
    val msgs = mutableStateListOf<Msg>()
    val calls = mutableStateListOf<CallRec>()
    val statuses = mutableStateListOf<Status>()
    val online = mutableStateMapOf<String, Boolean>()
    val unread = mutableStateMapOf<String, Int>()
    val progress = mutableStateMapOf<String, Float>()
    var openChat by mutableStateOf<String?>(null)
    var viewer by mutableStateOf<Viewable?>(null)
    var statusList by mutableStateOf<List<Status>?>(null)
    var playingId by mutableStateOf<String?>(null)
    var playProgress by mutableFloatStateOf(0f)

    var callState by mutableStateOf("idle") // idle, ringing_out, ringing_in, active
    var callPeer by mutableStateOf("")
    var callVideo by mutableStateOf(false)
    var seconds by mutableIntStateOf(0)
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(false)
    var frontCam by mutableStateOf(true)
    var remoteFrame by mutableStateOf<ImageBitmap?>(null)
    var localFrame by mutableStateOf<ImageBitmap?>(null)

    private var outgoing = false
    private var callStart = 0L
    private var callToken = 0
    private var ticker: Job? = null
    private var playTicker: Job? = null
    private var saveJob: Job? = null
    private var audio: AudioEngine? = null
    private var video: VideoEngine? = null
    private var ringtone: Ringtone? = null
    private val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val incoming = ConcurrentHashMap<Long, Incoming>()

    init {
        val s = store.load()
        contacts.addAll(s.contacts)
        groups.addAll(s.groups)
        msgs.addAll(s.msgs)
        calls.addAll(s.calls)
        val cutoff = System.currentTimeMillis() - 24L * 3600 * 1000
        statuses.addAll(s.statuses.filter { it.ts > cutoff })
        loadAvatar()
    }

    private fun main(f: () -> Unit) { scope.launch { f() } }
    private fun now() = System.currentTimeMillis()
    private fun newId() = UUID.randomUUID().toString()
    fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    fun nameOf(id: String): String = when {
        id == myUid -> "You"
        id.startsWith("g:") -> groups.firstOrNull { it.gid == id }?.name ?: "Group"
        else -> contacts.firstOrNull { it.uid == id }?.name ?: "Unknown"
    }
    fun isBlocked(uid: String) = contacts.firstOrNull { it.uid == uid }?.blocked == true

    fun markDirty() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(600)
            val c = contacts.toList(); val g = groups.toList(); val m = msgs.toList()
            val ca = calls.toList(); val st = statuses.toList()
            withContext(Dispatchers.IO) { store.save(c, g, m, ca, st) }
        }
    }

    // ---------------- connection ----------------
    fun host() { net.host() }
    fun join(ip: String) { store.lastIp = ip.trim(); net.join(ip) }

    private fun helloJson() = JSONObject().put("n", myName).put("a", myAbout).put("p", store.myAvatarThumb).toString()
    override fun myHello() = Packet(T.HELLO, myUid, "*", helloJson().toByteArray())
    private fun broadcastHello() { net.send(myHello()) }

    override fun onState(s: String) {
        main {
            state = s
            linked = s == "Connected" || s.startsWith("Hosting")
            if (s == "Disconnected" || s.startsWith("Error") || s.startsWith("Could not")) {
                online.clear()
                if (callState != "idle") finishCall()
            }
        }
    }

    // ---------------- incoming packets ----------------
    override fun onPacket(p: Packet) {
        val from = p.from
        try {
            when (p.type) {
                T.HELLO -> {
                    val j = JSONObject(String(p.data))
                    main { upsertContact(from, j.optString("n", "?"), j.optString("a", ""), j.optString("p", "")) }
                }
                T.BYE -> main {
                    online.remove(from)
                    if (callState != "idle" && callPeer == from) finishCall()
                }
                else -> {
                    if (isBlocked(from)) {
                        if (p.type == T.CALL_REQ) net.send(Packet(T.CALL_REJ, myUid, from))
                    } else handle(p)
                }
            }
        } catch (e: Exception) { }
    }

    private fun handle(p: Packet) {
        val from = p.from
        when (p.type) {
            T.MSG -> {
                val j = JSONObject(String(p.data))
                val g = j.optString("g", "")
                val chat = if (g.isNotEmpty()) g else from
                val m = Msg(j.getString("id"), chat, from, now(), "text", j.getString("t"), "", "", 0, 0, "done")
                main { addIncoming(m) }
            }
            T.GROUP -> {
                val j = JSONObject(String(p.data))
                val arr = j.getJSONArray("m")
                val g = Group(j.getString("g"), j.optString("n", "Group"), (0 until arr.length()).map { arr.getString(it) })
                main {
                    val i = groups.indexOfFirst { it.gid == g.gid }
                    if (i >= 0) groups[i] = g else groups.add(g)
                    markDirty()
                }
            }
            T.FSTART -> startIncoming(from, JSONObject(String(p.data)))
            T.FCHUNK -> chunkIncoming(p.data)
            T.FEND -> endIncoming(p.data)
            T.STATUS -> {
                val j = JSONObject(String(p.data))
                val st = Status(j.getString("id"), from, now(), "text", j.optString("t"), "", j.optLong("c"))
                main { statuses.add(st); markDirty() }
            }
            T.CALL_REQ -> main {
                if (callState != "idle") net.send(Packet(T.CALL_REJ, myUid, from))
                else {
                    outgoing = false; callPeer = from
                    callVideo = p.data.isNotEmpty() && p.data[0].toInt() == 1
                    callState = "ringing_in"
                    startRing(); armTimeout()
                }
            }
            T.CALL_ACC -> main { if (callState == "ringing_out" && callPeer == from) beginMedia() }
            T.CALL_REJ, T.CALL_END -> main { if (callState != "idle" && callPeer == from) finishCall() }
            T.AUDIO -> if (callPeer == from) audio?.play(p.data)
            T.VIDEO -> if (callPeer == from) {
                val bmp = BitmapFactory.decodeByteArray(p.data, 0, p.data.size)
                if (bmp != null) main { remoteFrame = bmp.asImageBitmap() }
            }
        }
    }

    private fun upsertContact(uid: String, name: String, about: String, avatar: String) {
        if (uid == myUid) return
        val i = contacts.indexOfFirst { it.uid == uid }
        val c = Contact(uid, name, about, avatar, if (i >= 0) contacts[i].blocked else false)
        if (i >= 0) contacts[i] = c else contacts.add(c)
        online[uid] = true
        markDirty()
    }

    private fun addIncoming(m: Msg) {
        if (msgs.any { it.id == m.id }) return
        msgs.add(m)
        if (openChat != m.chat) unread[m.chat] = (unread[m.chat] ?: 0) + 1
        markDirty()
    }

    private fun updateMsg(id: String, f: (Msg) -> Msg) {
        val i = msgs.indexOfFirst { it.id == id }
        if (i >= 0) msgs[i] = f(msgs[i])
    }

    // ---------------- receiving files ----------------
    private fun startIncoming(from: String, j: JSONObject) {
        val fid = j.getLong("fid")
        val name = j.optString("name", "file")
        val f = File(store.dir, "${fid}_${FileUtil.safeName(name)}")
        val inc = Incoming(
            j.getString("id"), j.optString("ctx", "chat"), FileOutputStream(f), f,
            j.optLong("size"), from, j.optString("kind", "file"), name, j.optString("t", "")
        )
        incoming[fid] = inc
        if (inc.ctx == "chat") {
            val g = j.optString("g", "")
            val chat = if (g.isNotEmpty()) g else from
            val m = Msg(inc.msgId, chat, from, now(), inc.kind, inc.text, name, f.absolutePath, inc.size, j.optLong("dur"), "downloading")
            main { addIncoming(m) }
        }
    }

    private fun chunkIncoming(data: ByteArray) {
        if (data.size < 8) return
        val fid = ByteBuffer.wrap(data, 0, 8).long
        val inc = incoming[fid] ?: return
        try { inc.out.write(data, 8, data.size - 8) } catch (e: Exception) { return }
        inc.got += data.size - 8
        val t = now()
        if (t - inc.lastUi > 150 && inc.size > 0) {
            inc.lastUi = t
            val frac = (inc.got.toFloat() / inc.size).coerceIn(0f, 1f)
            main { progress[inc.msgId] = frac }
        }
    }

    private fun endIncoming(data: ByteArray) {
        if (data.size < 8) return
        val fid = ByteBuffer.wrap(data, 0, 8).long
        val inc = incoming.remove(fid) ?: return
        runCatching { inc.out.close() }
        main {
            progress.remove(inc.msgId)
            if (inc.ctx == "chat") {
                updateMsg(inc.msgId) { it.copy(state = "done") }
            } else {
                statuses.add(Status(inc.msgId, inc.from, now(), inc.kind, inc.text, inc.file.absolutePath, 0L))
            }
            markDirty()
        }
    }

    // ---------------- sending ----------------
    private fun recipients(chat: String): List<String> =
        if (chat.startsWith("g:")) (groups.firstOrNull { it.gid == chat }?.members ?: emptyList()).filter { it != myUid && online[it] == true && !isBlocked(it) }
        else listOf(chat)

    fun canSend(chat: String): Boolean {
        if (!linked) { toast("Not connected. Open Connection and tap Host or Join."); return false }
        if (chat.startsWith("g:")) {
            if (recipients(chat).isEmpty()) { toast("No group members are online"); return false }
            return true
        }
        if (isBlocked(chat)) { toast("Unblock this contact first"); return false }
        if (online[chat] != true) { toast("${nameOf(chat)} is offline"); return false }
        return true
    }

    fun sendText(chat: String, text: String) {
        val t = text.trim()
        if (t.isEmpty() || !canSend(chat)) return
        val id = newId()
        msgs.add(Msg(id, chat, myUid, now(), "text", t, "", "", 0, 0, "done"))
        markDirty()
        recipients(chat).forEach { u ->
            val j = JSONObject().put("id", id).put("t", t)
            if (chat.startsWith("g:")) j.put("g", chat)
            net.send(Packet(T.MSG, myUid, u, j.toString().toByteArray()))
        }
    }

    fun sendFile(chat: String, file: File, name: String, kind: String, dur: Long = 0, caption: String = "") {
        if (!canSend(chat)) return
        val id = newId()
        msgs.add(Msg(id, chat, myUid, now(), kind, caption, name, file.absolutePath, file.length(), dur, "sending"))
        markDirty()
        val targets = recipients(chat)
        thread {
            transfer(file, name, kind, dur, id, "chat", chat, caption, targets)
            main { updateMsg(id) { it.copy(state = "done") }; progress.remove(id); markDirty() }
        }
    }

    private fun transfer(file: File, name: String, kind: String, dur: Long, id: String, ctx: String,
                         chat: String, text: String, targets: List<String>) {
        val size = file.length()
        targets.forEachIndexed { ti, u ->
            val fid = ThreadLocalRandom.current().nextLong()
            val j = JSONObject().put("fid", fid).put("id", id).put("kind", kind).put("name", name)
                .put("size", size).put("dur", dur).put("ctx", ctx).put("t", text)
            if (chat.startsWith("g:")) j.put("g", chat)
            net.send(Packet(T.FSTART, myUid, u, j.toString().toByteArray()))
            try {
                FileInputStream(file).use { ins ->
                    val buf = ByteArray(60000)
                    var sent = 0L
                    var lastUi = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n <= 0) break
                        val data = ByteBuffer.allocate(8 + n).putLong(fid).put(buf, 0, n).array()
                        while (net.backlog(u) > 12 && net.connected) Thread.sleep(4)
                        net.send(Packet(T.FCHUNK, myUid, u, data))
                        sent += n
                        val t = now()
                        if (ti == 0 && size > 0 && t - lastUi > 150) {
                            lastUi = t
                            val frac = (sent.toFloat() / size).coerceIn(0f, 1f)
                            main { progress[id] = frac }
                        }
                    }
                }
            } catch (e: Exception) { }
            net.send(Packet(T.FEND, myUid, u, ByteBuffer.allocate(8).putLong(fid).array()))
        }
    }

    fun sendUri(chat: String, uri: Uri, forceKind: String? = null) {
        thread {
            val r = FileUtil.copyUri(act, uri, store.dir)
            if (r == null) { main { toast("Couldn't read this file") }; return@thread }
            val kind = forceKind ?: FileUtil.kindOf(act, uri, r.name)
            val dur = if (kind == "video" || kind == "audio") FileUtil.duration(r.file.absolutePath) else 0L
            main { sendFile(chat, r.file, r.name, kind, dur) }
        }
    }

    fun sendCaptured(chat: String, f: File, kind: String) {
        thread {
            val dest = File(store.dir, "${System.nanoTime()}_${f.name}")
            runCatching { f.copyTo(dest, true); f.delete() }
            val dur = if (kind == "video") FileUtil.duration(dest.absolutePath) else 0L
            main { sendFile(chat, dest, f.name, kind, dur) }
        }
    }

    fun newVoiceFile() = File(store.dir, "voice_${System.nanoTime()}.m4a")

    fun sendVoice(chat: String, f: File, dur: Long) = sendFile(chat, f, "Voice message.m4a", "voice", dur)

    fun clearChat(chat: String) {
        msgs.filter { it.chat == chat }.forEach { runCatching { File(it.path).delete() } }
        msgs.removeAll { it.chat == chat }
        markDirty()
    }

    fun toggleBlock(uid: String) {
        val i = contacts.indexOfFirst { it.uid == uid }
        if (i >= 0) { contacts[i] = contacts[i].copy(blocked = !contacts[i].blocked); markDirty() }
    }

    // ---------------- groups ----------------
    private fun groupJson(g: Group) =
        JSONObject().put("g", g.gid).put("n", g.name).put("m", JSONArray(g.members)).toString().toByteArray()

    fun createGroup(name: String, members: List<String>): String {
        val gid = "g:" + newId().take(8)
        val g = Group(gid, name.trim().ifEmpty { "New group" }, (members + myUid).distinct())
        groups.add(g)
        members.forEach { net.send(Packet(T.GROUP, myUid, it, groupJson(g))) }
        markDirty()
        return gid
    }

    fun deleteGroup(gid: String) {
        clearChat(gid)
        groups.removeAll { it.gid == gid }
        markDirty()
    }

    // ---------------- status ----------------
    private fun statusTargets() = contacts.filter { online[it.uid] == true && !it.blocked }.map { it.uid }

    fun postStatusText(text: String, color: Long) {
        val t = text.trim()
        if (t.isEmpty()) return
        val id = newId()
        statuses.add(Status(id, myUid, now(), "text", t, "", color))
        markDirty()
        statusTargets().forEach { u ->
            val j = JSONObject().put("id", id).put("t", t).put("c", color)
            net.send(Packet(T.STATUS, myUid, u, j.toString().toByteArray()))
        }
    }

    private fun postStatusFile(f: File, name: String, kind: String, dur: Long) {
        val id = newId()
        statuses.add(Status(id, myUid, now(), kind, "", f.absolutePath, 0L))
        markDirty()
        val targets = statusTargets()
        thread { transfer(f, name, kind, dur, id, "status", "", "", targets) }
    }

    fun postStatusUri(uri: Uri, forceKind: String? = null) {
        thread {
            val r = FileUtil.copyUri(act, uri, store.dir)
            if (r == null) { main { toast("Couldn't read this file") }; return@thread }
            val kind = forceKind ?: FileUtil.kindOf(act, uri, r.name)
            val dur = if (kind == "video" || kind == "audio") FileUtil.duration(r.file.absolutePath) else 0L
            main { postStatusFile(r.file, r.name, kind, dur) }
        }
    }

    fun postStatusVoice(f: File, dur: Long) = postStatusFile(f, "Voice status.m4a", "voice", dur)

    fun deleteStatus(id: String) { statuses.removeAll { it.id == id }; markDirty() }

    fun liveStatuses(): List<Status> {
        val cutoff = now() - 24L * 3600 * 1000
        return statuses.filter { it.ts > cutoff }
    }

    // ---------------- profile ----------------
    private fun loadAvatar() {
        myAvatar = if (store.avatarFile.exists())
            FileUtil.decodeSampled(store.avatarFile.absolutePath, 256)?.asImageBitmap() else null
    }

    fun setAvatar(uri: Uri) {
        thread {
            val thumb = FileUtil.makeAvatar(act, uri, store.avatarFile)
            main {
                if (thumb != null) {
                    store.myAvatarThumb = thumb
                    loadAvatar()
                    broadcastHello()
                    toast("Profile photo updated")
                } else toast("Couldn't use this photo")
            }
        }
    }

    fun removeAvatar() {
        store.avatarFile.delete(); store.myAvatarThumb = ""
        myAvatar = null; broadcastHello()
    }

    fun saveProfile(name: String, about: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        myName = n; myAbout = about.trim()
        store.myName = myName; store.myAbout = myAbout
        broadcastHello()
    }

    fun clearAllChats() {
        msgs.forEach { runCatching { File(it.path).delete() } }
        msgs.clear(); markDirty()
    }
    fun clearCalls() { calls.clear(); markDirty() }
    fun clearStatuses() { statuses.clear(); markDirty() }

    // ---------------- playing audio ----------------
    fun togglePlay(id: String, path: String) {
        if (playingId == id) { stopPlay(); return }
        stopPlay()
        val ok = player.play(path) { main { stopPlay() } }
        if (!ok) { toast("Can't play this file"); return }
        playingId = id
        playTicker = scope.launch {
            while (playingId == id) { playProgress = player.progress(); delay(150) }
        }
    }

    fun stopPlay() {
        player.stop(); playingId = null; playProgress = 0f
        playTicker?.cancel(); playTicker = null
    }

    // ---------------- calls ----------------
    private fun perms(video: Boolean) =
        if (video) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        else arrayOf(Manifest.permission.RECORD_AUDIO)

    private fun startRing() {
        try {
            val r = RingtoneManager.getRingtone(act, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
            r.play(); ringtone = r
        } catch (e: Exception) { }
    }
    private fun stopRing() { runCatching { ringtone?.stop() }; ringtone = null }

    private fun armTimeout() {
        val tok = ++callToken
        scope.launch {
            delay(45000)
            if (tok == callToken && (callState == "ringing_out" || callState == "ringing_in")) hangup()
        }
    }

    fun startCall(peer: String, video: Boolean) {
        if (peer.startsWith("g:")) { toast("Group calls aren't supported yet"); return }
        if (callState != "idle") return
        if (!canSend(peer)) return
        act.ensurePerms(perms(video)) {
            outgoing = true; callPeer = peer; callVideo = video; callState = "ringing_out"
            net.send(Packet(T.CALL_REQ, myUid, peer, byteArrayOf(if (video) 1 else 0)))
            armTimeout()
        }
    }

    fun accept() {
        act.ensurePerms(perms(callVideo)) {
            stopRing()
            net.send(Packet(T.CALL_ACC, myUid, callPeer))
            beginMedia()
        }
    }

    fun decline() { net.send(Packet(T.CALL_REJ, myUid, callPeer)); finishCall() }
    fun hangup() { net.send(Packet(T.CALL_END, myUid, callPeer)); finishCall() }

    fun toggleMute() { muted = !muted }
    fun toggleSpeaker() { speaker = !speaker; am.isSpeakerphoneOn = speaker }
    fun switchCamera() { video?.let { it.switchCamera(); frontCam = it.front } }

    private fun beginMedia() {
        stopRing(); callToken++
        callState = "active"; callStart = now(); seconds = 0
        remoteFrame = null; localFrame = null; muted = false; frontCam = true
        val peer = callPeer
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        speaker = callVideo
        am.isSpeakerphoneOn = speaker
        audio = AudioEngine { if (!muted) net.send(Packet(T.AUDIO, myUid, peer, it)) }.also { it.start() }
        if (callVideo) {
            video = VideoEngine(act, act) { jpeg, bmp ->
                net.send(Packet(T.VIDEO, myUid, peer, jpeg))
                main { localFrame = bmp.asImageBitmap() }
            }.also { it.start() }
        }
        ticker = scope.launch {
            while (callState == "active") { delay(1000); seconds = ((now() - callStart) / 1000).toInt() }
        }
    }

    private fun finishCall() {
        val was = callState
        val secs = if (was == "active") ((now() - callStart) / 1000).toInt() else 0
        val dir = when { outgoing -> "out"; was == "active" -> "in"; else -> "missed" }
        val peer = callPeer
        val vid = callVideo
        callToken++
        stopRing()
        ticker?.cancel(); ticker = null
        audio?.stop(); audio = null
        video?.stop(); video = null
        runCatching { am.mode = AudioManager.MODE_NORMAL; am.isSpeakerphoneOn = false }
        callState = "idle"; remoteFrame = null; localFrame = null
        if (was != "idle") { calls.add(CallRec(peer, vid, dir, now(), secs)); markDirty() }
    }

    fun shutdown() {
        net.close(); scope.cancel(); stopPlay(); stopRing()
        audio?.stop(); video?.stop()
    }
}
