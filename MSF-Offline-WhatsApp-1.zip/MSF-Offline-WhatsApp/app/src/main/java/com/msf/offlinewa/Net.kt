package com.msf.offlinewa

import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

const val PORT = 8888

object T {
    const val HELLO = 1
    const val BYE = 2
    const val MSG = 3
    const val FSTART = 4
    const val FCHUNK = 5
    const val FEND = 6
    const val STATUS = 7
    const val CALL_REQ = 8
    const val CALL_ACC = 9
    const val CALL_REJ = 10
    const val CALL_END = 11
    const val AUDIO = 12
    const val VIDEO = 13
    const val GROUP = 14
}

/** to = a user id, or "*" for everyone. */
class Packet(val type: Int, val from: String, val to: String, val data: ByteArray = ByteArray(0))

class Conn(val sock: Socket) {
    private val dout = DataOutputStream(BufferedOutputStream(sock.getOutputStream(), 65536))
    private val din = DataInputStream(BufferedInputStream(sock.getInputStream(), 65536))
    private val writer = Executors.newSingleThreadExecutor()
    val pending = AtomicInteger(0)
    @Volatile var uid: String = ""
    @Volatile var alive = true

    fun read(): Packet {
        val type = din.readUnsignedByte()
        val from = din.readUTF()
        val to = din.readUTF()
        val len = din.readInt()
        if (len < 0 || len > 8_000_000) throw IOException("bad frame")
        val buf = ByteArray(len)
        din.readFully(buf)
        return Packet(type, from, to, buf)
    }

    fun write(p: Packet) {
        if (!alive) return
        if (p.type == T.VIDEO && pending.get() > 3) return
        if (p.type == T.AUDIO && pending.get() > 60) return
        pending.incrementAndGet()
        writer.execute {
            try {
                dout.writeByte(p.type)
                dout.writeUTF(p.from)
                dout.writeUTF(p.to)
                dout.writeInt(p.data.size)
                dout.write(p.data)
                dout.flush()
            } catch (e: Exception) {
                alive = false
            } finally {
                pending.decrementAndGet()
            }
        }
    }

    fun close() {
        alive = false
        runCatching { sock.close() }
        runCatching { writer.shutdown() }
    }
}

/**
 * Star network over hotspot / Wi-Fi. The host is a hub: every client connects to it and the
 * host forwards packets by user id. The host is also a normal user.
 */
class Net(private val myUid: () -> String, private val l: Listener) {
    interface Listener {
        fun onState(s: String)
        fun onPacket(p: Packet)
        fun myHello(): Packet
    }

    private var gen = 0
    private var server: ServerSocket? = null
    private var hubConn: Conn? = null
    private val conns = ConcurrentHashMap<String, Conn>()
    private val hellos = ConcurrentHashMap<String, Packet>()
    @Volatile var isHost = false
    @Volatile var connected = false

    private fun reset() {
        runCatching { server?.close() }; server = null
        runCatching { hubConn?.close() }; hubConn = null
        conns.values.forEach { it.close() }
        conns.clear(); hellos.clear()
        connected = false
    }

    fun host() {
        val g = ++gen
        reset()
        isHost = true
        thread {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(PORT))
                server = ss
                connected = true
                l.onState("Hosting. Waiting for friends...")
                while (g == gen) {
                    val s = ss.accept()
                    thread { handleClient(g, s) }
                }
            } catch (e: Exception) {
                if (g == gen) { connected = false; l.onState("Error: ${e.message}") }
            }
        }
    }

    private fun handleClient(g: Int, s: Socket) {
        var c: Conn? = null
        try {
            s.tcpNoDelay = true
            val conn = Conn(s)
            c = conn
            while (g == gen) {
                val p = conn.read()
                if (p.type == T.HELLO) {
                    val first = conn.uid.isEmpty()
                    conn.uid = p.from
                    if (first) {
                        val old = conns.put(p.from, conn)
                        if (old != null && old !== conn) old.close()
                        conn.write(l.myHello())
                        hellos.values.forEach { if (it.from != p.from) conn.write(it) }
                    }
                    hellos[p.from] = p
                    conns.forEach { (u, o) -> if (u != p.from) o.write(p) }
                    l.onPacket(p)
                } else if (conn.uid.isNotEmpty()) {
                    route(p, conn)
                }
            }
        } catch (e: Exception) {
        } finally {
            val u = c?.uid ?: ""
            c?.close()
            if (u.isNotEmpty() && conns[u] === c) {
                conns.remove(u); hellos.remove(u)
                val bye = Packet(T.BYE, u, "*")
                conns.values.forEach { it.write(bye) }
                l.onPacket(bye)
            }
        }
    }

    private fun route(p: Packet, from: Conn?) {
        when {
            p.to == "*" -> {
                conns.values.forEach { if (it !== from) it.write(p) }
                if (from != null) l.onPacket(p)
            }
            p.to == myUid() -> if (from != null) l.onPacket(p)
            else -> conns[p.to]?.write(p)
        }
    }

    fun join(ip: String) {
        val g = ++gen
        reset()
        isHost = false
        thread {
            try {
                l.onState("Connecting...")
                val s = Socket()
                s.connect(InetSocketAddress(ip.trim(), PORT), 8000)
                s.tcpNoDelay = true
                val c = Conn(s)
                hubConn = c
                connected = true
                l.onState("Connected")
                c.write(l.myHello())
                while (g == gen) l.onPacket(c.read())
            } catch (e: Exception) {
                if (g == gen) {
                    val had = hubConn != null
                    connected = false
                    l.onState(if (had) "Disconnected" else "Could not connect: ${e.message}")
                }
            }
        }
    }

    fun send(p: Packet) {
        if (!connected) return
        if (isHost) route(p, null) else hubConn?.write(p)
    }

    fun backlog(to: String): Int =
        if (isHost) (conns[to]?.pending?.get() ?: 0) else (hubConn?.pending?.get() ?: 0)

    fun close() { gen++; reset() }
}
