package com.msf.offlinewa

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.*
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.util.Size
import android.webkit.MimeTypeMap
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class Copied(val file: File, val name: String, val size: Long)

object FileUtil {
    fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    }

    fun kindOf(ctx: Context, uri: Uri?, name: String): String {
        val mime = (uri?.let { ctx.contentResolver.getType(it) } ?: mimeOf(name)).lowercase()
        return when {
            mime.startsWith("image/") -> "image"
            mime.startsWith("video/") -> "video"
            mime.startsWith("audio/") -> "audio"
            else -> "file"
        }
    }

    fun safeName(name: String) = name.replace(Regex("[^A-Za-z0-9._-]"), "_")

    fun copyUri(ctx: Context, uri: Uri, dir: File): Copied? {
        return try {
            var name = "file_${System.currentTimeMillis()}"
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) { val n = c.getString(0); if (!n.isNullOrBlank()) name = n }
            }
            val dest = File(dir, "${System.nanoTime()}_${safeName(name)}")
            ctx.contentResolver.openInputStream(uri)?.use { ins -> dest.outputStream().use { ins.copyTo(it) } } ?: return null
            Copied(dest, name, dest.length())
        } catch (e: Exception) { null }
    }

    fun decodeSampled(path: String, max: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            var s = 1
            while (o.outWidth / s > max * 2 || o.outHeight / s > max * 2) s *= 2
            val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
            val deg = try {
                when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } catch (e: Exception) { 0 }
            if (deg == 0) bmp
            else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg.toFloat()) }, true)
        } catch (e: Throwable) { null }
    }

    fun videoThumb(path: String): Bitmap? {
        val r = MediaMetadataRetriever()
        return try { r.setDataSource(path); r.getFrameAtTime(0) } catch (e: Exception) { null } finally { runCatching { r.release() } }
    }

    fun duration(path: String): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) { 0L } finally { runCatching { r.release() } }
    }

    fun b64ToBitmap(s: String): ImageBitmap? {
        if (s.isEmpty()) return null
        return try {
            val b = Base64.decode(s, Base64.NO_WRAP)
            BitmapFactory.decodeByteArray(b, 0, b.size)?.asImageBitmap()
        } catch (e: Exception) { null }
    }

    /** Centre-crops the picked picture to a square, saves it and returns a small base64 thumbnail. */
    fun makeAvatar(ctx: Context, uri: Uri, out: File): String? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 1200 || o.outHeight / s > 1200) s *= 2
            val src = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
            } ?: return null
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val big = Bitmap.createScaledBitmap(sq, 512, 512, true)
            out.outputStream().use { big.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            val small = Bitmap.createScaledBitmap(sq, 96, 96, true)
            val bos = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 70, bos)
            Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Throwable) { null }
    }

    /** Saves a received file to the phone's gallery / music / downloads (Android 10 and newer). */
    fun saveToPublic(ctx: Context, path: String, name: String, kind: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val (collection, folder) = when (kind) {
                "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
                "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
                "audio", "voice" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
                else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
            }
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/MSF Offline WhatsApp")
            }
            val uri = ctx.contentResolver.insert(collection, v) ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { o -> File(path).inputStream().use { it.copyTo(o) } }
            true
        } catch (e: Exception) { false }
    }
}

/** Microphone -> chunks, and incoming chunks -> speaker (16 kHz mono PCM). */
class AudioEngine(private val onChunk: (ByteArray) -> Unit) {
    private val rate = 16000
    @Volatile private var running = false
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null

    @SuppressLint("MissingPermission")
    fun start() {
        running = true
        val minRec = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minRec, 4096)
        )
        val minTr = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(maxOf(minTr, 8192))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        rec = r; track = t
        t.play(); r.startRecording()
        thread {
            val buf = ByteArray(1280)
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) onChunk(buf.copyOf(n)) else if (n < 0) break
            }
        }
    }

    fun play(data: ByteArray) { runCatching { track?.write(data, 0, data.size) } }

    fun stop() {
        running = false
        runCatching { rec?.stop(); rec?.release() }
        runCatching { track?.stop(); track?.release() }
        rec = null; track = null
    }
}

/** Camera (front or back) -> small JPEG frames, about 8 per second. Also reports a local preview. */
class VideoEngine(
    private val ctx: Context,
    private val owner: LifecycleOwner,
    private val onFrame: (ByteArray, Bitmap) -> Unit
) {
    private var provider: ProcessCameraProvider? = null
    private val exec = Executors.newSingleThreadExecutor()
    private var last = 0L
    @Volatile var front = true
        private set

    fun start() = bind()

    fun switchCamera() { front = !front; bind() }

    private fun bind() {
        val f = ProcessCameraProvider.getInstance(ctx)
        f.addListener({
            val p = f.get()
            provider = p
            val a = ImageAnalysis.Builder()
                .setTargetResolution(Size(480, 640))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            a.setAnalyzer(exec) { img ->
                val now = System.currentTimeMillis()
                if (now - last >= 120) {
                    last = now
                    try {
                        val bmp = img.toBitmap()
                        val m = Matrix().apply { postRotate(img.imageInfo.rotationDegrees.toFloat()) }
                        val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                        val bos = ByteArrayOutputStream()
                        rot.compress(Bitmap.CompressFormat.JPEG, 45, bos)
                        onFrame(bos.toByteArray(), rot)
                    } catch (e: Exception) {}
                }
                img.close()
            }
            p.unbindAll()
            val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            try {
                p.bindToLifecycle(owner, sel, a)
            } catch (e: Exception) {
                front = !front
                runCatching {
                    p.bindToLifecycle(owner, if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA, a)
                }
            }
        }, ContextCompat.getMainExecutor(ctx))
    }

    fun stop() { runCatching { provider?.unbindAll() } }
}

/** Records a voice message to an .m4a file. */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    private var startAt = 0L

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    fun start(f: File): Boolean {
        return try {
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(22050)
            r.setAudioEncodingBitRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            startAt = System.currentTimeMillis()
            true
        } catch (e: Exception) { rec = null; false }
    }

    /** Returns the length in milliseconds, or -1 if the recording failed. */
    fun stop(): Long {
        val r = rec ?: return -1
        rec = null
        return try {
            r.stop(); r.release()
            System.currentTimeMillis() - startAt
        } catch (e: Exception) {
            runCatching { r.release() }
            -1
        }
    }
}

/** Plays voice messages and audio files one at a time. */
class Player {
    private var mp: MediaPlayer? = null

    fun play(path: String, onDone: () -> Unit): Boolean {
        stop()
        return try {
            val m = MediaPlayer()
            m.setDataSource(path)
            m.prepare()
            m.setOnCompletionListener { onDone() }
            m.start()
            mp = m
            true
        } catch (e: Exception) { false }
    }

    fun progress(): Float {
        val m = mp ?: return 0f
        return try { if (m.duration > 0) m.currentPosition.toFloat() / m.duration else 0f } catch (e: Exception) { 0f }
    }

    fun stop() {
        runCatching { mp?.stop() }
        runCatching { mp?.release() }
        mp = null
    }
}
