package com.msf.offlinewa

import android.Manifest
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun VideoPlayer(path: String, modifier: Modifier, onEnd: () -> Unit = {}) {
    AndroidView(modifier = modifier, factory = { ctx ->
        VideoView(ctx).apply {
            setVideoPath(path)
            val mc = MediaController(ctx)
            mc.setAnchorView(this)
            setMediaController(mc)
            setOnCompletionListener { onEnd() }
            setOnPreparedListener { start() }
        }
    })
}

/** Hold to record, release to send. */
@Composable
fun HoldMic(m: Model, onDone: (File, Long) -> Unit) {
    var rec by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onDone)
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(if (rec) Red else Green)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    if (!m.act.has(Manifest.permission.RECORD_AUDIO)) {
                        m.act.ensurePerms(arrayOf(Manifest.permission.RECORD_AUDIO)) { m.toast("Now hold the mic to record") }
                    } else {
                        val f = m.newVoiceFile()
                        if (m.recorder.start(f)) {
                            rec = true
                            tryAwaitRelease()
                            rec = false
                            val d = m.recorder.stop()
                            if (d > 800) cb(f, d) else f.delete()
                        } else m.toast("Couldn't start the microphone")
                    }
                })
            },
        contentAlignment = Alignment.Center
    ) { Text(if (rec) "●" else "🎤", fontSize = 22.sp, color = Color.White) }
}

@Composable
fun ChatScreen(m: Model, chat: String, back: () -> Unit) {
    val isGroup = chat.startsWith("g:")
    var text by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var attach by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    val chatMsgs = m.msgs.filter { it.chat == chat }
    val blocked = !isGroup && m.isBlocked(chat)
    val online = !isGroup && m.online[chat] == true
    LaunchedEffect(chatMsgs.size) { if (chatMsgs.isNotEmpty()) list.animateScrollToItem(chatMsgs.size) }
    LaunchedEffect(chatMsgs.size) { m.unread.remove(chat) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(back) { Text("←", fontSize = 22.sp, color = Color.White) }
            Av(m, chat, 40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f).clickable { if (isGroup) info = true }) {
                Text(m.nameOf(chat), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    if (isGroup) "${m.groups.firstOrNull { it.gid == chat }?.members?.size ?: 0} members" else if (online) "online" else "offline",
                    color = if (online) Green else Sub, fontSize = 12.sp
                )
            }
            if (!isGroup) {
                TextButton({ m.startCall(chat, true) }) { Text("🎥", fontSize = 20.sp) }
                TextButton({ m.startCall(chat, false) }) { Text("📞", fontSize = 20.sp) }
            }
            Box {
                TextButton({ menu = true }) { Text("⋮", fontSize = 22.sp, color = Color.White) }
                DropdownMenu(menu, { menu = false }) {
                    if (isGroup) {
                        DropdownMenuItem(text = { Text("Group info") }, onClick = { menu = false; info = true })
                    } else {
                        DropdownMenuItem(
                            text = { Text(if (blocked) "Unblock" else "Block", color = if (blocked) Color.White else Red) },
                            onClick = { menu = false; m.toggleBlock(chat) }
                        )
                    }
                    DropdownMenuItem(text = { Text("Clear chat") }, onClick = { menu = false; m.clearChat(chat) })
                    if (isGroup) DropdownMenuItem(
                        text = { Text("Delete group", color = Red) },
                        onClick = { menu = false; m.deleteGroup(chat); back() }
                    )
                }
            }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 10.dp), state = list, verticalArrangement = Arrangement.spacedBy(5.dp)) {
            item {
                Text(
                    "Messages and files stay on your local network. Nothing goes through the internet.",
                    color = Color(0xFFE8C36A), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(8.dp)
                )
            }
            items(chatMsgs, key = { it.id }) { x -> Bubble(m, x, isGroup) }
        }
        if (blocked) {
            Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("You blocked ${m.nameOf(chat)}.", color = Sub, modifier = Modifier.weight(1f))
                TextButton({ m.toggleBlock(chat) }) { Text("Unblock", color = Green) }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    text, { text = it }, placeholder = { Text("Message") }, modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(28.dp), maxLines = 4,
                    trailingIcon = { TextButton({ attach = true }) { Text("📎", fontSize = 20.sp) } }
                )
                Spacer(Modifier.width(8.dp))
                if (text.isNotBlank()) {
                    Button(
                        onClick = { m.sendText(chat, text); text = "" }, shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Green),
                        contentPadding = PaddingValues(0.dp), modifier = Modifier.size(52.dp)
                    ) { Text("➤", fontSize = 20.sp, color = OnGreen) }
                } else HoldMic(m) { f, d -> m.sendVoice(chat, f, d) }
            }
        }
    }

    if (attach) {
        val pick: (String) -> Unit = { kind ->
            attach = false
            when (kind) {
                "media" -> m.act.pick("media") { m.sendUri(chat, it) }
                "photo" -> m.act.takePhoto { m.sendCaptured(chat, it, "image") }
                "video" -> m.act.takeVideo { m.sendCaptured(chat, it, "video") }
                "audio" -> m.act.pick("audio") { m.sendUri(chat, it, "audio") }
                else -> m.act.pick("doc") { m.sendUri(chat, it, "file") }
            }
        }
        Dialog(onDismissRequest = { attach = false }) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(
                        Triple("media", "🖼", "Gallery (photos and videos)"),
                        Triple("photo", "📷", "Camera"),
                        Triple("video", "🎥", "Record video"),
                        Triple("doc", "📄", "Document or any file"),
                        Triple("audio", "🎵", "Audio file")
                    ).forEach { (k, ic, label) ->
                        Row(Modifier.fillMaxWidth().clickable { pick(k) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(ic, fontSize = 24.sp)
                            Spacer(Modifier.width(16.dp))
                            Text(label, color = Color.White, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
    if (info) {
        val g = m.groups.firstOrNull { it.gid == chat }
        AlertDialog(
            onDismissRequest = { info = false },
            title = { Text(g?.name ?: "Group") },
            text = {
                Column {
                    Text("Members", color = Sub, modifier = Modifier.padding(bottom = 8.dp))
                    (g?.members ?: emptyList()).forEach { u ->
                        Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Av(m, u, 34.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(m.nameOf(u) + if (u != m.myUid && m.online[u] == true) "  (online)" else "", color = Color.White)
                        }
                    }
                }
            },
            confirmButton = { TextButton({ info = false }) { Text("Close", color = Green) } }
        )
    }
}

@Composable
fun Bubble(m: Model, x: Msg, group: Boolean) {
    val mine = x.from == m.myUid
    Box(Modifier.fillMaxWidth(), contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(
            Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(12.dp))
                .background(if (mine) Out else Panel).padding(6.dp)
        ) {
            if (group && !mine) Text(
                m.nameOf(x.from), color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            when (x.kind) {
                "text" -> Text(x.text, color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                "image", "video" -> MediaThumb(m, x)
                "voice", "audio" -> AudioRow(m, x)
                else -> FileRow(m, x)
            }
            if (x.kind != "text" && x.text.isNotEmpty()) Text(x.text, color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(4.dp))
            Row(Modifier.align(Alignment.End).padding(horizontal = 4.dp)) {
                Text(timeOf(x.ts), color = Sub, fontSize = 11.sp)
                if (mine) Text(if (x.state == "sending") "  🕓" else "  ✓✓", color = Sub, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun MediaThumb(m: Model, x: Msg) {
    val mine = x.from == m.myUid
    val ready = x.state == "done" || mine
    val bmp by produceState<ImageBitmap?>(null, x.path, ready) {
        value = if (!ready) null else withContext(Dispatchers.IO) {
            (if (x.kind == "video") FileUtil.videoThumb(x.path) else FileUtil.decodeSampled(x.path, 500))?.asImageBitmap()
        }
    }
    Box(
        Modifier.width(240.dp).height(240.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF111B21))
            .clickable(enabled = ready) { m.viewer = Viewable(x.kind, x.path, x.name) },
        contentAlignment = Alignment.Center
    ) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        if (x.kind == "video" && ready) Text("▶", fontSize = 42.sp, color = Color.White)
        if (x.state != "done") {
            val p = m.progress[x.id]
            Box(Modifier.clip(CircleShape).background(Color(0x99000000)).padding(12.dp)) {
                Text(
                    (if (mine) "Sending " else "Downloading ") + (if (p != null) "${(p * 100).toInt()}%" else "…"),
                    color = Color.White, fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun AudioRow(m: Model, x: Msg) {
    val ready = x.state == "done" || x.from == m.myUid
    val playing = m.playingId == x.id
    Row(Modifier.widthIn(min = 230.dp).padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(Green).clickable(enabled = ready) { m.togglePlay(x.id, x.path) },
            contentAlignment = Alignment.Center
        ) { Text(if (!ready) "…" else if (playing) "⏸" else "▶", color = OnGreen, fontSize = 18.sp) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            LinearProgressIndicator(
                progress = { if (playing) m.playProgress else if (!ready) (m.progress[x.id] ?: 0f) else 0f },
                modifier = Modifier.fillMaxWidth(), color = Green, trackColor = Sub
            )
            Text(
                (if (x.kind == "voice") "🎤 " else "🎵 ${x.name}  ") + durMs(x.dur),
                color = Sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
fun FileRow(m: Model, x: Msg) {
    val ready = x.state == "done" || x.from == m.myUid
    Row(
        Modifier.widthIn(min = 230.dp).clickable(enabled = ready) { m.act.openFile(x.path, x.name) }.padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("📄", fontSize = 30.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(x.name, color = Color.White, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val p = m.progress[x.id]
            Text(
                sizeText(x.size) + if (!ready) "  ·  ${if (p != null) "${(p * 100).toInt()}%" else "…"}" else "",
                color = Sub, fontSize = 12.sp
            )
        }
        if (ready) TextButton({
            m.toast(if (FileUtil.saveToPublic(m.act, x.path, x.name, "file")) "Saved to Downloads" else "Couldn't save (needs Android 10+)")
        }) { Text("⬇", fontSize = 20.sp) }
    }
}

@Composable
fun MediaViewer(m: Model, v: Viewable) {
    Dialog(onDismissRequest = { m.viewer = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            if (v.kind == "image") {
                val bmp by produceState<ImageBitmap?>(null, v.path) {
                    value = withContext(Dispatchers.IO) { FileUtil.decodeSampled(v.path, 1800)?.asImageBitmap() }
                }
                bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
            } else VideoPlayer(v.path, Modifier.fillMaxSize().padding(top = 56.dp))
            Row(Modifier.fillMaxWidth().background(Color(0x66000000)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton({ m.viewer = null }) { Text("✕", fontSize = 22.sp, color = Color.White) }
                Text(v.title, color = Color.White, fontSize = 15.sp, maxLines = 1, modifier = Modifier.weight(1f), overflow = TextOverflow.Ellipsis)
                TextButton({
                    m.toast(if (FileUtil.saveToPublic(m.act, v.path, v.title, v.kind)) "Saved to your gallery" else "Couldn't save (needs Android 10+)")
                }) { Text("⬇ Save", color = Color.White) }
            }
        }
    }
}

// ---------------------------------------------------------------- status

@Composable
fun UpdatesTab(m: Model, onAdd: () -> Unit) {
    val live = m.liveStatuses()
    val mine = live.filter { it.from == m.myUid }
    val others = live.filter { it.from != m.myUid }.groupBy { it.from }.entries.toList()
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(
                Modifier.fillMaxWidth().clickable { if (mine.isEmpty()) onAdd() else m.statusList = mine.sortedBy { it.ts } }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Av(m, m.myUid, 52.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("My status", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (mine.isEmpty()) "Tap to add a status update" else "${mine.size} update(s)  ·  ${fmt(mine.maxOf { it.ts })}",
                        color = Sub, fontSize = 14.sp
                    )
                }
                if (mine.isNotEmpty()) TextButton(onAdd) { Text("＋", fontSize = 22.sp, color = Green) }
            }
            Text(
                if (others.isEmpty()) "No updates from friends yet. Updates last 24 hours." else "Recent updates",
                color = Sub, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }
        items(others) { e ->
            val list = e.value.sortedBy { it.ts }
            Row(Modifier.fillMaxWidth().clickable { m.statusList = list }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(CircleShape).background(Green).padding(3.dp)) { Av(m, e.key, 50.dp) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(m.nameOf(e.key), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text("${list.size} update(s)  ·  ${fmt(list.last().ts)}", color = Sub, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun NewStatusDialog(m: Model, close: () -> Unit) {
    var mode by remember { mutableStateOf("choose") }
    var text by remember { mutableStateOf("") }
    val colors = listOf(0xFF1F6F5B, 0xFF5B3F7A, 0xFF2E5F7A, 0xFF8A3B2E, 0xFF7A6A2E, 0xFF3B4A54)
    var color by remember { mutableStateOf(colors[0]) }
    Dialog(onDismissRequest = close) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                when (mode) {
                    "choose" -> {
                        Text("New status", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        listOf(
                            Triple("text", "✎", "Text"),
                            Triple("media", "🖼", "Photo or video"),
                            Triple("voice", "🎤", "Voice note"),
                            Triple("audio", "🎵", "Audio file")
                        ).forEach { (k, ic, label) ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    when (k) {
                                        "text", "voice" -> mode = k
                                        "media" -> { close(); m.act.pick("media") { m.postStatusUri(it) } }
                                        else -> { close(); m.act.pick("audio") { m.postStatusUri(it, "audio") } }
                                    }
                                }.padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(ic, fontSize = 24.sp)
                                Spacer(Modifier.width(16.dp))
                                Text(label, color = Color.White, fontSize = 16.sp)
                            }
                        }
                    }
                    "text" -> {
                        Box(Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp)).background(Color(color)), contentAlignment = Alignment.Center) {
                            OutlinedTextField(text, { text = it }, placeholder = { Text("Type a status") }, modifier = Modifier.fillMaxWidth().padding(8.dp))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            colors.forEach { c ->
                                Box(Modifier.size(30.dp).clip(CircleShape).background(Color(c)).clickable { color = c })
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(close) { Text("Cancel") }
                            TextButton({
                                if (text.isBlank()) m.toast("Type something first")
                                else { m.postStatusText(text, color); close() }
                            }) { Text("Post", color = Green) }
                        }
                    }
                    else -> {
                        Text("Hold the mic and speak. Release to post.", color = Color.White)
                        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            HoldMic(m) { f, d -> m.postStatusVoice(f, d); close() }
                        }
                        TextButton(close) { Text("Cancel") }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusViewer(m: Model, list: List<Status>) {
    var idx by remember { mutableIntStateOf(0) }
    val s = list[idx.coerceIn(0, list.size - 1)]
    val mine = s.from == m.myUid
    fun next() { if (idx < list.size - 1) idx++ else { m.stopPlay(); m.statusList = null } }
    fun prev() { if (idx > 0) idx-- }
    LaunchedEffect(idx) {
        if (s.kind == "image" || s.kind == "text") { delay(5000); next() }
    }
    Dialog(onDismissRequest = { m.stopPlay(); m.statusList = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(if (s.kind == "text") Color(s.color) else Color.Black)) {
            when (s.kind) {
                "text" -> Text(
                    s.text, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center).padding(32.dp)
                )
                "image" -> {
                    val bmp by produceState<ImageBitmap?>(null, s.path) {
                        value = withContext(Dispatchers.IO) { FileUtil.decodeSampled(s.path, 1800)?.asImageBitmap() }
                    }
                    bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                }
                "video" -> VideoPlayer(s.path, Modifier.fillMaxSize().padding(vertical = 100.dp)) { next() }
                else -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (s.kind == "voice") "🎤" else "🎵", fontSize = 64.sp)
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { m.togglePlay(s.id, s.path) },
                        colors = ButtonDefaults.buttonColors(containerColor = Green)
                    ) { Text(if (m.playingId == s.id) "⏸  Pause" else "▶  Play", color = OnGreen) }
                    LinearProgressIndicator(
                        progress = { if (m.playingId == s.id) m.playProgress else 0f },
                        modifier = Modifier.width(220.dp).padding(top = 16.dp), color = Green, trackColor = Sub
                    )
                }
            }
            Column(Modifier.fillMaxWidth().background(Color(0x55000000)).padding(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    list.indices.forEach { i ->
                        Box(Modifier.weight(1f).height(3.dp).background(if (i <= idx) Color.White else Color(0x66FFFFFF)))
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Av(m, s.from, 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.nameOf(s.from), color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(fmt(s.ts), color = Color(0xFFCCCCCC), fontSize = 12.sp)
                    }
                    if (mine) TextButton({ m.deleteStatus(s.id); m.stopPlay(); m.statusList = null }) { Text("Delete", color = Red) }
                    TextButton({ m.stopPlay(); m.statusList = null }) { Text("✕", fontSize = 22.sp, color = Color.White) }
                }
            }
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x55000000)).padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton({ m.stopPlay(); prev() }) { Text("◀ Previous", color = Color.White) }
                TextButton({ m.stopPlay(); next() }) { Text("Next ▶", color = Color.White) }
            }
        }
    }
}

// ---------------------------------------------------------------- calls

@Composable
fun CallScreen(m: Model) {
    val frame = m.remoteFrame
    val showVideo = m.callVideo && m.callState == "active" && frame != null
    val active = m.callState == "active"
    Box(Modifier.fillMaxSize().background(Color(0xFF05100F)).clickable(enabled = false) {}) {
        if (showVideo) Image(frame!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        val local = m.localFrame
        if (m.callVideo && active && local != null) {
            Image(
                local, "Your camera",
                Modifier.align(Alignment.TopEnd).padding(top = 16.dp, end = 16.dp).size(width = 110.dp, height = 150.dp)
                    .clip(RoundedCornerShape(12.dp)).graphicsLayer(scaleX = if (m.frontCam) -1f else 1f),
                contentScale = ContentScale.Crop
            )
        }
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(32.dp))
            if (!showVideo) { Av(m, m.callPeer, 120.dp); Spacer(Modifier.height(16.dp)) }
            Text(m.nameOf(m.callPeer), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(
                when (m.callState) {
                    "ringing_out" -> "Calling..."
                    "ringing_in" -> if (m.callVideo) "Incoming video call" else "Incoming audio call"
                    else -> dur(m.seconds)
                },
                color = Sub, fontSize = 16.sp
            )
            Spacer(Modifier.weight(1f))
            if (active) {
                Row(horizontalArrangement = Arrangement.spacedBy(28.dp), modifier = Modifier.padding(bottom = 24.dp)) {
                    CallBtn(if (m.muted) "🔇" else "🎙", if (m.muted) "Unmute" else "Mute", Panel) { m.toggleMute() }
                    CallBtn(if (m.speaker) "🔊" else "🔈", "Speaker", Panel) { m.toggleSpeaker() }
                    if (m.callVideo) CallBtn("🔄", "Flip", Panel) { m.switchCamera() }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(48.dp), modifier = Modifier.padding(bottom = 32.dp)) {
                if (m.callState == "ringing_in") {
                    CallBtn("✕", "Decline", Red) { m.decline() }
                    CallBtn("✓", "Accept", Green) { m.accept() }
                } else CallBtn("✕", "End", Red) { m.hangup() }
            }
        }
    }
}

@Composable
fun CallBtn(icon: String, label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Button(
            onClick, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = color),
            contentPadding = PaddingValues(0.dp), modifier = Modifier.size(64.dp)
        ) { Text(icon, fontSize = 24.sp, color = Color.White) }
        Text(label, color = Sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
    }
}
