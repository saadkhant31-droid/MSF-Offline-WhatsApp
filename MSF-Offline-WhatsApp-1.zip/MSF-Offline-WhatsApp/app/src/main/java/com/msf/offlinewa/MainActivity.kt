package com.msf.offlinewa

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var model: Model
    private var pending: ((Boolean) -> Unit)? = null
    private var uriCb: ((Uri) -> Unit)? = null
    private var fileCb: ((File) -> Unit)? = null
    private var camFile: File? = null

    private val permL =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
            pending?.invoke(r.values.all { it }); pending = null
        }
    private val mediaL =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> if (u != null) uriCb?.invoke(u) }
    private val docL =
        registerForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) uriCb?.invoke(u) }
    private val photoL =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            val f = camFile
            if (ok && f != null) fileCb?.invoke(f)
        }
    private val videoL =
        registerForActivityResult(ActivityResultContracts.CaptureVideo()) { ok ->
            val f = camFile
            if (ok && f != null) fileCb?.invoke(f)
        }

    fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    fun ensurePerms(perms: Array<String>, then: () -> Unit) {
        if (perms.all { has(it) }) then()
        else {
            pending = { ok ->
                if (ok) then() else Toast.makeText(this, "Permission needed", Toast.LENGTH_SHORT).show()
            }
            permL.launch(perms)
        }
    }

    /** kind: media (photo or video), image, audio, doc */
    fun pick(kind: String, cb: (Uri) -> Unit) {
        uriCb = cb
        when (kind) {
            "media" -> mediaL.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
            "image" -> mediaL.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            "audio" -> docL.launch("audio/*")
            else -> docL.launch("*/*")
        }
    }

    private fun camUri(ext: String): Uri {
        val d = File(cacheDir, "camera").apply { mkdirs() }
        val f = File(d, "cap_${System.currentTimeMillis()}.$ext")
        camFile = f
        return FileProvider.getUriForFile(this, "$packageName.files", f)
    }

    fun takePhoto(cb: (File) -> Unit) = ensurePerms(arrayOf(Manifest.permission.CAMERA)) {
        fileCb = cb
        photoL.launch(camUri("jpg"))
    }

    fun takeVideo(cb: (File) -> Unit) = ensurePerms(arrayOf(Manifest.permission.CAMERA)) {
        fileCb = cb
        videoL.launch(camUri("mp4"))
    }

    fun openFile(path: String, name: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", File(path))
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, FileUtil.mimeOf(name))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "No app can open this file", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        model = Model(this)
        setContent { Root(model) }
    }

    override fun onDestroy() { model.shutdown(); super.onDestroy() }
}
