package com.msf.msf_nimaz_ki_record

import android.content.SharedPreferences
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

/** Live wallpaper: draws the selected MSF design with a running clock and today's prayer times. */
class MsfWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = MsfEngine()

    inner class MsfEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private lateinit var renderer: WpRenderer
        private var visible = false
        private val prefs: SharedPreferences by lazy { getSharedPreferences("msf_wp", MODE_PRIVATE) }
        private val frame = Runnable { drawFrame() }
        private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            renderer.reload()
            if (visible) drawFrame()
        }

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)
            renderer = WpRenderer(this@MsfWallpaperService)
            renderer.reload()
            prefs.registerOnSharedPreferenceChangeListener(listener)
        }

        override fun onDestroy() {
            handler.removeCallbacks(frame)
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
            super.onDestroy()
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            handler.removeCallbacks(frame)
            if (v) {
                renderer.reload()
                drawFrame()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            visible = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        private fun drawFrame() {
            handler.removeCallbacks(frame)
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) renderer.draw(canvas, canvas.width, canvas.height, System.currentTimeMillis())
            } catch (e: Throwable) {
                // ignore a bad frame
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) } catch (e: Throwable) { }
                }
            }
            if (visible) {
                val now = System.currentTimeMillis()
                val step = if (renderer.showSec) 1000L else 60000L
                handler.postDelayed(frame, step - (now % step) + 5L)
            }
        }
    }
}
