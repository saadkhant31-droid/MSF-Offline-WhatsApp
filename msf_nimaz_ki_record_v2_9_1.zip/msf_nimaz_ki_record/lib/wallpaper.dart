import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'timetable.dart';

/// Bridge to the native Android live wallpaper (see native/android/*.kt).
const _ch = MethodChannel('msf/wallpaper');

const wpThemeNames = [
  'نماز کے اوقات',
  'نماز ڈیش بورڈ ۱',
  'نماز ڈیش بورڈ ۲',
  'نماز ریکارڈ ۱',
  'اطراف کارڈ',
  'اسلامی گھڑی',
  'کوہاٹ نقشہ',
  'مکمل ایپ',
  'سادہ گھڑی',
  'نماز ڈیش بورڈ ۳',
  'نماز ریکارڈ ۲',
];

/// 0 = auto (device screen). Others are design sizes.
const wpDims = <List<int>>[
  [0, 0],
  [480, 854],
  [720, 1280],
  [1080, 1920],
  [1440, 3120],
];

int wpTheme() => clampI(getI('wp_theme'), 0, wpThemeNames.length - 1);
int wpDim() => clampI(getI('wp_dim'), 0, wpDims.length - 1);
bool wpSec() => getB('wp_sec', true);

Future<T?> _call<T>(String m, [Map<String, dynamic>? a]) async {
  if (!Platform.isAndroid) return null;
  try {
    return await _ch.invokeMethod<T>(m, a);
  } catch (_) {
    return null;
  }
}

int _m(DateTime x) => x.hour * 60 + x.minute;

/// Today (minus 1) + 60 days of prayer times, so the wallpaper keeps working without opening the app.
String wallpaperJson() {
  final today = dayOnly(DateTime.now());
  final days = <Map<String, dynamic>>[];
  for (var i = -1; i < 60; i++) {
    final d = addDays(today, i);
    final t = dayTimes(d);
    final a1 = dayTimes(d, hanafi: false).asr;
    final a2 = dayTimes(d, hanafi: true).asr;
    days.add({
      'k': dayKey(d),
      'hs': hijriText(d),
      // 0 sehri,1 fajr,2 sunrise,3 ishraq,4 chasht,5 zawal,6 zuhr,7 asr1,8 asr2,9 maghrib,10 isha,11 asr(chosen)
      't': [_m(t.sehri), _m(t.fajr), _m(t.sunrise), _m(t.ishraq), _m(t.chasht), _m(t.zawal), _m(t.zuhr), _m(a1), _m(a2), _m(t.maghrib), _m(t.isha), _m(t.asr)],
      'st': [for (var j = 0; j < 5; j++) prayerState(d, j)],
    });
  }
  return jsonEncode({'city': currentCity().name, 'days': days});
}

Timer? _syncTimer;

Future<void> syncWallpaper() => _call<bool>('sync', {
      'data': wallpaperJson(),
      'theme': wpTheme(),
      'dim': wpDim(),
      'sec': wpSec(),
    });

/// Call once from main(): pushes data now and whenever anything changes.
void initWallpaperSync() {
  if (!Platform.isAndroid) return;
  syncWallpaper();
  tick.addListener(() {
    _syncTimer?.cancel();
    _syncTimer = Timer(const Duration(milliseconds: 900), syncWallpaper);
  });
}

class WallpaperScreen extends StatefulWidget {
  const WallpaperScreen({super.key});
  @override
  State<WallpaperScreen> createState() => _WallpaperScreenState();
}

class _WallpaperScreenState extends State<WallpaperScreen> with WidgetsBindingObserver {
  final Map<String, Future<Uint8List?>> _cache = {};
  bool? active;
  bool busy = false;
  bool ready = false;
  List<int>? dev;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _status();
  }

  Future<void> _init() async {
    await syncWallpaper();
    final d = await _call<List<dynamic>>('deviceSize');
    if (d != null && d.length == 2) dev = [d[0] as int, d[1] as int];
    await _status();
    if (mounted) setState(() => ready = true);
  }

  Future<void> _status() async {
    final a = await _call<bool>('isActive');
    if (mounted) setState(() => active = a);
  }

  Future<Uint8List?> _preview(int theme, int w, int h) {
    final key = '$theme|${wpDim()}|$w|${getI('city')}';
    return _cache.putIfAbsent(key, () => _call<Uint8List>('preview', {'theme': theme, 'dim': wpDim(), 'w': w, 'h': h}));
  }

  double get _aspect {
    final d = wpDims[wpDim()];
    if (d[0] == 0) {
      final s = dev;
      return s == null ? 2.0 : s[1] / s[0];
    }
    return d[1] / d[0];
  }

  void _pickTheme(int i) {
    setI('wp_theme', i);
    syncWallpaper();
  }

  Future<void> _openLive(BuildContext c) async {
    await syncWallpaper();
    final ok = await _call<bool>('openLive');
    if (ok != true && c.mounted) {
      toast(c, Platform.isAndroid ? 'لائیو وال پیپر کی اسکرین نہیں کھل سکی' : 'یہ سہولت صرف اینڈرائیڈ میں ہے');
    } else if (c.mounted) {
      toast(c, 'کھلنے والی اسکرین میں «وال پیپر لگائیں» دبائیں، پھر ہوم، لاک یا دونوں چنیں');
    }
  }

  Future<void> _static(BuildContext c, int which) async {
    final name = which == 1 ? 'ہوم اسکرین' : (which == 2 ? 'لاک اسکرین' : 'ہوم اور لاک اسکرین');
    if (!await confirmDialog(c, 'یہ ڈیزائن «$name» پر ایک ساکن تصویر کی صورت میں لگے گا (گھڑی نہیں چلے گی)۔ چلتی گھڑی کے لیے «لائیو وال پیپر» استعمال کریں۔ جاری رکھیں؟')) return;
    setState(() => busy = true);
    final ok = await _call<bool>('setStatic', {'which': which, 'theme': wpTheme()});
    if (!mounted) return;
    setState(() => busy = false);
    toast(context, ok == true ? '$name پر وال پیپر لگ گیا' : 'وال پیپر نہیں لگ سکا');
    _status();
  }

  void _full(BuildContext c, int theme) {
    showDialog<void>(context: c, builder: (_) => _LiveDialog(theme: theme, aspect: _aspect));
  }

  Widget _tile(BuildContext c, int i) {
    final sel = wpTheme() == i;
    return GestureDetector(
      onTap: () => _pickTheme(i),
      onLongPress: () => _full(c, i),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: sel ? gold : green.withAlpha(80), width: sel ? 3.5 : 1.2),
          boxShadow: sel ? [BoxShadow(color: gold.withAlpha(120), blurRadius: 8)] : null,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(9),
          child: Stack(fit: StackFit.expand, children: [
            if (!ready) const Center(child: CircularProgressIndicator(strokeWidth: 2)) else FutureBuilder<Uint8List?>(
              future: _preview(i, 240, (240 * _aspect).round()),
              builder: (ctx, s) {
                if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator(strokeWidth: 2));
                final b = s.data;
                if (b == null) {
                  return Container(
                    color: green.withAlpha(40),
                    alignment: Alignment.center,
                    padding: const EdgeInsets.all(6),
                    child: Text(Platform.isAndroid ? 'پریویو نہیں بن سکا' : 'پریویو صرف اینڈرائیڈ پر', textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)),
                  );
                }
                return Image.memory(b, fit: BoxFit.cover, gaplessPlayback: true);
              },
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                color: Colors.black54,
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Text('${i + 1}. ${wpThemeNames[i]}', textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            ),
            if (sel) const Positioned(top: 4, right: 4, child: CircleAvatar(radius: 11, backgroundColor: green, child: Icon(Icons.check, size: 15, color: Colors.white))),
          ]),
        ),
      ),
    );
  }

  Widget _btn(IconData ic, String t, VoidCallback f, {bool primary = false}) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: SizedBox(
          width: double.infinity,
          height: 50,
          child: primary
              ? ElevatedButton.icon(onPressed: busy ? null : f, icon: Icon(ic), label: Text(t))
              : OutlinedButton.icon(
                  onPressed: busy ? null : f,
                  icon: Icon(ic, color: green),
                  label: Text(t, style: const TextStyle(color: green, fontWeight: FontWeight.bold)),
                  style: OutlinedButton.styleFrom(side: const BorderSide(color: green), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                ),
        ),
      );

  @override
  Widget build(BuildContext context) => Rebuild((c) {
        final sel = wpTheme();
        return Screen(
          'ڈیمنز وال پیپر',
          ListView(padding: const EdgeInsets.all(10), children: [
            box(
              c,
              child: Row(children: [
                Icon(active == true ? Icons.check_circle : Icons.info_outline, color: active == true ? green2 : Colors.orange, size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    active == null ? 'حالت معلوم کی جا رہی ہے…' : (active == true ? 'MSF لائیو وال پیپر فعال ہے' : 'MSF لائیو وال پیپر ابھی فعال نہیں ہے'),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(onPressed: _status, icon: const Icon(Icons.refresh, color: green)),
              ]),
            ),
            sectionTitle('ڈیزائن / تھیم منتخب کریں'),
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Text('ایک بار دبائیں: منتخب کریں۔ دیر تک دبائیں: چلتا ہوا پریویو دیکھیں۔', style: TextStyle(fontSize: 12)),
            ),
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 1 / (_aspect.clamp(1.3, 2.6) + 0.0),
              children: [for (var i = 0; i < wpThemeNames.length; i++) _tile(c, i)],
            ),
            const SizedBox(height: 10),
            sectionTitle('ڈیمنز (Dims) — اسکرین کا سائز'),
            box(
              c,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (dev != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('آپ کے فون کی اسکرین: ${dev![0]}×${dev![1]}', style: const TextStyle(fontSize: 12))),
                Wrap(spacing: 8, runSpacing: 6, children: [
                  for (var i = 0; i < wpDims.length; i++)
                    ChoiceChip(
                      label: Text(i == 0 ? 'خودکار (آپ کا فون)' : '${wpDims[i][0]}×${wpDims[i][1]}'),
                      selected: wpDim() == i,
                      selectedColor: green.withAlpha(60),
                      onSelected: (_) {
                        _cache.clear();
                        setI('wp_dim', i);
                        syncWallpaper();
                      },
                    ),
                ]),
                const SizedBox(height: 6),
                const Text('ڈیزائن اسی تناسب سے بنتا ہے۔ اگر اسکرین کا تناسب مختلف ہو تو کنارے ہلکے سے کٹ سکتے ہیں۔ «خودکار» سب سے بہتر ہے۔', style: TextStyle(fontSize: 11.5, height: 1.6)),
              ]),
            ),
            SwitchListTile(
              value: wpSec(),
              activeColor: green,
              title: const Text('سیکنڈ کی سوئی چلائیں'),
              subtitle: const Text('بند کرنے سے بیٹری کم خرچ ہوتی ہے (گھڑی منٹ کے حساب سے چلے گی)'),
              onChanged: (v) {
                setB('wp_sec', v);
                syncWallpaper();
              },
            ),
            const SizedBox(height: 6),
            sectionTitle('وال پیپر لگائیں'),
            _btn(Icons.live_tv, 'لائیو وال پیپر لگائیں (چلتی گھڑی)', () => _openLive(c), primary: true),
            _btn(Icons.lock, 'صرف لاک اسکرین (ساکن تصویر)', () => _static(c, 2)),
            _btn(Icons.home, 'صرف ہوم اسکرین (ساکن تصویر)', () => _static(c, 1)),
            _btn(Icons.smartphone, 'ہوم اور لاک دونوں (ساکن تصویر)', () => _static(c, 3)),
            _btn(Icons.visibility, 'منتخب ڈیزائن کا چلتا پریویو', () => _full(c, sel)),
            if (busy) const Padding(padding: EdgeInsets.all(8), child: Center(child: CircularProgressIndicator())),
            box(
              c,
              child: const Text(
                'لائیو وال پیپر: کھلنے والی اسکرین میں «وال پیپر لگائیں» دبائیں، پھر ہوم، لاک یا دونوں چنیں۔ ہوم اور لاک پر گھڑی لائیو چلے گی اور اوقات خود بدلتے رہیں گے۔ نماز کے اوقات ایپ سے لیے جاتے ہیں (اگلے 60 دن)، اس لیے مہینے میں ایک بار ایپ کھول لیں۔ موسم کی معلومات انٹرنیٹ کے بغیر دستیاب نہیں، اس لیے وال پیپر میں نہیں دکھائی جاتی۔',
                style: TextStyle(fontSize: 12, height: 1.7),
              ),
            ),
          ]),
        );
      });
}

/// Full-size preview that redraws every second, so the clock moves.
class _LiveDialog extends StatefulWidget {
  final int theme;
  final double aspect;
  const _LiveDialog({required this.theme, required this.aspect});
  @override
  State<_LiveDialog> createState() => _LiveDialogState();
}

class _LiveDialogState extends State<_LiveDialog> {
  Uint8List? img;
  Timer? t;
  bool loading = false;

  @override
  void initState() {
    super.initState();
    _load();
    t = Timer.periodic(const Duration(seconds: 1), (_) => _load());
  }

  @override
  void dispose() {
    t?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (loading) return;
    loading = true;
    final b = await _call<Uint8List>('preview', {'theme': widget.theme, 'dim': wpDim(), 'w': 540, 'h': (540 * widget.aspect).round()});
    loading = false;
    if (mounted && b != null) setState(() => img = b);
  }

  @override
  Widget build(BuildContext context) => Dialog(
        insetPadding: const EdgeInsets.all(14),
        backgroundColor: Colors.black,
        child: Stack(children: [
          AspectRatio(
            aspectRatio: 1 / widget.aspect,
            child: img == null ? const Center(child: CircularProgressIndicator()) : Image.memory(img!, fit: BoxFit.cover, gaplessPlayback: true),
          ),
          Positioned(top: 4, left: 4, child: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close, color: Colors.white))),
        ]),
      );
}
