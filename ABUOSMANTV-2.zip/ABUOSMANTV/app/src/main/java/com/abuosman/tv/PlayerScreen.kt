package com.abuosman.tv

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(
    ch: Channel, st: AppState, delayMs: Long,
    onPrev: () -> Unit, onNext: () -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val activity = ctx as Activity
    var buffering by remember { mutableStateOf(true) }
    var full by remember { mutableStateOf(false) }
    var retries by remember { mutableStateOf(0) }
    val handler = remember { Handler(Looper.getMainLooper()) }
    val startTime = remember { System.currentTimeMillis() }
    val startElapsed = remember { SystemClock.elapsedRealtime() }

    val exo = remember {
        // Fast Start: کم بفر کے ساتھ جلدی شروع
        val lc = DefaultLoadControl.Builder().setBufferDurationsMs(10_000, 40_000, 1_500, 3_000).build()
        ExoPlayer.Builder(ctx).setLoadControl(lc).build()
    }

    BackHandler(enabled = full) { full = false }

    LaunchedEffect(Unit) { st.addHistory(ch.id, startTime) }
    LaunchedEffect(ch.url) {
        if (ch.url.isNotBlank()) {
            if (delayMs > 0) delay(delayMs)
            exo.setMediaItem(MediaItem.fromUri(ch.url)); exo.prepare(); exo.playWhenReady = true
        }
    }
    LaunchedEffect(st.quality, st.dataMode) {
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(Int.MAX_VALUE, st.maxHeight()).build()
    }
    LaunchedEffect(full) {
        activity.requestedOrientation =
            if (full) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val c = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        if (full) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }
    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(s: Int) {
                buffering = s == Player.STATE_BUFFERING
                if (s == Player.STATE_READY) retries = 0
            }
            // Auto Retry: رکنے پر 5 بار دوبارہ کوشش
            override fun onPlayerError(error: PlaybackException) {
                if (st.autoRetry && retries < 5) {
                    retries++
                    handler.postDelayed({ exo.prepare() }, 2000L)
                } else {
                    Toast.makeText(ctx, "Could not play channel | چینل نہیں چل سکا", Toast.LENGTH_LONG).show()
                }
            }
        }
        exo.addListener(l)
        onDispose {
            handler.removeCallbacksAndMessages(null)
            exo.removeListener(l)
            exo.release()
            st.addDuration(startTime, (SystemClock.elapsedRealtime() - startElapsed) / 1000)
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                .show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Column(Modifier.fillMaxSize().background(C.bg)) {
        if (!full) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(RoundedCornerShape(8.dp)).background(C.card).clickable { onBack() }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text("←", color = Color.White, fontSize = 18.sp)
                }
                Spacer(Modifier.width(10.dp))
                Bi(ch.name, ch.nameUr, st, Modifier.weight(1f), size = 17.sp, bold = true)
                Text(if (ch.id in st.favorites) "❤️" else "🤍", fontSize = 26.sp,
                    modifier = Modifier.clickable { st.toggleFav(ch.id) }.padding(6.dp))
            }
        }
        Box(
            if (full) Modifier.fillMaxSize().background(Color.Black)
            else Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            if (ch.url.isBlank()) {
                Text("No stream link added for this channel\nاس چینل کا اسٹریم لنک شامل نہیں کیا گیا",
                    color = Color.White, modifier = Modifier.padding(16.dp))
            } else {
                AndroidView(
                    factory = {
                        PlayerView(it).apply {
                            this.player = exo
                            useController = true
                            keepScreenOn = st.keepOn
                            setFullscreenButtonClickListener { f -> full = f }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
                if (buffering) CircularProgressIndicator(color = C.blue)
            }
        }
        if (!full) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(C.card)
                        .border(1.dp, C.border, RoundedCornerShape(10.dp)).clickable { onPrev() }.padding(12.dp),
                        contentAlignment = Alignment.Center) { Text("⏮  Previous", color = Color.White) }
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(C.card)
                        .border(1.dp, C.border, RoundedCornerShape(10.dp)).clickable { onNext() }.padding(12.dp),
                        contentAlignment = Alignment.Center) { Text("Next  ⏭", color = Color.White) }
                }
                Bi("Video Quality", "ویڈیو کوالٹی", st, size = 14.sp, bold = true)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0 to "Auto", 240 to "240p", 360 to "360p", 480 to "480p", 720 to "720p", 1080 to "1080p").forEach { (v, label) ->
                        val sel = st.quality == v
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (sel) C.blue else C.card)
                                .border(1.dp, if (sel) Color(0xFF5B9BFF) else C.border, RoundedCornerShape(8.dp))
                                .clickable { st.setQuality(v) }.padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(label, color = Color.White, fontSize = 11.sp) }
                    }
                }
                Text(
                    when (st.dataMode) {
                        1 -> "Data Saver: max 480p  |  کم ڈیٹا موڈ"
                        2 -> "Low Data: max 360p  |  بہت کم ڈیٹا"
                        else -> "Standard mode  |  معیاری موڈ"
                    }, color = C.sub, fontSize = 12.sp
                )
            }
        }
    }
}
