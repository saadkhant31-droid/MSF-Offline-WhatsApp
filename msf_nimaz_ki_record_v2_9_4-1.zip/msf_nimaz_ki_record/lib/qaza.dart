import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'home.dart';
import 'prayers.dart';
import 'reports.dart';
import 'settings.dart';
import 'nav_common.dart' show msfNav7;

const _deep = Color(0xFF0B4D2E);
const _bannerGreen = Color(0xFF0E5B37);
const _red = Color(0xFFD32F2F);

// فرض (اور وتر) رکعات، اور سنت مؤکدہ رکعات
const _rakat = [2, 4, 4, 3, 4, 3];
const _sunnah = [2, 6, 0, 2, 2, 0];

const _pIcons = [Icons.wb_twilight, Icons.wb_sunny, Icons.light_mode, Icons.wb_twilight, Icons.nightlight_round];
const _pCols = [Color(0xFFF2A413), Color(0xFFF2A413), Color(0xFFEF7D12), Color(0xFFE65100), Color(0xFF1E3A8A)];

class _R {
  final String name;
  final IconData icon;
  final Color color;
  const _R(this.name, this.icon, this.color);
}

const _reasons = <_R>[
  _R('نیند', Icons.bedtime, Color(0xFF1E88E5)),
  _R('کام / روزگار', Icons.work, Color(0xFF1565C0)),
  _R('کھیل', Icons.sports_cricket, Color(0xFFD32F2F)),
  _R('بیماری', Icons.sick, Color(0xFF7B1FA2)),
  _R('سفر', Icons.flight, Color(0xFF1976D2)),
  _R('بھول جانا', Icons.schedule, Color(0xFF00897B)),
  _R('سستی / غفلت', Icons.warning_amber, Color(0xFFD32F2F)),
  _R('کوئی دوسری وجہ', Icons.edit, Color(0xFF1E88E5)),
];

String _two(int n) => n < 10 ? '0$n' : '$n';
String _fmtD(DateTime d) => '${d.year}-${_two(d.month)}-${_two(d.day)}';

// ------------------------------------------------------------------ shared dialogs / actions
Future<void> _editCount(BuildContext c, int i) async {
  final ctrl = TextEditingController(text: '${qazaBase(i)}');
  final ok = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text('${qazaNames[i]} کی پرانی قضا کی تعداد'),
      content: TextField(controller: ctrl, keyboardType: TextInputType.number, inputFormatters: [FilteringTextInputFormatter.digitsOnly], autofocus: true),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('محفوظ')),
      ],
    ),
  );
  if (ok == true) {
    final v = int.tryParse(ctrl.text.trim()) ?? 0;
    setI('qz_base_$i', v < 0 ? 0 : v);
  }
}

Future<void> _oldCountsDialog(BuildContext c) async {
  final ctrls = [for (int i = 0; i < 6; i++) TextEditingController(text: '${qazaBase(i)}')];
  final ok = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: const Text('پرانی قضا نمازوں کی ابتدائی تعداد'),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (int i = 0; i < 6; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(children: [
                SizedBox(width: 60, child: Text(qazaNames[i], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                Expanded(
                  child: TextField(
                    controller: ctrls[i],
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(isDense: true, border: OutlineInputBorder()),
                  ),
                ),
              ]),
            ),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('محفوظ')),
      ],
    ),
  );
  if (ok == true) {
    for (int i = 0; i < 6; i++) {
      final v = int.tryParse(ctrls[i].text.trim()) ?? 0;
      sp.setInt('qz_base_$i', v < 0 ? 0 : v);
    }
    bump();
    if (c.mounted) toast(c, 'پرانی قضا کی تعداد محفوظ ہو گئی');
  }
}

Future<void> _addDialog(BuildContext c) async {
  int p = 0;
  DateTime d = dayOnly(DateTime.now());
  final reason = TextEditingController();
  final ok = await showDialog<bool>(
    context: c,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS2) => AlertDialog(
        title: const Text('نئی قضا نماز'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 6, children: [
              for (int i = 0; i < 6; i++) ChoiceChip(label: Text(qazaNames[i]), selected: p == i, onSelected: (_) => setS2(() => p = i)),
            ]),
            const SizedBox(height: 10),
            TextButton.icon(
              onPressed: () async {
                final r = await showDatePicker(context: ctx, initialDate: d, firstDate: DateTime(2000), lastDate: DateTime.now());
                if (r != null) setS2(() => d = dayOnly(r));
              },
              icon: const Icon(Icons.calendar_month),
              label: Text(fmtDate(d)),
            ),
            TextField(controller: reason, decoration: const InputDecoration(labelText: 'وجہ / تفصیل')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('شامل کریں')),
        ],
      ),
    ),
  );
  if (ok == true) addQaza(p, d, reason.text.trim());
}

/// ایک قضا ادا شمار کرتا ہے (پہلے پرانی تعداد سے، پھر ریکارڈ کی سب سے پرانی قضا سے)
bool _makeUp(BuildContext c, int p) {
  if (qazaBase(p) > 0) {
    sp.setInt('qz_base_$p', qazaBase(p) - 1);
  } else {
    final l = qazaLog();
    final idx = l.indexWhere((x) => x['p'] == p && x['done'] != true);
    if (idx < 0) {
      toast(c, '${qazaNames[p]} کی کوئی قضا باقی نہیں');
      return false;
    }
    l[idx]['done'] = true;
    l[idx]['ad'] = dayKey(DateTime.now());
    saveQazaLog(l);
  }
  setI('qz_made_$p', qazaMade(p) + 1);
  return true;
}

Widget _qazaEntry(BuildContext c, Map<String, dynamic> e, bool done) {
  final p = clampI((e['p'] as int?) ?? 0, 0, 5);
  final reason = (e['r'] as String?) ?? '';
  final ad = (e['ad'] as String?) ?? '';
  return box(
    c,
    color: done ? Colors.grey.withAlpha(40) : null,
    child: Row(children: [
      Icon(done ? Icons.check_circle : Icons.event_busy, color: done ? green : _red),
      const SizedBox(width: 10),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(qazaNames[p], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text('تاریخ: ${e['d']}', style: TextStyle(fontSize: 12, color: subText(c))),
          if (done && ad.isNotEmpty) Text('ادا کی تاریخ: $ad', style: TextStyle(fontSize: 12, color: subText(c))),
          if (reason.isNotEmpty) Text('وجہ: $reason', style: TextStyle(fontSize: 12, color: subText(c))),
        ]),
      ),
      IconButton(
        tooltip: done ? 'واپس' : 'ادا کر لی',
        icon: Icon(done ? Icons.undo : Icons.done_all, color: green),
        onPressed: () {
          final l = qazaLog();
          final idx = l.indexWhere((x) => x['id'] == e['id']);
          if (idx < 0) return;
          l[idx]['done'] = !done;
          final made = qazaMade(p);
          sp.setInt('qz_made_$p', done ? (made > 0 ? made - 1 : 0) : made + 1);
          saveQazaLog(l);
        },
      ),
      IconButton(
        icon: const Icon(Icons.delete_outline, color: Colors.grey),
        onPressed: () async {
          if (!await confirmDialog(c, 'یہ ریکارڈ حذف کریں؟')) return;
          final l = qazaLog();
          l.removeWhere((x) => x['id'] == e['id']);
          saveQazaLog(l);
        },
      ),
    ]),
  );
}

// ------------------------------------------------------------------ main qaza screen
class QazaScreen extends StatefulWidget {
  const QazaScreen({super.key});
  @override
  State<QazaScreen> createState() => _QazaState();
}

class _QazaState extends State<QazaScreen> {
  int? missed; // کون سی نماز قضا ہوئی
  int? atTime; // کس نماز کے وقت ادا کی
  int? reason;
  String customReason = '';
  DateTime qDate = dayOnly(DateTime.now());
  DateTime aDate = dayOnly(DateTime.now());
  int adaRakat = 0;
  late int tarDone;
  final estCtrl = TextEditingController();

  String get _tarKey => 'qz_tar_${dayKey(DateTime.now())}';

  @override
  void initState() {
    super.initState();
    tarDone = clampI(getI(_tarKey), 0, 20);
  }

  @override
  void dispose() {
    estCtrl.dispose();
    super.dispose();
  }

  String get _reasonText {
    if (reason == null) return '';
    if (reason == _reasons.length - 1) return customReason;
    return _reasons[reason!].name;
  }

  Future<void> _pickDate(bool isQaza) async {
    final r = await showDatePicker(
      context: context,
      initialDate: isQaza ? qDate : aDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (r == null) return;
    setState(() {
      if (isQaza) {
        qDate = dayOnly(r);
      } else {
        aDate = dayOnly(r);
      }
    });
  }

  Future<void> _pickReason(int i) async {
    if (i == _reasons.length - 1) {
      final ctrl = TextEditingController(text: customReason);
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('کوئی دوسری وجہ'),
          content: TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(hintText: 'وجہ لکھیں')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('محفوظ')),
          ],
        ),
      );
      if (ok == true) {
        setState(() {
          customReason = ctrl.text.trim();
          reason = customReason.isEmpty ? null : i;
        });
      }
      return;
    }
    setState(() => reason = reason == i ? null : i);
  }

  void _save() {
    final p = missed;
    if (p == null) {
      toast(context, 'پہلے بتائیں کون سی نماز قضا ہوئی');
      return;
    }
    final madeUp = atTime != null;
    if (madeUp && aDate.isBefore(qDate)) {
      toast(context, 'ادا کی تاریخ قضا کی تاریخ سے پہلے نہیں ہو سکتی');
      return;
    }
    final l = qazaLog();
    l.add({
      'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'p': p,
      'd': dayKey(qDate),
      'r': _reasonText,
      'done': madeUp,
      'src': '',
      if (madeUp) 'ad': dayKey(aDate),
      if (madeUp) 'at': atTime,
    });
    if (madeUp) sp.setInt('qz_made_$p', qazaMade(p) + 1);
    saveQazaLog(l);
    setState(() {
      missed = null;
      atTime = null;
      reason = null;
      customReason = '';
      adaRakat = 0;
    });
    toast(context, madeUp ? 'ادا شدہ قضا کا ریکارڈ محفوظ ہو گیا' : 'قضا نماز کا ریکارڈ محفوظ ہو گیا');
  }

  void _complete() {
    final p = missed;
    if (p == null) {
      toast(context, 'پہلے بتائیں کون سی نماز قضا ہوئی');
      return;
    }
    if (_makeUp(context, p)) {
      setState(() => adaRakat = 0);
      toast(context, '${qazaNames[p]} کی ایک قضا ادا شمار ہو گئی');
    }
  }

  Future<void> _saveEstimate() async {
    final n = int.tryParse(estCtrl.text.trim()) ?? 0;
    if (n <= 0) {
      toast(context, 'تعداد درج کریں');
      return;
    }
    if (!await confirmDialog(context, 'ہر نماز (فجر تا وتر) کی پرانی قضا میں $n شامل کریں؟')) return;
    for (int i = 0; i < 6; i++) {
      sp.setInt('qz_base_$i', qazaBase(i) + n);
    }
    bump();
    estCtrl.clear();
    if (mounted) {
      FocusScope.of(context).unfocus();
      toast(context, 'تعداد شامل ہو گئی');
    }
  }

  // ---------------------------------------------------------------- build
  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
        child: Scaffold(
          backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
          bottomNavigationBar: _nav(context),
          body: Rebuild((c) => _body(c)),
        ),
      );

  Widget _body(BuildContext c) {
    final w = MediaQuery.of(c).size.width;
    return ListView(padding: EdgeInsets.zero, children: [
      _header(c, w),
      _banner(c),
      _tiles(c),
      _selectors(c),
      _entrySection(c),
      _tableRow(c),
      _bottomCards(c),
      _quote(c),
      Image.asset('assets/footer.png', width: double.infinity, fit: BoxFit.fitWidth),
    ]);
  }

  Widget _header(BuildContext c, double w) => SizedBox(
        width: w,
        height: w * 215 / 1024,
        child: Stack(children: [
          Positioned.fill(child: Image.asset('assets/qaza/header.png', fit: BoxFit.fill)),
          Positioned(
            left: w * 0.018,
            top: w * 58 / 1024,
            width: w * 0.165,
            height: w * 62 / 1024,
            child: Material(
              color: Colors.transparent,
              child: InkWell(borderRadius: BorderRadius.circular(30), onTap: () => Navigator.maybePop(c)),
            ),
          ),
        ]),
      );

  Widget _banner(BuildContext c) => Container(
        margin: const EdgeInsets.fromLTRB(8, 8, 8, 8),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF0B4D2E), Color(0xFF14804A)]),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: gold.withAlpha(140)),
        ),
        child: Row(children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: gold, width: 1.6)),
            child: const Icon(Icons.self_improvement, color: Colors.white, size: 32),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 5,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('قضا نماز', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
              const SizedBox(height: 2),
              const Text('جو نمازیں قضا رہ گئیں، ان کا مکمل ریکارڈ رکھیں', style: TextStyle(color: Colors.white, fontSize: 11.5, height: 1.4)),
            ]),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
              decoration: BoxDecoration(border: Border(right: BorderSide(color: gold.withAlpha(120)))),
              child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('جو نماز سے سو جائے یا بھول جائے، جب یاد آئے اسی وقت پڑھ لے۔', style: TextStyle(color: Colors.white, fontSize: 10.5, height: 1.5)),
                SizedBox(height: 2),
                Text('(بخاری و مسلم)', style: TextStyle(color: gold, fontSize: 10)),
              ]),
            ),
          ),
        ]),
      );

  // ---------------------------------------------------------------- action tiles
  Widget _tile(BuildContext c, IconData icon, Color col, String title, String sub, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          height: 104,
          padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 8),
          decoration: BoxDecoration(
            color: Color.alphaBlend(col.withAlpha(22), cardColor(c)),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: col.withAlpha(60)),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(color: col, shape: BoxShape.circle),
              child: Icon(icon, color: Colors.white, size: 22),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Text(title, maxLines: 2, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, height: 1.25)),
            ),
            FittedBox(fit: BoxFit.scaleDown, child: Text(sub, style: TextStyle(fontSize: 9, color: subText(c)))),
          ]),
        ),
      );

  Widget _tiles(BuildContext c) {
    final items = <Widget>[
      _tile(c, Icons.settings, const Color(0xFF0B3D4A), 'سیٹنگز', 'مزید آپشنز', () => go(c, const SettingsScreen())),
      _tile(c, Icons.bar_chart, const Color(0xFF4A3BC0), 'رپورٹس', 'اعداد و شمار', () => go(c, const QazaReportScreen())),
      _tile(c, Icons.format_list_bulleted, const Color(0xFFE53950), 'باقی قضا نمازیں', 'دیکھیں', () => go(c, const QazaListScreen(pendingOnly: true))),
      _tile(c, Icons.add, const Color(0xFF1B8A45), 'نئی قضا نماز شامل کریں', 'ریکارڈ بنائیں', () => _addDialog(c)),
      _tile(c, Icons.description, const Color(0xFF4F46E5), 'قضا نماز کی فہرست', 'تمام ریکارڈ دیکھیں', () => go(c, const QazaListScreen())),
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      child: Row(children: [
        for (int i = 0; i < items.length; i++) ...[
          if (i > 0) const SizedBox(width: 5),
          Expanded(child: items[i]),
        ],
      ]),
    );
  }

  // ---------------------------------------------------------------- selector cards
  Widget _panel(BuildContext c, Widget child) => Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: cardColor(c),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: green.withAlpha(55)),
          boxShadow: [BoxShadow(color: Colors.black.withAlpha(14), blurRadius: 4, offset: const Offset(0, 1))],
        ),
        child: child,
      );

  Widget _panelHead(BuildContext c, IconData icon, String title, String sub) => Row(children: [
        Container(
          width: 26,
          height: 26,
          decoration: const BoxDecoration(color: green, shape: BoxShape.circle),
          child: Icon(icon, color: Colors.white, size: 15),
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(title, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold))),
            Text(sub, maxLines: 2, style: TextStyle(fontSize: 8.5, color: subText(c), height: 1.2)),
          ]),
        ),
      ]);

  Widget _prayerCard(BuildContext c, String title, String sub, IconData icon, int? sel, void Function(int) onSel, bool showRakat) => _panel(
        c,
        Column(children: [
          _panelHead(c, icon, title, sub),
          const SizedBox(height: 6),
          for (int i = 0; i < 5; i++)
            InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () => onSel(i),
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 2),
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                decoration: BoxDecoration(
                  color: sel == i ? green.withAlpha(28) : null,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: sel == i ? green : Colors.grey.withAlpha(80)),
                ),
                child: Row(children: [
                  Icon(_pIcons[i], size: 16, color: _pCols[i]),
                  const SizedBox(width: 3),
                  Expanded(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: AlignmentDirectional.centerStart,
                      child: Text(showRakat ? '${qazaNames[i]}  ${_rakat[i]} رکعت' : qazaNames[i], style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  Icon(sel == i ? Icons.check_circle : Icons.radio_button_unchecked, size: 15, color: green),
                ]),
              ),
            ),
        ]),
      );

  Widget _reasonCard(BuildContext c) => _panel(
        c,
        Column(children: [
          _panelHead(c, Icons.assignment, 'قضا نماز ہونے کی وجہ', 'آپ کی نماز کس وجہ سے قضا ہوئی؟'),
          const SizedBox(height: 6),
          LayoutBuilder(builder: (ctx, bc) {
            final tw = (bc.maxWidth - 6) / 2;
            return Wrap(spacing: 6, runSpacing: 6, children: [
              for (int i = 0; i < _reasons.length; i++)
                SizedBox(
                  width: tw,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(8),
                    onTap: () => _pickReason(i),
                    child: Container(
                      height: 54,
                      padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
                      decoration: BoxDecoration(
                        color: reason == i ? green.withAlpha(28) : null,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: reason == i ? green : Colors.grey.withAlpha(80)),
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(_reasons[i].icon, color: _reasons[i].color, size: 21),
                        const SizedBox(height: 2),
                        FittedBox(fit: BoxFit.scaleDown, child: Text(_reasons[i].name, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold))),
                      ]),
                    ),
                  ),
                ),
            ]);
          }),
        ]),
      );

  Widget _selectors(BuildContext c) => Padding(
        padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            flex: 27,
            child: _prayerCard(c, 'کس نماز کے وقت ادا کی؟', 'نماز کے وقت کا انتخاب کریں', Icons.schedule, atTime, (i) => setState(() => atTime = atTime == i ? null : i), false),
          ),
          const SizedBox(width: 6),
          Expanded(
            flex: 29,
            child: _prayerCard(c, 'کون سی نماز قضا ہوئی؟', 'نماز کا انتخاب کریں', Icons.self_improvement, missed, (i) => setState(() => missed = missed == i ? null : i), true),
          ),
          const SizedBox(width: 6),
          Expanded(flex: 40, child: _reasonCard(c)),
        ]),
      );

  // ---------------------------------------------------------------- entry section
  Widget _bar(String title, IconData icon, {bool topOnly = true}) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: _bannerGreen,
          borderRadius: topOnly ? const BorderRadius.vertical(top: Radius.circular(10)) : BorderRadius.circular(8),
        ),
        child: Row(children: [
          Icon(icon, color: Colors.white, size: 18),
          const SizedBox(width: 6),
          Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 13.5, fontWeight: FontWeight.bold))),
        ]),
      );

  Widget _cell(BuildContext c, Widget child, {VoidCallback? onTap}) => InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: cardColor(c),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: green.withAlpha(55)),
          ),
          child: child,
        ),
      );

  Widget _dateCell(BuildContext c, String label, DateTime d, bool isQaza) => _cell(
        c,
        Column(children: [
          Icon(Icons.calendar_month, color: green, size: 22),
          const SizedBox(height: 2),
          FittedBox(fit: BoxFit.scaleDown, child: Text(label, style: TextStyle(fontSize: 10, color: subText(c)))),
          FittedBox(fit: BoxFit.scaleDown, child: Text(_fmtD(d), style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold))),
        ]),
        onTap: () => _pickDate(isQaza),
      );

  Widget _entrySection(BuildContext c) {
    final p = missed;
    final summaryName = p == null ? '—' : qazaNames[p];
    final rText = _reasonText.isEmpty ? '—' : _reasonText;
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      child: Column(children: [
        _bar('قضا نماز کا اندراج', Icons.mosque),
        Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: isDark(c) ? const Color(0xFF16231B) : const Color(0xFFEAF4EC),
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(10)),
            border: Border.all(color: green.withAlpha(50)),
          ),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              flex: 6,
              child: Column(children: [
                Row(children: [
                  Expanded(child: _dateCell(c, 'تاریخ قضا', qDate, true)),
                  const SizedBox(width: 6),
                  Expanded(child: _dateCell(c, 'ادا کی تاریخ', aDate, false)),
                ]),
                const SizedBox(height: 6),
                _cell(
                  c,
                  Row(children: [
                    const Icon(Icons.mosque, color: green, size: 26),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text('قضا نماز: $summaryName', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
                        FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text('قضا کی وجہ: $rText', style: TextStyle(fontSize: 11, color: subText(c)))),
                      ]),
                    ),
                  ]),
                ),
                const SizedBox(height: 6),
                _cell(
                  c,
                  Row(children: [
                    const Icon(Icons.wb_sunny, color: Color(0xFFF2A413), size: 26),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('کس نماز کے وقت ادا کی؟', style: TextStyle(fontSize: 9.5, color: subText(c))),
                        Text(atTime == null ? '—' : qazaNames[atTime!], style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                      ]),
                    ),
                  ]),
                ),
                const SizedBox(height: 6),
                Text('نوٹ: "کس نماز کے وقت ادا کی؟" چنیں تو قضا ادا شدہ درج ہو گی، ورنہ باقی۔', style: TextStyle(fontSize: 9.5, color: subText(c), height: 1.4)),
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: green),
                    onPressed: _save,
                    icon: const Icon(Icons.save, size: 18),
                    label: const Text('ریکارڈ محفوظ کریں'),
                  ),
                ),
              ]),
            ),
            const SizedBox(width: 7),
            Expanded(
              flex: 4,
              child: Column(children: [_rakatPanel(c), const SizedBox(height: 7), _tarPanel(c)]),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _stepper(int v, VoidCallback minus, VoidCallback plus) => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        InkWell(onTap: minus, child: const Icon(Icons.remove_circle_outline, color: _red, size: 22)),
        SizedBox(width: 26, child: Text('$v', textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold))),
        InkWell(onTap: plus, child: const Icon(Icons.add_circle_outline, color: green, size: 22)),
      ]);

  Widget _rakatPanel(BuildContext c) {
    final p = missed;
    final fard = p == null ? 0 : _rakat[p];
    final sun = p == null ? 0 : _sunnah[p];
    final rem = fard - adaRakat < 0 ? 0 : fard - adaRakat;
    Widget col(String t, int v) => Expanded(
          child: Column(children: [
            FittedBox(fit: BoxFit.scaleDown, child: Text(t, style: TextStyle(fontSize: 10, color: subText(c)))),
            Text('$v', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ]),
        );
    return Column(children: [
      _bar('رکعتوں کی ریکارڈ', Icons.format_list_numbered),
      Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: cardColor(c),
          borderRadius: const BorderRadius.vertical(bottom: Radius.circular(10)),
          border: Border.all(color: green.withAlpha(55)),
        ),
        child: Column(children: [
          Row(children: [col('فرض', fard), col('سنت', sun), col('نفل', 0)]),
          const Divider(height: 12),
          FittedBox(fit: BoxFit.scaleDown, child: Text('ادا کی گئی رکعتیں', style: TextStyle(fontSize: 10, color: subText(c)))),
          _stepper(adaRakat, () => setState(() => adaRakat = adaRakat > 0 ? adaRakat - 1 : 0), () => setState(() => adaRakat = adaRakat < fard ? adaRakat + 1 : adaRakat)),
          const SizedBox(height: 4),
          FittedBox(fit: BoxFit.scaleDown, child: Text('باقی رکعتیں: $rem', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: _red))),
          const SizedBox(height: 6),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6), minimumSize: const Size(0, 32)),
              onPressed: _complete,
              child: const FittedBox(fit: BoxFit.scaleDown, child: Text('مکمل ادا ہو گئی ✓', style: TextStyle(fontSize: 11))),
            ),
          ),
        ]),
      ),
    ]);
  }

  Widget _tarPanel(BuildContext c) {
    final rem = 20 - tarDone;
    return Column(children: [
      _bar('تراویح کی رکعتیں', Icons.nightlight_round),
      Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          color: cardColor(c),
          borderRadius: const BorderRadius.vertical(bottom: Radius.circular(10)),
          border: Border.all(color: green.withAlpha(55)),
        ),
        child: Column(children: [
          FittedBox(fit: BoxFit.scaleDown, child: Text('کل رکعتیں: 20', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
          const SizedBox(height: 4),
          FittedBox(fit: BoxFit.scaleDown, child: Text('پڑھی گئی رکعتیں', style: TextStyle(fontSize: 10, color: subText(c)))),
          _stepper(tarDone, () => setState(() => tarDone = tarDone >= 2 ? tarDone - 2 : 0), () => setState(() => tarDone = tarDone <= 18 ? tarDone + 2 : 20)),
          const SizedBox(height: 4),
          FittedBox(fit: BoxFit.scaleDown, child: Text('باقی رکعتیں: $rem', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: _red))),
          const SizedBox(height: 6),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6), minimumSize: const Size(0, 32)),
              onPressed: () {
                setI(_tarKey, tarDone);
                toast(c, 'تراویح کا ریکارڈ محفوظ ہو گیا');
              },
              child: const FittedBox(fit: BoxFit.scaleDown, child: Text('ریکارڈ محفوظ کریں', style: TextStyle(fontSize: 11))),
            ),
          ),
        ]),
      ),
    ]);
  }

  // ---------------------------------------------------------------- remaining table + estimate
  Widget _th(String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 2),
        child: Text(t, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold)),
      );

  Widget _td(BuildContext c, int i, String t, {Color? col, bool bold = false}) => InkWell(
        onTap: i < 0 ? null : () => _editCount(c, i),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
          child: Text(t, textAlign: TextAlign.center, style: TextStyle(fontSize: 12.5, fontWeight: bold ? FontWeight.bold : FontWeight.w600, color: col)),
        ),
      );

  Widget _tableRow(BuildContext c) {
    var tp = 0, tm = 0;
    for (int i = 0; i < 6; i++) {
      tp += qazaPending(i);
      tm += qazaMade(i);
    }
    final table = Container(
      decoration: BoxDecoration(
        color: cardColor(c),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: green.withAlpha(55)),
      ),
      child: Column(children: [
        _bar('قضا نمازوں کی باقی تعداد', Icons.table_chart),
        Table(
          columnWidths: const {0: FlexColumnWidth(1.25), 1: FlexColumnWidth(1), 2: FlexColumnWidth(1), 3: FlexColumnWidth(1)},
          border: TableBorder(horizontalInside: BorderSide(color: Colors.grey.withAlpha(70))),
          children: [
            TableRow(
              decoration: BoxDecoration(color: green.withAlpha(25)),
              children: [_th('نماز'), _th('کل قضا'), _th('ادا کیں'), _th('باقی')],
            ),
            for (int i = 0; i < 6; i++)
              TableRow(children: [
                _td(c, i, qazaNames[i], bold: true),
                _td(c, i, '${qazaPending(i) + qazaMade(i)}'),
                _td(c, i, '${qazaMade(i)}', col: green),
                _td(c, i, '${qazaPending(i)}', col: _red, bold: true),
              ]),
            TableRow(
              decoration: BoxDecoration(color: gold.withAlpha(40)),
              children: [_td(c, -1, 'کل', bold: true), _td(c, -1, '${tp + tm}', bold: true), _td(c, -1, '$tm', col: green, bold: true), _td(c, -1, '$tp', col: _red, bold: true)],
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.all(4),
          child: Text('تعداد بدلنے کے لیے کسی قطار پر ٹیپ کریں', style: TextStyle(fontSize: 9, color: subText(c))),
        ),
      ]),
    );

    final est = _panel(
      c,
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 24,
            height: 24,
            decoration: const BoxDecoration(color: _deep, shape: BoxShape.circle),
            child: const Center(child: Text('?', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold))),
          ),
          const SizedBox(width: 4),
          const Expanded(child: Text('معلوم نہیں کہ کتنی قضا ہیں؟', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, height: 1.3))),
        ]),
        const SizedBox(height: 6),
        Text('اگر آپ کو اندازہ نہیں تو تقریباً کتنی نمازیں قضا ہوئی ہیں؟ درج کریں', style: TextStyle(fontSize: 10, color: subText(c), height: 1.4)),
        const SizedBox(height: 8),
        TextField(
          controller: estCtrl,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          textAlign: TextAlign.center,
          decoration: InputDecoration(
            isDense: true,
            hintText: 'مثال: 5',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: green),
            onPressed: _saveEstimate,
            child: const Text('محفوظ کریں'),
          ),
        ),
      ]),
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 42, child: est),
        const SizedBox(width: 7),
        Expanded(flex: 58, child: table),
      ]),
    );
  }

  // ---------------------------------------------------------------- bottom link cards
  Widget _link(BuildContext c, Color col, IconData icon, String title, String sub, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          height: 74,
          padding: const EdgeInsets.symmetric(horizontal: 5),
          decoration: BoxDecoration(
            color: Color.alphaBlend(col.withAlpha(24), cardColor(c)),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: col.withAlpha(70)),
          ),
          child: Row(children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(color: col, shape: BoxShape.circle),
              child: Icon(icon, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 4),
            Expanded(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, maxLines: 2, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, height: 1.25)),
                const SizedBox(height: 2),
                Text(sub, maxLines: 2, style: TextStyle(fontSize: 8.5, color: subText(c), height: 1.2)),
              ]),
            ),
            Icon(Icons.chevron_left, size: 16, color: col),
          ]),
        ),
      );

  Widget _bottomCards(BuildContext c) => Padding(
        padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
        child: Row(children: [
          Expanded(child: _link(c, const Color(0xFF8A5A2B), Icons.menu_book, 'قضا نماز کی مکمل رہنمائی', 'مسائل و احکام (فقہ کے مطابق)', () => go(c, const QazaGuideScreen()))),
          const SizedBox(width: 5),
          Expanded(child: _link(c, const Color(0xFF0B3D5A), Icons.assignment, 'قضا نماز کی رپورٹ', 'دن، ہفتہ، ماہ اور سال کی رپورٹ', () => go(c, const QazaReportScreen()))),
          const SizedBox(width: 5),
          Expanded(child: _link(c, const Color(0xFF7B2FBF), Icons.history_edu, 'پرانی قضا نمازوں کا ریکارڈ', 'ابتدائی تعداد درج کریں', () => _oldCountsDialog(c))),
        ]),
      );

  Widget _quote(BuildContext c) => Container(
        margin: const EdgeInsets.fromLTRB(24, 4, 24, 6),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: _bannerGreen,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: gold.withAlpha(150)),
        ),
        child: const Text('"نماز کی قضا کو پورا کرنا اللہ کی رضا کا ذریعہ ہے۔"', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.bold)),
      );

  // ---------------------------------------------------------------- bottom nav
  Widget _nav(BuildContext c) {
    const items = <List<dynamic>>[
      [Icons.home, 'ہوم'],
      [Icons.mosque, 'نمازیں'],
      [Icons.fact_check, 'قضا نماز'],
      [Icons.bar_chart, 'رپورٹس'],
      [Icons.settings, 'سیٹنگز'],
      [Icons.menu, 'مزید'],
    ];
    void act(int i) {
      switch (i) {
        case 0:
          Navigator.of(c).popUntil((r) => r.isFirst);
          break;
        case 1:
          go(c, const PrayersScreen());
          break;
        case 2:
          break;
        case 3:
          go(c, const ReportScreen());
          break;
        case 4:
          go(c, const SettingsScreen());
          break;
        case 5:
          go(c, MorePage(features: allFeatures()));
          break;
      }
    }

    return Container(
      color: const Color(0xFF0B3D2A),
      padding: EdgeInsets.only(bottom: MediaQuery.of(c).padding.bottom, top: 4),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          for (int i = 0; i < items.length; i++)
            Expanded(
              child: InkWell(
                onTap: () => act(i),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  decoration: i == 2
                      ? BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF7CD65B), width: 1.4), color: const Color(0xFF14803F))
                      : null,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(items[i][0] as IconData, color: i == 2 ? gold : Colors.white, size: 24),
                    const SizedBox(height: 2),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(items[i][1] as String, style: TextStyle(color: i == 2 ? gold : Colors.white, fontSize: 11, fontWeight: FontWeight.bold))),
                  ]),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}

// ------------------------------------------------------------------ list screen
class QazaListScreen extends StatelessWidget {
  final bool pendingOnly;
  const QazaListScreen({super.key, this.pendingOnly = false});

  @override
  Widget build(BuildContext context) => Screen(
        pendingOnly ? 'باقی قضا نمازیں' : 'قضا نماز کی فہرست',
        Rebuild((c) {
          final log = qazaLog();
          final pendingLog = log.where((e) => e['done'] != true).toList().reversed.toList();
          final doneLog = log.where((e) => e['done'] == true).toList().reversed.toList();
          return ListView(padding: const EdgeInsets.all(10), children: [
            box(
              c,
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                _stat('کل باقی', '${qazaPendingTotal()}', _red),
                _stat('ادا کی گئی', '${qazaMadeTotal()}', green),
                _stat('ریکارڈ میں', '${pendingLog.length}', Colors.orange),
              ]),
            ),
            sectionTitle('ہر نماز کی باقی قضا'),
            box(
              c,
              child: Column(children: [
                for (int i = 0; i < 6; i++)
                  Row(children: [
                    SizedBox(width: 60, child: Text(qazaNames[i], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                    Expanded(
                      child: InkWell(
                        onTap: () => _editCount(c, i),
                        child: Center(child: Text('${qazaPending(i)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: green))),
                      ),
                    ),
                    IconButton(
                      tooltip: 'ایک ادا کی',
                      onPressed: qazaPending(i) > 0 ? () => _makeUp(c, i) : null,
                      icon: const Icon(Icons.check_circle_outline, color: green),
                    ),
                    IconButton(
                      tooltip: 'ایک بڑھائیں',
                      onPressed: () => setI('qz_base_$i', qazaBase(i) + 1),
                      icon: const Icon(Icons.add_circle_outline, color: Colors.orange),
                    ),
                  ]),
                Text('عدد پر ٹیپ کر کے پرانی تعداد لکھیں۔ ✔ دبانے سے ایک قضا ادا شمار ہو گی۔', style: TextStyle(fontSize: 11.5, color: subText(c))),
              ]),
            ),
            Row(children: [
              const Expanded(child: Text('قضا کا ریکارڈ (وجہ کے ساتھ)', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: green))),
              FilledButton.icon(onPressed: () => _addDialog(c), icon: const Icon(Icons.add), label: const Text('نئی قضا')),
            ]),
            const SizedBox(height: 8),
            if (pendingLog.isEmpty && (pendingOnly || doneLog.isEmpty))
              Padding(padding: const EdgeInsets.all(16), child: Center(child: Text('ابھی کوئی ریکارڈ نہیں', style: TextStyle(color: subText(c))))),
            for (final e in pendingLog) _qazaEntry(c, e, false),
            if (!pendingOnly && doneLog.isNotEmpty) sectionTitle('ادا شدہ قضا'),
            if (!pendingOnly)
              for (final e in doneLog) _qazaEntry(c, e, true),
          ]);
        }),
      );

  Widget _stat(String t, String v, Color col) => Column(children: [
        Text(v, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: col)),
        Text(t, style: const TextStyle(fontSize: 12)),
      ]);
}

// ------------------------------------------------------------------ guide
class QazaGuideScreen extends StatelessWidget {
  const QazaGuideScreen({super.key});

  static const _items = <List<String>>[
    ['قضا کیا ہے؟', 'فرض نماز اور وتر (واجب) اپنے وقت پر نہ پڑھی جائے تو بعد میں اسے پڑھنا "قضا" کہلاتا ہے۔'],
    ['قضا کا حکم', 'چھوٹی ہوئی فرض اور وتر نمازوں کی قضا لازم ہے اور جلد از جلد پڑھ لینی چاہیے۔ بلا عذر نماز چھوڑنے پر توبہ و استغفار بھی کریں۔'],
    ['نیت کیسے کریں؟', 'نیت میں دن اور نماز متعین کریں، مثلاً "فلاں دن کی فجر کی قضا"۔ اگر دن یاد نہ ہو تو "سب سے پہلی فجر" یا "سب سے آخری فجر" کی نیت کی جا سکتی ہے۔'],
    ['کن اوقات میں قضا نہ پڑھیں؟', 'سورج نکلنے، ٹھیک دوپہر (زوال) اور سورج ڈوبنے کے وقت نماز مکروہ ہے، ان اوقات میں قضا نہ پڑھیں۔'],
    ['سنتوں کی قضا', 'عام طور پر سنتوں کی قضا لازم نہیں۔ البتہ اگر فجر کی سنتیں اور فرض دونوں رہ جائیں اور زوال سے پہلے قضا کریں تو سنتیں بھی فرض کے ساتھ پڑھ لی جائیں۔'],
    ['وتر کی قضا', 'وتر واجب ہے، اس لیے اس کی بھی قضا لازم ہے (3 رکعات)۔'],
    ['سفر اور بیماری', 'جو نماز سفر میں رہ جائے، اس کی قضا (چار رکعت والی) گھر آ کر بھی دو رکعت ہی پڑھی جائے گی، اور جو گھر میں رہ جائے اس کی قضا سفر میں بھی پوری چار رکعت ہو گی۔ بیماری میں کھڑے نہ ہو سکیں تو بیٹھ کر یا لیٹ کر پڑھ لیں۔'],
    ['تعداد معلوم نہ ہو تو', 'اپنے غالب گمان سے حساب لگا کر تعداد طے کر لیں اور احتیاطاً کچھ زیادہ ادا کریں۔ پرانی قضا نمازیں روزانہ تھوڑی تھوڑی پڑھتے رہیں۔'],
  ];

  @override
  Widget build(BuildContext context) => Screen(
        'قضا نماز کی رہنمائی',
        ListView(padding: const EdgeInsets.all(10), children: [
          for (final it in _items)
            box(
              context,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(it[0], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: green)),
                const SizedBox(height: 6),
                Text(it[1], style: const TextStyle(fontSize: 14, height: 1.7)),
              ]),
            ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text('یہ حنفی فقہ کے مطابق بنیادی رہنمائی ہے۔ تفصیلی مسائل کے لیے کسی مستند عالمِ دین یا مفتی سے رجوع کریں۔', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: subText(context), height: 1.6)),
          ),
        ]),
      );
}

class QazaDetailReportScreen extends StatefulWidget {
  const QazaDetailReportScreen({super.key});
  @override
  State<QazaDetailReportScreen> createState() => _QazaDetailReportState();
}

class _QazaDetailReportState extends State<QazaDetailReportScreen> {
  int perDay = 5;

  @override
  Widget build(BuildContext context) => Screen(
        'قضا نمازوں کی رپورٹ',
        Rebuild((c) {
          final pend = qazaPendingTotal();
          final made = qazaMadeTotal();
          final all = pend + made;
          final days = pend == 0 ? 0 : (pend + perDay - 1) ~/ perDay;
          final text = StringBuffer('قضا نمازوں کی رپورٹ\n');
          for (int i = 0; i < 6; i++) {
            text.writeln('${qazaNames[i]}: باقی ${qazaPending(i)} • ادا ${qazaMade(i)}');
          }
          text.writeln('کل باقی: $pend • کل ادا: $made');
          return ListView(padding: const EdgeInsets.all(10), children: [
            box(
              c,
              child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _big('باقی', '$pend', const Color(0xFFD32F2F)),
                  _big('ادا', '$made', green),
                  _big('کل', '$all', Colors.blueGrey),
                ]),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(value: all == 0 ? 0 : made / all, minHeight: 10, color: green, backgroundColor: Colors.grey.withAlpha(60)),
                ),
                const SizedBox(height: 4),
                Text(all == 0 ? 'ابھی کوئی قضا درج نہیں' : 'مکمل ہوئی: ${(made * 100 / all).round()}٪', style: TextStyle(fontSize: 12, color: subText(c))),
              ]),
            ),
            sectionTitle('ہر نماز کا حساب'),
            for (int i = 0; i < 6; i++)
              box(
                c,
                child: Column(children: [
                  Row(children: [
                    Text(qazaNames[i], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const Spacer(),
                    Text('باقی ${qazaPending(i)}', style: const TextStyle(color: Color(0xFFD32F2F), fontWeight: FontWeight.bold)),
                    const SizedBox(width: 14),
                    Text('ادا ${qazaMade(i)}', style: const TextStyle(color: green, fontWeight: FontWeight.bold)),
                  ]),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: (qazaPending(i) + qazaMade(i)) == 0 ? 0 : qazaMade(i) / (qazaPending(i) + qazaMade(i)),
                      minHeight: 7,
                      color: green,
                      backgroundColor: Colors.grey.withAlpha(60),
                    ),
                  ),
                ]),
              ),
            sectionTitle('باقی نمازیں کب پوری ہوں گی؟'),
            box(
              c,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('روزانہ کتنی قضا ادا کریں گے؟'),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [
                  for (final n in [1, 2, 5, 10, 20, 30])
                    ChoiceChip(label: Text('$n'), selected: perDay == n, onSelected: (_) => setState(() => perDay = n)),
                ]),
                const SizedBox(height: 10),
                Text(pend == 0 ? 'الحمدللہ، کوئی قضا باقی نہیں۔' : 'تقریباً $days دن (${(days / 30).toStringAsFixed(1)} ماہ) میں مکمل ہو جائیں گی۔', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: green)),
              ]),
            ),
            FilledButton.icon(onPressed: () => copyText(c, text.toString()), icon: const Icon(Icons.copy), label: const Text('رپورٹ کاپی / شیئر کریں')),
          ]);
        }),
      );

  Widget _big(String t, String v, Color col) => Column(children: [
        Text(v, style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: col)),
        Text(t),
      ]);
}

// =====================================================================
//  نئی "قضا نمازوں کی رپورٹ" اسکرین
// =====================================================================
const _rTint = [Color(0xFF8CC8F2), Color(0xFFF7D56A), Color(0xFFF5A860), Color(0xFF8E6CC9), Color(0xFF5B86DB), Color(0xFF4DB6AC)];
const _rIcons = [Icons.wb_twilight, Icons.wb_sunny, Icons.light_mode, Icons.wb_twilight, Icons.nightlight_round, Icons.star];
const _pieCols = [Color(0xFF0E8A4A), Color(0xFF1E6FD9), Color(0xFFF2B63C), Color(0xFF7E3FA8), Color(0xFF8E9AA0), Color(0xFFE5533D), Color(0xFF26A69A), Color(0xFFB0785A)];

String _iso(String key) {
  final p = key.split('-');
  if (p.length != 3) return key;
  final y = int.tryParse(p[0]) ?? 0, m = int.tryParse(p[1]) ?? 0, d = int.tryParse(p[2]) ?? 0;
  return '$y-${_two(m)}-${_two(d)}';
}

DateTime _parseKey(String key) {
  final p = key.split('-');
  if (p.length != 3) return dayOnly(DateTime.now());
  return DateTime(int.tryParse(p[0]) ?? 2000, int.tryParse(p[1]) ?? 1, int.tryParse(p[2]) ?? 1);
}

/// ایک قضا ریکارڈ کو ادا / باقی کرتا ہے اور ادا شدہ گنتی درست رکھتا ہے۔
void _setEntryDone(String id, bool done) {
  final l = qazaLog();
  final idx = l.indexWhere((x) => x['id'] == id);
  if (idx < 0) return;
  final was = l[idx]['done'] == true;
  if (was == done) return;
  final p = clampI((l[idx]['p'] as int?) ?? 0, 0, 5);
  l[idx]['done'] = done;
  if (done) {
    l[idx]['ad'] = dayKey(DateTime.now());
  } else {
    l[idx].remove('ad');
    l[idx].remove('at');
  }
  final made = qazaMade(p);
  sp.setInt('qz_made_$p', done ? made + 1 : (made > 0 ? made - 1 : 0));
  saveQazaLog(l);
}

class _PiePainter extends CustomPainter {
  final List<double> vals;
  final List<Color> cols;
  _PiePainter(this.vals, this.cols);

  @override
  void paint(Canvas canvas, Size size) {
    final total = vals.fold<double>(0, (a, b) => a + b);
    final rect = Offset.zero & size;
    final paint = Paint()..style = PaintingStyle.fill;
    if (total <= 0) {
      paint.color = Colors.grey.withAlpha(70);
      canvas.drawCircle(size.center(Offset.zero), size.width / 2, paint);
      return;
    }
    final border = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = Colors.white;
    double start = -math.pi / 2;
    for (int i = 0; i < vals.length; i++) {
      final sweep = vals[i] / total * 2 * math.pi;
      paint.color = cols[i % cols.length];
      canvas.drawArc(rect, start, sweep, true, paint);
      canvas.drawArc(rect, start, sweep, true, border);
      final pct = (vals[i] * 100 / total).round();
      if (pct >= 7) {
        final mid = start + sweep / 2;
        final r = size.width / 2 * 0.62;
        final pos = size.center(Offset.zero) + Offset(math.cos(mid) * r, math.sin(mid) * r);
        final tp = TextPainter(
          text: TextSpan(text: '$pct%', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, pos - Offset(tp.width / 2, tp.height / 2));
      }
      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant _PiePainter old) => true;
}

class QazaReportScreen extends StatefulWidget {
  const QazaReportScreen({super.key});
  @override
  State<QazaReportScreen> createState() => _QazaReportState();
}

class _QazaReportState extends State<QazaReportScreen> {
  int? fPrayer;
  int? fReason;
  String fCustom = '';
  DateTime fDate = dayOnly(DateTime.now());
  final rkCtrl = TextEditingController();

  @override
  void dispose() {
    rkCtrl.dispose();
    super.dispose();
  }

  // ------------------------------------------------------------ build
  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
        child: Scaffold(
          backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
          bottomNavigationBar: msfNav7(context, icon3: Icons.fact_check, label3: 'قضا نمازیں'),
          body: Rebuild((c) => _body(c)),
        ),
      );

  Widget _body(BuildContext c) {
    final w = MediaQuery.of(c).size.width;
    return ListView(padding: EdgeInsets.zero, children: [
      _header(c, w),
      Padding(padding: const EdgeInsets.fromLTRB(8, 8, 8, 8), child: _topRow(c)),
      Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 8), child: _statsRow(c)),
      Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 8), child: _tableAndPie(c)),
      Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 8), child: _bottomCards(c)),
      Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 10), child: _actionButtons(c)),
      Image.asset('assets/footer.png', width: double.infinity, fit: BoxFit.fitWidth),
    ]);
  }

  Widget _header(BuildContext c, double w) => SizedBox(
        width: w,
        height: w * 184 / 1024,
        child: Stack(children: [
          Positioned.fill(child: Image.asset('assets/qaza/report_header.png', fit: BoxFit.fill)),
          Positioned(
            left: w * 0.02,
            top: w * 8 / 1024,
            width: w * 0.17,
            height: w * 70 / 1024,
            child: Material(color: Colors.transparent, child: InkWell(borderRadius: BorderRadius.circular(30), onTap: () => Navigator.maybePop(c))),
          ),
        ]),
      );

  // ------------------------------------------------------------ banner + date
  Widget _topRow(BuildContext c) {
    final now = DateTime.now();
    final h = toHijri(now);
    final hText = '${h[2]} ${hijriMonths[clampI(h[1] - 1, 0, 11)]} ${h[0]}ھ';
    return IntrinsicHeight(
      child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(
          flex: 62,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF0B4D2E), Color(0xFF14804A)]),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: gold.withAlpha(140)),
            ),
            child: Row(children: [
              const Icon(Icons.mosque, color: gold, size: 40),
              const SizedBox(width: 8),
              Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const FittedBox(fit: BoxFit.scaleDown, child: Text('قضا نمازوں کی رپورٹ', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold))),
                  const SizedBox(height: 2),
                  Text('اپنی قضا نمازوں کا مکمل ریکارڈ دیکھیں', style: TextStyle(color: Colors.white.withAlpha(230), fontSize: 10.5)),
                ]),
              ),
            ]),
          ),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 38,
          child: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(70))),
            child: Row(children: [
              const Icon(Icons.calendar_month, color: green, size: 28),
              const SizedBox(width: 4),
              Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('آج کی تاریخ', style: TextStyle(fontSize: 10, color: subText(c))),
                  FittedBox(fit: BoxFit.scaleDown, child: Text('${now.year}-${_two(now.month)}-${_two(now.day)}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold))),
                  FittedBox(fit: BoxFit.scaleDown, child: Text(hText, style: TextStyle(fontSize: 10, color: subText(c)))),
                ]),
              ),
            ]),
          ),
        ),
      ]),
    );
  }

  // ------------------------------------------------------------ stats
  Widget _statTile(BuildContext c, IconData icon, String label, int v, Color col, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
          decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(60))),
          child: Column(children: [
            Icon(icon, color: col, size: 26),
            const SizedBox(height: 2),
            FittedBox(fit: BoxFit.scaleDown, child: Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))),
            Text('$v', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: col == green ? const Color(0xFF0B3D2A) : col)),
          ]),
        ),
      );

  Widget _statsRow(BuildContext c) {
    final pend = qazaPendingTotal();
    final made = qazaMadeTotal();
    final all = pend + made;
    final String t1, t2;
    if (all == 0) {
      t1 = 'شروع کریں';
      t2 = 'ابھی کوئی قضا درج نہیں۔ نیچے سے ریکارڈ شامل کریں۔';
    } else if (pend == 0) {
      t1 = 'ماشاءاللہ!';
      t2 = 'آپ کی تمام قضا نمازیں ادا ہو چکی ہیں۔';
    } else {
      t1 = 'اچھی بات!';
      t2 = 'آپ نے قضا نمازوں کا ریکارڈ رکھا ہے۔ یہ بہت بڑی نیکی ہے۔';
    }
    return IntrinsicHeight(
      child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(flex: 18, child: _statTile(c, Icons.assignment, 'کل قضا نمازیں', all, green, () => go(c, const QazaListScreen()))),
        const SizedBox(width: 5),
        Expanded(flex: 18, child: _statTile(c, Icons.check_circle, 'ادا کی گئی', made, green, () => go(c, const QazaListScreen()))),
        const SizedBox(width: 5),
        Expanded(flex: 18, child: _statTile(c, Icons.schedule, 'باقی رہیں', pend, const Color(0xFFD32F2F), () => go(c, const QazaListScreen(pendingOnly: true)))),
        const SizedBox(width: 6),
        Expanded(
          flex: 40,
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF0B4D2E), Color(0xFF14804A)]),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: gold.withAlpha(140)),
            ),
            child: Row(children: [
              const Icon(Icons.mosque, color: gold, size: 30),
              const SizedBox(width: 4),
              Expanded(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  FittedBox(fit: BoxFit.scaleDown, child: Text(t1, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold))),
                  const SizedBox(height: 2),
                  Text(t2, style: const TextStyle(color: Colors.white, fontSize: 9.5, height: 1.4)),
                ]),
              ),
            ]),
          ),
        ),
      ]),
    );
  }

  // ------------------------------------------------------------ section bar
  Widget _sec(IconData icon, String title) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        decoration: const BoxDecoration(color: _bannerGreen, borderRadius: BorderRadius.vertical(top: Radius.circular(10))),
        child: Row(children: [
          Icon(icon, color: Colors.white, size: 17),
          const SizedBox(width: 5),
          Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.bold)))),
        ]),
      );

  Widget _secBody(BuildContext c, Widget child, {EdgeInsets pad = const EdgeInsets.all(6)}) => Container(
        width: double.infinity,
        padding: pad,
        decoration: BoxDecoration(
          color: cardColor(c),
          borderRadius: const BorderRadius.vertical(bottom: Radius.circular(10)),
          border: Border.all(color: green.withAlpha(60)),
        ),
        child: child,
      );

  // ------------------------------------------------------------ table + pie
  Widget _th(String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 1),
        child: FittedBox(fit: BoxFit.scaleDown, child: Text(t, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold))),
      );

  Widget _td(String t, {Color? col, bool bold = false, VoidCallback? onTap}) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 1),
          child: FittedBox(fit: BoxFit.scaleDown, child: Text(t, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, fontWeight: bold ? FontWeight.bold : FontWeight.w600, color: col))),
        ),
      );

  Widget _prayerChip(int i, {VoidCallback? onTap}) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 1),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 3),
            decoration: BoxDecoration(color: _rTint[i], borderRadius: BorderRadius.circular(6)),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(_rIcons[i], size: 11, color: Colors.black54),
              const SizedBox(width: 2),
              Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text(qazaNames[i], style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.black87)))),
            ]),
          ),
        ),
      );

  Widget _tableAndPie(BuildContext c) {
    var tAll = 0, tMade = 0, tPend = 0, tRk = 0, tRkMade = 0;
    final rows = <TableRow>[
      TableRow(decoration: BoxDecoration(color: green.withAlpha(25)), children: [
        _th('نماز'),
        _th('کل قضا'),
        _th('ادا کی گئی'),
        _th('باقی'),
        _th('رکعتیں (کل)'),
        _th('رکعتیں (ادا)'),
      ]),
    ];
    for (int i = 0; i < 6; i++) {
      final pend = qazaPending(i), made = qazaMade(i), all = pend + made;
      final rk = all * _rakat[i], rkMade = made * _rakat[i];
      tAll += all;
      tMade += made;
      tPend += pend;
      tRk += rk;
      tRkMade += rkMade;
      rows.add(TableRow(children: [
        _prayerChip(i, onTap: () => _editCount(c, i)),
        _td('$all', onTap: () => _editCount(c, i)),
        _td('$made', col: green, onTap: () => _editCount(c, i)),
        _td('$pend', col: _red, bold: true, onTap: () => _editCount(c, i)),
        _td('$rk'),
        _td('$rkMade', col: green),
      ]));
    }
    rows.add(TableRow(decoration: BoxDecoration(color: gold.withAlpha(45)), children: [
      _td('کل', bold: true),
      _td('$tAll', bold: true),
      _td('$tMade', col: green, bold: true),
      _td('$tPend', col: _red, bold: true),
      _td('$tRk', bold: true),
      _td('$tRkMade', col: green, bold: true),
    ]));

    final table = Column(children: [
      _sec(Icons.bar_chart, 'نمازوں کے لحاظ سے قضا کا حساب'),
      _secBody(
        c,
        Column(children: [
          Table(
            columnWidths: const {0: FlexColumnWidth(1.7), 1: FlexColumnWidth(1), 2: FlexColumnWidth(1.1), 3: FlexColumnWidth(1), 4: FlexColumnWidth(1.2), 5: FlexColumnWidth(1.2)},
            defaultVerticalAlignment: TableCellVerticalAlignment.middle,
            border: TableBorder(horizontalInside: BorderSide(color: Colors.grey.withAlpha(70))),
            children: rows,
          ),
          Padding(padding: const EdgeInsets.only(top: 4), child: Text('تعداد بدلنے کے لیے نماز کی قطار پر ٹیپ کریں', style: TextStyle(fontSize: 9, color: subText(c)))),
        ]),
        pad: const EdgeInsets.all(4),
      ),
    ]);

    // وجوہات کا حساب
    final counts = <String, int>{};
    for (final e in qazaLog()) {
      var r = ((e['r'] as String?) ?? '').trim();
      if (r.isEmpty) r = 'وجہ درج نہیں';
      counts[r] = (counts[r] ?? 0) + 1;
    }
    final sorted = counts.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final shown = <MapEntry<String, int>>[];
    var other = 0;
    for (int i = 0; i < sorted.length; i++) {
      if (i < 5) {
        shown.add(sorted[i]);
      } else {
        other += sorted[i].value;
      }
    }
    if (other > 0) shown.add(MapEntry('دیگر', other));
    final logTotal = shown.fold<int>(0, (a, b) => a + b.value);

    final pie = Column(children: [
      _sec(Icons.pie_chart, 'قضا نماز کی وجہ'),
      _secBody(
        c,
        Column(children: [
          const SizedBox(height: 4),
          SizedBox(width: 108, height: 108, child: CustomPaint(painter: _PiePainter([for (final e in shown) e.value.toDouble()], _pieCols))),
          const SizedBox(height: 8),
          if (shown.isEmpty) Text('ابھی کوئی وجہ درج نہیں', style: TextStyle(fontSize: 10, color: subText(c))),
          for (int i = 0; i < shown.length; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(children: [
                Container(width: 9, height: 9, decoration: BoxDecoration(color: _pieCols[i % _pieCols.length], shape: BoxShape.circle)),
                const SizedBox(width: 4),
                Expanded(child: Text(shown[i].key, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10))),
                Text('${shown[i].value}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
              ]),
            ),
          const Divider(height: 10),
          Row(children: [
            const Expanded(child: Text('ریکارڈ شدہ قضا', style: TextStyle(fontSize: 10))),
            Text('$logTotal', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
          ]),
        ]),
      ),
    ]);

    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(flex: 63, child: table),
      const SizedBox(width: 6),
      Expanded(flex: 37, child: pie),
    ]);
  }

  // ------------------------------------------------------------ bottom three cards
  Widget _kv(BuildContext c, String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Text(k, style: TextStyle(fontSize: 9.5, color: subText(c))),
          const SizedBox(width: 3),
          Expanded(child: Align(alignment: AlignmentDirectional.centerEnd, child: FittedBox(fit: BoxFit.scaleDown, child: Text(v, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold))))),
        ]),
      );

  Widget _smallBtn(String t, IconData icon, VoidCallback onTap) => SizedBox(
        width: double.infinity,
        child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: _bannerGreen, padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8), minimumSize: const Size(0, 34)),
          onPressed: onTap,
          child: FittedBox(fit: BoxFit.scaleDown, child: Row(mainAxisSize: MainAxisSize.min, children: [Text(t, style: const TextStyle(fontSize: 10.5)), const SizedBox(width: 3), Icon(icon, size: 13)])),
        ),
      );

  String _atName(Map<String, dynamic> e) {
    final at = e['at'];
    if (e['done'] == true && at is int && at >= 0 && at < 6) return qazaNames[at];
    return e['done'] == true ? '—' : 'ابھی باقی';
  }

  Widget _lastCard(BuildContext c) {
    final log = qazaLog();
    final e = log.isEmpty ? null : log.last;
    Widget body;
    if (e == null) {
      body = Padding(padding: const EdgeInsets.symmetric(vertical: 24), child: Text('ابھی کوئی ریکارڈ نہیں', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: subText(c))));
    } else {
      final p = clampI((e['p'] as int?) ?? 0, 0, 5);
      final r = ((e['r'] as String?) ?? '').trim();
      final rk = (e['rk'] is int) ? e['rk'] as int : _rakat[p];
      body = Column(children: [
        _kv(c, 'نماز کا نام', qazaNames[p]),
        _kv(c, 'قضا کی وجہ', r.isEmpty ? '—' : r),
        _kv(c, 'اصل تاریخ', _iso('${e['d']}')),
        _kv(c, 'ادا کی تاریخ', e['ad'] == null ? '—' : _iso('${e['ad']}')),
        _kv(c, 'کس نماز کے وقت ادا کی', _atName(e)),
        _kv(c, 'رکعتیں', '$rk'),
        _kv(c, 'سنت', _sunnah[p] > 0 ? '${_sunnah[p]}' : 'نہیں'),
        _kv(c, 'نفل', 'نہیں'),
      ]);
    }
    return Column(children: [
      _sec(Icons.assignment_turned_in, 'آخری قضا نماز کا ریکارڈ'),
      _secBody(c, Column(children: [
        body,
        const SizedBox(height: 6),
        _smallBtn('مکمل تفصیلات دیکھیں', Icons.chevron_left, () {
          if (e == null) {
            toast(c, 'ابھی کوئی ریکارڈ نہیں');
          } else {
            _detailDialog(c, e);
          }
        }),
      ])),
    ]);
  }

  Future<void> _detailDialog(BuildContext c, Map<String, dynamic> e) async {
    final p = clampI((e['p'] as int?) ?? 0, 0, 5);
    final done = e['done'] == true;
    final r = ((e['r'] as String?) ?? '').trim();
    final ok = await showDialog<bool>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: Text('${qazaNames[p]} کی قضا'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('قضا کی تاریخ: ${_iso('${e['d']}')}'),
          const SizedBox(height: 6),
          Text('وجہ: ${r.isEmpty ? '—' : r}'),
          const SizedBox(height: 6),
          Text('حالت: ${done ? 'ادا ہو چکی' : 'باقی'}'),
          if (done && e['ad'] != null) ...[const SizedBox(height: 6), Text('ادا کی تاریخ: ${_iso('${e['ad']}')}')],
          const SizedBox(height: 6),
          Text('رکعتیں: ${(e['rk'] is int) ? e['rk'] : _rakat[p]}  •  سنت: ${_sunnah[p] > 0 ? _sunnah[p] : 'نہیں'}'),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('بند کریں')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(done ? 'باقی کر دیں' : 'ادا ہو گئی')),
        ],
      ),
    );
    if (ok == true) _setEntryDone('${e['id']}', !done);
  }

  Widget _listCard(BuildContext c) {
    final log = qazaLog().reversed.take(6).toList();
    return Column(children: [
      _sec(Icons.list_alt, 'قضا نمازوں کی فہرست'),
      _secBody(c, Column(children: [
        if (log.isEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 24), child: Text('ابھی کوئی ریکارڈ نہیں', style: TextStyle(fontSize: 11, color: subText(c)))),
        for (final e in log)
          Builder(builder: (_) {
            final p = clampI((e['p'] as int?) ?? 0, 0, 5);
            final done = e['done'] == true;
            final r = ((e['r'] as String?) ?? '').trim();
            return Container(
              margin: const EdgeInsets.only(bottom: 4),
              padding: const EdgeInsets.symmetric(vertical: 4),
              decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.withAlpha(60)))),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    FittedBox(fit: BoxFit.scaleDown, child: Text(_iso('${e['d']}'), style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold))),
                    Text('${qazaNames[p]}${r.isEmpty ? '' : ' • $r'}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 9.5, color: subText(c))),
                  ]),
                ),
                const SizedBox(width: 3),
                InkWell(
                  borderRadius: BorderRadius.circular(6),
                  onTap: () => _setEntryDone('${e['id']}', !done),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                    decoration: BoxDecoration(color: done ? const Color(0xFF2EB85C) : const Color(0xFFE5533D), borderRadius: BorderRadius.circular(6)),
                    child: Text(done ? 'مکمل' : 'باقی', style: const TextStyle(color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.bold)),
                  ),
                ),
              ]),
            );
          }),
        const SizedBox(height: 4),
        _smallBtn('تمام ریکارڈ دیکھیں', Icons.save_alt, () => go(c, const QazaListScreen())),
      ])),
    ]);
  }

  Widget _drop<T>(BuildContext c, String hint, T? value, List<DropdownMenuItem<T>> items, ValueChanged<T?> onChanged) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        decoration: BoxDecoration(color: isDark(c) ? const Color(0xFF16231B) : Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: green.withAlpha(90))),
        child: DropdownButton<T>(
          isExpanded: true,
          isDense: true,
          underline: const SizedBox.shrink(),
          hint: Text(hint, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, color: subText(c))),
          value: value,
          items: items,
          onChanged: onChanged,
          style: TextStyle(fontSize: 11, color: isDark(c) ? Colors.white : Colors.black87),
        ),
      );

  Widget _lbl(String t) => Padding(padding: const EdgeInsets.only(top: 6, bottom: 2), child: Text(t, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)));

  Future<void> _pickReason(BuildContext c, int? i) async {
    if (i == null) return;
    if (i == _reasons.length - 1) {
      final ctrl = TextEditingController(text: fCustom);
      final ok = await showDialog<bool>(
        context: c,
        builder: (ctx) => AlertDialog(
          title: const Text('کوئی دوسری وجہ'),
          content: TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(hintText: 'وجہ لکھیں')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('محفوظ')),
          ],
        ),
      );
      if (ok == true && ctrl.text.trim().isNotEmpty) {
        setState(() {
          fCustom = ctrl.text.trim();
          fReason = i;
        });
      }
      return;
    }
    setState(() => fReason = i);
  }

  void _saveNew(BuildContext c) {
    final p = fPrayer;
    if (p == null) {
      toast(c, 'پہلے نماز منتخب کریں');
      return;
    }
    final r = fReason == null ? '' : (fReason == _reasons.length - 1 ? fCustom : _reasons[fReason!].name);
    final rk = int.tryParse(rkCtrl.text.trim());
    final l = qazaLog();
    l.add({
      'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'p': p,
      'd': dayKey(fDate),
      'r': r,
      'done': false,
      'src': '',
      if (rk != null && rk > 0) 'rk': rk,
    });
    saveQazaLog(l);
    rkCtrl.clear();
    FocusScope.of(c).unfocus();
    setState(() {
      fPrayer = null;
      fReason = null;
      fCustom = '';
      fDate = dayOnly(DateTime.now());
    });
    toast(c, 'قضا نماز کا ریکارڈ محفوظ ہو گیا');
  }

  Widget _addCard(BuildContext c) => Column(children: [
        _sec(Icons.add_circle, 'قضا نماز شامل کریں'),
        _secBody(
          c,
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _lbl('نماز کا انتخاب کریں'),
            _drop<int>(c, 'نماز منتخب کریں', fPrayer, [for (int i = 0; i < 6; i++) DropdownMenuItem(value: i, child: Text(qazaNames[i]))], (v) => setState(() => fPrayer = v)),
            _lbl('قضا کی وجہ'),
            _drop<int>(
              c,
              'وجہ منتخب کریں',
              fReason,
              [for (int i = 0; i < _reasons.length; i++) DropdownMenuItem(value: i, child: Text(i == _reasons.length - 1 && fReason == i && fCustom.isNotEmpty ? fCustom : _reasons[i].name, maxLines: 1, overflow: TextOverflow.ellipsis))],
              (v) => _pickReason(c, v),
            ),
            _lbl('تاریخ'),
            InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: () async {
                final r = await showDatePicker(context: c, initialDate: fDate, firstDate: DateTime(2000), lastDate: DateTime.now());
                if (r != null) setState(() => fDate = dayOnly(r));
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
                decoration: BoxDecoration(color: isDark(c) ? const Color(0xFF16231B) : Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: green.withAlpha(90))),
                child: Row(children: [
                  const Icon(Icons.calendar_month, size: 14, color: green),
                  const SizedBox(width: 4),
                  Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text('${fDate.year}-${_two(fDate.month)}-${_two(fDate.day)}', style: const TextStyle(fontSize: 11)))),
                ]),
              ),
            ),
            _lbl('رکعتیں'),
            TextField(
              controller: rkCtrl,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              style: const TextStyle(fontSize: 11),
              decoration: InputDecoration(isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 6, vertical: 9), hintText: 'تعداد درج کریں', hintStyle: TextStyle(fontSize: 10, color: subText(c))),
            ),
            const SizedBox(height: 8),
            _smallBtn('ریکارڈ محفوظ کریں', Icons.save, () => _saveNew(c)),
          ]),
        ),
      ]);

  Widget _bottomCards(BuildContext c) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 34, child: _lastCard(c)),
        const SizedBox(width: 5),
        Expanded(flex: 33, child: _listCard(c)),
        const SizedBox(width: 5),
        Expanded(flex: 33, child: _addCard(c)),
      ]);

  // ------------------------------------------------------------ edit / delete
  Future<Map<String, dynamic>?> _pickEntry(BuildContext c, String title) async {
    final log = qazaLog().reversed.toList();
    if (log.isEmpty) {
      toast(c, 'ابھی کوئی ریکارڈ نہیں');
      return null;
    }
    return showModalBottomSheet<Map<String, dynamic>>(
      context: c,
      builder: (ctx) => SafeArea(
        child: ListView(children: [
          Padding(padding: const EdgeInsets.all(14), child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
          for (final e in log)
            ListTile(
              leading: Icon(e['done'] == true ? Icons.check_circle : Icons.event_busy, color: e['done'] == true ? green : _red),
              title: Text(qazaNames[clampI((e['p'] as int?) ?? 0, 0, 5)]),
              subtitle: Text('${_iso('${e['d']}')}${((e['r'] as String?) ?? '').isEmpty ? '' : ' • ${e['r']}'}'),
              onTap: () => Navigator.pop(ctx, e),
            ),
        ]),
      ),
    );
  }

  Future<void> _edit(BuildContext c) async {
    final e = await _pickEntry(c, 'ترمیم کے لیے ریکارڈ چنیں');
    if (e == null || !c.mounted) return;
    int p = clampI((e['p'] as int?) ?? 0, 0, 5);
    DateTime d = _parseKey('${e['d']}');
    bool done = e['done'] == true;
    final reason = TextEditingController(text: (e['r'] as String?) ?? '');
    final ok = await showDialog<bool>(
      context: c,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS2) => AlertDialog(
          title: const Text('ریکارڈ میں ترمیم'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 6, children: [for (int i = 0; i < 6; i++) ChoiceChip(label: Text(qazaNames[i]), selected: p == i, onSelected: (_) => setS2(() => p = i))]),
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () async {
                  final r = await showDatePicker(context: ctx, initialDate: d, firstDate: DateTime(2000), lastDate: DateTime.now());
                  if (r != null) setS2(() => d = dayOnly(r));
                },
                icon: const Icon(Icons.calendar_month),
                label: Text(fmtDate(d)),
              ),
              TextField(controller: reason, decoration: const InputDecoration(labelText: 'وجہ / تفصیل')),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('ادا ہو چکی'), value: done, onChanged: (v) => setS2(() => done = v)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('محفوظ')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final l = qazaLog();
    final idx = l.indexWhere((x) => x['id'] == e['id']);
    if (idx < 0) return;
    final oldP = clampI((l[idx]['p'] as int?) ?? 0, 0, 5);
    final wasDone = l[idx]['done'] == true;
    if (wasDone) sp.setInt('qz_made_$oldP', qazaMade(oldP) > 0 ? qazaMade(oldP) - 1 : 0);
    if (done) sp.setInt('qz_made_$p', qazaMade(p) + 1);
    l[idx]['p'] = p;
    l[idx]['d'] = dayKey(d);
    l[idx]['r'] = reason.text.trim();
    l[idx]['done'] = done;
    if (done) {
      l[idx]['ad'] = l[idx]['ad'] ?? dayKey(DateTime.now());
    } else {
      l[idx].remove('ad');
      l[idx].remove('at');
    }
    saveQazaLog(l);
    if (c.mounted) toast(c, 'ریکارڈ میں ترمیم ہو گئی');
  }

  Future<void> _delete(BuildContext c) async {
    final e = await _pickEntry(c, 'حذف کرنے کے لیے ریکارڈ چنیں');
    if (e == null || !c.mounted) return;
    if (!await confirmDialog(c, 'یہ ریکارڈ حذف کریں؟')) return;
    final l = qazaLog();
    final idx = l.indexWhere((x) => x['id'] == e['id']);
    if (idx < 0) return;
    if (l[idx]['done'] == true) {
      final p = clampI((l[idx]['p'] as int?) ?? 0, 0, 5);
      sp.setInt('qz_made_$p', qazaMade(p) > 0 ? qazaMade(p) - 1 : 0);
    }
    l.removeAt(idx);
    saveQazaLog(l);
    if (c.mounted) toast(c, 'ریکارڈ حذف ہو گیا');
  }

  Widget _actBtn(Color col, IconData icon, String t, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
          decoration: BoxDecoration(color: col, borderRadius: BorderRadius.circular(12)),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: Colors.white, size: 22),
            const SizedBox(width: 6),
            Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text(t, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)))),
          ]),
        ),
      );

  Widget _actionButtons(BuildContext c) => Row(children: [
        Expanded(child: _actBtn(const Color(0xFF6A3FA0), Icons.edit, 'ریکارڈ میں ترمیم کریں', () => _edit(c))),
        const SizedBox(width: 6),
        Expanded(child: _actBtn(const Color(0xFFD83A3A), Icons.delete, 'ریکارڈ حذف کریں', () => _delete(c))),
        const SizedBox(width: 6),
        Expanded(child: _actBtn(const Color(0xFF1F5FD0), Icons.bar_chart, 'رپورٹ دیکھیں', () => go(c, const QazaDetailReportScreen()))),
      ]);
}
