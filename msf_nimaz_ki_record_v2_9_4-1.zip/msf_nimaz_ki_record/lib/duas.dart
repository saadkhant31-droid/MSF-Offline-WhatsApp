import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'nav_common.dart' show msfNav7;

class Dua {
  final String title, arabic, urdu, pron, fazl, waqt, ref;
  final List<int> cats; // زمرے: 1 صبح، 2 رات، 3 نماز کے بعد، 4 گھر، 5 دکھی دل
  final IconData icon;
  final bool popular;
  const Dua(this.title, this.arabic, this.urdu, this.pron, this.fazl, this.waqt, this.ref, this.cats, this.icon, {this.popular = false});
}

const duaCats = <String>['تمام دعائیں', 'صبح کی دعائیں', 'رات کی دعائیں', 'نماز کے بعد کی دعائیں', 'گھر کے لیے دعائیں', 'دکھی دل کے لیے دعائیں'];
const duaCatIcons = <IconData>[Icons.back_hand, Icons.wb_sunny, Icons.nightlight_round, Icons.mosque, Icons.groups, Icons.favorite];
const _favCat = 6; // پسندیدہ دعائیں

const duas = <Dua>[
  Dua(
    'نیند سے بیدار ہو کر',
    'اَلْحَمْدُ لِلّٰهِ الَّذِيْ اَحْيَانَا بَعْدَ مَا اَمَاتَنَا وَاِلَيْهِ النُّشُوْرُ',
    'سب تعریفیں اللہ کے لیے ہیں جس نے ہمیں مارنے (سلانے) کے بعد زندہ کیا اور اسی کی طرف لوٹنا ہے۔',
    'الحمدُ لِلّٰہِ الَّذِی اَحیانا بعدَ ما اَماتَنا و اِلَیہِ النُّشور',
    'نیند کو موت سے مشابہ کہا گیا ہے، جاگتے ہی اللہ کی حمد دن کا بہترین آغاز ہے۔',
    'صبح نیند سے بیدار ہوتے ہی',
    'صحیح بخاری',
    [1],
    Icons.alarm,
  ),
  Dua(
    'صبح کی دعا',
    'اَللّٰهُمَّ بِكَ اَصْبَحْنَا وَبِكَ اَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوْتُ وَاِلَيْكَ النُّشُوْرُ',
    'اے اللہ! تیرے ہی حکم سے ہم نے صبح کی اور تیرے ہی حکم سے شام کی، تیرے ہی نام پر ہم جیتے اور مرتے ہیں اور تیری ہی طرف اٹھ کر جانا ہے۔',
    'اللّٰہُمَّ بِکَ اَصبَحنا و بِکَ اَمسَینا و بِکَ نَحیا و بِکَ نَموتُ و اِلَیکَ النُّشور',
    'صبح کا آغاز اللہ پر بھروسے اور اس کی یاد کے ساتھ ہوتا ہے۔',
    'ہر صبح، فجر کے بعد',
    'جامع ترمذی',
    [1],
    Icons.wb_twilight,
    popular: true,
  ),
  Dua(
    'شام کی دعا',
    'اَللّٰهُمَّ بِكَ اَمْسَيْنَا وَبِكَ اَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوْتُ وَاِلَيْكَ الْمَصِيْرُ',
    'اے اللہ! تیرے ہی حکم سے ہم نے شام کی اور تیرے ہی حکم سے صبح کی، تیرے ہی نام پر ہم جیتے اور مرتے ہیں اور تیری ہی طرف لوٹنا ہے۔',
    'اللّٰہُمَّ بِکَ اَمسَینا و بِکَ اَصبَحنا و بِکَ نَحیا و بِکَ نَموتُ و اِلَیکَ المَصیر',
    'شام کو اللہ کی پناہ اور اس پر بھروسے کا اظہار ہے۔',
    'ہر شام، عصر یا مغرب کے بعد',
    'جامع ترمذی',
    [2],
    Icons.nights_stay,
  ),
  Dua(
    'سید الاستغفار',
    'اَللّٰهُمَّ اَنْتَ رَبِّيْ لَا اِلٰهَ اِلَّا اَنْتَ خَلَقْتَنِيْ وَاَنَا عَبْدُكَ وَاَنَا عَلٰى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ اَعُوْذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ اَبُوْءُ لَكَ بِنِعْمَتِكَ عَلَيَّ وَاَبُوْءُ بِذَنْبِيْ فَاغْفِرْ لِيْ فَاِنَّهٗ لَا يَغْفِرُ الذُّنُوْبَ اِلَّا اَنْتَ',
    'اے اللہ! تو میرا رب ہے، تیرے سوا کوئی معبود نہیں، تو نے مجھے پیدا کیا اور میں تیرا بندہ ہوں، اور اپنی طاقت بھر تیرے عہد و وعدے پر قائم ہوں۔ جو کچھ میں نے کیا اس کے شر سے تیری پناہ چاہتا ہوں۔ میں تیری نعمت کا اقرار کرتا ہوں اور اپنے گناہ کا اعتراف کرتا ہوں، پس مجھے بخش دے، کیونکہ تیرے سوا کوئی گناہ نہیں بخشتا۔',
    'اللّٰہُمَّ اَنتَ رَبّی لا اِلٰہَ اِلّا اَنتَ خَلَقتَنی و اَنا عَبدُکَ و اَنا عَلٰی عَہدِکَ و وَعدِکَ مَا استَطَعتُ اَعوذُ بِکَ مِن شَرِّ مَا صَنَعتُ اَبوءُ لَکَ بِنِعمَتِکَ عَلَیَّ و اَبوءُ بِذَنبی فَاغفِر لی فَاِنَّہُ لا یَغفِرُ الذُّنوبَ اِلّا اَنت',
    'حدیث میں ہے کہ جو شخص اسے یقین کے ساتھ صبح پڑھے اور اسی دن فوت ہو جائے تو جنتی ہے، اور شام کو پڑھے اور رات میں فوت ہو جائے تو بھی جنتی ہے۔',
    'صبح اور شام',
    'صحیح بخاری',
    [1, 2, 5],
    Icons.auto_awesome,
  ),
  Dua(
    'سونے سے پہلے',
    'بِاسْمِكَ اَللّٰهُمَّ اَمُوْتُ وَاَحْيَا',
    'اے اللہ! تیرے نام کے ساتھ میں مرتا (سوتا) اور جیتا (جاگتا) ہوں۔',
    'بِاسمِکَ اللّٰہُمَّ اَموتُ و اَحیا',
    'رات کی نیند اللہ کے نام اور اس کی حفاظت میں شروع ہوتی ہے۔',
    'رات کو بستر پر لیٹتے وقت',
    'صحیح بخاری',
    [2],
    Icons.bedtime,
    popular: true,
  ),
  Dua(
    'وضو کے بعد',
    'اَشْهَدُ اَنْ لَّا اِلٰهَ اِلَّا اللّٰهُ وَحْدَهٗ لَا شَرِيْكَ لَهٗ وَاَشْهَدُ اَنَّ مُحَمَّدًا عَبْدُهٗ وَرَسُوْلُهٗ',
    'میں گواہی دیتا ہوں کہ اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے، اس کا کوئی شریک نہیں، اور گواہی دیتا ہوں کہ محمد ﷺ اس کے بندے اور رسول ہیں۔',
    'اَشہَدُ اَن لا اِلٰہَ اِلّا اللّٰہُ وَحدَہٗ لا شَریکَ لَہٗ و اَشہَدُ اَنَّ مُحَمَّدًا عَبدُہٗ و رَسولُہ',
    'حدیث میں ہے کہ جو وضو کے بعد یہ کلمات پڑھے اس کے لیے جنت کے آٹھوں دروازے کھول دیے جاتے ہیں۔',
    'وضو مکمل کرنے کے بعد',
    'صحیح مسلم',
    [3],
    Icons.water_drop,
  ),
  Dua(
    'اذان کے بعد',
    'اَللّٰهُمَّ رَبَّ هٰذِهِ الدَّعْوَةِ التَّامَّةِ وَالصَّلٰوةِ الْقَائِمَةِ اٰتِ مُحَمَّدَنِ الْوَسِيْلَةَ وَالْفَضِيْلَةَ وَابْعَثْهُ مَقَامًا مَّحْمُوْدَنِ الَّذِيْ وَعَدْتَهٗ',
    'اے اللہ! اس مکمل پکار اور قائم ہونے والی نماز کے رب! محمد ﷺ کو وسیلہ اور فضیلت عطا فرما اور انہیں مقامِ محمود پر پہنچا جس کا تو نے وعدہ کیا ہے۔',
    'اللّٰہُمَّ رَبَّ ہٰذِہِ الدَّعوَۃِ التَّامَّۃِ و الصَّلاۃِ القائِمَۃِ آتِ مُحَمَّدَنِ الوَسیلَۃَ و الفَضیلَۃَ و ابعَثہُ مَقامًا مَّحمودَنِ الَّذی وَعَدتَّہ',
    'حدیث میں ہے کہ جو اذان کے بعد یہ دعا پڑھے اس کے لیے قیامت کے دن نبی ﷺ کی شفاعت واجب ہو جاتی ہے۔',
    'اذان سننے کے بعد، درود شریف کے ساتھ',
    'صحیح بخاری',
    [3],
    Icons.volume_up,
  ),
  Dua(
    'مسجد میں داخل ہوتے وقت',
    'اَللّٰهُمَّ افْتَحْ لِيْ اَبْوَابَ رَحْمَتِكَ',
    'اے اللہ! میرے لیے اپنی رحمت کے دروازے کھول دے۔',
    'اللّٰہُمَّ افتَح لی اَبوابَ رَحمَتِک',
    'مسجد میں داخلہ رحمت کے دروازے کھلنے کی طلب کے ساتھ ہو۔',
    'مسجد میں پہلے دایاں پاؤں رکھتے وقت',
    'صحیح مسلم',
    [3],
    Icons.login,
  ),
  Dua(
    'مسجد سے نکلتے وقت',
    'اَللّٰهُمَّ اِنِّيْ اَسْاَلُكَ مِنْ فَضْلِكَ',
    'اے اللہ! میں تجھ سے تیرے فضل کا سوال کرتا ہوں۔',
    'اللّٰہُمَّ اِنّی اَسئَلُکَ مِن فَضلِک',
    'مسجد سے نکل کر بھی اللہ کے فضل کی طلب رہے۔',
    'مسجد سے پہلے بایاں پاؤں نکالتے وقت',
    'صحیح مسلم',
    [3],
    Icons.logout,
  ),
  Dua(
    'نماز کے بعد',
    'اَللّٰهُمَّ اَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْاِكْرَامِ',
    'اے اللہ! تو سلامتی والا ہے اور تجھی سے سلامتی ہے، تو بابرکت ہے اے عظمت اور بزرگی والے!',
    'اللّٰہُمَّ اَنتَ السَّلامُ و مِنکَ السَّلامُ تَبارَکتَ یا ذَا الجَلالِ و الاِکرام',
    'فرض نماز کے سلام کے فوراً بعد پڑھنا نبی ﷺ کا معمول تھا۔',
    'ہر فرض نماز کے سلام کے بعد',
    'صحیح مسلم',
    [3],
    Icons.mosque,
  ),
  Dua(
    'ذکر و شکر کی توفیق',
    'اَللّٰهُمَّ اَعِنِّيْ عَلٰى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ',
    'اے اللہ! اپنے ذکر، اپنے شکر اور اچھے طریقے سے اپنی عبادت کرنے میں میری مدد فرما۔',
    'اللّٰہُمَّ اَعِنّی عَلٰی ذِکرِکَ و شُکرِکَ و حُسنِ عِبادَتِک',
    'نبی ﷺ نے حضرت معاذ رضی اللہ عنہ کو ہر نماز کے بعد یہ دعا نہ چھوڑنے کی نصیحت فرمائی۔',
    'ہر نماز کے بعد',
    'سنن ابو داؤد',
    [3],
    Icons.favorite_border,
  ),
  Dua(
    'استخارہ کی دعا',
    'اَللّٰهُمَّ اِنِّيْ اَسْتَخِيْرُكَ بِعِلْمِكَ وَاَسْتَقْدِرُكَ بِقُدْرَتِكَ وَاَسْاَلُكَ مِنْ فَضْلِكَ الْعَظِيْمِ فَاِنَّكَ تَقْدِرُ وَلَا اَقْدِرُ وَتَعْلَمُ وَلَا اَعْلَمُ وَاَنْتَ عَلَّامُ الْغُيُوْبِ',
    'اے اللہ! میں تیرے علم کے ساتھ تجھ سے خیر مانگتا ہوں، تیری قدرت کے ساتھ طاقت مانگتا ہوں اور تجھ سے تیرا بڑا فضل مانگتا ہوں، کیونکہ تو قدرت رکھتا ہے اور میں نہیں رکھتا، تو جانتا ہے اور میں نہیں جانتا، اور تو غیب کی باتوں کو خوب جاننے والا ہے۔ (یہ دعا کا ابتدائی حصہ ہے، آگے اپنی حاجت کا ذکر کر کے مکمل دعا کسی مستند کتاب سے پڑھیں۔)',
    'اللّٰہُمَّ اِنّی اَستَخیرُکَ بِعِلمِکَ و اَستَقدِرُکَ بِقُدرَتِکَ و اَسئَلُکَ مِن فَضلِکَ العَظیم فَاِنَّکَ تَقدِرُ و لا اَقدِرُ و تَعلَمُ و لا اَعلَمُ و اَنتَ عَلّامُ الغُیوب',
    'ہر اہم کام سے پہلے اللہ سے بہتری مانگنے کا مسنون طریقہ ہے۔',
    'کسی اہم فیصلے سے پہلے دو رکعت نفل کے بعد',
    'صحیح بخاری',
    [3],
    Icons.compare_arrows,
    popular: true,
  ),
  Dua(
    'دعائے قنوت (نمازِ وتر)',
    'اَللّٰهُمَّ اِنَّا نَسْتَعِيْنُكَ وَنَسْتَغْفِرُكَ وَنُؤْمِنُ بِكَ وَنَتَوَكَّلُ عَلَيْكَ وَنُثْنِيْ عَلَيْكَ الْخَيْرَ وَنَشْكُرُكَ وَلَا نَكْفُرُكَ وَنَخْلَعُ وَنَتْرُكُ مَنْ يَّفْجُرُكَ، اَللّٰهُمَّ اِيَّاكَ نَعْبُدُ وَلَكَ نُصَلِّيْ وَنَسْجُدُ وَاِلَيْكَ نَسْعٰى وَنَحْفِدُ وَنَرْجُوْ رَحْمَتَكَ وَنَخْشٰى عَذَابَكَ اِنَّ عَذَابَكَ بِالْكُفَّارِ مُلْحِقٌ',
    'اے اللہ! ہم تجھ سے مدد مانگتے ہیں، تجھ سے بخشش چاہتے ہیں، تجھ پر ایمان رکھتے ہیں، تجھ پر بھروسا کرتے ہیں اور تیری اچھی تعریف کرتے ہیں۔ ہم تیرا شکر کرتے ہیں اور ناشکری نہیں کرتے، اور جو تیری نافرمانی کرے اسے چھوڑ دیتے ہیں۔ اے اللہ! ہم تیری ہی عبادت کرتے ہیں، تیرے لیے نماز پڑھتے اور سجدہ کرتے ہیں، تیری طرف دوڑتے ہیں، تیری رحمت کی امید اور تیرے عذاب کا خوف رکھتے ہیں۔ بے شک تیرا عذاب کافروں کو پہنچنے والا ہے۔',
    'اللّٰہُمَّ اِنّا نَستَعینُکَ و نَستَغفِرُکَ و نُؤمِنُ بِکَ و نَتَوَکَّلُ عَلَیکَ و نُثنی عَلَیکَ الخَیرَ و نَشکُرُکَ و لا نَکفُرُکَ و نَخلَعُ و نَترُکُ مَن یَّفجُرُکَ، اللّٰہُمَّ اِیّاکَ نَعبُدُ و لَکَ نُصَلّی و نَسجُدُ و اِلَیکَ نَسعٰی و نَحفِدُ و نَرجو رَحمَتَکَ و نَخشٰی عَذابَکَ اِنَّ عَذابَکَ بِالکُفّارِ مُلحِق',
    'یہ دعا وتر کی تیسری رکعت میں پڑھی جاتی ہے۔',
    'نمازِ عشاء کے وتر میں، رکوع سے پہلے',
    'حنفی فقہ کی کتب',
    [2, 3],
    Icons.nightlight_round,
  ),
  Dua(
    'غم اور پریشانی کی دعا',
    'اَللّٰهُمَّ اِنِّيْ اَعُوْذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ وَالْعَجْزِ وَالْكَسَلِ وَالْبُخْلِ وَالْجُبْنِ وَضَلَعِ الدَّيْنِ وَغَلَبَةِ الرِّجَالِ',
    'اے اللہ! میں تیری پناہ مانگتا ہوں فکر اور غم سے، عاجزی اور سستی سے، بخل اور بزدلی سے، قرض کے بوجھ سے اور لوگوں کے غلبے سے۔',
    'اللّٰہُمَّ اِنّی اَعوذُ بِکَ مِنَ الہَمِّ و الحَزَنِ و العَجزِ و الکَسَلِ و البُخلِ و الجُبنِ و ضَلَعِ الدَّینِ و غَلَبَۃِ الرِّجال',
    'نبی ﷺ یہ دعا کثرت سے مانگا کرتے تھے۔',
    'جب بھی دل غمگین یا پریشان ہو، صبح و شام',
    'صحیح بخاری',
    [5],
    Icons.favorite,
    popular: true,
  ),
  Dua(
    'دعائے یونس علیہ السلام',
    'لَا اِلٰهَ اِلَّا اَنْتَ سُبْحَانَكَ اِنِّيْ كُنْتُ مِنَ الظَّالِمِيْنَ',
    'تیرے سوا کوئی معبود نہیں، تو پاک ہے، بے شک میں ہی ظالموں میں سے تھا۔',
    'لا اِلٰہَ اِلّا اَنتَ سُبحانَکَ اِنّی کُنتُ مِنَ الظّالِمین',
    'حدیث میں ہے کہ جو مسلمان کسی معاملے میں یہ دعا مانگے، اللہ اس کی دعا قبول فرماتا ہے۔',
    'سختی، بیماری یا کسی بھی مشکل میں',
    'جامع ترمذی',
    [5],
    Icons.waves,
  ),
  Dua(
    'اللہ کی رحمت کی امید',
    'اَللّٰهُمَّ رَحْمَتَكَ اَرْجُوْ فَلَا تَكِلْنِيْ اِلٰى نَفْسِيْ طَرْفَةَ عَيْنٍ وَاَصْلِحْ لِيْ شَاْنِيْ كُلَّهٗ لَا اِلٰهَ اِلَّا اَنْتَ',
    'اے اللہ! میں تیری رحمت کا امیدوار ہوں، پس مجھے پلک جھپکنے کے برابر بھی میرے نفس کے حوالے نہ کر، اور میرے سب کام درست فرما دے، تیرے سوا کوئی معبود نہیں۔',
    'اللّٰہُمَّ رَحمَتَکَ اَرجو فَلا تَکِلنی اِلٰی نَفسی طَرفَۃَ عَینٍ و اَصلِح لی شَاأنی کُلَّہٗ لا اِلٰہَ اِلّا اَنت',
    'مشکل وقت میں مکمل بھروسا اللہ پر کرنے کی دعا ہے۔',
    'پریشانی اور تنگی کے وقت',
    'سنن ابو داؤد',
    [5],
    Icons.volunteer_activism,
  ),
  Dua(
    'حسبنا اللہ ونعم الوکیل',
    'حَسْبُنَا اللّٰهُ وَنِعْمَ الْوَكِيْلُ',
    'ہمیں اللہ کافی ہے اور وہ بہترین کارساز ہے۔',
    'حَسبُنَا اللّٰہُ و نِعمَ الوَکیل',
    'مشکلات اور خوف کے وقت اللہ پر توکل کا کلمہ ہے۔',
    'خوف، خطرے یا مشکل کے وقت',
    'سورۃ آل عمران 173',
    [5],
    Icons.shield,
  ),
  Dua(
    'استغفار',
    'اَسْتَغْفِرُ اللّٰهَ رَبِّيْ مِنْ كُلِّ ذَنْبٍ وَّاَتُوْبُ اِلَيْهِ',
    'میں اپنے رب اللہ سے ہر گناہ کی معافی مانگتا ہوں اور اسی کی طرف توبہ کرتا ہوں۔',
    'اَستَغفِرُ اللّٰہَ رَبّی مِن کُلِّ ذَنبٍ و اَتوبُ اِلَیہ',
    'استغفار دلوں کو سکون دیتا اور گناہ مٹاتا ہے۔',
    'ہر وقت، خصوصاً نماز کے بعد اور رات کے آخری حصے میں',
    'مسنون اذکار',
    [3, 5],
    Icons.healing,
  ),
  Dua(
    'کھانے سے پہلے',
    'بِسْمِ اللّٰهِ وَعَلٰى بَرَكَةِ اللّٰهِ',
    'اللہ کے نام سے اور اللہ کی برکت پر (شروع کرتا ہوں)۔',
    'بِسمِ اللّٰہِ و عَلٰی بَرَکَۃِ اللّٰہ',
    'کھانے میں برکت اور شیطان کے شریک ہونے سے حفاظت کا ذریعہ ہے۔',
    'کھانا شروع کرنے سے پہلے',
    'سنن ابو داؤد',
    [4],
    Icons.restaurant,
  ),
  Dua(
    'کھانے کے بعد',
    'اَلْحَمْدُ لِلّٰهِ الَّذِيْ اَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِيْنَ',
    'سب تعریفیں اللہ کے لیے ہیں جس نے ہمیں کھلایا، پلایا اور مسلمان بنایا۔',
    'اَلحَمدُ لِلّٰہِ الَّذی اَطعَمَنا و سَقانا و جَعَلَنا مُسلِمین',
    'نعمت پر شکر ادا کرنے کی دعا ہے۔',
    'کھانا ختم کرنے کے بعد',
    'سنن ابو داؤد',
    [4],
    Icons.local_dining,
  ),
  Dua(
    'گھر سے نکلتے وقت',
    'بِسْمِ اللّٰهِ تَوَكَّلْتُ عَلَى اللّٰهِ وَلَا حَوْلَ وَلَا قُوَّةَ اِلَّا بِاللّٰهِ',
    'اللہ کے نام سے، میں نے اللہ پر بھروسا کیا، اور گناہ سے بچنے اور نیکی کرنے کی طاقت اللہ ہی کی طرف سے ہے۔',
    'بِسمِ اللّٰہِ تَوَکَّلتُ عَلَی اللّٰہِ و لا حَولَ و لا قُوَّۃَ اِلّا بِاللّٰہ',
    'حدیث میں ہے کہ ایسے شخص سے کہا جاتا ہے: تجھے ہدایت ملی، تو کافی ہوا اور تو بچا لیا گیا۔',
    'گھر سے باہر قدم رکھتے وقت',
    'سنن ابو داؤد، جامع ترمذی',
    [4],
    Icons.exit_to_app,
  ),
  Dua(
    'گھر میں داخل ہوتے وقت',
    'اَللّٰهُمَّ اِنِّيْ اَسْاَلُكَ خَيْرَ الْمَوْلَجِ وَخَيْرَ الْمَخْرَجِ، بِسْمِ اللّٰهِ وَلَجْنَا وَبِسْمِ اللّٰهِ خَرَجْنَا وَعَلَى اللّٰهِ رَبِّنَا تَوَكَّلْنَا',
    'اے اللہ! میں تجھ سے داخل ہونے اور نکلنے کی بھلائی مانگتا ہوں۔ اللہ کے نام سے ہم داخل ہوئے، اللہ کے نام سے نکلے اور اپنے رب اللہ پر بھروسا کیا۔',
    'اللّٰہُمَّ اِنّی اَسئَلُکَ خَیرَ المَولَجِ و خَیرَ المَخرَجِ، بِسمِ اللّٰہِ وَلَجنا و بِسمِ اللّٰہِ خَرَجنا و عَلَی اللّٰہِ رَبِّنا تَوَکَّلنا',
    'گھر میں برکت آتی ہے اور گھر والوں کو سلام کرنا بھی سنت ہے۔',
    'گھر میں داخل ہوتے وقت',
    'سنن ابو داؤد',
    [4],
    Icons.home,
  ),
  Dua(
    'گھر والوں کے لیے',
    'رَبَّنَا هَبْ لَنَا مِنْ اَزْوَاجِنَا وَذُرِّيّٰتِنَا قُرَّةَ اَعْيُنٍ وَّاجْعَلْنَا لِلْمُتَّقِيْنَ اِمَامًا',
    'اے ہمارے رب! ہمیں ہماری بیویوں اور اولاد کی طرف سے آنکھوں کی ٹھنڈک عطا فرما اور ہمیں پرہیزگاروں کا امام بنا دے۔',
    'رَبَّنا ہَب لَنا مِن اَزواجِنا و ذُرّیّاتِنا قُرَّۃَ اَعیُنٍ و اجعَلنا لِلمُتَّقینَ اِمامًا',
    'یہ اللہ کے نیک بندوں کی دعا ہے جو قرآن میں مذکور ہے۔',
    'گھر اور اولاد کی بھلائی کے لیے، کسی بھی وقت',
    'سورۃ الفرقان 74',
    [4],
    Icons.house,
    popular: true,
  ),
  Dua(
    'والدین کے لیے',
    'رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِيْ صَغِيْرًا',
    'اے میرے رب! ان دونوں پر رحم فرما جیسا کہ انہوں نے بچپن میں میری پرورش کی۔',
    'رَبِّ ارحَمہُما کَما رَبَّیانی صَغیرا',
    'والدین کے حق میں دعا ان کے احسان کا بدلہ چکانے کی ایک صورت ہے۔',
    'ہر نماز کے بعد اور موقع ملنے پر',
    'سورۃ بنی اسرائیل 24',
    [4],
    Icons.family_restroom,
  ),
  Dua(
    'سفر کی دعا',
    'سُبْحَانَ الَّذِيْ سَخَّرَ لَنَا هٰذَا وَمَا كُنَّا لَهٗ مُقْرِنِيْنَ وَاِنَّا اِلٰى رَبِّنَا لَمُنْقَلِبُوْنَ',
    'پاک ہے وہ ذات جس نے اس سواری کو ہمارے تابع کر دیا حالانکہ ہم اسے قابو میں لانے والے نہ تھے، اور بے شک ہم اپنے رب کی طرف لوٹنے والے ہیں۔',
    'سُبحانَ الَّذی سَخَّرَ لَنا ہٰذا و ما کُنّا لَہٗ مُقرِنین و اِنّا اِلٰی رَبِّنا لَمُنقَلِبون',
    'سفر کی سواری پر اللہ کی نعمت یاد کرنے اور آخرت کو یاد رکھنے کی دعا ہے۔',
    'سواری پر بیٹھتے وقت',
    'سورۃ الزخرف 13-14، صحیح مسلم',
    [],
    Icons.flight,
    popular: true,
  ),
  Dua(
    'دنیا و آخرت کی بھلائی',
    'رَبَّنَا اٰتِنَا فِي الدُّنْيَا حَسَنَةً وَّفِي الْاٰخِرَةِ حَسَنَةً وَّقِنَا عَذَابَ النَّارِ',
    'اے ہمارے رب! ہمیں دنیا میں بھلائی دے اور آخرت میں بھلائی دے اور ہمیں آگ کے عذاب سے بچا۔',
    'رَبَّنا آتِنا فِی الدُّنیا حَسَنَۃً و فِی الآخِرَۃِ حَسَنَۃً و قِنا عَذابَ النّار',
    'نبی ﷺ کی سب سے کثرت سے مانگی جانے والی دعاؤں میں سے ہے۔',
    'ہر وقت، خصوصاً طواف اور نماز کے بعد',
    'سورۃ البقرہ 201، صحیح بخاری',
    [3],
    Icons.public,
  ),
  Dua(
    'علم میں اضافہ',
    'رَبِّ زِدْنِيْ عِلْمًا',
    'اے میرے رب! میرے علم میں اضافہ فرما۔',
    'رَبِّ زِدنی عِلما',
    'اللہ نے اپنے نبی ﷺ کو علم میں اضافے کی دعا سکھائی۔',
    'پڑھائی یا علم حاصل کرنے سے پہلے',
    'سورۃ طٰہٰ 114',
    [],
    Icons.menu_book,
  ),
];

String _two2(int n) => n < 10 ? '0$n' : '$n';

String _todayIso() {
  final n = DateTime.now();
  return '${n.year}-${_two2(n.month)}-${_two2(n.day)}';
}

String _todayHijri() {
  final h = toHijri(DateTime.now());
  return '${h[2]} ${hijriMonths[clampI(h[1] - 1, 0, 11)]} ${h[0]}ھ';
}

bool _fav(int i) => getB('dua_fav_$i');

// ------------------------------------------------------------------ list screen
class DuasScreen extends StatefulWidget {
  const DuasScreen({super.key});
  @override
  State<DuasScreen> createState() => _DuasState();
}

class _DuasState extends State<DuasScreen> {
  int cat = 0;
  String query = '';
  final searchCtrl = TextEditingController();
  final scroll = ScrollController();

  static const _detailKeys = <List<dynamic>>[
    ['dua_show_ar', 'عربی متن', Icons.article],
    ['dua_show_ur', 'اردو ترجمہ', Icons.translate],
    ['dua_show_pr', 'تلفظ', Icons.record_voice_over],
    ['dua_show_fz', 'فضائل', Icons.star_border],
    ['dua_show_wq', 'استعمال کا وقت', Icons.access_time],
  ];

  @override
  void dispose() {
    searchCtrl.dispose();
    scroll.dispose();
    super.dispose();
  }

  List<int> _filtered() {
    final q = query.trim();
    final out = <int>[];
    for (int i = 0; i < duas.length; i++) {
      final d = duas[i];
      if (cat == _favCat) {
        if (!_fav(i)) continue;
      } else if (cat != 0 && !d.cats.contains(cat)) {
        continue;
      }
      if (q.isNotEmpty && !(d.title.contains(q) || d.urdu.contains(q) || d.arabic.contains(q))) continue;
      out.add(i);
    }
    return out;
  }

  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
        child: Scaffold(
          backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
          bottomNavigationBar: msfNav7(context, icon3: Icons.back_hand, label3: 'دعائیں', onActiveTap: () {
            if (scroll.hasClients) scroll.animateTo(0, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
          }),
          body: Rebuild((c) => _body(c)),
        ),
      );

  Widget _body(BuildContext c) {
    final w = MediaQuery.of(c).size.width;
    final list = _filtered();
    final showSplit = cat == 0 && query.trim().isEmpty;
    final popular = [for (final i in list) if (duas[i].popular) i];
    final others = [for (final i in list) if (!duas[i].popular) i];
    return ListView(controller: scroll, padding: EdgeInsets.zero, children: [
      SizedBox(
        width: w,
        height: w * 184 / 1024,
        child: Stack(children: [
          Positioned.fill(child: Image.asset('assets/duas/header.png', fit: BoxFit.fill)),
          Positioned(
            left: w * 0.02,
            top: w * 8 / 1024,
            width: w * 0.17,
            height: w * 70 / 1024,
            child: Material(color: Colors.transparent, child: InkWell(borderRadius: BorderRadius.circular(30), onTap: () => Navigator.maybePop(c))),
          ),
        ]),
      ),
      Padding(padding: const EdgeInsets.fromLTRB(8, 8, 8, 8), child: _topRow(c)),
      _catChips(c),
      Padding(padding: const EdgeInsets.fromLTRB(8, 4, 8, 8), child: _searchRow(c)),
      Padding(
        padding: const EdgeInsets.fromLTRB(8, 0, 8, 6),
        child: _bar(showSplit ? 'مشہور دعائیں' : (cat == _favCat ? 'پسندیدہ دعائیں' : duaCats[cat]), Icons.back_hand, count: showSplit ? popular.length : list.length),
      ),
      if (list.isEmpty)
        Padding(
          padding: const EdgeInsets.all(28),
          child: Center(child: Text(cat == _favCat && query.trim().isEmpty ? 'ابھی کوئی پسندیدہ دعا نہیں۔ کسی دعا پر ستارے کو دبائیں۔' : 'کوئی دعا نہیں ملی', textAlign: TextAlign.center, style: TextStyle(color: subText(c)))),
        )
      else ...[
        _grid(c, showSplit ? popular : list),
        if (showSplit && others.isNotEmpty) ...[
          Padding(padding: const EdgeInsets.fromLTRB(8, 10, 8, 6), child: _bar('دیگر دعائیں', Icons.menu_book, count: others.length)),
          _grid(c, others),
        ],
      ],
      Padding(padding: const EdgeInsets.fromLTRB(8, 10, 8, 10), child: _bottomStrip(c)),
      Image.asset('assets/footer.png', width: double.infinity, fit: BoxFit.fitWidth),
    ]);
  }

  // ---------------------------------------------------------------- banner + date
  Widget _topRow(BuildContext c) => IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            flex: 62,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF0B4D2E), Color(0xFF14804A)]),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: gold.withAlpha(140)),
              ),
              child: Row(children: [
                const Icon(Icons.back_hand, color: Colors.white, size: 38),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const FittedBox(fit: BoxFit.scaleDown, child: Text('دعائیں', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold))),
                    const SizedBox(height: 2),
                    Text('قرآن و سنت کی روشنی میں منتخب دعائیں', style: TextStyle(color: Colors.white.withAlpha(230), fontSize: 10.5)),
                  ]),
                ),
              ]),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            flex: 38,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(70))),
              child: Row(children: [
                const Icon(Icons.calendar_month, color: green, size: 28),
                const SizedBox(width: 4),
                Expanded(
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('آج کی تاریخ', style: TextStyle(fontSize: 10, color: subText(c))),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(_todayIso(), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold))),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(_todayHijri(), style: TextStyle(fontSize: 10, color: subText(c)))),
                  ]),
                ),
              ]),
            ),
          ),
        ]),
      );

  // ---------------------------------------------------------------- category chips
  Widget _catChips(BuildContext c) => SizedBox(
        height: 82,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          itemCount: duaCats.length,
          separatorBuilder: (_, __) => const SizedBox(width: 6),
          itemBuilder: (_, i) {
            final sel = cat == i;
            return InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => setState(() => cat = i),
              child: Container(
                width: 82,
                padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 8),
                decoration: BoxDecoration(
                  color: sel ? const Color(0xFF0E5B37) : cardColor(c),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: sel ? const Color(0xFF7CD65B) : green.withAlpha(60), width: sel ? 1.6 : 1),
                ),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(duaCatIcons[i], size: 26, color: sel ? Colors.white : green),
                  const SizedBox(height: 4),
                  Text(duaCats[i], textAlign: TextAlign.center, maxLines: 2, style: TextStyle(fontSize: 10, height: 1.25, fontWeight: FontWeight.bold, color: sel ? Colors.white : null)),
                ]),
              ),
            );
          },
        ),
      );

  // ---------------------------------------------------------------- search + category list
  Widget _searchRow(BuildContext c) => Row(children: [
        Expanded(
          child: TextField(
            controller: searchCtrl,
            onChanged: (v) => setState(() => query = v),
            style: const TextStyle(fontSize: 13),
            decoration: InputDecoration(
              hintText: 'دعا کا نام تلاش کریں...',
              hintStyle: TextStyle(fontSize: 12, color: subText(c)),
              prefixIcon: const Icon(Icons.search, color: green),
              suffixIcon: query.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.close, size: 18),
                      onPressed: () {
                        searchCtrl.clear();
                        FocusScope.of(c).unfocus();
                        setState(() => query = '');
                      },
                    ),
              contentPadding: const EdgeInsets.symmetric(vertical: 10),
            ),
          ),
        ),
        const SizedBox(width: 6),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFF0E5B37), padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12)),
          onPressed: () => _catSheet(c),
          icon: const Icon(Icons.format_list_bulleted, size: 18),
          label: const Text('تمام زمروں کی فہرست', style: TextStyle(fontSize: 11)),
        ),
      ]);

  int _catCount(int k) {
    if (k == _favCat) return [for (int i = 0; i < duas.length; i++) if (_fav(i)) i].length;
    if (k == 0) return duas.length;
    return duas.where((d) => d.cats.contains(k)).length;
  }

  Future<void> _catSheet(BuildContext c) async {
    final r = await showModalBottomSheet<int>(
      context: c,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          const Padding(padding: EdgeInsets.all(14), child: Text('دعاؤں کے زمرے', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
          for (int k = 0; k < duaCats.length; k++)
            ListTile(
              leading: Icon(duaCatIcons[k], color: green),
              title: Text(duaCats[k]),
              trailing: Text('${_catCount(k)}', style: const TextStyle(fontWeight: FontWeight.bold)),
              selected: cat == k,
              onTap: () => Navigator.pop(ctx, k),
            ),
          ListTile(
            leading: const Icon(Icons.star, color: gold),
            title: const Text('پسندیدہ دعائیں'),
            trailing: Text('${_catCount(_favCat)}', style: const TextStyle(fontWeight: FontWeight.bold)),
            selected: cat == _favCat,
            onTap: () => Navigator.pop(ctx, _favCat),
          ),
        ]),
      ),
    );
    if (r != null) setState(() => cat = r);
  }

  // ---------------------------------------------------------------- section bar
  Widget _bar(String t, IconData icon, {int? count}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF0E5B37), Color(0xFF1B8A45)]),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(children: [
          Icon(icon, color: Colors.white, size: 18),
          const SizedBox(width: 6),
          Expanded(child: Text(t, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold))),
          if (count != null) Text('$count', style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ]),
      );

  // ---------------------------------------------------------------- cards grid
  Widget _grid(BuildContext c, List<int> idx) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: idx.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 8, crossAxisSpacing: 8, mainAxisExtent: 186),
          itemBuilder: (_, k) => _card(c, idx[k]),
        ),
      );

  Widget _card(BuildContext c, int i) {
    final d = duas[i];
    final fav = _fav(i);
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => go(c, DuaDetailScreen(index: i)),
      child: Container(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
        decoration: BoxDecoration(
          color: cardColor(c),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: green.withAlpha(70)),
          boxShadow: [BoxShadow(color: Colors.black.withAlpha(14), blurRadius: 4, offset: const Offset(0, 1))],
        ),
        child: Column(children: [
          Row(children: [
            Container(width: 34, height: 34, decoration: const BoxDecoration(color: Color(0xFF0E5B37), shape: BoxShape.circle), child: Icon(d.icon, color: Colors.white, size: 19)),
            const SizedBox(width: 6),
            Expanded(child: Text(d.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, height: 1.25))),
            InkWell(
              onTap: () => setB('dua_fav_$i', !fav),
              child: Padding(padding: const EdgeInsets.all(2), child: Icon(fav ? Icons.star : Icons.star_border, color: fav ? gold : Colors.grey, size: 22)),
            ),
          ]),
          const SizedBox(height: 4),
          Text(d.arabic, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, height: 1.8)),
          Expanded(child: Text(d.urdu, maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, height: 1.5, color: subText(c)))),
          SizedBox(
            width: double.infinity,
            height: 30,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFF0E5B37), padding: EdgeInsets.zero),
              onPressed: () => go(c, DuaDetailScreen(index: i)),
              child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('تفصیل دیکھیں', style: TextStyle(fontSize: 11)),
                SizedBox(width: 4),
                Icon(Icons.chevron_left, size: 16),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  // ---------------------------------------------------------------- bottom strip
  Widget _bottomStrip(BuildContext c) => IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            flex: 66,
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(60))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: const Color(0xFF0E5B37), borderRadius: BorderRadius.circular(6)),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.menu_book, color: Colors.white, size: 14),
                    SizedBox(width: 4),
                    Text('دعا کی تفصیلات', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                  ]),
                ),
                const SizedBox(height: 6),
                Row(children: [
                  for (final k in _detailKeys)
                    Expanded(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(8),
                        onTap: () => setB(k[0] as String, !getB(k[0] as String, true)),
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 1.5),
                          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 1),
                          decoration: BoxDecoration(
                            color: getB(k[0] as String, true) ? green.withAlpha(30) : null,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: getB(k[0] as String, true) ? green : Colors.grey.withAlpha(90)),
                          ),
                          child: Column(children: [
                            Icon(k[2] as IconData, size: 20, color: getB(k[0] as String, true) ? green : Colors.grey),
                            const SizedBox(height: 3),
                            FittedBox(fit: BoxFit.scaleDown, child: Text(k[1] as String, style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold))),
                          ]),
                        ),
                      ),
                    ),
                ]),
                const SizedBox(height: 4),
                Text('دعا کھولنے پر یہی حصے دکھائے جائیں گے۔ ٹیپ کر کے آن/آف کریں۔', style: TextStyle(fontSize: 8.5, color: subText(c))),
              ]),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            flex: 34,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFFF3F0D2), Color(0xFFDCEBD3)]),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: green.withAlpha(50)),
              ),
              child: const Center(
                child: Text('دعا دل کی روشنی ہے، جو ہر مشکل کو آسان بنا دیتی ہے۔', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, height: 1.7, fontWeight: FontWeight.bold, color: Color(0xFF0B3D2A))),
              ),
            ),
          ),
        ]),
      );
}

// ------------------------------------------------------------------ detail screen
class DuaDetailScreen extends StatelessWidget {
  final int index;
  const DuaDetailScreen({super.key, required this.index});

  Widget _section(BuildContext c, IconData icon, String title, Widget child) => box(
        c,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(icon, color: green, size: 18),
            const SizedBox(width: 6),
            Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: green)),
          ]),
          const Divider(height: 14),
          child,
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final d = duas[index];
    return Screen(
      d.title,
      actions: [
        Rebuild((c) => IconButton(
              tooltip: 'پسندیدہ',
              icon: Icon(_fav(index) ? Icons.star : Icons.star_border, color: _fav(index) ? gold : Colors.white),
              onPressed: () => setB('dua_fav_$index', !_fav(index)),
            )),
        IconButton(
          tooltip: 'کاپی',
          icon: const Icon(Icons.copy),
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: '${d.title}\n\n${d.arabic}\n\n${d.urdu}\n\n(${d.ref})'));
            if (context.mounted) toast(context, 'کاپی ہو گیا');
          },
        ),
      ],
      Rebuild((c) {
        final secs = <Widget>[];
        if (getB('dua_show_ar', true)) {
          secs.add(_section(c, Icons.article, 'عربی متن', Text(d.arabic, textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, height: 2.2))));
        }
        if (getB('dua_show_pr', true)) {
          secs.add(_section(c, Icons.record_voice_over, 'تلفظ', Text(d.pron, style: const TextStyle(fontSize: 16, height: 2))));
        }
        if (getB('dua_show_ur', true)) {
          secs.add(_section(c, Icons.translate, 'اردو ترجمہ', Text(d.urdu, style: const TextStyle(fontSize: 15, height: 1.9))));
        }
        if (getB('dua_show_fz', true)) {
          secs.add(_section(c, Icons.star_border, 'فضائل', Text(d.fazl, style: const TextStyle(fontSize: 14, height: 1.8))));
        }
        if (getB('dua_show_wq', true)) {
          secs.add(_section(c, Icons.access_time, 'استعمال کا وقت', Text(d.waqt, style: const TextStyle(fontSize: 14, height: 1.8))));
        }
        secs.add(_section(c, Icons.menu_book, 'حوالہ', Text(d.ref, style: const TextStyle(fontSize: 14))));
        return ListView(padding: const EdgeInsets.all(10), children: [
          if (secs.length == 1)
            Padding(padding: const EdgeInsets.all(12), child: Text('تمام حصے بند ہیں۔ دعاؤں کی فہرست میں "دعا کی تفصیلات" سے آن کریں۔', textAlign: TextAlign.center, style: TextStyle(color: subText(c)))),
          ...secs,
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: index > 0 ? () => Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => DuaDetailScreen(index: index - 1))) : null,
                icon: const Icon(Icons.chevron_right),
                label: const Text('پچھلی دعا'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: index < duas.length - 1 ? () => Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => DuaDetailScreen(index: index + 1))) : null,
                icon: const Icon(Icons.chevron_left),
                label: const Text('اگلی دعا'),
              ),
            ),
          ]),
          const SizedBox(height: 12),
        ]);
      }),
    );
  }
}
