import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'timetable.dart';
import 'home.dart';

const _deep = Color(0xFF0B4D2E);
const _orange = Color(0xFFF2A413);
const _doneGreen = Color(0xFF1B7F45);

class _TC {
  final String name, art, sub, rakat;
  final DateTime time;
  final DateTime? end;
  final int farz; // 0..4 for the five fard prayers, -1 for nafl
  const _TC(this.name, this.art, this.time, this.farz, {this.end, this.sub = '', this.rakat = ''});
}

class _Mini {
  final String name, sub;
  final IconData icon;
  final DateTime time;
  final VoidCallback onTap;
  const _Mini(this.name, this.icon, this.time, this.sub, this.onTap);
}

class PrayersScreen extends StatefulWidget {
  const PrayersScreen({super.key});
  @override
  State<PrayersScreen> createState() => _PrayersState();
}

class _PrayersState extends State<PrayersScreen> {
  DateTime date = dayOnly(DateTime.now());
  DateTime now = DateTime.now();
  Timer? timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() => now = DateTime.now());
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  bool get _isToday => sameDay(date, dayOnly(now));
  bool get _isFuture => date.isAfter(dayOnly(now));

  void _move(int n) => setState(() => date = addDays(date, n));

  String _nfKey(String n) => 'nf|${dayKey(date)}|$n';

  void _openPage(String title) {
    for (final f in allFeatures()) {
      if (f.title == title) {
        go(context, f.page());
        return;
      }
    }
  }

  bool _canMark() {
    if (_isFuture) {
      toast(context, 'آنے والے دن کی نماز کا ریکارڈ نہیں ہو سکتا');
      return false;
    }
    return true;
  }

  String _rem(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes % 60;
    if (h > 0) return '$h گھنٹے $m منٹ';
    return '$m منٹ';
  }

  // ------------------------------------------------------------ actions
  void _pick(int i) {
    if (!_canMark()) return;
    final opts = [2, 1, 3, 0];
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Text('${prayerInfos[i].name} - ${fmtDate(date)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
          for (final s in opts)
            ListTile(
              leading: Icon(s == 0 ? Icons.clear : (s == 3 ? Icons.event_busy : Icons.check_circle), color: s == 0 ? Colors.grey : statusColor(s)),
              title: Text(s == 0 ? 'نشان ہٹائیں' : (s == 2 ? 'با جماعت ادا کی' : (s == 1 ? 'اکیلے ادا کی' : 'قضا ہو گئی'))),
              onTap: () {
                setPrayerState(date, i, s);
                Navigator.pop(c);
              },
            ),
        ]),
      ),
    );
  }

  void _quick(int i) {
    if (!_canMark()) return;
    final cur = prayerState(date, i);
    setPrayerState(date, i, (cur == 0 || cur == 3) ? 2 : 0);
  }

  void _toggleNafl(String key) {
    if (!_canMark()) return;
    final k = _nfKey(key);
    setB(k, !getB(k));
  }

  void _info(String title, String body) {
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: green)),
            const SizedBox(height: 10),
            Text(body, style: const TextStyle(fontSize: 14.5, height: 1.8)),
          ]),
        ),
      ),
    );
  }

  void _detail(_TC x) {
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${x.name} - ${fmtDate(date)}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: green)),
            const SizedBox(height: 10),
            Text('آغاز: ${p12(x.time)}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            if (x.end != null) Text('اختتام: ${p12(x.end!)}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Text(x.farz >= 0 ? prayerInfos[x.farz].rakat.join(' • ') : x.rakat, style: TextStyle(fontSize: 13, color: subText(context))),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: green),
                onPressed: () {
                  Navigator.pop(c);
                  if (x.farz >= 0) {
                    _pick(x.farz);
                  } else {
                    _toggleNafl(x.art);
                  }
                },
                icon: const Icon(Icons.edit_note),
                label: Text(x.farz >= 0 ? 'ریکارڈ درج کریں' : (getB(_nfKey(x.art)) ? 'نشان ہٹائیں' : 'ادا کر لی')),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  // ------------------------------------------------------------ build
  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
        child: Scaffold(
          backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
          bottomNavigationBar: _nav(context),
          body: Rebuild((c) => _body(c)),
        ),
      );

  Widget _body(BuildContext c) {
    final w = MediaQuery.of(c).size.width;
    final t = dayTimes(date);
    final tom = dayTimes(addDays(date, 1));
    return ListView(padding: EdgeInsets.zero, children: [
      _header(c, w),
      Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
        child: Column(children: [
          _mapSelector(c),
          const SizedBox(height: 8),
          _titleRow(c, t, tom),
          const SizedBox(height: 8),
          _timeRow(c, t, tom),
          const SizedBox(height: 8),
          _miniRow(c, t, tom),
          const SizedBox(height: 8),
          _panels(c),
          const SizedBox(height: 8),
          _grid(c),
          const SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.asset('assets/prayers/banner.png', width: double.infinity, fit: BoxFit.fitWidth),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              ttMap() == 0
                  ? 'اوقات: کوہاٹ کا متفقہ نقشہ اوقات نماز۔ اشراق، چاشت اور سحری کے اوقات اسی نقشے کے طلوع و فجر سے اخذ کیے گئے ہیں۔'
                  : 'اوقات: دائمی نقشہ سحر و افطار (کوہاٹ اور مضافات)۔',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11.5, color: subText(c), height: 1.6),
            ),
          ),
        ]),
      ),
    ]);
  }

  Widget _header(BuildContext c, double w) => SizedBox(
        width: w,
        height: w * 296 / 1024,
        child: Stack(children: [
          Positioned.fill(child: Image.asset('assets/prayers/header.png', fit: BoxFit.fill)),
          // transparent hit area over the "واپس" button drawn in the artwork
          Positioned(
            left: w * 0.018,
            top: w * 125 / 1024,
            width: w * 0.165,
            height: w * 0.07,
            child: Material(
              color: Colors.transparent,
              child: InkWell(borderRadius: BorderRadius.circular(30), onTap: () => Navigator.maybePop(c)),
            ),
          ),
        ]),
      );

  // ------------------------------------------------------------ map selector
  Widget _mapSelector(BuildContext c) {
    final cur = ttMap();
    final asr = useHanafi();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(4, 0, 4, 6),
        child: Text('اوقات کا نقشہ منتخب کریں', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: green)),
      ),
      Row(children: [
        for (int k = 0; k < 2; k++) ...[
          if (k == 1) const SizedBox(width: 8),
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => setI('ttmap', k),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                decoration: BoxDecoration(
                  gradient: cur == k ? const LinearGradient(colors: [Color(0xFF14803F), _deep]) : null,
                  color: cur == k ? null : cardColor(c),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: cur == k ? gold : green.withAlpha(90), width: cur == k ? 1.6 : 1),
                ),
                child: Row(children: [
                  Icon(cur == k ? Icons.radio_button_checked : Icons.radio_button_off, size: 20, color: cur == k ? gold : green),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      ttNames[k],
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, height: 1.35, color: cur == k ? Colors.white : null),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ],
      ]),
      const SizedBox(height: 6),
      Wrap(spacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
        Text('عصر / عشاء:', style: TextStyle(fontSize: 12.5, color: subText(c), fontWeight: FontWeight.bold)),
        ChoiceChip(
          visualDensity: VisualDensity.compact,
          label: const Text('حنفی', style: TextStyle(fontSize: 12)),
          selected: asr,
          onSelected: (_) => setI('asr', 2),
        ),
        ChoiceChip(
          visualDensity: VisualDensity.compact,
          label: const Text('شافعی', style: TextStyle(fontSize: 12)),
          selected: !asr,
          onSelected: (_) => setI('asr', 1),
        ),
      ]),
    ]);
  }

  // ------------------------------------------------------------ title + date
  Widget _titleRow(BuildContext c, DayTimes t, DayTimes tom) {
    String line;
    if (_isToday) {
      final list = <List<dynamic>>[
        ['فجر', t.fajr],
        ['ظہر', t.zuhr],
        ['عصر', t.asr],
        ['مغرب', t.maghrib],
        ['عشاء', t.isha],
      ];
      line = '';
      for (final e in list) {
        final d = e[1] as DateTime;
        if (d.isAfter(now)) {
          line = 'اگلی نماز: ${e[0]} • ${_rem(d.difference(now))} باقی';
          break;
        }
      }
      if (line.isEmpty) line = 'اگلی نماز: فجر • ${_rem(tom.fajr.difference(now))} باقی';
    } else {
      line = 'آج کے اوقات کے لیے یہاں دبائیں';
    }
    return Directionality(
      textDirection: TextDirection.ltr,
      child: SizedBox(
        height: 78,
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            flex: 11,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: _isToday ? null : () => setState(() => date = dayOnly(DateTime.now())),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF14803F), _deep]),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: gold.withAlpha(150)),
                ),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Row(children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: gold, width: 1.5)),
                      child: const Icon(Icons.mosque, color: Colors.white, size: 26),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(_isToday ? 'آج کی نماز کے اوقات' : '${fmtShort(date)} کے اوقات', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                        ),
                        const SizedBox(height: 3),
                        FittedBox(fit: BoxFit.scaleDown, child: Text(line, style: const TextStyle(color: Colors.white70, fontSize: 11.5))),
                      ]),
                    ),
                  ]),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 7,
            child: Container(
              decoration: BoxDecoration(
                color: cardColor(c),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: green.withAlpha(70)),
              ),
              child: Row(children: [
                InkWell(onTap: () => _move(-1), child: const Padding(padding: EdgeInsets.all(2), child: Icon(Icons.chevron_left, color: green, size: 22))),
                Expanded(
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(_isToday ? 'آج کی تاریخ' : 'منتخب تاریخ', style: TextStyle(fontSize: 11, color: subText(c))),
                          const SizedBox(width: 4),
                          const Icon(Icons.calendar_month, color: green, size: 18),
                        ]),
                        Text('${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                        Text('(${hijriText(date)})', style: TextStyle(fontSize: 10.5, color: subText(c))),
                      ]),
                    ),
                  ),
                ),
                InkWell(onTap: () => _move(1), child: const Padding(padding: EdgeInsets.all(2), child: Icon(Icons.chevron_right, color: green, size: 22))),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  // ------------------------------------------------------------ 7 time cards
  Widget _timeRow(BuildContext c, DayTimes t, DayTimes tom) {
    final items = <_TC>[
      _TC('فجر', 'fajr', t.fajr, 0, end: t.sunrise),
      _TC('اشراق', 'ishraq', t.ishraq, -1, sub: 'طلوع ${p12(t.sunrise)}', rakat: '2 یا 4 رکعات، سورج نکلنے کے کچھ دیر بعد'),
      _TC('چاشت', 'chasht', t.chasht, -1, end: t.zawal, sub: 'تا ${p12(t.zawal)}', rakat: '2 سے 12 رکعات، سورج بلند ہونے کے بعد'),
      _TC('ظہر', 'zuhr', t.zuhr, 1, end: t.asr),
      _TC('عصر', 'asr', t.asr, 2, end: t.maghrib),
      _TC('مغرب', 'maghrib', t.maghrib, 3, end: t.isha),
      _TC('عشاء', 'isha', t.isha, 4, end: tom.fajr),
    ];
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (final x in items) Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 1.5), child: _timeCard(c, x))),
      ]),
    );
  }

  Widget _timeCard(BuildContext c, _TC x) {
    final past = !_isFuture && (!_isToday || x.time.isBefore(now));
    String label;
    Color col;
    bool solid;
    if (x.farz >= 0) {
      final s = prayerState(date, x.farz);
      if (s == 1 || s == 2) {
        label = s == 2 ? 'با جماعت ادا' : 'نماز ادا ہو چکی';
        col = _doneGreen;
        solid = true;
      } else if (s == 3) {
        label = 'قضا';
        col = const Color(0xFFD32F2F);
        solid = true;
      } else {
        label = past ? 'باقی' : 'آنے والی';
        col = past ? _orange : Colors.grey;
        solid = past;
      }
    } else {
      final done = getB(_nfKey(x.art));
      label = done ? 'ادا ہو چکی' : (past ? 'ادا کریں' : 'آنے والی');
      col = done ? _doneGreen : (past ? _orange : Colors.grey);
      solid = done || past;
    }
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => _detail(x),
      child: Container(
        decoration: BoxDecoration(
          color: cardColor(c),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: green.withAlpha(70)),
          boxShadow: [BoxShadow(color: Colors.black.withAlpha(18), blurRadius: 4, offset: const Offset(0, 2))],
        ),
        child: Column(children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(11)),
            child: AspectRatio(aspectRatio: 1.42, child: Image.asset('assets/prayers/card_${x.art}.png', fit: BoxFit.cover)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(2, 4, 2, 4),
            child: Column(children: [
              FittedBox(fit: BoxFit.scaleDown, child: Text(x.name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold))),
              FittedBox(fit: BoxFit.scaleDown, child: Text(p12(x.time), style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700))),
              SizedBox(
                height: 14,
                child: x.sub.isEmpty ? null : FittedBox(fit: BoxFit.scaleDown, child: Text(x.sub, style: TextStyle(fontSize: 9, color: subText(c)))),
              ),
              const SizedBox(height: 2),
              _pill(label, col, solid, () {
                if (x.farz >= 0) {
                  _pick(x.farz);
                } else {
                  _toggleNafl(x.art);
                }
              }),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _pill(String label, Color col, bool solid, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Container(
          height: 22,
          width: double.infinity,
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(horizontal: 3),
          decoration: BoxDecoration(
            color: solid ? col : col.withAlpha(40),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: col),
          ),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(label, style: TextStyle(color: solid ? Colors.white : col, fontSize: 10, fontWeight: FontWeight.bold)),
          ),
        ),
      );

  // ------------------------------------------------------------ 6 mini cards
  Widget _miniRow(BuildContext c, DayTimes t, DayTimes tom) {
    final night = tom.fajr.difference(t.maghrib).inMinutes;
    final tahajjud = t.maghrib.add(Duration(minutes: (night * 2 / 3).round()));
    var fri = date;
    while (fri.weekday != DateTime.friday) {
      fri = addDays(fri, 1);
    }
    final friSub = sameDay(fri, date) ? '(آج)' : '(${fmtShort(fri)})';
    final items = <_Mini>[
      _Mini('اوابین', Icons.wb_twilight, t.maghrib.add(const Duration(minutes: 20)), '(مغرب کے بعد)', () => _openPage('نفل نمازیں')),
      _Mini('تہجد', Icons.bedtime, tahajjud, '(رات کا آخری تہائی)', () => _openPage('تہجد')),
      _Mini('سحری کا اختتام', Icons.free_breakfast, t.sehri, '(صبح)', () => _info('سحری کا اختتام', 'سحری کا وقت صبح صادق سے پہلے ختم ہو جاتا ہے۔ احتیاطاً چند منٹ پہلے سحری ختم کر لیں۔ یہ وقت منتخب نقشے کے مطابق ہے۔')),
      _Mini('افطار', Icons.restaurant, t.maghrib, '(شام)', () => _info('افطار', 'روزہ غروب آفتاب کے فوراً بعد افطار کیا جاتا ہے۔ یہ وقت منتخب نقشے کے مطابق ہے۔')),
      _Mini('زوال', Icons.wb_sunny, t.zawal, '(نصف النہار)', () => _info('زوال (نصف النہار)', 'عین دوپہر کے وقت نماز پڑھنا مکروہ ہے۔ اس کے فوراً بعد ظہر کا وقت شروع ہو جاتا ہے۔')),
      _Mini('جمعہ', Icons.mosque, t.zuhr, friSub, () => _openPage('جمعہ کی نماز')),
    ];
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(children: [
        for (final m in items)
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 1.5),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: m.onTap,
                child: Container(
                  height: 96,
                  padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
                  decoration: BoxDecoration(
                    color: cardColor(c),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: green.withAlpha(70)),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                    Icon(m.icon, color: green, size: 24),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(m.name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(p12(m.time), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(m.sub, style: TextStyle(fontSize: 8.5, color: subText(c)))),
                  ]),
                ),
              ),
            ),
          ),
      ]),
    );
  }

  // ------------------------------------------------------------ quick record + nafl panels
  Widget _panels(BuildContext c) {
    const order = [0, 1, 2, 3, 4];
    return Directionality(
      textDirection: TextDirection.ltr,
      child: SizedBox(
        height: 112,
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            flex: 3,
            child: _panelShell(
              c,
              'پانچ وقتہ نماز کا ریکارڈ',
              Icons.mosque,
              Padding(
                padding: const EdgeInsets.all(5),
                child: Row(children: [
                  for (final i in order)
                    Expanded(
                      child: Padding(padding: const EdgeInsets.symmetric(horizontal: 2), child: _quickTile(c, i)),
                    ),
                ]),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => _openPage('نفل نمازیں'),
              child: _panelShell(
                c,
                'نفل نمازیں',
                Icons.back_hand,
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Directionality(
                    textDirection: TextDirection.rtl,
                    child: Row(children: [
                      Expanded(child: Text('تمام نفل نمازوں کا مکمل ریکارڈ', style: TextStyle(fontSize: 11.5, color: subText(c), height: 1.5))),
                      const Icon(Icons.chevron_left, color: green),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _panelShell(BuildContext c, String title, IconData icon, Widget body) => Container(
        decoration: BoxDecoration(
          color: cardColor(c),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: green.withAlpha(90)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [Color(0xFF14803F), _deep]),
              borderRadius: BorderRadius.vertical(top: Radius.circular(13)),
            ),
            child: Directionality(
              textDirection: TextDirection.rtl,
              child: Row(children: [
                Icon(icon, color: Colors.white, size: 20),
                const SizedBox(width: 6),
                Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)))),
              ]),
            ),
          ),
          Expanded(child: Align(alignment: Alignment.center, child: body)),
        ]),
      );

  Widget _quickTile(BuildContext c, int i) {
    final s = prayerState(date, i);
    final ok = s == 1 || s == 2;
    final bad = s == 3;
    final bg = ok ? _doneGreen : (bad ? const Color(0xFFD32F2F) : green.withAlpha(28));
    final fg = (ok || bad) ? Colors.white : green;
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => _quick(i),
      onLongPress: () => _pick(i),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(ok ? Icons.check_circle : (bad ? Icons.event_busy : prayerInfos[i].icon), color: fg, size: 24),
          const SizedBox(height: 3),
          FittedBox(fit: BoxFit.scaleDown, child: Text(prayerInfos[i].name, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.bold))),
        ]),
      ),
    );
  }

  // ------------------------------------------------------------ 10 feature buttons
  Widget _grid(BuildContext c) {
    final rows = <List<List<dynamic>>>[
      [
        ['تراویح', 'رمضان المبارک', Icons.mosque_outlined, 'تراویح'],
        ['تہجد', 'رات کی نماز', Icons.bedtime, 'تہجد'],
        ['جمعہ', 'جمعہ کی نماز', Icons.location_city, 'جمعہ کی نماز'],
        ['عیدین', 'عیدالفطر / عیدالاضحیٰ', Icons.celebration, 'عیدین کی نماز'],
        ['قضا نماز', 'قضا نمازوں کا ریکارڈ', Icons.timer, 'قضا نماز'],
      ],
      [
        ['قبلہ', 'قبلہ کی سمت', Icons.explore, 'قبلہ'],
        ['اسلامی کیلنڈر', 'ہجری اور اسلامی تاریخیں', Icons.calendar_month, 'اسلامی کیلنڈر'],
        ['دعائیں', 'روزانہ کی دعائیں', Icons.back_hand, 'دعائیں'],
        ['رپورٹس', 'روزانہ، ہفتہ وار، ماہانہ', Icons.bar_chart, 'نماز کی رپورٹس'],
        ['سیٹنگز', 'ایپ کی ترتیبات', Icons.settings, 'سیٹنگز'],
      ],
    ];
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(children: [
        for (final row in rows)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(children: [
              for (final it in row)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => _openPage(it[3] as String),
                      child: Container(
                        height: 92,
                        padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 6),
                        decoration: BoxDecoration(
                          color: cardColor(c),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: green.withAlpha(70)),
                        ),
                        child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                          Icon(it[2] as IconData, color: green, size: 30),
                          FittedBox(fit: BoxFit.scaleDown, child: Text(it[0] as String, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold))),
                          Text(it[1] as String, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 8.5, color: subText(c), height: 1.3)),
                        ]),
                      ),
                    ),
                  ),
                ),
            ]),
          ),
      ]),
    );
  }

  // ------------------------------------------------------------ bottom nav
  Widget _nav(BuildContext c) {
    const items = <List<dynamic>>[
      [Icons.home, 'ہوم'],
      [Icons.mosque, 'نمازیں'],
      [Icons.menu_book, 'دعائیں'],
      [Icons.nightlight_round, 'تراویح'],
      [Icons.bedtime, 'تہجد'],
      [Icons.settings, 'سیٹنگز'],
      [Icons.menu, 'مزید'],
    ];
    void act(int i) {
      switch (i) {
        case 0:
          Navigator.of(c).popUntil((r) => r.isFirst);
          break;
        case 1:
          break;
        case 2:
          _openPage('دعائیں');
          break;
        case 3:
          _openPage('تراویح');
          break;
        case 4:
          _openPage('تہجد');
          break;
        case 5:
          _openPage('سیٹنگز');
          break;
        case 6:
          go(c, MorePage(features: allFeatures()));
          break;
      }
    }

    return Container(
      color: const Color(0xFF0B3D2A),
      padding: EdgeInsets.only(bottom: MediaQuery.of(c).padding.bottom, top: 4),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          for (int i = 0; i < items.length; i++)
            Expanded(
              child: InkWell(
                onTap: () => act(i),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  decoration: i == 1 ? BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF7CD65B), width: 1.4), color: const Color(0xFF14803F)) : null,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(items[i][0] as IconData, color: i == 1 ? gold : Colors.white, size: 24),
                    const SizedBox(height: 2),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(items[i][1] as String, style: TextStyle(color: i == 1 ? gold : Colors.white, fontSize: 11, fontWeight: FontWeight.bold))),
                  ]),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}
