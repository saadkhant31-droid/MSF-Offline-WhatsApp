import 'dart:io' show Platform;
import 'package:android_intent_plus/android_intent.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'timetable.dart';
import 'jumah.dart' show JRec, lastFriday;
import 'wallpaper.dart';

const _pkg = 'com.msf.msf_nimaz_ki_record';
const _dark = Color(0xFF0B3D2A);

Future<bool> _intent(String action, {Map<String, dynamic>? args, String? data}) async {
  if (!Platform.isAndroid) return false;
  try {
    await AndroidIntent(action: action, arguments: args, data: data).launch();
    return true;
  } catch (_) {
    return false;
  }
}

Future<void> _sheet(BuildContext c, String title, Widget Function(BuildContext) body) {
  return showModalBottomSheet<void>(
    context: c,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.8),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: green)),
          ),
          Flexible(child: SingleChildScrollView(child: Rebuild(body))),
        ]),
      ),
    ),
  );
}

/// Profile helpers (stored in the same backup as everything else).
String profileName() => getS('pf_name').trim();

class _Item {
  final String title, sub;
  final IconData icon;
  final Color c1, c2;
  final VoidCallback onTap;
  const _Item(this.title, this.sub, this.icon, this.c1, this.c2, this.onTap);
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  // ------------------------------------------------------------ actions
  Future<void> _restore(BuildContext c) async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('ڈیٹا بحال کریں'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('بیک اپ کا متن یہاں چسپاں کریں۔ موجودہ ڈیٹا بدل جائے گا۔', style: TextStyle(fontSize: 13)),
          const SizedBox(height: 8),
          TextField(controller: ctrl, maxLines: 4, decoration: const InputDecoration(border: OutlineInputBorder())),
          TextButton(
            onPressed: () async {
              final d = await Clipboard.getData('text/plain');
              ctrl.text = d?.text ?? '';
            },
            child: const Text('کلپ بورڈ سے چسپاں کریں'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('بحال کریں')),
        ],
      ),
    );
    if (ok == true) {
      final r = await importData(ctrl.text.trim());
      if (c.mounted) toast(c, r ? 'ڈیٹا بحال ہو گیا' : 'بیک اپ درست نہیں ہے');
    }
  }

  Future<void> _clearAll(BuildContext c) async {
    if (!await confirmDialog(c, 'تمام ریکارڈ ہمیشہ کے لیے حذف ہو جائے گا۔ کیا آپ واقعی حذف کرنا چاہتے ہیں؟')) return;
    await sp.clear();
    themeMode.value = ThemeMode.light;
    bump();
    if (c.mounted) toast(c, 'تمام ڈیٹا حذف ہو گیا');
  }

  Future<void> _logout(BuildContext c) async {
    if (profileName().isEmpty && getS('pf_father').isEmpty && getS('pf_phone').isEmpty && getS('pf_note').isEmpty) {
      toast(c, 'ابھی کوئی پروفائل محفوظ نہیں ہے');
      return;
    }
    if (!await confirmDialog(c, 'پروفائل کی معلومات (نام وغیرہ) ہٹا دی جائیں؟ نماز کا ریکارڈ محفوظ رہے گا۔')) return;
    for (final k in ['pf_name', 'pf_father', 'pf_phone', 'pf_note']) {
      sp.remove(k);
    }
    bump();
    if (c.mounted) toast(c, 'پروفائل سے باہر نکل گئے');
  }

  Future<void> _rate(BuildContext c) async {
    var ok = await _intent('android.intent.action.VIEW', data: 'market://details?id=$_pkg');
    if (!ok) ok = await _intent('android.intent.action.VIEW', data: 'https://play.google.com/store/apps/details?id=$_pkg');
    if (!ok && c.mounted) toast(c, 'پلے اسٹور نہیں کھل سکا');
  }

  String _report() {
    final now = dayOnly(DateTime.now());
    final cnt = List.generate(prayerInfos.length, (_) => [0, 0, 0]);
    for (var d = 0; d < 30; d++) {
      final day = addDays(now, -d);
      for (var i = 0; i < prayerInfos.length; i++) {
        final s = prayerState(day, i);
        if (s == 1) cnt[i][0]++;
        if (s == 2) cnt[i][1]++;
        if (s == 3) cnt[i][2]++;
      }
    }
    final b = StringBuffer('MSF Nimaz ki Record - رپورٹ\n${fmtDate(now)}\n\nپچھلے 30 دن (ادا / با جماعت / قضا)\n');
    for (var i = 0; i < prayerInfos.length; i++) {
      b.writeln('${prayerInfos[i].name}: ${cnt[i][0]} / ${cnt[i][1]} / ${cnt[i][2]}');
    }
    var yes = 0, no = 0;
    var f = lastFriday(DateTime(now.year, 1, 7));
    while (f.year == now.year && !f.isAfter(now)) {
      final r = JRec.load(f);
      if (r.saved) {
        if (r.st == 'yes') {
          yes++;
        } else {
          no++;
        }
      }
      f = addDays(f, 7);
    }
    b.writeln('\nجمعہ ${now.year}: پڑھی $yes، نہیں پڑھی $no');
    return b.toString();
  }

  // ------------------------------------------------------------ sheets
  void _language(BuildContext c) => _sheet(c, 'زبان', (ctx) => Column(children: [
        const ListTile(leading: Icon(Icons.radio_button_checked, color: green), title: Text('اردو (Default)')),
        ListTile(
          leading: const Icon(Icons.radio_button_off, color: Colors.grey),
          title: const Text('English'),
          subtitle: const Text('جلد آ رہی ہے'),
          onTap: () => toast(ctx, 'انگریزی زبان جلد شامل کی جائے گی'),
        ),
      ]));

  void _theme(BuildContext c) => _sheet(c, 'تھیم', (ctx) {
        Widget t(String title, IconData ic, bool dark) => ListTile(
              leading: Icon(getB('dark') == dark ? Icons.radio_button_checked : Icons.radio_button_off, color: green),
              title: Text(title),
              trailing: Icon(ic, color: green),
              onTap: () {
                themeMode.value = dark ? ThemeMode.dark : ThemeMode.light;
                setB('dark', dark);
              },
            );
        return Column(children: [t('لائٹ موڈ', Icons.light_mode, false), t('ڈارک موڈ', Icons.dark_mode, true)]);
      });

  Future<void> _fridayAlarm(BuildContext c) async {
    final t = await showTimePicker(context: c, initialTime: const TimeOfDay(hour: 11, minute: 30));
    if (t == null) return;
    final ok = await _intent('android.intent.action.SET_ALARM', args: {
      'android.intent.extra.alarm.HOUR': t.hour,
      'android.intent.extra.alarm.MINUTES': t.minute,
      'android.intent.extra.alarm.MESSAGE': 'جمعہ کی نماز',
      'android.intent.extra.alarm.DAYS': <int>[6],
      'android.intent.extra.alarm.SKIP_UI': false,
    });
    if (!ok && c.mounted) toast(c, 'الارم نہیں لگ سکا');
  }

  void _notify(BuildContext c) => _sheet(c, 'نوٹیفیکیشن (یاد دہانی اور الرٹ)', (ctx) => Column(children: [
        ListTile(
          leading: const Icon(Icons.alarm_add, color: green),
          title: const Text('جمعہ کی یاد دہانی (ہر جمعہ الارم)'),
          subtitle: const Text('وقت چن کر فون کی الارم ایپ میں لگائیں'),
          onTap: () => _fridayAlarm(ctx),
        ),
        ListTile(
          leading: const Icon(Icons.notifications_active, color: green),
          title: const Text('اینڈرائیڈ نوٹیفیکیشن سیٹنگز کھولیں'),
          onTap: () async {
            final ok = await _intent('android.settings.APP_NOTIFICATION_SETTINGS', args: {'android.provider.extra.APP_PACKAGE': _pkg});
            if (!ok && ctx.mounted) toast(ctx, 'سیٹنگز نہیں کھل سکیں');
          },
        ),
      ]));

  void _sound(BuildContext c) => _sheet(c, 'آواز اور اذان', (ctx) => Column(children: [
        ListTile(
          leading: const Icon(Icons.volume_up, color: green),
          title: const Text('فون کی آواز کی سیٹنگز کھولیں'),
          subtitle: const Text('الارم، نوٹیفیکیشن اور رنگ ٹون کی آواز'),
          onTap: () async {
            final ok = await _intent('android.settings.SOUND_SETTINGS');
            if (!ok && ctx.mounted) toast(ctx, 'سیٹنگز نہیں کھل سکیں');
          },
        ),
        const Padding(
          padding: EdgeInsets.all(14),
          child: Text('الارم کی ٹون فون کی الارم ایپ سے منتخب ہوتی ہے۔', style: TextStyle(fontSize: 13)),
        ),
      ]));

  void _backup(BuildContext c) => _sheet(c, 'بیک اپ اور بحالی', (ctx) => Column(children: [
        ListTile(
          leading: const Icon(Icons.backup, color: green),
          title: const Text('بیک اپ کاپی کریں'),
          subtitle: const Text('سارا ریکارڈ متن کی صورت میں کاپی ہو گا، اسے کہیں محفوظ کر لیں'),
          onTap: () => copyText(ctx, exportData()),
        ),
        ListTile(
          leading: const Icon(Icons.restore, color: green),
          title: const Text('بیک اپ سے بحال کریں'),
          onTap: () {
            Navigator.pop(ctx);
            _restore(c);
          },
        ),
      ]));

  void _export(BuildContext c) => _sheet(c, 'ڈیٹا ایکسپورٹ', (ctx) => Column(children: [
        ListTile(
          leading: const Icon(Icons.summarize, color: green),
          title: const Text('رپورٹ کا خلاصہ کاپی کریں'),
          subtitle: const Text('پچھلے 30 دن اور جمعہ کا خلاصہ، کہیں بھی چسپاں کر سکتے ہیں'),
          onTap: () => copyText(ctx, _report()),
        ),
        ListTile(
          leading: const Icon(Icons.data_object, color: green),
          title: const Text('مکمل ڈیٹا کاپی کریں'),
          onTap: () => copyText(ctx, exportData()),
        ),
      ]));

  void _privacy(BuildContext c) => _sheet(c, 'رازداری اور سیکیورٹی', (ctx) => Column(children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Text('آپ کا سارا ریکارڈ اور پروفائل صرف آپ کے فون میں محفوظ رہتا ہے۔ ایپ کوئی ڈیٹا انٹرنیٹ پر نہیں بھیجتی۔ فون بدلتے وقت «بیک اپ» ضرور لے لیں۔', style: TextStyle(height: 1.8)),
        ),
        ListTile(
          leading: const Icon(Icons.delete_forever, color: Color(0xFFD32F2F)),
          title: const Text('تمام ڈیٹا حذف کریں'),
          onTap: () {
            Navigator.pop(ctx);
            _clearAll(c);
          },
        ),
      ]));

  void _city(BuildContext c) => pickCity(c);

  void _asr(BuildContext c) => _sheet(c, 'عصر کا وقت', (ctx) {
        final asr = getI('asr', 2);
        return Column(children: [
          ListTile(
            leading: Icon(asr == 2 ? Icons.radio_button_checked : Icons.radio_button_off, color: green),
            title: const Text('حنفی (دو مثل)'),
            onTap: () => setI('asr', 2),
          ),
          ListTile(
            leading: Icon(asr == 1 ? Icons.radio_button_checked : Icons.radio_button_off, color: green),
            title: const Text('شافعی / مالکی / حنبلی (ایک مثل)'),
            onTap: () => setI('asr', 1),
          ),
        ]);
      });

  void _ttmap(BuildContext c) => _sheet(c, 'نماز اوقات کا نقشہ (کوہاٹ)', (ctx) => Column(children: [
        for (var k = 0; k < 2; k++)
          ListTile(
            leading: Icon(ttMap() == k ? Icons.radio_button_checked : Icons.radio_button_off, color: green),
            title: Text(ttNames[k]),
            onTap: () => setI('ttmap', k),
          ),
      ]));

  void _hijri(BuildContext c) => _sheet(c, 'ہجری تاریخ ایڈجسٹ کریں', (ctx) {
        final adj = getI('hadj');
        return Padding(
          padding: const EdgeInsets.all(12),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(onPressed: adj > -2 ? () => setI('hadj', adj - 1) : null, icon: const Icon(Icons.remove_circle_outline, color: green, size: 34)),
            const SizedBox(width: 12),
            Text(adj > 0 ? '+$adj دن' : '$adj دن', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(width: 12),
            IconButton(onPressed: adj < 2 ? () => setI('hadj', adj + 1) : null, icon: const Icon(Icons.add_circle_outline, color: green, size: 34)),
          ]),
        );
      });

  void _font(BuildContext c) => _sheet(c, 'فونٹ', (ctx) => Column(children: [
        for (final f in appFonts)
          ListTile(
            leading: Icon(getS('font') == f[0] ? Icons.radio_button_checked : Icons.radio_button_off, color: green),
            title: Text(f[1]),
            subtitle: Text('بِسۡمِ اللّٰہِ الرَّحۡمٰنِ الرَّحِیۡمِ  •  نماز کی ریکارڈ', style: TextStyle(fontFamily: f[0].isEmpty ? null : f[0], fontSize: 20, height: 1.9)),
            onTap: () => setS('font', f[0]),
          ),
      ]));

  // ------------------------------------------------------------ UI
  Widget _card(BuildContext c, _Item it) => Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: it.onTap,
          child: Ink(
            height: 76,
            decoration: BoxDecoration(
              color: cardColor(c),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: isDark(c) ? Colors.white12 : green.withAlpha(60)),
              boxShadow: [BoxShadow(color: Colors.black.withAlpha(16), blurRadius: 5, offset: const Offset(0, 2))],
            ),
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(gradient: LinearGradient(colors: [it.c1, it.c2], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(12)),
                child: Icon(it.icon, color: Colors.white, size: 26),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(it.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Text(it.sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5, color: subText(c), height: 1.4)),
                  ]),
                ),
              ),
              const Icon(Icons.chevron_right, color: green),
            ]),
          ),
        ),
      );

  Widget _wide(BuildContext c, _Item it) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: _card(c, it),
      );

  Widget _profileCard(BuildContext c) {
    final n = profileName();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => go(c, const ProfileScreen()),
          child: Ink(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), Color(0xFF0B5D3B)]),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: gold, width: 1.6),
            ),
            child: Row(children: [
              const CircleAvatar(radius: 28, backgroundColor: Colors.white, backgroundImage: AssetImage('assets/logo.png')),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('پروفائل', style: TextStyle(color: Colors.white70, fontSize: 12)),
                  Text(n.isEmpty ? 'اپنا نام درج کریں' : n, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  const Text('نام اور دیگر معلومات لکھیں یا تبدیل کریں', style: TextStyle(color: Colors.white70, fontSize: 11)),
                ]),
              ),
              const Icon(Icons.edit, color: gold),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _banner() => Container(
        margin: const EdgeInsets.fromLTRB(10, 8, 10, 10),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF0E5A3A), _dark], begin: Alignment.topCenter, end: Alignment.bottomCenter),
          border: Border.all(color: gold, width: 1.6),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: const [
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.auto_awesome, color: gold, size: 18),
            SizedBox(width: 8),
            Icon(Icons.settings, color: Colors.white, size: 30),
            SizedBox(width: 8),
            Text('سیٹنگز', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(width: 8),
            Icon(Icons.auto_awesome, color: gold, size: 18),
          ]),
          SizedBox(height: 2),
          Text('اپنی پسند کے مطابق ایپ کو سیٹ کریں', style: TextStyle(color: Colors.white, fontSize: 13)),
        ]),
      );

  Widget _duaStrip() => Container(
        width: double.infinity,
        margin: const EdgeInsets.fromLTRB(24, 0, 24, 6),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        decoration: BoxDecoration(color: _dark, border: Border.all(color: gold.withAlpha(160)), borderRadius: BorderRadius.circular(16)),
        child: const FittedBox(
          fit: BoxFit.scaleDown,
          child: Text('اَللّٰهُمَّ اَعِنَّا عَلٰى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ', style: TextStyle(color: Colors.white, fontSize: 15)),
        ),
      );

  Widget _header(BuildContext c) {
    final top = MediaQuery.of(c).padding.top;
    final w = MediaQuery.of(c).size.width;
    final canPop = Navigator.of(c).canPop();
    return SizedBox(
      height: top + w * 0.27,
      child: Stack(fit: StackFit.expand, children: [
        Image.asset('assets/header.png', fit: BoxFit.cover, alignment: Alignment.bottomCenter),
        if (canPop || shellHome != null)
          Positioned(
            left: 12,
            top: top + 6,
            child: InkWell(
              onTap: () => canPop ? Navigator.of(c).pop() : shellHome?.call(),
              borderRadius: BorderRadius.circular(30),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(color: green.withAlpha(220), border: Border.all(color: const Color(0xFF55E0C0), width: 2), borderRadius: BorderRadius.circular(30)),
                child: const Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.arrow_back, color: Colors.white, size: 20),
                    SizedBox(width: 6),
                    Text('واپس', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                  ]),
                ),
              ),
            ),
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [
        _header(context),
        Expanded(
          child: Rebuild((c) {
            final city = currentCity();
            final asr = getI('asr', 2);
            final adj = getI('hadj');
            final dark = getB('dark');
            final fontName = appFonts.firstWhere((f) => f[0] == getS('font'), orElse: () => appFonts.first)[1];
            const blue = Color(0xFF1565C0);
            final grid = <_Item>[
              _Item('زبان', 'اردو (Default)', Icons.translate, const Color(0xFF2EAD4B), const Color(0xFF1B8A45), () => _language(c)),
              _Item('تھیم', dark ? 'ڈارک موڈ' : 'لائٹ موڈ', Icons.brightness_6, const Color(0xFFF59E0B), const Color(0xFF1E2A55), () => _theme(c)),
              _Item('نوٹیفیکیشن', 'یاد دہانی اور الرٹ کی سیٹنگ', Icons.notifications, const Color(0xFFEF4565), const Color(0xFFD81B3C), () => _notify(c)),
              _Item('آواز اور اذان', 'اذان، نوٹیفیکیشن ساؤنڈ', Icons.volume_up, const Color(0xFF8E3FD1), const Color(0xFF5B21B6), () => _sound(c)),
              _Item('بیک اپ اور بحالی', 'اپنا ڈیٹا محفوظ کریں', Icons.cloud_upload, const Color(0xFF2196F3), const Color(0xFF0D5BC0), () => _backup(c)),
              _Item('ڈیٹا ایکسپورٹ', 'رپورٹ کا خلاصہ کاپی کریں', Icons.upload, const Color(0xFF14A38B), const Color(0xFF0B7A66), () => _export(c)),
              _Item('رازداری اور سیکیورٹی', 'ڈیٹا کی حفاظت کے لیے سیٹنگ', Icons.verified_user, const Color(0xFFFFA726), const Color(0xFFF57C00), () => _privacy(c)),
              _Item('ایپ کے بارے میں', 'ورژن اور معلومات', Icons.info, const Color(0xFF1E5CD6), const Color(0xFF0A3A9A), () => go(c, const AboutScreen())),
              _Item('ایپ شیئر کریں', 'دوسروں کے ساتھ شیئر کریں', Icons.share, const Color(0xFF7C3AED), const Color(0xFF5B21B6), () => copyText(c, 'MSF Nimaz ki Record (ایم ایس ایف نماز کی ریکارڈ)\nنماز، قضا، نوافل، تسبیح اور دعاؤں کا مکمل ریکارڈ رکھنے والی اردو ایپ۔')),
              _Item('ریٹ کریں', 'اپنی رائے سے ہمیں آگاہ کریں', Icons.star, const Color(0xFFF43F5E), const Color(0xFFD81B60), () => _rate(c)),
              _Item('شہر', city.name, Icons.location_city, const Color(0xFF1B8A45), const Color(0xFF0D5C2C), () => _city(c)),
              _Item('عصر کا وقت', asr == 2 ? 'حنفی (دو مثل)' : 'شافعی (ایک مثل)', Icons.wb_cloudy, blue, const Color(0xFF0B3F8C), () => _asr(c)),
              _Item('نماز اوقات کا نقشہ', ttShort[ttMap()], Icons.schedule, const Color(0xFF9A5A2B), const Color(0xFF6B3A14), () => _ttmap(c)),
              _Item('ہجری تاریخ', adj == 0 ? 'کوئی تبدیلی نہیں' : (adj > 0 ? '+$adj دن' : '$adj دن'), Icons.calendar_month, const Color(0xFF1AA0B5), const Color(0xFF0F7788), () => _hijri(c)),
              _Item('ڈیمنز وال پیپر', 'لائیو وال پیپر: ہوم اور لاک', Icons.wallpaper, const Color(0xFF0E7C86), const Color(0xFF075760), () => go(c, const WallpaperScreen())),
              _Item('فونٹ', fontName, Icons.font_download, const Color(0xFFA81E52), const Color(0xFF741136), () => _font(c)),
            ];
            return ListView(padding: const EdgeInsets.fromLTRB(10, 0, 10, 10), children: [
              _banner(),
              _profileCard(c),
              Directionality(
                textDirection: TextDirection.ltr,
                child: LayoutBuilder(builder: (ctx, cons) {
                  final tw = (cons.maxWidth - 10) / 2;
                  return Wrap(spacing: 10, runSpacing: 10, children: [
                    for (final it in grid) SizedBox(width: tw, child: _card(c, it)),
                  ]);
                }),
              ),
              const SizedBox(height: 10),
              Directionality(
                textDirection: TextDirection.ltr,
                child: Column(children: [
                  _wide(c, _Item('ڈیٹا صاف کریں', 'تمام ڈیٹا حذف کریں', Icons.delete, const Color(0xFF757575), const Color(0xFF424242), () => _clearAll(c))),
                  _wide(c, _Item('لاگ آؤٹ', 'پروفائل سے باہر نکلیں', Icons.logout, const Color(0xFFF44336), const Color(0xFFC62828), () => _logout(c))),
                ]),
              ),
              _duaStrip(),
            ]);
          }),
        ),
      ]),
    );
  }
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final nameC = TextEditingController(text: getS('pf_name'));
  final fatherC = TextEditingController(text: getS('pf_father'));
  final phoneC = TextEditingController(text: getS('pf_phone'));
  final noteC = TextEditingController(text: getS('pf_note'));

  @override
  void dispose() {
    nameC.dispose();
    fatherC.dispose();
    phoneC.dispose();
    noteC.dispose();
    super.dispose();
  }

  void _save() {
    sp.setString('pf_name', nameC.text.trim());
    sp.setString('pf_father', fatherC.text.trim());
    sp.setString('pf_phone', phoneC.text.trim());
    sp.setString('pf_note', noteC.text.trim());
    bump();
    toast(context, 'پروفائل محفوظ ہو گئی ✓');
  }

  Widget _field(TextEditingController c, String label, IconData ic, {int lines = 1, TextInputType? type}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(controller: c, maxLines: lines, keyboardType: type, decoration: InputDecoration(labelText: label, prefixIcon: Icon(ic, color: green))),
      );

  @override
  Widget build(BuildContext context) => Screen(
        'پروفائل',
        ListView(padding: const EdgeInsets.all(12), children: [
          Center(
            child: ValueListenableBuilder<TextEditingValue>(
              valueListenable: nameC,
              builder: (c, v, _) => Container(
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: gold, width: 3)),
                child: const CircleAvatar(radius: 52, backgroundColor: Colors.white, backgroundImage: AssetImage('assets/logo.png')),
              ),
            ),
          ),
          const SizedBox(height: 16),
          box(
            context,
            child: Column(children: [
              _field(nameC, 'آپ کا نام', Icons.person),
              _field(fatherC, 'والد کا نام (اختیاری)', Icons.family_restroom),
              _field(phoneC, 'فون نمبر (اختیاری)', Icons.phone, type: TextInputType.phone),
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: InkWell(
                  onTap: () => pickCity(context).then((_) => setState(() {})),
                  child: InputDecorator(
                    decoration: const InputDecoration(labelText: 'شہر', prefixIcon: Icon(Icons.location_city, color: green)),
                    child: Text(currentCity().name),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              _field(noteC, 'اپنے بارے میں کچھ لکھیں (اختیاری)', Icons.edit_note, lines: 3),
            ]),
          ),
          Row(children: [
            Expanded(child: ElevatedButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('پروفائل محفوظ کریں'), style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)))),
          ]),
        ]),
      );
}

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  @override
  Widget build(BuildContext context) {
    const steps = [
      '«پانچ وقت کی نماز» میں ہر نماز پر ٹیپ کر کے ادا، با جماعت یا قضا کا نشان لگائیں۔',
      'قضا منتخب کرنے پر وہ خود «قضا نماز» کے ریکارڈ میں شامل ہو جاتی ہے۔',
      'نفل، تراویح، تہجد، جمعہ اور عیدین میں روزانہ (یا سالانہ) چیک لسٹ بھریں۔',
      'رپورٹس میں روزانہ، ہفتہ وار اور ماہانہ کارکردگی دیکھیں۔',
      'نماز کے اوقات اور قبلہ کے لیے سیٹنگز میں اپنا شہر منتخب کریں۔',
      'سارا ڈیٹا صرف آپ کے فون میں رہتا ہے۔ سیٹنگز سے بیک اپ لیتے رہیں۔',
    ];
    return Screen(
      'ایپ کے بارے میں',
      ListView(padding: const EdgeInsets.all(14), children: [
        Center(child: ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/header.png', width: 300, fit: BoxFit.cover))),
        const SizedBox(height: 14),
        const Center(child: Text('MSF Nimaz ki Record', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: green))),
        const Center(child: Text('ایم ایس ایف نماز کی ریکارڈ', style: TextStyle(fontSize: 17))),
        const SizedBox(height: 4),
        Center(child: Text('ورژن 2.7.0', style: TextStyle(color: subText(context)))),
        const SizedBox(height: 14),
        sectionTitle('مدد: ایپ کیسے استعمال کریں'),
        for (final s in steps)
          box(context, child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.check, color: green, size: 20), const SizedBox(width: 8), Expanded(child: Text(s, style: const TextStyle(height: 1.7)))])),
        Padding(padding: const EdgeInsets.all(8), child: Center(child: Text('اللہ ہمیں نماز کی پابندی کی توفیق عطا فرمائے۔ آمین', style: TextStyle(color: subText(context))))),
      ]),
    );
  }
}
