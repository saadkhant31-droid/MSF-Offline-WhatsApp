import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;
Color cardColor(BuildContext c) => isDark(c) ? const Color(0xFF1F2B25) : const Color(0xFFF4FAF5);
const Color green2 = Color(0xFF3DB45C);
VoidCallback? shellHome;
Color subText(BuildContext c) => isDark(c) ? Colors.white70 : Colors.black54;

class Screen extends StatelessWidget {
  final String title;
  final Widget child;
  final List<Widget>? actions;
  const Screen(this.title, this.child, {super.key, this.actions});

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    final w = MediaQuery.of(context).size.width;
    final canPop = Navigator.of(context).canPop();
    return Scaffold(
      body: Column(children: [
        SizedBox(
          height: top + w * 0.27,
          child: Stack(fit: StackFit.expand, children: [
            Image.asset('assets/header.png', fit: BoxFit.cover, alignment: Alignment.bottomCenter),
            Positioned(
              left: 12,
              top: top + 6,
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: Row(children: [
                  if (canPop || shellHome != null)
                    InkWell(
                      onTap: () => canPop ? Navigator.of(context).pop() : shellHome?.call(),
                      borderRadius: BorderRadius.circular(30),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                        decoration: BoxDecoration(
                          color: green.withAlpha(220),
                          border: Border.all(color: const Color(0xFF55E0C0), width: 2),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: const [
                          Icon(Icons.arrow_back, color: Colors.white, size: 20),
                          SizedBox(width: 6),
                          Text('واپس', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                        ]),
                      ),
                    ),
                  if (actions != null)
                    Theme(
                      data: Theme.of(context).copyWith(iconButtonTheme: IconButtonThemeData(style: IconButton.styleFrom(foregroundColor: Colors.white))),
                      child: Row(children: actions!),
                    ),
                ]),
              ),
            ),
            Positioned(
              right: 10,
              bottom: 6,
              child: Container(
                constraints: BoxConstraints(maxWidth: w * 0.42),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), green], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                  border: Border.all(color: gold, width: 2.5),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ]),
        ),
        Expanded(child: child),
      ]),
    );
  }
}

Widget box(BuildContext c, {required Widget child, EdgeInsets? padding, Color? color}) => Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: padding ?? const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color ?? cardColor(c),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: isDark(c) ? Colors.white12 : green.withAlpha(70), width: 1.2),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(18), blurRadius: 5, offset: const Offset(0, 2))],
      ),
      child: child,
    );

Widget sectionTitle(String t) => Container(
      margin: const EdgeInsets.fromLTRB(0, 6, 0, 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [green, green2]),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(children: [
        const Icon(Icons.mosque, color: Colors.white, size: 20),
        const SizedBox(width: 8),
        Expanded(child: Text(t, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white))),
      ]),
    );

class DateNav extends StatelessWidget {
  final String label;
  final VoidCallback onPrev, onNext;
  const DateNav({super.key, required this.label, required this.onPrev, required this.onNext});
  @override
  Widget build(BuildContext context) => box(
        context,
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Row(children: [
            IconButton(onPressed: onPrev, icon: const Icon(Icons.chevron_left, color: green, size: 30)),
            Expanded(
              child: Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            ),
            IconButton(onPressed: onNext, icon: const Icon(Icons.chevron_right, color: green, size: 30)),
          ]),
        ),
      );
}

void toast(BuildContext c, String m) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 2)));
}

Future<void> copyText(BuildContext c, String t) async {
  await Clipboard.setData(ClipboardData(text: t));
  if (c.mounted) toast(c, 'کاپی ہو گیا');
}

void go(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));

Future<bool> confirmDialog(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('نہیں')),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ہاں')),
      ],
    ),
  );
  return r ?? false;
}

Future<void> pickCity(BuildContext context) async {
  await showModalBottomSheet<void>(
    context: context,
    builder: (c) => SafeArea(
      child: ListView(children: [
        const Padding(
          padding: EdgeInsets.all(14),
          child: Text('اپنا شہر منتخب کریں', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        ),
        for (int i = 0; i < cities.length; i++)
          ListTile(
            title: Text(cities[i].name),
            trailing: getI('city') == i ? const Icon(Icons.check_circle, color: green) : null,
            onTap: () {
              setI('city', i);
              Navigator.pop(c);
            },
          ),
      ]),
    ),
  );
}

/// Image header with back pill (left) and title badge (right).
Widget appHeader(BuildContext c, String title, String sub, VoidCallback? onBack) {
  final top = MediaQuery.of(c).padding.top;
  final w = MediaQuery.of(c).size.width;
  return SizedBox(
    height: top + w * 0.30,
    child: Stack(fit: StackFit.expand, children: [
      Image.asset('assets/header.png', fit: BoxFit.cover, alignment: Alignment.bottomCenter),
      Positioned(
        left: 12,
        top: top + 6,
        child: InkWell(
          onTap: () => Navigator.of(c).canPop() ? Navigator.of(c).pop() : onBack?.call(),
          borderRadius: BorderRadius.circular(30),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            decoration: BoxDecoration(color: green.withAlpha(220), border: Border.all(color: const Color(0xFF55E0C0), width: 2), borderRadius: BorderRadius.circular(30)),
            child: const Directionality(
              textDirection: TextDirection.ltr,
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.arrow_back, color: Colors.white, size: 20),
                SizedBox(width: 6),
                Text('واپس', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
              ]),
            ),
          ),
        ),
      ),
      Positioned(
        right: 8,
        bottom: 6,
        child: Container(
          constraints: BoxConstraints(maxWidth: w * 0.45),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), green], begin: Alignment.topCenter, end: Alignment.bottomCenter),
            border: Border.all(color: gold, width: 2.5),
            borderRadius: BorderRadius.circular(22),
          ),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, height: 1.1)),
              if (sub.isNotEmpty) Text(sub, style: const TextStyle(color: Colors.white70, fontSize: 11)),
            ]),
          ),
        ),
      ),
    ]),
  );
}
