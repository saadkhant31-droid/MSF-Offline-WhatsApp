import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'prayers.dart';
import 'checklist.dart';
import 'qaza.dart';
import 'nafl.dart';
import 'taraweeh.dart';
import 'tahajjud.dart';
import 'reports.dart';
import 'qibla.dart';
import 'calendar.dart';
import 'duas.dart';
import 'tasbeeh.dart';
import 'jumah.dart';
import 'eidain.dart';
import 'settings.dart';
import 'timetable.dart';
import 'wallpaper.dart';

class Feature {
  final String title, sub;
  final IconData icon;
  final Color c1, c2;
  final Widget Function() page;
  Feature(this.title, this.sub, this.icon, this.c1, this.c2, this.page);
}

List<Feature> allFeatures() => [
      Feature('پانچ وقت کی نماز', 'تمام نمازوں کا مکمل ریکارڈ', Icons.mosque, const Color(0xFF1B8A45), const Color(0xFF0D5C2C), () => const PrayersScreen()),
      Feature('قضا نماز', 'وجہ، وقت اور تفصیل کے ساتھ', Icons.fact_check, const Color(0xFF1565C0), const Color(0xFF0B3F8C), () => const QazaScreen()),
      Feature('نفل نمازیں', 'تمام نوافل کا ریکارڈ', Icons.back_hand, const Color(0xFF8E24AA), const Color(0xFF5E1578), () => const NaflScreen()),
      Feature('تراویح', '20 رکعت کا مکمل ریکارڈ', Icons.mosque_outlined, const Color(0xFF136B4B), const Color(0xFF0A4733), () => const TaraweehScreen()),
      Feature('تہجد', 'رات کی نماز کا ریکارڈ', Icons.self_improvement, const Color(0xFF9A5A2B), const Color(0xFF6B3A14), () => const TahajjudScreen()),
      Feature(
        'جمعہ کی نماز',
        'سنت، فرض اور نوافل',
        Icons.mosque,
        const Color(0xFF1456A8),
        const Color(0xFF0A3470),
        () => const JumahScreen(),
      ),
      Feature(
        'عیدین کی نماز',
        'عید الفطر اور عید الاضحیٰ',
        Icons.celebration,
        const Color(0xFFD81B60),
        const Color(0xFF9C1048),
        () => const EidainScreen(),
      ),
      Feature('قبلہ', 'سمت معلوم کریں', Icons.explore, const Color(0xFF1B6B2E), const Color(0xFF0F4A1F), () => const QiblaScreen()),
      Feature('اسلامی کیلنڈر', 'ہجری اور اسلامی تاریخیں', Icons.calendar_month, const Color(0xFF1AA0B5), const Color(0xFF0F7788), () => const CalendarScreen()),
      Feature('نماز کی رپورٹس', 'روزانہ، ہفتہ وار، ماہانہ', Icons.summarize, const Color(0xFFEF7D12), const Color(0xFFC25A05), () => const ReportScreen()),
      Feature('قضا نمازوں کی رپورٹ', 'باقی قضا نمازوں کا حساب', Icons.bar_chart, const Color(0xFF4A3BC0), const Color(0xFF2F2490), () => const QazaReportScreen()),
      Feature('سیٹنگز', 'شہر، تھیم، بیک اپ وغیرہ', Icons.settings, const Color(0xFF6E8E2A), const Color(0xFF4A641A), () => const SettingsScreen()),
      Feature('دعائیں', 'روزمرہ کی اہم دعائیں', Icons.menu_book, const Color(0xFFA81E52), const Color(0xFF741136), () => const DuasScreen()),
      Feature('تسبیح کاؤنٹر', 'ڈیجیٹل تسبیح', Icons.blur_circular, const Color(0xFF1296A8), const Color(0xFF0B6877), () => const TasbeehScreen()),
      Feature('ڈیمنز وال پیپر', 'لائیو وال پیپر: ہوم اور لاک اسکرین', Icons.wallpaper, const Color(0xFF0E7C86), const Color(0xFF075760), () => const WallpaperScreen()),
      Feature('ایپ کے بارے میں', 'ورژن اور مدد', Icons.info, const Color(0xFF5B7289), const Color(0xFF3E5063), () => const AboutScreen()),
    ];

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int idx = 0;
  late final List<Feature> features = allFeatures();

  @override
  void initState() {
    super.initState();
    shellHome = () => setState(() => idx = 0);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: idx == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) setState(() => idx = 0);
      },
      child: Scaffold(
        body: IndexedStack(index: idx, children: [
          HomePage(features: features, onMenu: () => setState(() => idx = 6), onSettings: () => setState(() => idx = 5)),
          const PrayersScreen(),
          JumahScreen(onBack: () => setState(() => idx = 0)),
          const TaraweehScreen(),
          const TahajjudScreen(),
          const SettingsScreen(),
          MorePage(features: features),
        ]),
        bottomNavigationBar: _nav(context),
      ),
    );
  }

  bool get _home => idx == 0;

  void _tapNav(BuildContext context, int i) {
    if (!_home) {
      setState(() => idx = i);
      return;
    }
    switch (i) {
      case 1:
        go(context, const DuasScreen());
        break;
      case 2:
        go(context, const CalendarScreen());
        break;
      case 3:
        go(context, const QiblaScreen());
        break;
      case 4:
        setState(() => idx = 5);
        break;
      case 5:
        setState(() => idx = 6);
        break;
    }
  }

  Widget _nav(BuildContext context) {
    final items = _home
        ? const [
            [Icons.home, 'ہوم'],
            [Icons.menu_book, 'دعائیں'],
            [Icons.calendar_month, 'تاریخ'],
            [Icons.explore, 'قبلہ'],
            [Icons.settings, 'سیٹنگز'],
            [Icons.menu, 'مزید'],
          ]
        : const [
            [Icons.home, 'ہوم'],
            [Icons.mosque, 'نمازیں'],
            [Icons.account_balance, 'جمعہ'],
            [Icons.nightlight_round, 'تراویح'],
            [Icons.self_improvement, 'تہجد'],
            [Icons.settings, 'سیٹنگز'],
            [Icons.menu, 'مزید'],
          ];
    final act = _home ? 0 : idx;
    const glow = Color(0xFF3DDC84);
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0E5A3A), Color(0xFF06291B)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        border: Border(top: BorderSide(color: gold.withAlpha(140), width: 1.5)),
      ),
      padding: EdgeInsets.fromLTRB(4, 6, 4, 6 + MediaQuery.of(context).padding.bottom),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          for (int i = 0; i < items.length; i++) ...[
            if (i > 0) Container(width: 1, height: 34, color: Colors.white24),
            Expanded(
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => _tapNav(context, i),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: act == i ? Colors.white10 : null,
                    border: Border.all(color: act == i ? glow : Colors.transparent, width: 2),
                    boxShadow: act == i ? [BoxShadow(color: glow.withAlpha(90), blurRadius: 8)] : null,
                  ),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(items[i][0] as IconData, color: act == i ? gold : Colors.white, size: 22),
                    const SizedBox(height: 2),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(items[i][1] as String, style: TextStyle(color: act == i ? gold : Colors.white, fontSize: 10.5, fontWeight: FontWeight.bold)),
                    ),
                  ]),
                ),
              ),
            ),
          ],
        ]),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final List<Feature> features;
  final VoidCallback? onMenu, onSettings;
  const HomePage({super.key, required this.features, this.onMenu, this.onSettings});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DateTime now = DateTime.now();
  Timer? timer;
  int mode = 0;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (mounted) setState(() => now = DateTime.now());
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Widget _circleBtn(IconData ic, VoidCallback? f) => InkWell(
        onTap: f,
        customBorder: const CircleBorder(),
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(color: const Color(0xFF0B3D2A).withAlpha(225), shape: BoxShape.circle, border: Border.all(color: const Color(0xFF55E0C0), width: 2)),
          child: Icon(ic, color: Colors.white, size: 24),
        ),
      );

  Widget _header(BuildContext c) {
    final top = MediaQuery.of(c).padding.top;
    final w = MediaQuery.of(c).size.width;
    return SizedBox(
      width: double.infinity,
      height: top + w * 312 / 1024,
      child: Stack(fit: StackFit.expand, children: [
        Image.asset('assets/header.png', fit: BoxFit.cover, alignment: Alignment.bottomCenter),
        Positioned(left: 12, top: top + 8, child: _circleBtn(Icons.menu, widget.onMenu)),
        Positioned(right: 12, top: top + 8, child: _circleBtn(Icons.settings, widget.onSettings)),
        Positioned(
          bottom: 6,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 4),
              decoration: BoxDecoration(color: const Color(0xFF0B3D2A).withAlpha(230), border: Border.all(color: gold, width: 1.6), borderRadius: BorderRadius.circular(18)),
              child: const Text('نماز ہی کامیابی ہے', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _mapCard(BuildContext c, int k, String title, String sub, Color c1, Color c2, IconData ic) {
    final sel = ttMap() == k;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          setI('ttmap', k);
          setState(() => mode = k);
          toast(c, '$title منتخب ہو گیا');
        },
        child: Container(
          height: 92,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [c1, c2], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: sel ? gold : Colors.transparent, width: 2),
          ),
          child: Row(children: [
            Icon(ic, color: Colors.white, size: 44),
            const SizedBox(width: 6),
            Expanded(
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  FittedBox(fit: BoxFit.scaleDown, child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold))),
                  Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 10.5, height: 1.4)),
                ]),
              ),
            ),
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(color: const Color(0xFF0B3D2A), shape: BoxShape.circle, border: Border.all(color: Colors.white54)),
              child: Icon(sel ? Icons.check : Icons.chevron_right, color: Colors.white, size: 18),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _infoCell(BuildContext c, IconData ic, String title, String value, VoidCallback onTap) => Expanded(
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
            child: Row(children: [
              Icon(ic, color: green, size: 32),
              const SizedBox(width: 4),
              Expanded(
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    FittedBox(fit: BoxFit.scaleDown, child: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold))),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(value, style: TextStyle(fontSize: 11, color: subText(c)))),
                  ]),
                ),
              ),
            ]),
          ),
        ),
      );

  Widget _info(BuildContext c) {
    final div = Container(width: 1, height: 44, color: Colors.grey.withAlpha(90));
    return Container(
      margin: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      decoration: BoxDecoration(
        color: cardColor(c),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: green.withAlpha(90), width: 1.2),
      ),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          _infoCell(c, Icons.location_on, currentCity().name, 'موجودہ مقام', () => pickCity(c)),
          div,
          _infoCell(c, Icons.calendar_month, '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}', hijriText(now), () => go(c, const CalendarScreen())),
          div,
          _infoCell(c, Icons.mosque, 'اسلامی کیلنڈر', hijriText(now), () => go(c, const CalendarScreen())),
        ]),
      ),
    );
  }

  Widget _toggle(String t, String sub, IconData ic, int k) {
    final sel = mode == k;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => setState(() => mode = k),
        child: Container(
          height: 64,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: sel ? const Color(0xFF0B4A32) : const Color(0xFFDDEFE3),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: sel ? gold : green.withAlpha(60), width: sel ? 2 : 1),
          ),
          child: Row(children: [
            Icon(ic, color: sel ? Colors.white : const Color(0xFF0B3D2A), size: 34),
            const SizedBox(width: 6),
            Expanded(
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  FittedBox(fit: BoxFit.scaleDown, child: Text(t, style: TextStyle(color: sel ? Colors.white : const Color(0xFF0B3D2A), fontSize: 16, fontWeight: FontWeight.bold))),
                  FittedBox(fit: BoxFit.scaleDown, child: Text(sub, style: TextStyle(color: sel ? Colors.white70 : Colors.black54, fontSize: 11))),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _time(BuildContext c, String name, DateTime t, String sub, IconData ic, Color col, VoidCallback onTap) {
    final dark = isDark(c);
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            height: 118,
            padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
            decoration: BoxDecoration(color: col.withAlpha(dark ? 45 : 26), borderRadius: BorderRadius.circular(14), border: Border.all(color: col.withAlpha(120))),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(ic, color: col, size: 28),
              const SizedBox(height: 2),
              FittedBox(fit: BoxFit.scaleDown, child: Text(name, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: dark ? Colors.white : Colors.black87))),
              FittedBox(fit: BoxFit.scaleDown, child: Text(p12(t), style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: col))),
              const SizedBox(height: 2),
              FittedBox(fit: BoxFit.scaleDown, child: Text('($sub)', style: TextStyle(fontSize: 9, color: col))),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _times(BuildContext c) {
    final t = dayTimes(now);
    final asr1 = dayTimes(now, hanafi: false).asr;
    final asr2 = dayTimes(now, hanafi: true).asr;
    final taraweeh = t.isha.add(const Duration(minutes: 85));
    void prayers() => shellGoPrayers(c);
    void tar() => go(c, const TaraweehScreen());
    final fajr = _time(c, 'فجر', t.fajr, 'صبح کی نماز', Icons.mosque, const Color(0xFF1B8A5A), prayers);
    final sunrise = _time(c, 'طلوع', t.sunrise, 'سورج نکلنے کا وقت', Icons.wb_twilight, const Color(0xFF5E35B1), prayers);
    final zuhr = _time(c, 'ظہر', t.zuhr, 'دوپہر کی نماز', Icons.wb_sunny, const Color(0xFFF2A100), prayers);
    final a1 = _time(c, 'عصر اول', asr1, 'عصر کی پہلی نماز', Icons.wb_cloudy, const Color(0xFFEF7D12), prayers);
    final a2 = _time(c, 'عصر ثانی', asr2, 'عصر کی دوسری نماز', Icons.wb_cloudy, const Color(0xFFE64A19), prayers);
    final mag = _time(c, 'مغرب', t.maghrib, 'مغرب کی نماز', Icons.brightness_4, const Color(0xFFD81B60), prayers);
    final isha = _time(c, 'عشاء', t.isha, 'عشاء کی نماز', Icons.nightlight_round, const Color(0xFF5B2A9E), prayers);
    final tar1 = _time(c, 'تراویح', taraweeh, 'تراویح کا اندازاً وقت', Icons.dark_mode, const Color(0xFF1976D2), tar);
    final sehri = _time(c, 'سحر', t.sehri, 'سحر کا وقت', Icons.wb_twilight, const Color(0xFF1565C0), () => setState(() => mode = 1));
    final iftar = _time(c, 'افطار', t.maghrib, 'افطار کا وقت', Icons.restaurant, const Color(0xFF1B8A45), () => setState(() => mode = 1));
    final chasht = _time(c, 'چاشت', t.chasht, 'چاشت کا وقت', Icons.light_mode, const Color(0xFF1E88E5), prayers);
    final ishraq = _time(c, 'اشراق', t.ishraq, 'اشراق کا وقت', Icons.wb_sunny_outlined, const Color(0xFF4527A0), prayers);
    Widget row(List<Widget> l) => Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 8), child: Row(children: l));
    return Directionality(
      textDirection: TextDirection.ltr,
      child: mode == 0
          ? Column(children: [
              row([sunrise, fajr, zuhr, a1, a2, mag]),
              row([isha, tar1, sehri, iftar, chasht, ishraq]),
            ])
          : Column(children: [
              row([sehri, iftar, tar1]),
              row([fajr, mag, isha]),
            ]),
    );
  }

  Widget _quote() => Stack(alignment: Alignment.center, children: [
        Image.asset('assets/footer.png', width: double.infinity, height: 80, fit: BoxFit.cover),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 28),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(color: const Color(0xFF0B3D2A).withAlpha(235), border: Border.all(color: gold.withAlpha(170)), borderRadius: BorderRadius.circular(18)),
          child: const FittedBox(fit: BoxFit.scaleDown, child: Text('اللہ کے قریب ہونے کا آسان راستہ نماز ہے', style: TextStyle(color: Colors.white, fontSize: 14))),
        ),
      ]);

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
      child: SingleChildScrollView(
        child: Rebuild((c) => Column(children: [
              _header(c),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(children: [
                    _mapCard(c, 0, 'کوہاٹ کا متفقہ نقشہ', 'نماز کا کوہاٹ متفقہ نقشہ', const Color(0xFF1B7F6A), const Color(0xFF0B4A3F), Icons.map),
                    const SizedBox(width: 8),
                    _mapCard(c, 1, 'سحر و افطار کا متفقہ نقشہ', 'کوہاٹ کا سحر و افطار متفقہ نقشہ', const Color(0xFF1F4A8C), const Color(0xFF0E2A5C), Icons.restaurant),
                  ]),
                ),
              ),
              _info(c),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(children: [
                    _toggle('نماز کے اوقات', '(قاعدہ اوقات)', Icons.mosque, 0),
                    const SizedBox(width: 8),
                    _toggle('سحر و افطار اوقات', '(رمضان المبارک)', Icons.restaurant_menu, 1),
                  ]),
                ),
              ),
              _times(c),
              _quote(),
            ])),
      ),
    );
  }
}

/// Opens the five-prayer screen (used by the home time tiles).
void shellGoPrayers(BuildContext c) => go(c, const PrayersScreen());

class ListPage extends StatelessWidget {
  final List<Feature> features;
  const ListPage({super.key, required this.features});
  @override
  Widget build(BuildContext context) => Screen(
        'فہرست',
        ListView(padding: const EdgeInsets.all(10), children: [
          for (final f in features)
            InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => go(context, f.page()),
              child: box(
                context,
                child: Row(children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(gradient: LinearGradient(colors: [f.c1, f.c2]), borderRadius: BorderRadius.circular(12)),
                    child: Icon(f.icon, color: Colors.white),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(f.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      Text(f.sub, style: TextStyle(fontSize: 12, color: subText(context))),
                    ]),
                  ),
                  const Icon(Icons.chevron_left),
                ]),
              ),
            ),
        ]),
      );
}

class MorePage extends StatelessWidget {
  final List<Feature> features;
  const MorePage({super.key, required this.features});

  @override
  Widget build(BuildContext context) {
    // دعائیں, تسبیح, قبلہ, کیلنڈر, قضا رپورٹ, ایپ کے بارے میں
    final picks = features;
    return Screen(
      'مزید',
      ListView(padding: const EdgeInsets.all(10), children: [
        for (final f in picks)
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => go(context, f.page()),
            child: box(
              context,
              child: Row(children: [
                Icon(f.icon, color: green, size: 28),
                const SizedBox(width: 14),
                Expanded(child: Text(f.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                const Icon(Icons.chevron_left),
              ]),
            ),
          ),
        InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => copyText(context, 'MSF Nimaz ki Record (ایم ایس ایف نماز کی ریکارڈ)\nنماز، قضا، نوافل، تسبیح اور دعاؤں کا مکمل ریکارڈ رکھنے والی اردو ایپ۔'),
          child: box(
            context,
            child: const Row(children: [
              Icon(Icons.share, color: green, size: 28),
              SizedBox(width: 14),
              Expanded(child: Text('ایپ شیئر کریں', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
            ]),
          ),
        ),
      ]),
    );
  }
}
