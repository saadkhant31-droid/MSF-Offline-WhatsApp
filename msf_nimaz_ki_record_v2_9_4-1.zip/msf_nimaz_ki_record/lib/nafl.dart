import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';

const _bannerGreen = Color(0xFF0E5B37);
const _red = Color(0xFFD32F2F);

class _NI {
  final String id, name, sub, label;
  final List<int> opts;
  final IconData icon;
  final Color color;
  final bool custom;
  const _NI(this.id, this.name, this.sub, this.label, this.opts, this.icon, this.color, {this.custom = false});
}

const _std = <_NI>[
  _NI('0', 'تہجد', 'یا حسب استطاعت', '2 سے 12', [2, 4, 6, 8, 10, 12], Icons.mosque, Color(0xFF1E2A78)),
  _NI('1', 'اشراق', '', '4 یا 2', [2, 4], Icons.wb_sunny, Color(0xFFF2A413)),
  _NI('2', 'چاشت (ضحیٰ)', '', '2، 4 یا 8', [2, 4, 8], Icons.light_mode, Color(0xFFF59E0B)),
  _NI('3', 'اوابین', '', '6', [6], Icons.mosque, Color(0xFF6D28D9)),
  _NI('4', 'تحیۃ المسجد', '', '2', [2], Icons.mosque, Color(0xFF1B7F45)),
  _NI('5', 'وضو کے نفل', '', '2', [2], Icons.water_drop, Color(0xFFE11D48)),
  _NI('6', 'تحیۃ الوضوء', '', '2', [2], Icons.back_hand, Color(0xFF0F9D8A)),
  _NI('7', 'صلاۃ التوبہ', '', '2', [2], Icons.self_improvement, Color(0xFF7C3AED)),
  _NI('8', 'صلاۃ الحاجت', '', '2', [2], Icons.pan_tool, Color(0xFFE11D48)),
  _NI('9', 'صلاۃ الاستخارۃ', '', '2', [2], Icons.blur_circular, Color(0xFF1D4ED8)),
  _NI('10', 'صلاۃ التسبیح', '', '4', [4], Icons.blur_circular, Color(0xFF16A34A)),
  _NI('11', 'تہجد کے بعد وتر', 'اگر پہلے نہ پڑھے ہوں', '1 یا 3', [1, 3], Icons.nightlight_round, Color(0xFF7E22CE)),
  _NI('12', 'مغرب کے بعد نفل', '', '2', [2], Icons.wb_twilight, Color(0xFFEA580C)),
  _NI('13', 'عشاء کے بعد نفل', '', '2', [2], Icons.nightlight_round, Color(0xFF1D4ED8)),
  _NI('14', 'فجر سے پہلے سنتیں', '', '2', [2], Icons.mosque, Color(0xFF16A34A)),
  _NI('15', 'ظہر سے پہلے سنتیں', '', '4', [4], Icons.mosque, Color(0xFF7C3AED)),
  _NI('16', 'ظہر کے بعد سنتیں', '', '2', [2], Icons.light_mode, Color(0xFF0E9AA7)),
  _NI('17', 'عصر سے پہلے نفل', '', '4', [4], Icons.wb_sunny, Color(0xFFDB2777)),
  _NI('18', 'مغرب سے پہلے نفل', '', '2', [2], Icons.wb_twilight, Color(0xFF65A30D)),
  _NI('19', 'عشاء سے پہلے نفل', '', '4', [4], Icons.nightlight_round, Color(0xFF1D4ED8)),
];

// ------------------------------------------------------------------ data helpers
String _key(DateTime d, String id) => 'nk|${dayKey(d)}|$id';
int _val(DateTime d, String id) => getI(_key(d, id));

List<_NI> _customItems() {
  final s = getS('nafl_custom');
  if (s.isEmpty) return [];
  try {
    return (jsonDecode(s) as List).map((e) {
      final m = Map<String, dynamic>.from(e as Map);
      final r = (m['r'] as int?) ?? 2;
      return _NI(m['id'] as String, m['n'] as String, '', '$r', [r], Icons.add_circle, const Color(0xFF0F766E), custom: true);
    }).toList();
  } catch (_) {
    return [];
  }
}

List<_NI> _allItems() => [..._std, ..._customItems()];

int _dayTotal(DateTime d, List<_NI> items) {
  var t = 0;
  for (final it in items) {
    t += _val(d, it.id);
  }
  return t;
}

int _timesDone(String id) => sp.getKeys().where((k) => k.startsWith('nk|') && k.endsWith('|$id') && (sp.getInt(k) ?? 0) > 0).length;

// ------------------------------------------------------------------ main screen
class NaflScreen extends StatefulWidget {
  const NaflScreen({super.key});
  @override
  State<NaflScreen> createState() => _NaflState();
}

class _NaflState extends State<NaflScreen> {
  DateTime date = dayOnly(DateTime.now());
  final totalKey = GlobalKey();

  void _move(int dir) {
    final nd = addDays(date, dir);
    if (nd.isAfter(dayOnly(DateTime.now()))) return;
    setState(() => date = nd);
  }

  void _setVal(String id, int v) {
    if (v <= 0) {
      del(_key(date, id));
    } else {
      setI(_key(date, id), v);
    }
  }

  // ---------------------------------------------------------------- build
  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
        child: Scaffold(
          backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
          body: Rebuild((c) => _body(c)),
        ),
      );

  Widget _body(BuildContext c) {
    final items = _allItems();
    final customs = items.where((e) => e.custom).toList();
    return ListView(padding: EdgeInsets.zero, children: [
      _header(c),
      Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
        child: Column(children: [
          _title(c),
          DateNav(label: '${fmtDate(date)}\n${hijriText(date)}', onPrev: () => _move(-1), onNext: () => _move(1)),
          _grid(c, _std, 1),
          if (customs.isNotEmpty) ...[
            const Padding(
              padding: EdgeInsets.fromLTRB(4, 2, 4, 6),
              child: Align(alignment: AlignmentDirectional.centerStart, child: Text('میری شامل کردہ نفل نمازیں (حذف کے لیے دیر تک دبائیں)', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: green))),
            ),
            _grid(c, customs, 22),
          ],
          _taraweeh(c),
          _notes(c),
          _totalSection(c, items),
          _features(c),
          _quote(c),
          SizedBox(height: MediaQuery.of(c).padding.bottom + 10),
        ]),
      ),
    ]);
  }

  Widget _header(BuildContext c) {
    final top = MediaQuery.of(c).padding.top;
    final w = MediaQuery.of(c).size.width;
    return SizedBox(
      width: w,
      height: top + w * 201 / 1024,
      child: Stack(children: [
        Positioned.fill(child: Image.asset('assets/nafl/header.png', fit: BoxFit.cover, alignment: Alignment.bottomCenter)),
        Positioned(
          left: 8,
          top: top + 4,
          child: Material(
            color: Colors.black.withAlpha(90),
            shape: const CircleBorder(side: BorderSide(color: Color(0xFF6FE3C6), width: 1.4)),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: () => Navigator.maybePop(c),
              child: const Padding(padding: EdgeInsets.all(7), child: Icon(Icons.arrow_back, color: Colors.white, size: 20)),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _title(BuildContext c) => Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF0B4D2E), Color(0xFF14804A)]),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: gold.withAlpha(150)),
          ),
          child: const FittedBox(fit: BoxFit.scaleDown, child: Text('نفل نمازوں کے نام اور کل رکعتوں کی تعداد', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold))),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          child: Text('آپ کی MSF نماز ریکارڈ ایپ کی نفل نمازوں کے لیے فہرست، ہر نماز کی رکعتیں اور روزانہ کل رکعتوں کا حساب درج ذیل ہے۔ نماز پر ٹیپ کر کے آج کا ریکارڈ درج کریں۔', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: subText(c), height: 1.6)),
        ),
      ]);

  // ---------------------------------------------------------------- grid
  Widget _grid(BuildContext c, List<_NI> list, int startNum) {
    final rows = <Widget>[];
    for (int i = 0; i < list.length; i += 5) {
      rows.add(Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: Row(children: [
          for (int k = 0; k < 5; k++) ...[
            if (k > 0) const SizedBox(width: 5),
            Expanded(child: i + k < list.length ? _card(c, list[i + k], startNum + i + k) : const SizedBox()),
          ],
        ]),
      ));
    }
    return Column(children: rows);
  }

  Widget _card(BuildContext c, _NI it, int num) {
    final v = _val(date, it.id);
    final done = v > 0;
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => _open(it, num),
      onLongPress: it.custom ? () => _deleteCustom(it) : null,
      child: Container(
        height: 122,
        decoration: BoxDecoration(
          color: Color.alphaBlend(it.color.withAlpha(20), cardColor(c)),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: done ? green : it.color.withAlpha(70), width: done ? 2 : 1),
        ),
        child: Stack(children: [
          Positioned(
            top: 3,
            right: 3,
            child: Container(
              width: 18,
              height: 18,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: it.color, shape: BoxShape.circle),
              child: Text('$num', style: const TextStyle(color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.bold)),
            ),
          ),
          if (done) const Positioned(top: 3, left: 3, child: Icon(Icons.check_circle, size: 17, color: green)),
          Padding(
            padding: const EdgeInsets.fromLTRB(3, 18, 3, 5),
            child: Column(children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(color: it.color, shape: BoxShape.circle),
                child: Icon(it.icon, color: Colors.white, size: 20),
              ),
              Expanded(
                child: Center(
                  child: Text(it.name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, height: 1.2)),
                ),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 3),
                decoration: BoxDecoration(color: (done ? green : it.color).withAlpha(40), borderRadius: BorderRadius.circular(8)),
                child: FittedBox(fit: BoxFit.scaleDown, child: Text(done ? '✓ $v' : it.label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: done ? green : null))),
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  // ---------------------------------------------------------------- item sheet
  void _open(_NI it, int num) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: Rebuild((c) {
          final v = _val(date, it.id);
          return Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(color: it.color, shape: BoxShape.circle),
                  child: Icon(it.icon, color: Colors.white, size: 26),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(it.name, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                    Text('رکعات: ${it.label}${it.sub.isNotEmpty ? '  •  ${it.sub}' : ''}', style: TextStyle(fontSize: 12.5, color: subText(c))),
                  ]),
                ),
              ]),
              const SizedBox(height: 10),
              Text(fmtDate(date), style: TextStyle(fontSize: 12, color: subText(c))),
              const SizedBox(height: 10),
              if (it.opts.length > 1) ...[
                const Text('کتنی رکعات پڑھیں؟', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Wrap(spacing: 8, runSpacing: 4, children: [
                  for (final n in it.opts) ChoiceChip(label: Text('$n'), selected: v == n, onSelected: (_) => _setVal(it.id, v == n ? 0 : n)),
                ]),
              ] else
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: v > 0 ? Colors.grey : green),
                    onPressed: () => _setVal(it.id, v > 0 ? 0 : it.opts.first),
                    icon: Icon(v > 0 ? Icons.undo : Icons.check),
                    label: Text(v > 0 ? 'واپس (ادا نہیں کی)' : 'ادا کر لی'),
                  ),
                ),
              const SizedBox(height: 10),
              Text('کل ریکارڈ: ${_timesDone(it.id)} بار', style: const TextStyle(fontSize: 12.5, color: green, fontWeight: FontWeight.bold)),
              if (it.custom)
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: TextButton.icon(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _deleteCustom(it);
                    },
                    icon: const Icon(Icons.delete_outline, color: _red),
                    label: const Text('یہ نماز حذف کریں', style: TextStyle(color: _red)),
                  ),
                ),
            ]),
          );
        }),
      ),
    );
  }

  // ---------------------------------------------------------------- taraweeh
  Widget _stepper(int v, VoidCallback minus, VoidCallback plus) => Row(mainAxisSize: MainAxisSize.min, children: [
        InkWell(onTap: minus, child: const Icon(Icons.remove_circle_outline, color: _red, size: 24)),
        SizedBox(width: 34, child: Text('$v', textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
        InkWell(onTap: plus, child: const Icon(Icons.add_circle_outline, color: green, size: 24)),
      ]);

  Widget _taraweeh(BuildContext c) {
    final tar = clampI(_val(date, 'tar'), 0, 20);
    final para = clampI(_val(date, 'para'), 0, 30);
    const col = Color(0xFF6D28D9);
    return Container(
      margin: const EdgeInsets.only(top: 3, bottom: 8),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Color.alphaBlend(col.withAlpha(18), cardColor(c)),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: col.withAlpha(80)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
        Column(children: [
          Container(
            width: 20,
            height: 20,
            alignment: Alignment.center,
            decoration: const BoxDecoration(color: col, shape: BoxShape.circle),
            child: const Text('21', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 4),
          Container(
            width: 46,
            height: 46,
            decoration: const BoxDecoration(color: col, shape: BoxShape.circle),
            child: const Icon(Icons.mosque, color: Colors.white, size: 26),
          ),
          const SizedBox(height: 4),
          const Text('تراویح', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
          const Text('کل رکعتیں: 20', style: TextStyle(fontSize: 10.5)),
        ]),
        const SizedBox(width: 10),
        Expanded(
          child: Column(children: [
            Row(children: [
              Expanded(child: Text('پڑھی گئی رکعتیں', style: TextStyle(fontSize: 11, color: subText(c)))),
              _stepper(tar, () => _setVal('tar', tar >= 2 ? tar - 2 : 0), () => _setVal('tar', tar <= 18 ? tar + 2 : 20)),
            ]),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text('باقی رکعتیں: ${20 - tar}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: _red)),
            ),
            const Divider(height: 14),
            Row(children: [
              Expanded(child: Text('قرآن مکمل: پارہ', style: TextStyle(fontSize: 11, color: subText(c)))),
              _stepper(para, () => _setVal('para', para > 0 ? para - 1 : 0), () => _setVal('para', para < 30 ? para + 1 : 30)),
            ]),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(para >= 30 ? 'ماشاءاللہ، قرآن مکمل ہوا' : '$para / 30 پارے', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: green)),
            ),
          ]),
        ),
      ]),
    );
  }

  // ---------------------------------------------------------------- notes
  Widget _notes(BuildContext c) {
    const lines = [
      'اس فہرست میں نفل، سنت اور وتر کو الگ الگ درج کیا گیا ہے۔',
      'بعض نمازوں کی رکعتوں کی تعداد میں فقہی اختلاف بھی ہے۔',
      'فجر اور ظہر وغیرہ کی سنتیں عام نفل نمازوں سے الگ شمار کی جا سکتی ہیں۔',
    ];
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(60))),
      child: Column(children: [
        _bar('اہم وضاحت', Icons.lightbulb),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Column(children: [
            for (final l in lines)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('• ', style: TextStyle(fontWeight: FontWeight.bold)),
                  Expanded(child: Text(l, style: TextStyle(fontSize: 11.5, height: 1.5, color: subText(c)))),
                ]),
              ),
          ]),
        ),
      ]),
    );
  }

  Widget _bar(String title, IconData icon) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: const BoxDecoration(color: _bannerGreen, borderRadius: BorderRadius.vertical(top: Radius.circular(11))),
        child: Row(children: [
          Icon(icon, color: Colors.white, size: 18),
          const SizedBox(width: 6),
          Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 13.5, fontWeight: FontWeight.bold))),
        ]),
      );

  // ---------------------------------------------------------------- daily total
  Widget _totalSection(BuildContext c, List<_NI> items) {
    final done = items.where((e) => _val(date, e.id) > 0).toList();
    final total = _dayTotal(date, items);
    return Container(
      key: totalKey,
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(60))),
      child: Column(children: [
        _bar('روزانہ کل رکعتوں کا حساب', Icons.calculate),
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(done.isEmpty ? 'اس دن ابھی کوئی نفل نماز درج نہیں۔' : 'اس دن آپ نے یہ نمازیں پڑھیں:', style: TextStyle(fontSize: 11.5, color: subText(c))),
                const SizedBox(height: 6),
                Wrap(spacing: 5, runSpacing: 5, children: [
                  for (final e in done)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                      decoration: BoxDecoration(color: e.color.withAlpha(28), borderRadius: BorderRadius.circular(8), border: Border.all(color: e.color.withAlpha(80))),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Text(e.name, style: const TextStyle(fontSize: 10.5)),
                        const SizedBox(width: 5),
                        Text('${_val(date, e.id)}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      ]),
                    ),
                ]),
              ]),
            ),
            const SizedBox(width: 8),
            Container(
              width: 96,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF0B4D2E), Color(0xFF14804A)]), borderRadius: BorderRadius.circular(14)),
              child: Column(children: [
                const Text('کل رکعتیں', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                Text('$total', style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
                const Text('(اس دن کی)', style: TextStyle(color: Colors.white70, fontSize: 10)),
              ]),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 8, left: 10, right: 10),
          child: Text('تراویح کی رکعتیں اس حساب میں شامل نہیں، وہ الگ درج ہوتی ہیں۔', style: TextStyle(fontSize: 10, color: subText(c))),
        ),
      ]),
    );
  }

  // ---------------------------------------------------------------- features strip
  Widget _feat(BuildContext c, IconData icon, String text, VoidCallback onTap) => Expanded(
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
            child: Column(children: [
              Icon(icon, color: _bannerGreen, size: 28),
              const SizedBox(height: 4),
              Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold, height: 1.3)),
            ]),
          ),
        ),
      );

  Widget _features(BuildContext c) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(60))),
        child: Column(children: [
          _bar('MSF نماز ریکارڈ ایپ میں نفل نمازوں کے فیچرز', Icons.stars),
          Padding(
            padding: const EdgeInsets.all(4),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _feat(c, Icons.format_list_bulleted, 'ہر نماز کی الگ رکعتیں', _showDetails),
              _feat(c, Icons.check_circle_outline, 'آج پڑھی گئی رکعتیں (خودکار حساب)', () {
                final ctx = totalKey.currentContext;
                if (ctx != null) Scrollable.ensureVisible(ctx, duration: const Duration(milliseconds: 400), curve: Curves.easeInOut);
              }),
              _feat(c, Icons.bar_chart, 'گراف اور اعداد و شمار', () => go(c, const NaflStatsScreen(range: 7))),
              _feat(c, Icons.calendar_month, 'ہفتہ وار اور ماہانہ رپورٹ', () => go(c, const NaflStatsScreen(range: 30))),
              _feat(c, Icons.add_box, 'اپنی مرضی سے دوسری نفل نماز شامل کریں', _addCustom),
            ]),
          ),
        ]),
      );

  void _showDetails() {
    final items = _allItems();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.8,
          child: Column(children: [
            const Padding(padding: EdgeInsets.all(14), child: Text('ہر نماز کی رکعتیں اور کل ریکارڈ', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
            Expanded(
              child: ListView(children: [
                for (int i = 0; i < items.length; i++)
                  ListTile(
                    dense: true,
                    leading: CircleAvatar(radius: 14, backgroundColor: items[i].color, child: Text('${i < 20 ? i + 1 : i + 2}', style: const TextStyle(color: Colors.white, fontSize: 11))),
                    title: Text(items[i].name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('رکعات: ${items[i].label}${items[i].sub.isNotEmpty ? '  •  ${items[i].sub}' : ''}', style: const TextStyle(fontSize: 11.5)),
                    trailing: Text('${_timesDone(items[i].id)} بار', style: const TextStyle(color: green, fontWeight: FontWeight.bold)),
                    onTap: () {
                      Navigator.pop(ctx);
                      _open(items[i], i < 20 ? i + 1 : i + 2);
                    },
                  ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _addCustom() async {
    final nameCtrl = TextEditingController();
    final rakCtrl = TextEditingController(text: '2');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('نئی نفل نماز شامل کریں'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: nameCtrl, autofocus: true, decoration: const InputDecoration(labelText: 'نماز کا نام')),
          TextField(controller: rakCtrl, keyboardType: TextInputType.number, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: const InputDecoration(labelText: 'رکعات کی تعداد')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('شامل کریں')),
        ],
      ),
    );
    final name = nameCtrl.text.trim();
    final r = int.tryParse(rakCtrl.text.trim()) ?? 0;
    if (ok != true) return;
    if (name.isEmpty || r <= 0) {
      if (mounted) toast(context, 'نام اور رکعات درست درج کریں');
      return;
    }
    List<dynamic> l = [];
    try {
      final s = getS('nafl_custom');
      if (s.isNotEmpty) l = jsonDecode(s) as List;
    } catch (_) {}
    l.add({'id': 'c${DateTime.now().microsecondsSinceEpoch}', 'n': name, 'r': r});
    setS('nafl_custom', jsonEncode(l));
    if (mounted) toast(context, 'نفل نماز شامل ہو گئی');
  }

  Future<void> _deleteCustom(_NI it) async {
    if (!await confirmDialog(context, '"${it.name}" اور اس کا ریکارڈ حذف کریں؟')) return;
    try {
      final l = (jsonDecode(getS('nafl_custom')) as List).where((e) => (e as Map)['id'] != it.id).toList();
      for (final k in sp.getKeys().where((k) => k.startsWith('nk|') && k.endsWith('|${it.id}')).toList()) {
        sp.remove(k);
      }
      setS('nafl_custom', jsonEncode(l));
    } catch (_) {}
  }

  Widget _quote(BuildContext c) => Container(
        margin: const EdgeInsets.fromLTRB(8, 4, 8, 0),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(color: _bannerGreen, borderRadius: BorderRadius.circular(18), border: Border.all(color: gold.withAlpha(150))),
        child: const Text('"نماز دل کو سکون دیتی ہے، اور زندگی میں برکت لاتی ہے۔"', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.bold)),
      );
}

// ------------------------------------------------------------------ stats screen
class NaflStatsScreen extends StatefulWidget {
  final int range;
  const NaflStatsScreen({super.key, this.range = 7});
  @override
  State<NaflStatsScreen> createState() => _NaflStatsState();
}

class _NaflStatsState extends State<NaflStatsScreen> {
  late int range = widget.range;

  @override
  Widget build(BuildContext context) => Screen(
        'نفل نمازوں کی رپورٹ',
        Rebuild((c) {
          final items = _allItems();
          final today = dayOnly(DateTime.now());
          final days = [for (int k = range - 1; k >= 0; k--) addDays(today, -k)];
          final totals = [for (final d in days) _dayTotal(d, items)];
          final sum = totals.fold<int>(0, (a, b) => a + b);
          final active = totals.where((t) => t > 0).length;
          final avg = range == 0 ? 0 : sum / range;
          final counts = <_NI, int>{};
          for (final it in items) {
            var n = 0;
            for (final d in days) {
              if (_val(d, it.id) > 0) n++;
            }
            counts[it] = n;
          }
          final ranked = counts.entries.where((e) => e.value > 0).toList()..sort((a, b) => b.value.compareTo(a.value));
          // bars: daily for 7 & 30; weekly for 90
          final bars = <int>[];
          final labels = <String>[];
          if (range <= 30) {
            for (int i = 0; i < days.length; i++) {
              bars.add(totals[i]);
              labels.add(range == 7 ? urduDays[days[i].weekday - 1] : '${days[i].day}');
            }
          } else {
            for (int i = 0; i < days.length; i += 7) {
              final end = i + 7 > days.length ? days.length : i + 7;
              bars.add(totals.sublist(i, end).fold<int>(0, (a, b) => a + b));
              labels.add(fmtShort(days[i]));
            }
          }
          final mx = bars.fold<int>(1, (a, b) => b > a ? b : a);
          return ListView(padding: const EdgeInsets.all(10), children: [
            Wrap(spacing: 8, children: [
              for (final r in [7, 30, 90]) ChoiceChip(label: Text(r == 7 ? '7 دن' : (r == 30 ? '30 دن' : '90 دن')), selected: range == r, onSelected: (_) => setState(() => range = r)),
            ]),
            const SizedBox(height: 8),
            box(
              c,
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                _big('کل رکعتیں', '$sum', green),
                _big('فعال دن', '$active', Colors.orange),
                _big('روزانہ اوسط', avg.toStringAsFixed(1), Colors.blueGrey),
              ]),
            ),
            sectionTitle(range == 90 ? 'ہفتہ وار رکعتیں' : 'روزانہ رکعتیں'),
            box(
              c,
              child: SizedBox(
                height: 170,
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    for (int i = 0; i < bars.length; i++)
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 1.5),
                          child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                            if (bars.length <= 14) Text('${bars[i]}', style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold)),
                            Container(height: 120.0 * bars[i] / mx, decoration: BoxDecoration(color: bars[i] == 0 ? Colors.grey.withAlpha(60) : green, borderRadius: BorderRadius.circular(3))),
                            const SizedBox(height: 3),
                            if (bars.length <= 14) FittedBox(fit: BoxFit.scaleDown, child: Text(labels[i], style: const TextStyle(fontSize: 9))),
                          ]),
                        ),
                      ),
                  ]),
                ),
              ),
            ),
            sectionTitle('ہر نماز کتنے دن پڑھی گئی'),
            if (ranked.isEmpty) Padding(padding: const EdgeInsets.all(16), child: Center(child: Text('اس مدت میں کوئی نفل نماز درج نہیں', style: TextStyle(color: subText(c))))),
            for (final e in ranked)
              box(
                c,
                child: Row(children: [
                  Icon(e.key.icon, color: e.key.color),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(e.key.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: LinearProgressIndicator(value: e.value / range, minHeight: 7, color: e.key.color, backgroundColor: Colors.grey.withAlpha(60)),
                      ),
                    ]),
                  ),
                  const SizedBox(width: 10),
                  Text('${e.value} دن', style: const TextStyle(fontWeight: FontWeight.bold, color: green)),
                ]),
              ),
          ]);
        }),
      );

  Widget _big(String t, String v, Color col) => Column(children: [
        Text(v, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: col)),
        Text(t, style: const TextStyle(fontSize: 12)),
      ]);
}

/// For reports: [id, name] of all nafl items (standard + custom).
List<List<String>> naflIdNames() => [for (final i in _allItems()) [i.id, i.name]];
