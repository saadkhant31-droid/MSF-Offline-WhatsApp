import 'dart:convert';
import 'package:flutter/material.dart';
import 'store.dart';
import 'widgets.dart';

const _gDark = Color(0xFF0B5D3B);
const _gMid = Color(0xFF1E8A4C);
const _gLight = Color(0xFFE6F4EA);

DateTime lastFriday(DateTime d) {
  var x = dayOnly(d);
  while (x.weekday != DateTime.friday) {
    x = addDays(x, -1);
  }
  return x;
}

String isoDate(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class JRec {
  String st = '';
  String txt = '';
  String mosque = '';
  List<bool> done = [true, true, true, false];
  List<int> rk = [4, 2, 6, 0];
  bool saved = false;

  String enc() => jsonEncode({'st': st, 'txt': txt, 'm': mosque, 'd': done, 'r': rk});

  static JRec load(DateTime d) {
    final r = JRec();
    final s = getS('jm:${dayKey(d)}');
    if (s.isEmpty) return r;
    try {
      final m = jsonDecode(s) as Map<String, dynamic>;
      r.st = (m['st'] ?? '') as String;
      r.txt = (m['txt'] ?? '') as String;
      r.mosque = (m['m'] ?? '') as String;
      r.done = (m['d'] as List).map((e) => e == true).toList();
      r.rk = (m['r'] as List).map((e) => (e as num).toInt()).toList();
      r.saved = true;
    } catch (_) {}
    return r;
  }
}

class _Stats {
  int total = 0, yes = 0, no = 0, fard = 0, sunnat = 0, nafl = 0;
}

_Stats _stats(Iterable<DateTime> fridays) {
  final s = _Stats();
  for (final f in fridays) {
    s.total++;
    final r = JRec.load(f);
    if (!r.saved) continue;
    if (r.st == 'yes') {
      s.yes++;
      if (r.done[0]) s.sunnat += r.rk[0];
      if (r.done[1]) s.fard += r.rk[1];
      if (r.done[2]) s.sunnat += r.rk[2];
      if (r.done[3]) s.nafl += r.rk[3];
    } else {
      s.no++;
    }
  }
  return s;
}

class JumahScreen extends StatefulWidget {
  final VoidCallback? onBack;
  const JumahScreen({super.key, this.onBack});
  @override
  State<JumahScreen> createState() => _JumahScreenState();
}

class _JumahScreenState extends State<JumahScreen> {
  late DateTime fri;
  late JRec r;
  final txtC = TextEditingController();
  final mosqueC = TextEditingController();
  bool editing = true;

  static const opts = [
    ['yes', 'جی ہاں\nپڑھ لی'],
    ['no', 'نہیں پڑھی'],
    ['r1', 'مسجد نہیں جا سکا'],
    ['r2', 'بیماری کی وجہ سے نہیں جا سکا'],
    ['r3', 'کام یا مصروفیت کی وجہ سے نہیں جا سکا'],
    ['r4', 'نیند یا غفلت کی وجہ سے نہیں جا سکا'],
    ['r5', 'دوسری وجہ'],
  ];
  static const optIcons = [Icons.mosque, Icons.mosque_outlined, Icons.home, Icons.healing, Icons.work, Icons.bedtime, Icons.list_alt];
  static const rowNames = ['جمعہ سے پہلے کی سنت', 'جمعہ کے فرض', 'جمعہ کے بعد کی سنت', 'اضافی نفل'];

  @override
  void initState() {
    super.initState();
    fri = lastFriday(DateTime.now());
    _load();
  }

  @override
  void dispose() {
    txtC.dispose();
    mosqueC.dispose();
    super.dispose();
  }

  void _load() {
    r = JRec.load(fri);
    txtC.text = r.txt;
    mosqueC.text = r.mosque;
    editing = !r.saved;
  }

  bool _canEdit() {
    if (!editing) toast(context, 'پہلے "ریکارڈ میں ترمیم کریں" دبائیں');
    return editing;
  }

  void _shift(int weeks) {
    setState(() {
      fri = addDays(fri, 7 * weeks);
      _load();
    });
  }

  Future<void> _pickDate() async {
    final p = await showDatePicker(
      context: context,
      initialDate: fri,
      firstDate: DateTime(2020),
      lastDate: DateTime(DateTime.now().year + 1, 12, 31),
      selectableDayPredicate: (d) => d.weekday == DateTime.friday,
    );
    if (p != null) {
      setState(() {
        fri = dayOnly(p);
        _load();
      });
    }
  }

  void _save() {
    if (r.st.isEmpty) {
      toast(context, 'پہلے بتائیں کہ جمعہ کی نماز پڑھی یا نہیں');
      return;
    }
    r.txt = txtC.text.trim();
    r.mosque = mosqueC.text.trim();
    r.saved = true;
    setS('jm:${dayKey(fri)}', r.enc());
    setState(() => editing = false);
    toast(context, 'ریکارڈ محفوظ ہو گیا ✓');
  }

  Future<void> _delete() async {
    if (!r.saved) {
      toast(context, 'اس جمعے کا کوئی محفوظ ریکارڈ نہیں');
      return;
    }
    if (!await confirmDialog(context, 'کیا اس جمعے کا ریکارڈ حذف کریں؟')) return;
    del('jm:${dayKey(fri)}');
    setState(_load);
    toast(context, 'ریکارڈ حذف ہو گیا');
  }

  int get total {
    if (r.st != 'yes') return 0;
    var t = 0;
    for (var i = 0; i < 4; i++) {
      if (r.done[i]) t += r.rk[i];
    }
    return t;
  }

  // ------------------------------------------------------------ build
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Column(children: [
        _header(context, w),
        Expanded(
          child: ListView(padding: const EdgeInsets.fromLTRB(10, 10, 10, 16), children: [
            _banner(context),
            _sec(Icons.how_to_reg, 'جمعہ کی نماز پڑھی یا نہیں؟'),
            _options(context),
            _sec(Icons.edit_note, 'جمعہ کی نماز کا ریکارڈ'),
            _recordCard(context),
            _actions(context),
            const SizedBox(height: 6),
            Rebuild((c) => _reports(c)),
          ]),
        ),
      ]),
    );
  }

  Widget _header(BuildContext c, double w) {
    final top = MediaQuery.of(c).padding.top;
    return SizedBox(
      height: w * 312 / 1024 + top,
      child: Stack(fit: StackFit.expand, children: [
        Image.asset('assets/header.png', fit: BoxFit.cover, alignment: Alignment.bottomCenter),
        Positioned(
          left: 12,
          top: top + 6,
          child: InkWell(
            onTap: () {
              if (Navigator.of(c).canPop()) {
                Navigator.of(c).pop();
              } else {
                widget.onBack?.call();
              }
            },
            borderRadius: BorderRadius.circular(30),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: _gDark.withAlpha(220),
                border: Border.all(color: const Color(0xFF55E0C0), width: 2),
                borderRadius: BorderRadius.circular(30),
              ),
              child: const Directionality(
                textDirection: TextDirection.ltr,
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.arrow_back, color: Colors.white, size: 20),
                  SizedBox(width: 6),
                  Text('واپس', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                ]),
              ),
            ),
          ),
        ),
        Positioned(
          right: 10,
          bottom: 6,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_gMid, _gDark], begin: Alignment.topCenter, end: Alignment.bottomCenter),
              border: Border.all(color: gold, width: 2.5),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: const [
              Icon(Icons.mosque, color: Colors.white, size: 20),
              Text('جمعہ', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold, height: 1.1)),
              Text('کی نماز', style: TextStyle(color: Colors.white70, fontSize: 12)),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _banner(BuildContext c) {
    final today = sameDay(fri, DateTime.now());
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(
          flex: 6,
          child: Container(
            margin: const EdgeInsets.only(bottom: 10, right: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [_gMid, _gDark]),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Stack(alignment: Alignment.center, children: [
              Positioned(left: 0, bottom: 0, child: Icon(Icons.mosque, color: Colors.white.withAlpha(60), size: 54)),
              Column(mainAxisSize: MainAxisSize.min, children: [
                FittedBox(fit: BoxFit.scaleDown, child: Text(today ? 'آج جمعہ ہے' : 'جمعہ کا ریکارڈ', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold))),
                const SizedBox(height: 2),
                const FittedBox(fit: BoxFit.scaleDown, child: Text('اپنی نماز کا ریکارڈ درج کریں', style: TextStyle(color: Colors.white, fontSize: 13))),
              ]),
            ]),
          ),
        ),
        Expanded(
          flex: 5,
          child: InkWell(
            onTap: _pickDate,
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              decoration: BoxDecoration(color: isDark(c) ? const Color(0xFF1F2B25) : _gLight, borderRadius: BorderRadius.circular(14), border: Border.all(color: _gMid.withAlpha(90))),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
                  Icon(Icons.calendar_month, color: _gDark, size: 20),
                  SizedBox(width: 4),
                  Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text('جمعہ کی تاریخ', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)))),
                ]),
                const SizedBox(height: 2),
                Text(isoDate(fri), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                FittedBox(fit: BoxFit.scaleDown, child: Text(hijriText(fri), style: TextStyle(fontSize: 11, color: subText(c)))),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _sec(IconData ic, String t) => Container(
        margin: const EdgeInsets.only(top: 4, bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [_gDark, green2]),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(children: [
          Icon(ic, color: Colors.white),
          const SizedBox(width: 8),
          Text(t, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
        ]),
      );

  Widget _options(BuildContext c) {
    return LayoutBuilder(builder: (ctx, cons) {
      const gap = 6.0;
      final tw = (cons.maxWidth - gap * 4) / 5;
      return Directionality(
        textDirection: TextDirection.ltr,
        child: Column(children: [
          Row(children: [
            for (var i = 0; i < 5; i++) ...[
              if (i > 0) const SizedBox(width: gap),
              _tile(c, i, tw),
            ],
          ]),
          const SizedBox(height: gap),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _tile(c, 5, tw),
            const SizedBox(width: gap),
            _tile(c, 6, tw),
            const SizedBox(width: gap),
            Expanded(child: _reasonBox(c)),
          ]),
        ]),
      );
    });
  }

  Widget _reasonBox(BuildContext c) => Container(
        height: 96,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.withAlpha(90))),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(mainAxisAlignment: MainAxisAlignment.end, children: const [
            Text('اپنی وجہ خود لکھیں', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            SizedBox(width: 4),
            Icon(Icons.edit, color: _gDark, size: 16),
          ]),
          const SizedBox(height: 6),
          Directionality(
            textDirection: TextDirection.rtl,
            child: TextField(
              controller: txtC,
              enabled: editing,
              maxLines: 1,
              style: const TextStyle(fontSize: 13),
              decoration: const InputDecoration(hintText: 'اپنی وجہ یہاں لکھیں…', hintStyle: TextStyle(fontSize: 12), contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 10)),
            ),
          ),
        ]),
      );

  Widget _tile(BuildContext c, int i, double w) {
    final key = opts[i][0];
    final sel = r.st == key;
    final badge = key == 'yes' ? Colors.green : (key == 'no' ? Colors.red : null);
    return InkWell(
      onTap: () {
        if (!_canEdit()) return;
        setState(() => r.st = key);
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: w,
        height: 96,
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: sel ? (isDark(c) ? const Color(0xFF24543A) : const Color(0xFFD5EEDC)) : cardColor(c),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: sel ? _gMid : Colors.grey.withAlpha(90), width: sel ? 2.5 : 1),
        ),
        child: Stack(children: [
          Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(optIcons[i], size: 28, color: _gDark),
              const SizedBox(height: 4),
              Text(opts[i][1], textAlign: TextAlign.center, maxLines: 4, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, height: 1.35)),
            ]),
          ),
          if (sel && badge != null)
            Positioned(top: 0, right: 0, child: Icon(key == 'yes' ? Icons.check_circle : Icons.cancel, color: badge, size: 20)),
        ]),
      ),
    );
  }

  Widget _recordCard(BuildContext c) {
    final off = r.st != 'yes';
    return LayoutBuilder(builder: (ctx, cons) {
      final w = cons.maxWidth;
      return Directionality(
        textDirection: TextDirection.ltr,
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: w * 0.27, child: _sideCards(c)),
          const SizedBox(width: 6),
          Expanded(child: _table(c, off)),
          const SizedBox(width: 6),
          SizedBox(width: w * 0.18, child: _totalCard(c)),
        ]),
      );
    });
  }

  Widget _sideCards(BuildContext c) => Column(children: [
        InkWell(
          onTap: _pickDate,
          child: Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: _gMid.withAlpha(80))),
            child: Column(children: [
              const Icon(Icons.calendar_month, color: _gDark, size: 26),
              const SizedBox(height: 2),
              const Text('تاریخ', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
              FittedBox(fit: BoxFit.scaleDown, child: Text(isoDate(fri), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
            ]),
          ),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: _gMid.withAlpha(80))),
          child: Column(children: [
            const Icon(Icons.mosque, color: _gDark, size: 26),
            const SizedBox(height: 2),
            const Text('مسجد کا نام (اختیاری)', textAlign: TextAlign.center, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Directionality(
              textDirection: TextDirection.rtl,
              child: TextField(
                controller: mosqueC,
                enabled: editing,
                style: const TextStyle(fontSize: 12),
                decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(horizontal: 6, vertical: 8)),
              ),
            ),
          ]),
        ),
      ]);

  Widget _table(BuildContext c, bool off) {
    Widget head(String t) => Text(t, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold));
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: _gMid.withAlpha(80))),
      child: Column(children: [
        Row(children: [
          Expanded(child: head('نماز کی قسم')),
          SizedBox(width: 66, child: head('رکعتیں')),
          SizedBox(width: 58, child: head('ریکارڈ')),
        ]),
        const Divider(height: 8),
        if (off)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Text('رکعات کا ریکارڈ صرف تب درج ہو گا جب «جی ہاں پڑھ لی» منتخب ہو۔', textAlign: TextAlign.center, style: TextStyle(color: subText(c), fontSize: 11.5, height: 1.6)),
          )
        else
          for (var i = 0; i < 4; i++) _row(c, i),
      ]),
    );
  }

  Widget _row(BuildContext c, int i) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        Expanded(child: Text(rowNames[i], textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 10.5, height: 1.3))),
        SizedBox(
          width: 66,
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            _mini(Icons.remove, () {
              if (!_canEdit()) return;
              setState(() => r.rk[i] = clampI(r.rk[i] - 1, 0, 20));
            }),
            SizedBox(width: 22, child: Text('${r.rk[i]}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold))),
            _mini(Icons.add, () {
              if (!_canEdit()) return;
              setState(() => r.rk[i] = clampI(r.rk[i] + 1, 0, 20));
            }),
          ]),
        ),
        SizedBox(
          width: 58,
          child: InkWell(
            onTap: () {
              if (!_canEdit()) return;
              setState(() => r.done[i] = !r.done[i]);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 5),
              decoration: BoxDecoration(color: r.done[i] ? Colors.green : Colors.grey, borderRadius: BorderRadius.circular(8)),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(r.done[i] ? Icons.check : Icons.close, color: Colors.white, size: 14),
                const SizedBox(width: 2),
                Text(r.done[i] ? 'پڑھی' : 'نہیں', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 11)),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _mini(IconData ic, VoidCallback f) => InkWell(
        onTap: f,
        child: Container(
          width: 20,
          height: 20,
          decoration: const BoxDecoration(color: _gDark, shape: BoxShape.circle),
          child: Icon(ic, color: Colors.white, size: 14),
        ),
      );

  Widget _totalCard(BuildContext c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
        decoration: BoxDecoration(color: isDark(c) ? const Color(0xFF24543A) : _gLight, borderRadius: BorderRadius.circular(12), border: Border.all(color: _gMid.withAlpha(80))),
        child: Column(children: [
          const FittedBox(fit: BoxFit.scaleDown, child: Text('کل رکعتیں', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold))),
          const SizedBox(height: 6),
          const Icon(Icons.mosque, color: _gDark, size: 34),
          const SizedBox(height: 6),
          Text('$total', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: _gDark)),
        ]),
      );

  Widget _actions(BuildContext c) {
    Widget b(String t, IconData ic, Color col, VoidCallback f) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: ElevatedButton.icon(
              onPressed: f,
              icon: Icon(ic, size: 16),
              label: FittedBox(fit: BoxFit.scaleDown, child: Text(t, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold))),
              style: ElevatedButton.styleFrom(backgroundColor: col, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            ),
          ),
        );
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          b('ریکارڈ محفوظ کریں', Icons.save, _gDark, _save),
          b('ریکارڈ میں ترمیم کریں', Icons.edit, _gMid, () {
            setState(() => editing = true);
            toast(c, 'اب ترمیم کر سکتے ہیں');
          }),
          b('ریکارڈ حذف کریں', Icons.delete, const Color(0xFFD32F2F), _delete),
        ]),
      ),
    );
  }

  // ------------------------------------------------------------ reports
  Widget _reports(BuildContext c) {
    final now = dayOnly(DateTime.now());
    final week = _stats(fri.isAfter(now) ? <DateTime>[] : [fri]);
    final yr = <DateTime>[];
    var f = lastFriday(DateTime(fri.year, 1, 7));
    while (f.year == fri.year && !f.isAfter(now)) {
      yr.add(f);
      f = addDays(f, 7);
    }
    final y = _stats(yr);
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
          flex: 4,
          child: _repBox(c, 'جمعہ کی ہفتہ وار رپورٹ', Icons.bar_chart, [
            ['اس ہفتے گزرے جمعے', week.total],
            ['جمعہ کی نماز پڑھی', week.yes],
            ['نماز نہیں پڑھی', week.no],
            ['فرض کی کل رکعتیں', week.fard],
            ['سنتوں کی کل رکعتیں', week.sunnat],
            ['نفل کی کل رکعتیں', week.nafl],
          ]),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 4,
          child: _repBox(c, 'جمعہ کی سالانہ رپورٹ', Icons.calendar_month, [
            ['کل گزرے جمعے', y.total],
            ['پڑھی گئی جمعہ نمازیں', y.yes],
            ['نہیں پڑھی', y.no],
            ['فرض کی کل رکعتیں', y.fard],
            ['سنتوں کی کل رکعتیں', y.sunnat],
            ['نفل کی کل رکعتیں', y.nafl],
          ]),
        ),
        const SizedBox(width: 6),
        Expanded(
          flex: 3,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF0E6B43), Color(0xFF06331F)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
              border: Border.all(color: gold, width: 2),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(children: const [
              Icon(Icons.mosque, color: gold, size: 36),
              SizedBox(height: 6),
              Text('جمعہ کا دن', style: TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.bold)),
              SizedBox(height: 4),
              Text('اللہ کی خاص رحمتوں اور مغفرت کا دن ہے۔ اس دن کی نماز میں کبھی کوتاہی نہ کریں۔', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 10.5, height: 1.7)),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _repBox(BuildContext c, String t, IconData ic, List<List<Object>> rows) {
    return Container(
      decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: _gMid.withAlpha(80))),
      child: Column(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
          decoration: const BoxDecoration(gradient: LinearGradient(colors: [_gDark, green2]), borderRadius: BorderRadius.vertical(top: Radius.circular(11))),
          child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text(t, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)))),
            const SizedBox(width: 4),
            Icon(ic, color: Colors.white, size: 16),
          ]),
        ),
        for (final x in rows)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.withAlpha(50)))),
            child: Row(children: [
              Text('${x[1]}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: _gDark)),
              const SizedBox(width: 4),
              Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerRight, child: Text(x[0] as String, style: const TextStyle(fontSize: 10.5)))),
            ]),
          ),
      ]),
    );
  }
}
