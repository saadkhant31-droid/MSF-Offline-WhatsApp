import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'store.dart';
import 'home.dart';
import 'wallpaper.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  sp = await SharedPreferences.getInstance();
  themeMode.value = getB('dark') ? ThemeMode.dark : ThemeMode.light;
  initWallpaperSync();
  runApp(const MsfApp());
}

ThemeData _theme(Brightness b, String? font) {
  final dark = b == Brightness.dark;
  return ThemeData(
    useMaterial3: true,
    fontFamily: font,
    colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: b),
    scaffoldBackgroundColor: dark ? const Color(0xFF111A15) : const Color(0xFFEFF7F1),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: green,
        foregroundColor: Colors.white,
        textStyle: const TextStyle(fontWeight: FontWeight.bold),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(backgroundColor: green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: dark ? const Color(0xFF1F2B25) : Colors.white,
      isDense: true,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: green.withAlpha(120))),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: green.withAlpha(120))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: green, width: 2)),
    ),
  );
}

class MsfApp extends StatelessWidget {
  const MsfApp({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: themeMode,
        builder: (c, m, _) => Rebuild((_) => MaterialApp(
          title: 'MSF Nimaz ki Record',
          debugShowCheckedModeBanner: false,
          themeMode: m,
          theme: _theme(Brightness.light, currentFont()),
          darkTheme: _theme(Brightness.dark, currentFont()),
          builder: (ctx, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox()),
          home: const Shell(),
        )),
      );
}
