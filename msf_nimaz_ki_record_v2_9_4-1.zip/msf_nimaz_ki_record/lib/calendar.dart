import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'nav_common.dart';
import 'eidain.dart' show hijriToGreg, EidainScreen;

const _gd = Color(0xFF0B5D3B);

const hijriEvents = {
  '1-1': 'اسلامی سال کا آغاز (یکم محرم)',
  '1-10': 'یومِ عاشورہ (10 محرم)',
  '3-12': '12 ربیع الاول (عید میلاد النبی ﷺ)',
  '7-27': 'شبِ معراج (27 رجب)',
  '8-15': 'شبِ برأت (15 شعبان)',
  '9-1': 'رمضان المبارک کا آغاز',
  '9-27': '27 رمضان (شبِ قدر کی ایک روایت)',
  '10-1': 'عید الفطر',
  '12-9': 'یومِ عرفہ',
  '12-10': 'عید الاضحیٰ',
};

String _eventOf(DateTime d) {
  final h = toHijri(d);
  return hijriEvents['${h[1]}-${h[2]}'] ?? '';
}

class _Ev {
  final int m, d;
  final String name, sub;
  final IconData icon;
  const _Ev(this.m, this.d, this.name, this.sub, this.icon);
}

const _evs = [
  _Ev(10, 1, 'عید الفطر', '1 شوال', Icons.mosque),
  _Ev(12, 10, 'عید الاضحیٰ', '10 ذوالحجہ', Icons.account_balance),
  _Ev(9, 1, 'رمضان المبارک', '1 رمضان', Icons.nightlight_round),
  _Ev(1, 1, 'محرم الحرام', '1 محرم', Icons.location_city),
  _Ev(1, 10, 'یومِ عاشورہ', '10 محرم', Icons.mosque),
  _Ev(3, 12, 'میلاد النبی ﷺ', '12 ربیع الاول', Icons.mosque),
  _Ev(8, 15, 'شبِ برأت', '15 شعبان', Icons.lightbulb),
  _Ev(7, 27, 'شبِ معراج', '27 رجب', Icons.auto_awesome),
];

DateTime _nextOf(int hm, int hd) {
  final t = dayOnly(DateTime.now());
  final hy = toHijri(t)[0];
  var d = hijriToGreg(hy, hm, hd);
  if (d.isBefore(t)) d = hijriToGreg(hy + 1, hm, hd);
  return d;
}

String _remain(DateTime d) {
  final n = d.difference(dayOnly(DateTime.now())).inDays;
  return n == 0 ? 'آج' : '$n دن باقی';
}

class CalendarScreen extends StatefulWidget {
  const CalendarScreen({super.key});
  @override
  State<CalendarScreen> createState() => _CalState();
}

class _CalState extends State<CalendarScreen> {
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime sel = dayOnly(DateTime.now());
  final kCal = GlobalKey(), kMon = GlobalKey(), kEv = GlobalKey(), kRam = GlobalKey(), kEid = GlobalKey(), kAdj = GlobalKey();

  void _move(int n) => setState(() => month = DateTime(month.year, month.month + n, 1));

  void _scroll(GlobalKey k) {
    final c = k.currentContext;
    if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 400), curve: Curves.easeOut);
  }

  void _showDate(DateTime d) {
    setState(() {
      sel = dayOnly(d);
      month = DateTime(d.year, d.month, 1);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _scroll(kCal));
  }

  Future<void> _pickMonth() async {
    final p = await showDatePicker(context: context, initialDate: sel, firstDate: DateTime(1990), lastDate: DateTime(2100));
    if (p != null) _showDate(p);
  }

  void _monthSheet(int hm, int hy) {
    final start = hijriToGreg(hy, hm, 1);
    final next = hm == 12 ? hijriToGreg(hy + 1, 1, 1) : hijriToGreg(hy, hm + 1, 1);
    final len = next.difference(start).inDays;
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('${hijriMonths[hm - 1]} $hyھ', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: green)),
            const SizedBox(height: 8),
            Text('آغاز: ${fmtDate(start)}', style: const TextStyle(fontSize: 15)),
            Text('دن: $len', style: const TextStyle(fontSize: 15)),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(c);
                  _showDate(start);
                },
                icon: const Icon(Icons.calendar_month),
                label: const Text('کیلنڈر میں دیکھیں'),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _evSheet(_Ev e) {
    final d = _nextOf(e.m, e.d);
    final h = toHijri(d);
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(e.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: green)),
            const SizedBox(height: 6),
            Text('${e.sub} ${h[0]}ھ', style: const TextStyle(fontSize: 15)),
            Text(fmtDate(d), style: const TextStyle(fontSize: 15)),
            Text(_remain(d), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: _gd)),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(c);
                  _showDate(d);
                },
                icon: const Icon(Icons.calendar_month),
                label: const Text('کیلنڈر میں دیکھیں'),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  void _adjust() {
    var v = getI('hadj');
    showDialog<void>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: const Text('ہجری تاریخ میں تبدیلی'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('چاند کے اعلان کے مطابق دن آگے یا پیچھے کریں (-2 سے +2)', style: TextStyle(height: 1.7)),
            const SizedBox(height: 10),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton(onPressed: v > -2 ? () => setD(() => v--) : null, icon: const Icon(Icons.remove_circle, color: green, size: 32)),
                SizedBox(width: 50, child: Text(v > 0 ? '+$v' : '$v', textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
                IconButton(onPressed: v < 2 ? () => setD(() => v++) : null, icon: const Icon(Icons.add_circle, color: green, size: 32)),
              ]),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('منسوخ')),
            TextButton(
              onPressed: () {
                setI('hadj', v);
                Navigator.pop(c);
                toast(context, 'تاریخ تبدیل ہو گئی');
              },
              child: const Text('محفوظ کریں'),
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------ build
  final ScrollController _sc = ScrollController();

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  BoxDecoration _deco(BuildContext c, {Color? color}) => BoxDecoration(
        color: color ?? cardColor(c),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: green.withAlpha(60)),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(16), blurRadius: 5, offset: const Offset(0, 2))],
      );

  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
        child: Scaffold(
          backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
          body: Rebuild((c) => _body(c)),
          bottomNavigationBar: msfBottomNav(context, qibla: false),
        ),
      );

  Widget _body(BuildContext c) {
    final today = dayOnly(DateTime.now());
    final ht = toHijri(today);
    final hy = ht[0];
    return SingleChildScrollView(
      controller: _sc,
      child: Column(children: [
        artHeader(c, 'assets/calendar/header.png', 250 / 1024),
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 14),
          child: Column(children: [
            IntrinsicHeight(
              child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Expanded(flex: 38, child: _todayCard(c, today)),
                const SizedBox(width: 8),
                Expanded(flex: 62, child: _banner()),
              ]),
            ),
            const SizedBox(height: 8),
            _tabs(c, today),
            const SizedBox(height: 8),
            KeyedSubtree(key: kCal, child: _calendarCard(c, today)),
            const SizedBox(height: 8),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: KeyedSubtree(key: kEv, child: _eventsPanel(c))),
              const SizedBox(width: 6),
              Expanded(child: KeyedSubtree(key: kMon, child: _monthsPanel(c, ht, hy))),
            ]),
            const SizedBox(height: 8),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: _summaryPanel(c)),
              const SizedBox(width: 6),
              Expanded(child: KeyedSubtree(key: kAdj, child: _adjPanel(c))),
            ]),
            const SizedBox(height: 8),
            KeyedSubtree(key: kRam, child: sectionTitle('رمضان المبارک')),
            _ramadan(c, ht),
            KeyedSubtree(key: kEid, child: sectionTitle('عیدین')),
            _eids(c),
            _quote(),
          ]),
        ),
      ]),
    );
  }

  Widget _bar(String title, IconData icon) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [_gd, Color(0xFF2E8B57)]), borderRadius: BorderRadius.vertical(top: Radius.circular(12))),
        child: Row(children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(width: 6),
          Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 14.5, fontWeight: FontWeight.bold)))),
        ]),
      );

  Widget _panel(BuildContext c, String title, IconData icon, Widget child) => Container(
        decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(70))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [_bar(title, icon), child]),
      );

  Widget _banner() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), _gd]), borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Expanded(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: const [
              FittedBox(fit: BoxFit.scaleDown, child: Text('اسلامی کیلنڈر', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold))),
              SizedBox(height: 4),
              Text('ہجری اور اسلامی تاریخیں', style: TextStyle(color: Colors.white, fontSize: 12)),
            ]),
          ),
          const SizedBox(width: 8),
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(border: Border.all(color: gold, width: 2), borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.calendar_month, color: gold, size: 36),
          ),
        ]),
      );

  Widget _todayCard(BuildContext c, DateTime t) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: _deco(c),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => _showDate(t),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                const Icon(Icons.calendar_month, color: _gd, size: 30),
                const SizedBox(width: 4),
                Expanded(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: AlignmentDirectional.centerStart,
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('آج کی تاریخ', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12.5)),
                      Text('${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                      Text(hijriText(t), style: TextStyle(fontSize: 10.5, color: subText(c))),
                    ]),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );

  Widget _tabs(BuildContext c, DateTime today) {
    // RTL row: first child sits on the right, so the list runs right -> left.
    final items = <List<Object>>[
      [Icons.settings, 'تاریخ میں تبدیلی', () => _scroll(kAdj)],
      [Icons.celebration, 'عیدین', () => _scroll(kEid)],
      [Icons.nightlight_round, 'رمضان المبارک', () => _scroll(kRam)],
      [Icons.star, 'اہم اسلامی تاریخیں', () => _scroll(kEv)],
      [Icons.mosque, 'اسلامی مہینے', () => _scroll(kMon)],
      [Icons.calendar_today, 'موجودہ تاریخ', () => _showDate(today)],
    ];
    return SizedBox(
      height: 72,
      child: Row(children: [
        for (int i = 0; i < items.length; i++) ...[
          if (i > 0) const SizedBox(width: 4),
          Expanded(
            child: Material(
              color: Colors.transparent,
              child: Ink(
                decoration: BoxDecoration(
                  color: i == items.length - 1 ? _gd : cardColor(c),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: green.withAlpha(80)),
                ),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: items[i][2] as VoidCallback,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(items[i][0] as IconData, color: i == items.length - 1 ? Colors.white : _gd, size: 24),
                      const SizedBox(height: 3),
                      Text(items[i][1] as String, maxLines: 2, textAlign: TextAlign.center, style: TextStyle(fontSize: 9.5, height: 1.25, fontWeight: FontWeight.bold, color: i == items.length - 1 ? Colors.white : null)),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        ],
      ]),
    );
  }

  Widget _calendarCard(BuildContext c, DateTime today) {
    final lead = month.weekday % 7;
    final nDays = DateTime(month.year, month.month + 1, 0).day;
    final weeks = ((lead + nDays) / 7).ceil();
    const heads = ['اتوار', 'پیر', 'منگل', 'بدھ', 'جمعرات', 'جمعہ', 'ہفتہ'];
    return _panel(
      c,
      'موجودہ تاریخ',
      Icons.mosque,
      Padding(
        padding: const EdgeInsets.all(8),
        child: Column(children: [
          Directionality(
            textDirection: TextDirection.ltr,
            child: Container(
              decoration: BoxDecoration(color: isDark(c) ? const Color(0xFF24543A) : const Color(0xFFE6F4EA), borderRadius: BorderRadius.circular(10)),
              child: Row(children: [
                IconButton(onPressed: () => _move(-1), icon: const Icon(Icons.chevron_left, color: _gd, size: 28)),
                Expanded(
                  child: InkWell(
                    onTap: _pickMonth,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text('${month.year}  ${urduMonths[month.month - 1]}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ),
                IconButton(onPressed: () => _move(1), icon: const Icon(Icons.chevron_right, color: _gd, size: 28)),
              ]),
            ),
          ),
          const SizedBox(height: 6),
          Row(children: [
            for (final h in heads)
              Expanded(child: Center(child: Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: FittedBox(fit: BoxFit.scaleDown, child: Text(h, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: _gd)))))),
          ]),
          for (int w = 0; w < weeks; w++)
            Row(children: [
              for (int col = 0; col < 7; col++) _cell(c, w * 7 + col - lead + 1, nDays, col, today),
            ]),
          const SizedBox(height: 8),
          Material(
            color: Colors.transparent,
            child: Ink(
              decoration: BoxDecoration(color: Color.alphaBlend(green.withAlpha(20), cardColor(c)), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(50))),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => _showDate(today),
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Row(children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: _gd),
                      child: const Icon(Icons.nightlight_round, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('آج کی تاریخ', style: TextStyle(fontSize: 11, color: subText(c))),
                        Text(fmtDate(today), style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.bold)),
                        Text(hijriText(today), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: _gd)),
                      ]),
                    ),
                  ]),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _cell(BuildContext c, int day, int nDays, int col, DateTime today) {
    if (day < 1 || day > nDays) return const Expanded(child: SizedBox(height: 46));
    final d = DateTime(month.year, month.month, day);
    final h = toHijri(d);
    final isToday = sameDay(d, today);
    final isSel = sameDay(d, sel);
    final hasEv = _eventOf(d).isNotEmpty;
    final fg = isToday ? Colors.white : (col == 5 ? green : null);
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(25),
        onTap: () => setState(() => sel = d),
        child: Container(
          height: 46,
          margin: const EdgeInsets.all(1.5),
          decoration: BoxDecoration(
            color: isToday ? _gd : null,
            shape: BoxShape.circle,
            border: isSel && !isToday ? Border.all(color: _gd, width: 2) : (hasEv && !isToday ? Border.all(color: gold, width: 1.6) : null),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('$day', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: fg)),
            Text('${h[2]}', style: TextStyle(fontSize: 9, color: isToday ? Colors.white70 : gold.withAlpha(240), fontWeight: FontWeight.w600)),
          ]),
        ),
      ),
    );
  }

  Widget _eventsPanel(BuildContext c) => _panel(
        c,
        'اہم اسلامی تاریخیں',
        Icons.mosque,
        Padding(
          padding: const EdgeInsets.all(5),
          child: Column(children: [for (final e in _evs) _evTile(c, e)]),
        ),
      );

  Widget _evTile(BuildContext c, _Ev e) {
    final d = _nextOf(e.m, e.d);
    final h = toHijri(d);
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(color: Color.alphaBlend(green.withAlpha(14), cardColor(c)), borderRadius: BorderRadius.circular(10), border: Border.all(color: green.withAlpha(40))),
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => _evSheet(e),
            child: Padding(
              padding: const EdgeInsets.all(5),
              child: Row(children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(color: _gd, borderRadius: BorderRadius.circular(8)),
                  child: Icon(e.icon, color: Colors.white, size: 19),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: AlignmentDirectional.centerStart,
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(e.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      Text('${e.sub} ${h[0]}ھ', style: TextStyle(fontSize: 10, color: subText(c))),
                    ]),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _monthsPanel(BuildContext c, List<int> ht, int hy) => _panel(
        c,
        'اسلامی مہینے',
        Icons.mosque,
        Padding(
          padding: const EdgeInsets.all(5),
          child: Column(children: [
            for (int i = 1; i <= 12; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Material(
                  color: Colors.transparent,
                  child: Ink(
                    decoration: BoxDecoration(color: ht[1] == i ? _gd : null, borderRadius: BorderRadius.circular(8)),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(8),
                      onTap: () => _monthSheet(i, hy),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 9),
                        child: Row(children: [
                          Icon(i == 9 ? Icons.nightlight_round : (i == 12 ? Icons.account_balance : Icons.mosque), color: ht[1] == i ? Colors.white : _gd, size: 17),
                          const SizedBox(width: 5),
                          Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(hijriMonths[i - 1], style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, color: ht[1] == i ? Colors.white : null)))),
                          Text('$hyھ', style: TextStyle(fontSize: 10, color: ht[1] == i ? Colors.white70 : subText(c))),
                          if (ht[1] == i) const Padding(padding: EdgeInsets.only(right: 4), child: Icon(Icons.arrow_back, color: Colors.white, size: 15)),
                        ]),
                      ),
                    ),
                  ),
                ),
              ),
          ]),
        ),
      );

  Widget _summaryPanel(BuildContext c) {
    final h = toHijri(sel);
    final ev = _eventOf(sel);
    final bayd = h[2] >= 13 && h[2] <= 15;
    Widget row(String a, String b) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(a, style: TextStyle(fontSize: 10, color: subText(c))),
            FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(b, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
          ]),
        );
    return _panel(
      c,
      'منتخب تاریخ کا خلاصہ',
      Icons.event_note,
      Padding(
        padding: const EdgeInsets.all(8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          row('تاریخ', fmtDate(sel)),
          const Divider(height: 4),
          row('ہجری تاریخ', hijriText(sel)),
          const Divider(height: 4),
          row('مہینے کا نام', hijriMonths[clampI(h[1] - 1, 0, 11)]),
          const Divider(height: 4),
          row('مہینے کا دن', '${h[2]}'),
          if (ev.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Row(children: [
                const Icon(Icons.star, color: gold, size: 16),
                const SizedBox(width: 4),
                Expanded(child: Text(ev, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11, height: 1.4))),
              ]),
            ),
          if (bayd) const Padding(padding: EdgeInsets.only(top: 6), child: Text('ایامِ بیض (روزے کے مستحب دن)', style: TextStyle(color: _gd, fontWeight: FontWeight.bold, fontSize: 11))),
        ]),
      ),
    );
  }

  Widget _adjPanel(BuildContext c) {
    final adj = getI('hadj');
    return _panel(
      c,
      'تاریخ میں تبدیلی',
      Icons.edit_calendar,
      Padding(
        padding: const EdgeInsets.all(8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('مقامی چاند دیکھنے کے اعلان کے مطابق ہجری تاریخ میں ایک دن کا فرق ہو سکتا ہے۔ آپ اپنی دستی طور پر تاریخ درست کر سکتے ہیں۔', style: TextStyle(fontSize: 10.5, height: 1.7, color: subText(c))),
          const SizedBox(height: 6),
          Text('موجودہ: ${adj > 0 ? '+$adj' : adj}', style: const TextStyle(fontWeight: FontWeight.bold, color: _gd, fontSize: 12)),
          const SizedBox(height: 6),
          ElevatedButton(
            onPressed: _adjust,
            style: ElevatedButton.styleFrom(backgroundColor: _gd, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const FittedBox(
              fit: BoxFit.scaleDown,
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.edit_calendar, size: 16),
                SizedBox(width: 4),
                Text('تاریخ تبدیل کریں', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

    Widget _ramadan(BuildContext c, List<int> ht) {
    final start = _nextOf(9, 1);
    final qadr = _nextOf(9, 27);
    final eid = _nextOf(10, 1);
    Widget row(String a, DateTime d) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(children: [Expanded(child: Text(a)), Text(fmtDate(d), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12.5)), const SizedBox(width: 8), Text(_remain(d), style: const TextStyle(color: _gd, fontSize: 12))]),
        );
    return box(c, child: Column(children: [
      if (ht[1] == 9)
        Container(
          width: double.infinity,
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), _gd]), borderRadius: BorderRadius.circular(10)),
          child: Text('رمضان جاری ہے — آج ${ht[2]} رمضان ہے 🌙', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ),
      row('رمضان کا آغاز', start),
      row('27 ویں شب', qadr),
      row('عید الفطر', eid),
    ]));
  }

  Widget _eids(BuildContext c) {
    final f = _nextOf(10, 1);
    final a = _nextOf(12, 10);
    return box(c, child: Column(children: [
      Row(children: [const Icon(Icons.mosque, color: _gd), const SizedBox(width: 8), const Expanded(child: Text('عید الفطر')), Text(fmtDate(f), style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold))]),
      const SizedBox(height: 8),
      Row(children: [const Icon(Icons.account_balance, color: _gd), const SizedBox(width: 8), const Expanded(child: Text('عید الاضحیٰ')), Text(fmtDate(a), style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold))]),
      const SizedBox(height: 10),
      SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(onPressed: () => go(c, const EidainScreen()), icon: const Icon(Icons.edit_note), label: const Text('عیدین کا ریکارڈ کھولیں')),
      ),
    ]));
  }

  Widget _quote() => Container(
        margin: const EdgeInsets.only(top: 4),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF0E6B43), Color(0xFF06331F)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
          border: Border.all(color: gold, width: 2),
          borderRadius: BorderRadius.circular(14),
        ),
        clipBehavior: Clip.antiAlias,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => toast(context, 'اللہ تعالیٰ ہمارے ہر دن کو اپنی رضا کے لیے بنا دے، آمین'),
            child: Column(children: [
              SizedBox(height: 90, width: double.infinity, child: Image.asset('assets/calendar/quote.png', fit: BoxFit.cover)),
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 8, 16, 14),
                child: Column(children: [
                  Text('اسلامی کیلنڈر', style: TextStyle(color: gold, fontSize: 17, fontWeight: FontWeight.bold)),
                  SizedBox(height: 6),
                  Text('ہمارا مقصد صرف تاریخ جاننا نہیں، بلکہ ہر دن کو اللہ کی رضا کے لیے بہتر بنانا ہے۔', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, height: 1.8, fontSize: 13.5)),
                ]),
              ),
            ]),
          ),
        ),
      );
}
