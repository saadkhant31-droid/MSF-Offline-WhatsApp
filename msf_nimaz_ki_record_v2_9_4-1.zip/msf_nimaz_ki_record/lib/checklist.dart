import 'package:flutter/material.dart';
import 'store.dart';
import 'widgets.dart';

class CItem {
  final String title, sub;
  const CItem(this.title, [this.sub = '']);
}

class ChecklistScreen extends StatefulWidget {
  final String id, title, hint;
  final List<CItem> items;
  final bool yearly, withTime, fridayOnly;
  const ChecklistScreen({
    super.key,
    required this.id,
    required this.title,
    required this.items,
    this.hint = '',
    this.yearly = false,
    this.withTime = false,
    this.fridayOnly = false,
  });
  @override
  State<ChecklistScreen> createState() => _ChecklistState();
}

class _ChecklistState extends State<ChecklistScreen> {
  late DateTime date;
  final ctrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    date = dayOnly(DateTime.now());
    if (widget.fridayOnly) {
      while (date.weekday != DateTime.friday) {
        date = addDays(date, -1);
      }
    }
    _loadNote();
  }

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  String get scope => widget.yearly ? '${date.year}' : dayKey(date);
  String _ik(int i) => 'ck|${widget.id}|$scope|$i';
  String get _noteKey => 'nt|${widget.id}|$scope';
  String get _timeKey => 'tm|${widget.id}|$scope';

  void _loadNote() => ctrl.text = getS(_noteKey);

  void _move(int dir) {
    final today = dayOnly(DateTime.now());
    DateTime nd;
    if (widget.yearly) {
      nd = DateTime(date.year + dir, 1, 1);
      if (nd.year > today.year) return;
    } else {
      nd = addDays(date, dir * (widget.fridayOnly ? 7 : 1));
      if (nd.isAfter(today)) return;
    }
    setState(() {
      date = nd;
      _loadNote();
    });
  }

  int _total(int i) => sp.getKeys().where((k) => k.startsWith('ck|${widget.id}|') && k.endsWith('|$i') && sp.getBool(k) == true).length;

  Future<void> _pickTime() async {
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (t == null) return;
    final dt = DateTime(2000, 1, 1, t.hour, t.minute);
    setS(_timeKey, fmtTime(dt));
  }

  @override
  Widget build(BuildContext context) => Screen(
        widget.title,
        Rebuild((c) {
          var done = 0;
          for (int i = 0; i < widget.items.length; i++) {
            if (getB(_ik(i))) done++;
          }
          final label = widget.yearly ? 'سال ${date.year}' : '${fmtDate(date)}\n${hijriText(date)}';
          final time = getS(_timeKey);
          return ListView(padding: const EdgeInsets.all(10), children: [
            DateNav(label: label, onPrev: () => _move(-1), onNext: () => _move(1)),
            if (widget.fridayOnly && date.weekday != DateTime.friday) Padding(padding: const EdgeInsets.all(6), child: Text('یہ دن جمعہ نہیں ہے', style: TextStyle(color: subText(c)))),
            box(
              c,
              child: Column(children: [
                Row(children: [
                  Text('مکمل: $done / ${widget.items.length}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const Spacer(),
                  if (done == widget.items.length) const Icon(Icons.verified, color: green),
                ]),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(value: widget.items.isEmpty ? 0 : done / widget.items.length, minHeight: 9, color: green, backgroundColor: Colors.grey.withAlpha(60)),
                ),
              ]),
            ),
            for (int i = 0; i < widget.items.length; i++) _tile(c, i),
            if (widget.withTime)
              InkWell(
                onTap: _pickTime,
                child: box(
                  c,
                  child: Row(children: [
                    const Icon(Icons.access_time, color: green),
                    const SizedBox(width: 10),
                    Expanded(child: Text(time.isEmpty ? 'نماز کا وقت درج کریں' : 'نماز کا وقت: $time', style: const TextStyle(fontWeight: FontWeight.bold))),
                    if (time.isNotEmpty) IconButton(onPressed: () => del(_timeKey), icon: const Icon(Icons.close)),
                  ]),
                ),
              ),
            box(
              c,
              child: TextField(
                controller: ctrl,
                maxLines: 3,
                onChanged: (v) => sp.setString(_noteKey, v),
                decoration: const InputDecoration(border: InputBorder.none, hintText: 'نوٹ لکھیں (اختیاری)', icon: Icon(Icons.edit_note, color: green)),
              ),
            ),
            if (widget.hint.isNotEmpty) Padding(padding: const EdgeInsets.all(6), child: Text(widget.hint, style: TextStyle(fontSize: 12, color: subText(c), height: 1.6))),
          ]);
        }),
      );

  Widget _tile(BuildContext c, int i) {
    final it = widget.items[i];
    final checked = getB(_ik(i));
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => setB(_ik(i), !checked),
      child: box(
        c,
        color: checked ? green.withAlpha(isDark(c) ? 70 : 28) : null,
        child: Row(children: [
          Icon(checked ? Icons.check_circle : Icons.radio_button_unchecked, color: checked ? green : Colors.grey, size: 30),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(it.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              if (it.sub.isNotEmpty) Text(it.sub, style: TextStyle(fontSize: 12, color: subText(c))),
              Text('کل ریکارڈ: ${_total(i)} بار', style: TextStyle(fontSize: 11, color: green.withAlpha(210))),
            ]),
          ),
        ]),
      ),
    );
  }
}
