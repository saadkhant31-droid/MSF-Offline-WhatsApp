import 'dart:convert';
import 'package:flutter/material.dart';
import 'store.dart';
import 'widgets.dart';

const _gd = Color(0xFF0B5D3B);
const _gl = Color(0xFFE6F4EA);

String _iso(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// Gregorian date of a Hijri date (searches with the app's own Hijri converter).
DateTime hijriToGreg(int hy, int hm, int hd) {
  final y0 = ((hy * 32) ~/ 33) + 622;
  var d = DateTime(y0, 1, 1);
  for (var i = 0; i < 900; i++) {
    final h = toHijri(d);
    if (h[0] == hy && h[1] == hm && h[2] == hd) return d;
    d = addDays(d, 1);
  }
  return DateTime(y0, 1, 1);
}

Map<String, String> loadEid(int hy) {
  final s = getS('eid:$hy');
  if (s.isEmpty) return {};
  try {
    return (jsonDecode(s) as Map).map((k, v) => MapEntry(k.toString(), v.toString()));
  } catch (_) {
    return {};
  }
}

const _yn = [['y', 'جی ہاں'], ['n', 'نہیں']];
const _where = [['eidgah', 'عید گاہ میں'], ['masjid', 'مسجد میں'], ['other', 'دوسری جگہ']];
const _why = [['ill', 'بیماری'], ['sleep', 'نیند یا دیر سے اٹھنا'], ['travel', 'سفر'], ['home', 'گھریلو مجبوری'], ['other', 'دوسری وجہ']];
const _qwhy = [['money', 'مالی استطاعت نہیں تھی'], ['noanimal', 'جانور دستیاب نہیں تھا'], ['forced', 'قربانی مجبوری'], ['other', 'دوسری وجہ']];
const _behalf = [['self', 'اپنی طرف سے'], ['father', 'والد کی طرف سے'], ['mother', 'والدہ کی طرف سے'], ['spouse', 'شوہر یا بیوی کی طرف سے'], ['kids', 'بچوں کی طرف سے'], ['other', 'دوسرے فرد کی طرف سے']];
const _how = [['own', 'اپنا مکمل جانور'], ['share', 'گائے یا اونٹ میں حصہ'], ['forother', 'کسی دوسرے کی طرف سے'], ['other', 'دوسری صورت']];
const _animals = [['bull', 'بیل', '🐂'], ['cow', 'گائے', '🐄'], ['goat', 'بکری', '🐐'], ['he', 'بکرا', '🐐'], ['camel', 'اونٹ', '🐪'], ['ram', 'دنبہ', '🐏'], ['sheep', 'بھیڑ', '🐑'], ['other', 'دوسرا جانور', '🐾']];

String _lbl(List<List<String>> opts, String? v) {
  for (final o in opts) {
    if (o[0] == v) return o[1];
  }
  return '—';
}

class EidainScreen extends StatefulWidget {
  final VoidCallback? onBack;
  const EidainScreen({super.key, this.onBack});
  @override
  State<EidainScreen> createState() => _EidainScreenState();
}

class _EidainScreenState extends State<EidainScreen> {
  late int hy;
  Map<String, String> m = {};
  bool saved = false, editing = true;
  static const textKeys = ['fn', 'an', 'qn', 'm1', 'm2', 'm3'];
  final ctr = {for (final k in textKeys) k: TextEditingController()};
  final kF = GlobalKey(), kA = GlobalKey(), kQ = GlobalKey();

  @override
  void initState() {
    super.initState();
    hy = toHijri(DateTime.now())[0];
    _load();
  }

  @override
  void dispose() {
    for (final c in ctr.values) {
      c.dispose();
    }
    super.dispose();
  }

  void _load() {
    m = loadEid(hy);
    saved = m.isNotEmpty;
    editing = !saved;
    for (final k in textKeys) {
      ctr[k]!.text = m[k] ?? '';
    }
  }

  String g(String k) => m[k] ?? '';

  bool _can() {
    if (!editing) toast(context, 'پہلے "ترمیم کریں" دبائیں');
    return editing;
  }

  void _set(String k, String v) {
    if (!_can()) return;
    setState(() => m[k] = g(k) == v ? '' : v);
  }

  void _year(int d) => setState(() {
        hy += d;
        _load();
      });

  void _save() {
    for (final k in textKeys) {
      m[k] = ctr[k]!.text.trim();
    }
    if (g('fp').isEmpty && g('ap').isEmpty && g('qd').isEmpty) {
      toast(context, 'کم از کم ایک سوال کا جواب دیں');
      return;
    }
    setS('eid:$hy', jsonEncode(m));
    setState(() {
      saved = true;
      editing = false;
    });
    toast(context, 'ریکارڈ محفوظ ہو گیا ✓');
  }

  Future<void> _delete() async {
    if (!saved) {
      toast(context, 'اس سال کا کوئی محفوظ ریکارڈ نہیں');
      return;
    }
    if (!await confirmDialog(context, 'کیا $hy ھ کا ریکارڈ حذف کریں؟')) return;
    del('eid:$hy');
    setState(_load);
    toast(context, 'ریکارڈ حذف ہو گیا');
  }

  void _scroll(GlobalKey k) {
    final c = k.currentContext;
    if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 400), curve: Curves.easeOut);
  }

  // ------------------------------------------------------------ build
  @override
  Widget build(BuildContext context) {
    final cw = MediaQuery.of(context).size.width - 20;
    final half = (cw - 8) / 2 - 0.5;
    final fitr = hijriToGreg(hy, 10, 1);
    final adha = hijriToGreg(hy, 12, 10);
    return Scaffold(
      body: Column(children: [
        appHeader(context, 'عیدین', 'کی نماز اور قربانی کا ریکارڈ', widget.onBack),
        Expanded(
          child: ListView(padding: const EdgeInsets.fromLTRB(10, 10, 10, 16), children: [
            Row(children: [
              Expanded(child: _banner('عید الفطر', 'کی نماز کا ریکارڈ', Icons.mosque, () => _scroll(kF))),
              const SizedBox(width: 8),
              Expanded(child: _banner('عید الاضحیٰ', 'کی نماز اور قربانی کا ریکارڈ', Icons.pets, () => _scroll(kA))),
            ]),
            const SizedBox(height: 10),
            DateNav(label: 'ہجری سال $hy ھ', onPrev: () => _year(-1), onNext: () => _year(1)),
            // ---------------- Fitr
            KeyedSubtree(key: kF, child: _sec(Icons.mosque, 'عید الفطر کی نماز کا ریکارڈ')),
            Wrap(spacing: 8, children: [
              _radio('کیا عید الفطر کی نماز پڑھی؟', Icons.help_outline, 'fp', _yn, half),
              _radio('نماز کہاں پڑھی؟', Icons.place, 'fw', _where, half),
              _radio('اگر نماز نہیں پڑھی تو وجہ کیا تھی؟', Icons.help, 'fr', _why, half),
              _dateCard('fd', fitr, 'تاریخ (1 شوال)', half),
            ]),
            _note('fn'),
            _greeting('عید الفطر مبارک ہو'),
            // ---------------- Adha
            KeyedSubtree(key: kA, child: _sec(Icons.mosque, 'عید الاضحیٰ کی نماز کا ریکارڈ')),
            Wrap(spacing: 8, children: [
              _radio('کیا عید الاضحیٰ کی نماز پڑھی؟', Icons.help_outline, 'ap', _yn, half),
              _radio('نماز کہاں پڑھی؟', Icons.place, 'aw', _where, half),
              _radio('اگر نماز نہیں پڑھی تو وجہ کیا تھی؟', Icons.help, 'ar', _why, half),
              _dateCard('ad', adha, 'تاریخ (10 ذوالحجہ)', half),
            ]),
            _note('an'),
            _greeting('عید الاضحیٰ مبارک ہو'),
            // ---------------- Qurbani
            KeyedSubtree(key: kQ, child: _sec(Icons.pets, 'قربانی کا ریکارڈ')),
            Wrap(spacing: 8, children: [
              _radio('کیا قربانی کی؟', Icons.volunteer_activism, 'qd', _yn, half),
              _dateCard('qdate', adha, 'قربانی کی تاریخ', half),
            ]),
            box(context, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: const [Icon(Icons.pets, color: _gd, size: 20), SizedBox(width: 6), Text('قربانی کس جانور کی کی؟', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13))]),
              const SizedBox(height: 8),
              Wrap(spacing: 6, runSpacing: 6, children: [for (final a in _animals) _animalTile(a, (cw - 50) / 4)]),
            ])),
            Wrap(spacing: 8, children: [
              _counter(half),
              _radio('قربانی کس طرح کی؟', Icons.groups, 'qh', _how, half),
              _radio('قربانی کس کی طرف سے کی؟', Icons.family_restroom, 'qb', _behalf, half),
              _radio('اگر قربانی نہیں کی تو وجہ کیا تھی؟', Icons.help, 'qr', _qwhy, half),
            ]),
            _note('qn'),
            _sec(Icons.share, 'گوشت کی تقسیم (اگر کی ہو)'),
            box(context, child: Column(children: [
              _kg('m1', 'غریبوں میں کتنا گوشت بانٹا؟'),
              const SizedBox(height: 8),
              _kg('m2', 'رشتہ داروں کو کتنا دیا؟'),
              const SizedBox(height: 8),
              _kg('m3', 'اپنے گھر کے لیے کتنا رکھا؟'),
            ])),
            _actions(),
            const SizedBox(height: 4),
            Rebuild((c) => _reports(c)),
            _eidCard(),
          ]),
        ),
      ]),
    );
  }

  // ------------------------------------------------------------ pieces
  Widget _banner(String t, String s, IconData ic, VoidCallback f) => InkWell(
        onTap: f,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          height: 84,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1E8A4C), _gd]), borderRadius: BorderRadius.circular(14), border: Border.all(color: gold, width: 1.5)),
          child: Row(children: [
            Icon(ic, color: gold, size: 34),
            const SizedBox(width: 8),
            Expanded(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: AlignmentDirectional.centerStart,
                child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(t, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                  Text(s, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                ]),
              ),
            ),
          ]),
        ),
      );

  Widget _sec(IconData ic, String t) => sectionTitle(t);

  Widget _radio(String title, IconData ic, String key, List<List<String>> opts, double w) => SizedBox(
        width: w,
        child: box(context, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(ic, color: _gd, size: 20),
            const SizedBox(width: 6),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
          ]),
          const Divider(height: 14),
          for (final o in opts)
            InkWell(
              onTap: () => _set(key, o[0]),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Row(children: [
                  Icon(g(key) == o[0] ? Icons.radio_button_checked : Icons.radio_button_unchecked, color: g(key) == o[0] ? Colors.green : Colors.grey, size: 22),
                  const SizedBox(width: 6),
                  Expanded(child: Text(o[1], style: const TextStyle(fontSize: 13))),
                ]),
              ),
            ),
        ])),
      );

  Widget _dateCard(String key, DateTime def, String title, double w) {
    final d = g(key).isEmpty ? def : (DateTime.tryParse(g(key)) ?? def);
    return SizedBox(
      width: w,
      child: InkWell(
        onTap: () async {
          if (!_can()) return;
          final p = await showDatePicker(context: context, initialDate: d, firstDate: DateTime(2000), lastDate: DateTime(2100));
          if (p != null) setState(() => m[key] = _iso(p));
        },
        child: box(context, child: Column(children: [
          Row(children: [
            const Icon(Icons.calendar_month, color: _gd, size: 22),
            const SizedBox(width: 6),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
          ]),
          const SizedBox(height: 6),
          Text(_iso(d), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          Text(hijriText(d), style: TextStyle(fontSize: 12, color: subText(context))),
        ])),
      ),
    );
  }

  Widget _note(String k) => box(context, child: TextField(
        controller: ctr[k],
        enabled: editing,
        maxLines: 2,
        decoration: const InputDecoration(labelText: 'اضافی وضاحت (اختیاری)', hintText: 'اپنی وضاحت یہاں لکھیں…', prefixIcon: Icon(Icons.edit_note, color: _gd)),
      ));

  Widget _kg(String k, String label) => TextField(
        controller: ctr[k],
        enabled: editing,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(labelText: label, suffixText: 'کلوگرام'),
      );

  Widget _animalTile(List<String> a, double w) {
    final sel = g('qa') == a[0];
    return InkWell(
      onTap: () => _set('qa', a[0]),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: w,
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: sel ? const Color(0xFFD5EEDC) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: sel ? Colors.green : Colors.grey.withAlpha(100), width: sel ? 2.5 : 1),
        ),
        child: Column(children: [
          Text(a[2], style: const TextStyle(fontSize: 28)),
          FittedBox(fit: BoxFit.scaleDown, child: Text(a[1], style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: sel ? Colors.black87 : null))),
        ]),
      ),
    );
  }

  Widget _counter(double w) {
    final n = int.tryParse(g('qc')) ?? 1;
    Widget rb(IconData ic, int d) => InkWell(
          onTap: () {
            if (!_can()) return;
            setState(() => m['qc'] = '${clampI(n + d, 1, 99)}');
          },
          child: Container(width: 34, height: 34, decoration: const BoxDecoration(color: _gd, shape: BoxShape.circle), child: Icon(ic, color: Colors.white, size: 20)),
        );
    return SizedBox(
      width: w,
      child: box(context, child: Column(children: [
        Row(children: const [Icon(Icons.pin, color: _gd, size: 20), SizedBox(width: 6), Expanded(child: Text('کتنے جانور قربان کیے؟', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)))]),
        const SizedBox(height: 10),
        Directionality(
          textDirection: TextDirection.ltr,
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            rb(Icons.remove, -1),
            SizedBox(width: 56, child: Text('$n', textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: _gd))),
            rb(Icons.add, 1),
          ]),
        ),
      ])),
    );
  }

  Widget _greeting(String t) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        height: 64,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFFFFF4D6), Color(0xFFDDF1E2)]),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: gold, width: 1.5),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('🌙', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 10),
          Text(t, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: _gd)),
          const SizedBox(width: 10),
          const Text('✨', style: TextStyle(fontSize: 22)),
        ]),
      );

  Widget _actions() {
    Widget b(String t, IconData ic, Color col, VoidCallback f) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: ElevatedButton.icon(
              onPressed: f,
              icon: Icon(ic, size: 18),
              label: FittedBox(fit: BoxFit.scaleDown, child: Text(t, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold))),
              style: ElevatedButton.styleFrom(backgroundColor: col, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 13)),
            ),
          ),
        );
    return Row(children: [
      b('محفوظ کریں', Icons.save, _gd, _save),
      b('ترمیم کریں', Icons.edit, const Color(0xFF1565C0), () {
        setState(() => editing = true);
        toast(context, 'اب ترمیم کر سکتے ہیں');
      }),
      b('حذف کریں', Icons.delete, const Color(0xFFD32F2F), _delete),
    ]);
  }

  // ------------------------------------------------------------ reports
  Widget _reports(BuildContext c) {
    final cur = toHijri(DateTime.now())[0];
    var years = 0, fp = 0, ap = 0, q = 0, animals = 0;
    for (var y = cur - 20; y <= cur + 1; y++) {
      final r = loadEid(y);
      if (r.isEmpty) continue;
      years++;
      if (r['fp'] == 'y') fp++;
      if (r['ap'] == 'y') ap++;
      if (r['qd'] == 'y') {
        q++;
        animals += int.tryParse(r['qc'] ?? '1') ?? 1;
      }
    }
    final r = saved ? m : <String, String>{};
    String yn(String k) => r[k] == 'y' ? 'جی ہاں' : (r[k] == 'n' ? 'نہیں' : '—');
    final animal = _animals.where((a) => a[0] == r['qa']).map((a) => a[1]).join();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _repBox(c, 'عید الاضحیٰ کی سالانہ رپورٹ $hy ھ', Icons.assignment, [
        ['عید الفطر کی نماز؟', yn('fp')],
        ['عید الاضحیٰ کی نماز؟', yn('ap')],
        ['قربانی کی؟', yn('qd')],
        ['کس جانور کی قربانی؟', animal.isEmpty ? '—' : animal],
        ['کتنے جانور قربان کیے؟', r['qd'] == 'y' ? (r['qc'] ?? '1') : '—'],
        ['قربانی کس طرح کی؟', _lbl(_how, r['qh'])],
        ['قربانی کس کی طرف سے؟', _lbl(_behalf, r['qb'])],
        ['اگر نہیں کی تو وجہ', _lbl(_qwhy, r['qr'])],
      ]),
      _repBox(c, 'کل ریکارڈ (تمام سال)', Icons.bar_chart, [
        ['ریکارڈ شدہ سال', '$years'],
        ['عید الفطر کی نمازیں ادا', '$fp'],
        ['عید الاضحیٰ کی نمازیں ادا', '$ap'],
        ['قربانیاں', '$q'],
        ['کل قربان کیے گئے جانور', '$animals'],
      ]),
    ]);
  }

  Widget _repBox(BuildContext c, String t, IconData ic, List<List<String>> rows) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(80))),
        child: Column(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: const BoxDecoration(gradient: LinearGradient(colors: [green, green2]), borderRadius: BorderRadius.vertical(top: Radius.circular(11))),
            child: Row(children: [
              Icon(ic, color: Colors.white),
              const SizedBox(width: 8),
              Expanded(child: Text(t, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15))),
            ]),
          ),
          for (final x in rows)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.grey.withAlpha(50)))),
              child: Row(children: [
                Expanded(child: Text(x[0], style: const TextStyle(fontSize: 13.5))),
                Text(x[1], style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: _gd)),
              ]),
            ),
        ]),
      );

  Widget _eidCard() => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF0E6B43), Color(0xFF06331F)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
          border: Border.all(color: gold, width: 2),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(children: const [
          Text('🌙', style: TextStyle(fontSize: 34)),
          SizedBox(height: 6),
          Text('عید کی خوشیاں', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
          SizedBox(height: 4),
          Text('عبادتوں کے ساتھ\nاور قربانی کے پیغام کے ساتھ', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, height: 1.8)),
        ]),
      );
}
