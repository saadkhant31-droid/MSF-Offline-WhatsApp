import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'home.dart';
import 'settings.dart';
import 'qaza.dart';
import 'qibla.dart';
import 'nafl.dart';
import 'jumah.dart';
import 'eidain.dart';

const _deep = Color(0xFF0B4D2E);
const _okC = Color(0xFF1B7F45);
const _redC = Color(0xFFD32F2F);

// ------------------------------------------------------------------ helpers
DateTime? _parseDay(String s) {
  final p = s.split('-');
  if (p.length != 3) return null;
  final y = int.tryParse(p[0]);
  final m = int.tryParse(p[1]);
  final d = int.tryParse(p[2]);
  if (y == null || m == null || d == null) return null;
  return DateTime(y, m, d);
}

class _PS {
  int offered = 0, jamaat = 0, alone = 0, qaza = 0, pending = 0, slots = 0, days = 0, perfect = 0;
  final List<int> per = List<int>.filled(5, 0);
  double get pct => slots == 0 ? 0.0 : offered / slots;
  int get pc => (pct * 100).round();
}

_PS _prayerStats(Iterable<DateTime> days) {
  final today = dayOnly(DateTime.now());
  final s = _PS();
  for (final d in days) {
    if (d.isAfter(today)) continue;
    s.days++;
    var o = 0;
    for (int i = 0; i < 5; i++) {
      final st = prayerState(d, i);
      s.slots++;
      if (st == 1 || st == 2) {
        s.offered++;
        o++;
        s.per[i]++;
        if (st == 2) {
          s.jamaat++;
        } else {
          s.alone++;
        }
      } else if (st == 3) {
        s.qaza++;
      } else {
        s.pending++;
      }
    }
    if (o == 5) s.perfect++;
  }
  return s;
}

int _dayOffered(DateTime d) {
  var n = 0;
  for (int i = 0; i < 5; i++) {
    final s = prayerState(d, i);
    if (s == 1 || s == 2) n++;
  }
  return n;
}

List<DateTime> _range(DateTime a, DateTime b) {
  final l = <DateTime>[];
  var d = a;
  while (!d.isAfter(b) && l.length < 4000) {
    l.add(d);
    d = addDays(d, 1);
  }
  return l;
}

int _tar(DateTime d) => getI('nk|${dayKey(d)}|tar');
int _para(DateTime d) => getI('nk|${dayKey(d)}|para');
int _tjSt(DateTime d) => getI('tj|${dayKey(d)}|st');

int _naflRakat(DateTime d, List<String> ids) {
  var t = 0;
  for (final id in ids) {
    t += getI('nk|${dayKey(d)}|$id');
  }
  return t;
}

class _NScan {
  final Map<String, int> times = {}, rak = {};
  final Set<String> active = {};
  int tarDays = 0, tarRakat = 0, maxPara = 0;
}

_NScan _scanNafl(DateTime? start) {
  final names = {for (final p in naflIdNames()) p[0]: p[1]};
  final today = dayOnly(DateTime.now());
  final r = _NScan();
  for (final k in sp.getKeys()) {
    if (!k.startsWith('nk|')) continue;
    final p = k.split('|');
    if (p.length != 3) continue;
    final d = _parseDay(p[1]);
    if (d == null || d.isAfter(today)) continue;
    if (start != null && d.isBefore(start)) continue;
    final v = sp.get(k);
    if (v is! int || v <= 0) continue;
    final id = p[2];
    if (id == 'tar') {
      r.tarDays++;
      r.tarRakat += v;
    } else if (id == 'para') {
      if (v > r.maxPara) r.maxPara = v;
    } else if (names.containsKey(id)) {
      r.times[id] = (r.times[id] ?? 0) + 1;
      r.rak[id] = (r.rak[id] ?? 0) + v;
      r.active.add(p[1]);
    }
  }
  return r;
}

Widget _bar(double v, Color col, {double h = 9}) => ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: LinearProgressIndicator(value: v < 0 ? 0.0 : (v > 1 ? 1.0 : v), minHeight: h, color: col, backgroundColor: Colors.grey.withAlpha(60)),
    );

Widget _num(String t, String v, Color col) => Column(children: [
      Text(v, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: col)),
      Text(t, style: const TextStyle(fontSize: 11.5)),
    ]);

Widget _kv(BuildContext c, IconData ic, String k, String v, {Color? col}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [
        Icon(ic, size: 20, color: col ?? green),
        const SizedBox(width: 8),
        Expanded(child: Text(k, style: TextStyle(fontSize: 13.5, color: subText(c)))),
        Text(v, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
      ]),
    );

Widget _chipS(int s, {String? label}) {
  final col = s == 0 ? Colors.orange : statusColor(s);
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: col.withAlpha(35), borderRadius: BorderRadius.circular(20), border: Border.all(color: col)),
    child: Text(label ?? statusLabels[s], style: TextStyle(color: col, fontSize: 12, fontWeight: FontWeight.bold)),
  );
}

Widget _prayerStatsBox(BuildContext c, _PS s) => box(
      c,
      child: Column(children: [
        Text('${s.pc}٪', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold, color: green)),
        Text('ادا شدہ نمازیں: ${s.offered} / ${s.slots}'),
        const SizedBox(height: 8),
        _bar(s.pct, green, h: 10),
        const SizedBox(height: 12),
        Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _num('با جماعت', '${s.jamaat}', statusColor(2)),
          _num('اکیلے', '${s.alone}', statusColor(1)),
          _num('قضا', '${s.qaza}', statusColor(3)),
          _num('باقی', '${s.pending}', Colors.orange),
        ]),
      ]),
    );

Widget _perPrayerBox(BuildContext c, _PS s) => box(
      c,
      child: Column(children: [
        for (int i = 0; i < 5; i++)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(children: [
              SizedBox(width: 52, child: Text(prayerInfos[i].name, style: const TextStyle(fontWeight: FontWeight.bold))),
              Expanded(child: _bar(s.days == 0 ? 0.0 : s.per[i] / s.days, green)),
              SizedBox(width: 56, child: Text('${s.per[i]} / ${s.days}', textAlign: TextAlign.end, style: const TextStyle(fontSize: 12))),
            ]),
          ),
      ]),
    );

// ------------------------------------------------------------------ bottom nav
Widget _nav(BuildContext c, bool hub) {
  const items = <List<dynamic>>[
    [Icons.home, 'ہوم'],
    [Icons.list_alt, 'فہرست'],
    [Icons.bar_chart, 'رپورٹس'],
    [Icons.settings, 'سیٹنگز'],
    [Icons.menu, 'مزید'],
  ];
  void act(int i) {
    switch (i) {
      case 0:
        Navigator.of(c).popUntil((r) => r.isFirst);
        shellHome?.call();
        break;
      case 1:
        go(c, ListPage(features: allFeatures()));
        break;
      case 2:
        if (!hub) Navigator.of(c).maybePop();
        break;
      case 3:
        go(c, const SettingsScreen());
        break;
      case 4:
        go(c, MorePage(features: allFeatures()));
        break;
    }
  }

  return Container(
    color: const Color(0xFF0B3D2A),
    padding: EdgeInsets.only(bottom: MediaQuery.of(c).padding.bottom, top: 4),
    child: Directionality(
      textDirection: TextDirection.ltr,
      child: Row(children: [
        for (int i = 0; i < items.length; i++)
          Expanded(
            child: InkWell(
              onTap: () => act(i),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
                padding: const EdgeInsets.symmetric(vertical: 5),
                decoration: i == 2
                    ? BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF7CD65B), width: 1.4), color: const Color(0xFF14803F))
                    : null,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(items[i][0] as IconData, color: i == 2 ? gold : Colors.white, size: 24),
                  const SizedBox(height: 2),
                  FittedBox(fit: BoxFit.scaleDown, child: Text(items[i][1] as String, style: TextStyle(color: i == 2 ? gold : Colors.white, fontSize: 11, fontWeight: FontWeight.bold))),
                ]),
              ),
            ),
          ),
      ]),
    ),
  );
}

Widget _header(BuildContext c, double w) => SizedBox(
      width: w,
      height: w * 236 / 1024,
      child: Stack(children: [
        Positioned.fill(child: Image.asset('assets/reports/header.png', fit: BoxFit.fill)),
        Positioned(
          left: w * 0.018,
          top: w * 60 / 1024,
          width: w * 0.165,
          height: w * 66 / 1024,
          child: Material(
            color: Colors.transparent,
            child: InkWell(borderRadius: BorderRadius.circular(30), onTap: () => Navigator.maybePop(c)),
          ),
        ),
      ]),
    );

Widget _footer() => Padding(
      padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
      child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset('assets/reports/footer.png', width: double.infinity, fit: BoxFit.fitWidth)),
    );

// ------------------------------------------------------------------ page scaffold for sub-reports
class _RPage extends StatelessWidget {
  final String title, sub;
  final IconData icon;
  final Color color;
  final List<Widget> children;
  final String? copy;
  const _RPage({required this.title, required this.sub, required this.icon, required this.color, required this.children, this.copy});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
      child: Scaffold(
        backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
        body: ListView(padding: EdgeInsets.zero, children: [
          _header(context, w),
          Container(
            margin: const EdgeInsets.fromLTRB(10, 8, 10, 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [_deep, Color.lerp(_deep, color, 0.55)!]),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: gold.withAlpha(140)),
            ),
            child: Row(children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white12, border: Border.all(color: gold, width: 1.6)),
                child: Icon(icon, color: Colors.white, size: 30),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 2),
                  Text(sub, style: const TextStyle(color: Colors.white70, fontSize: 12.5, height: 1.4)),
                ]),
              ),
            ]),
          ),
          Padding(padding: const EdgeInsets.fromLTRB(10, 0, 10, 4), child: Column(children: children)),
          if (copy != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
              child: FilledButton.icon(onPressed: () => copyText(context, copy!), icon: const Icon(Icons.copy), label: const Text('رپورٹ کاپی / شیئر کریں')),
            ),
          _footer(),
        ]),
        bottomNavigationBar: _nav(context, false),
      ),
    );
  }
}

// ------------------------------------------------------------------ HUB
class _RC {
  final String title, sub, btn;
  final IconData icon;
  final Color color;
  final Widget Function() page;
  _RC(this.title, this.sub, this.btn, this.icon, this.color, this.page);
}

class ReportScreen extends StatelessWidget {
  const ReportScreen({super.key});

  Widget _card(BuildContext c, _RC r) => InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => go(c, r.page()),
        child: Container(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
          decoration: BoxDecoration(
            color: isDark(c) ? const Color(0xFF1F2B25) : Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: r.color.withAlpha(120), width: 1.4),
            boxShadow: [BoxShadow(color: Colors.black.withAlpha(18), blurRadius: 5, offset: const Offset(0, 2))],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(color: r.color, shape: BoxShape.circle),
                child: Icon(r.icon, color: Colors.white, size: 27),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerRight,
                    child: Text(r.title, style: TextStyle(color: r.color, fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(height: 2),
                  SizedBox(
                    height: 28,
                    child: Align(
                      alignment: Alignment.topRight,
                      child: Text(r.sub, textAlign: TextAlign.right, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, color: subText(c), height: 1.3)),
                    ),
                  ),
                ]),
              ),
              Icon(Icons.chevron_right, color: r.color, size: 20),
            ]),
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
              decoration: BoxDecoration(color: r.color.withAlpha(32), borderRadius: BorderRadius.circular(8)),
              child: FittedBox(fit: BoxFit.scaleDown, child: Text(r.btn, style: TextStyle(color: r.color, fontSize: 11.5, fontWeight: FontWeight.bold))),
            ),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final cards = <_RC>[
      _RC('روزانہ رپورٹ', 'آج کی نمازیں، نوافل، قضا اور دیگر تفصیلات', 'آج کی مکمل رپورٹ دیکھیں', Icons.calendar_month, const Color(0xFF1B7A1B), () => const _DailyReport()),
      _RC('ہفتہ وار رپورٹ', 'پچھلے 7 دنوں کی نمازوں کا ریکارڈ', 'ہفتہ وار رپورٹ دیکھیں', Icons.calendar_view_week, const Color(0xFF0D47A1), () => const _PeriodReport(0)),
      _RC('ماہانہ رپورٹ', 'مکمل مہینے کی نمازوں کا خلاصہ', 'ماہانہ رپورٹ دیکھیں', Icons.calendar_month, const Color(0xFF5B21B6), () => const _PeriodReport(1)),
      _RC('سالانہ رپورٹ', 'پورے سال کی نمازوں کا ریکارڈ', 'سالانہ رپورٹ دیکھیں', Icons.event_note, const Color(0xFFE65100), () => const _PeriodReport(2)),
      _RC('قضا نمازوں کا حساب', 'باقی قضا نمازوں کی تفصیل', 'قضا نمازوں کی رپورٹ دیکھیں', Icons.alarm, const Color(0xFFD32F2F), () => const QazaReportScreen()),
      _RC('تراویح کی رپورٹ', 'رمضان کی تراویح کا ریکارڈ', 'تراویح کی رپورٹ دیکھیں', Icons.mosque, const Color(0xFF00796B), () => const _TaraweehReport()),
      _RC('نوافل نمازوں کی رپورٹ', 'تمام نفل نمازوں کا مکمل ریکارڈ', 'نوافل کی رپورٹ دیکھیں', Icons.self_improvement, const Color(0xFF0D3B8C), () => const _NaflReport()),
      _RC('جمعہ و عیدین کی رپورٹ', 'نماز جمعہ، عید الفطر، عید الاضحیٰ کا ریکارڈ', 'جمعہ و عیدین کی رپورٹ دیکھیں', Icons.account_balance, const Color(0xFF6A1B9A), () => const _JumahEidReport()),
      _RC('قبلہ اور مقام کی رپورٹ', 'قبلہ کی سمت اور مقام کی تفصیل', 'قبلہ کی رپورٹ دیکھیں', Icons.explore, const Color(0xFF556B14), () => const _QiblaReport()),
      _RC('تجزیاتی رپورٹ', 'مجموعی اعداد و شمار اور گراف', 'تجزیاتی رپورٹ دیکھیں', Icons.bar_chart, const Color(0xFF424242), () => const _AnalyticsReport()),
    ];
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
      child: Scaffold(
        backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
        body: ListView(padding: EdgeInsets.zero, children: [
          _header(context, w),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
            child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset('assets/reports/banner.png', width: double.infinity, fit: BoxFit.fitWidth)),
          ),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 0, 10, 4),
              child: Column(children: [
                for (int i = 0; i < cards.length; i += 2)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Expanded(child: _card(context, cards[i])),
                      const SizedBox(width: 10),
                      Expanded(child: _card(context, cards[i + 1])),
                    ]),
                  ),
              ]),
            ),
          ),
          _footer(),
        ]),
        bottomNavigationBar: _nav(context, true),
      ),
    );
  }
}

// ------------------------------------------------------------------ 1. DAILY
class _DailyReport extends StatefulWidget {
  const _DailyReport();
  @override
  State<_DailyReport> createState() => _DailyState();
}

class _DailyState extends State<_DailyReport> {
  DateTime date = dayOnly(DateTime.now());

  void _move(int n) {
    final nd = addDays(date, n);
    if (nd.isAfter(dayOnly(DateTime.now()))) return;
    setState(() => date = nd);
  }

  @override
  Widget build(BuildContext context) => Rebuild((c) {
        final s = _prayerStats([date]);
        final names = naflIdNames();
        final ids = names.map((e) => e[0]).toList();
        final dk = dayKey(date);
        final naflRows = <List<String>>[];
        for (final p in names) {
          final v = getI('nk|$dk|${p[0]}');
          if (v > 0) naflRows.add([p[1], '$v رکعات']);
        }
        final tar = _tar(date);
        final para = _para(date);
        final tj = _tjSt(date);
        final isFri = date.weekday == DateTime.friday;
        final jr = isFri ? JRec.load(date) : null;
        final qlog = qazaLog().where((e) => e['d'] == dk).length;

        final text = StringBuffer('روزانہ رپورٹ - ${fmtDate(date)}\n${hijriText(date)}\n');
        text.writeln('نمازیں: ${s.offered} / 5 ادا (با جماعت ${s.jamaat}، قضا ${s.qaza}، باقی ${s.pending})');
        for (int i = 0; i < 5; i++) {
          text.writeln('${prayerInfos[i].name}: ${prayerState(date, i) == 0 ? 'باقی' : statusLabels[prayerState(date, i)]}');
        }
        text.writeln('نوافل کی کل رکعات: ${_naflRakat(date, ids)}');
        if (tar > 0) text.writeln('تراویح: $tar رکعات، پارہ $para');
        text.writeln('کل باقی قضا نمازیں: ${qazaPendingTotal()}');

        return _RPage(
          title: 'روزانہ رپورٹ',
          sub: '${fmtDate(date)} • ${hijriText(date)}',
          icon: Icons.calendar_month,
          color: const Color(0xFF1B7A1B),
          copy: text.toString(),
          children: [
            DateNav(label: fmtDate(date), onPrev: () => _move(-1), onNext: () => _move(1)),
            _prayerStatsBox(c, s),
            sectionTitle('پانچ وقت کی نماز'),
            box(
              c,
              child: Column(children: [
                for (int i = 0; i < 5; i++)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Row(children: [
                      Icon(prayerInfos[i].icon, color: green, size: 22),
                      const SizedBox(width: 10),
                      Expanded(child: Text(prayerInfos[i].name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                      _chipS(prayerState(date, i)),
                    ]),
                  ),
              ]),
            ),
            sectionTitle('نوافل، تراویح اور تہجد'),
            box(
              c,
              child: Column(children: [
                _kv(c, Icons.self_improvement, 'نوافل کی کل رکعات', '${_naflRakat(date, ids)}'),
                for (final r in naflRows) _kv(c, Icons.check_circle, r[0], r[1], col: _okC),
                _kv(c, Icons.mosque, 'تراویح', tar > 0 ? '$tar رکعات • پارہ $para' : 'ریکارڈ نہیں'),
                _kv(c, Icons.nightlight_round, 'تہجد', tj == 0 ? 'ریکارڈ نہیں' : (tj == 1 ? 'ادا کی' : 'نہیں پڑھی'), col: tj > 1 ? _redC : null),
                if (isFri && jr != null) _kv(c, Icons.account_balance, 'جمعہ کی نماز', !jr.saved ? 'ریکارڈ نہیں' : (jr.st == 'yes' ? 'پڑھی' : 'نہیں پڑھی'), col: (jr.saved && jr.st != 'yes') ? _redC : null),
              ]),
            ),
            sectionTitle('قضا نمازیں'),
            box(
              c,
              child: Column(children: [
                _kv(c, Icons.alarm, 'کل باقی قضا نمازیں', '${qazaPendingTotal()}', col: _redC),
                _kv(c, Icons.add_alarm, 'اس دن شامل ہونے والی قضا', '$qlog'),
                _kv(c, Icons.done_all, 'اب تک ادا کی گئی قضا', '${qazaMadeTotal()}'),
              ]),
            ),
          ],
        );
      });
}

// ------------------------------------------------------------------ 2-4. WEEK / MONTH / YEAR
class _PeriodReport extends StatefulWidget {
  final int mode; // 0 week, 1 month, 2 year
  const _PeriodReport(this.mode);
  @override
  State<_PeriodReport> createState() => _PeriodState();
}

class _PeriodState extends State<_PeriodReport> {
  late DateTime anchor;

  @override
  void initState() {
    super.initState();
    final t = dayOnly(DateTime.now());
    anchor = widget.mode == 0 ? t : (widget.mode == 1 ? DateTime(t.year, t.month, 1) : DateTime(t.year, 1, 1));
  }

  void _move(int dir) {
    final today = dayOnly(DateTime.now());
    DateTime nd;
    if (widget.mode == 0) {
      nd = addDays(anchor, dir * 7);
      if (nd.isAfter(today)) nd = today;
    } else if (widget.mode == 1) {
      nd = DateTime(anchor.year, anchor.month + dir, 1);
      if (nd.isAfter(today)) return;
    } else {
      nd = DateTime(anchor.year + dir, 1, 1);
      if (nd.isAfter(today)) return;
    }
    setState(() => anchor = nd);
  }

  Color _sq(DateTime d, int o) {
    if (d.isAfter(dayOnly(DateTime.now()))) return Colors.grey.withAlpha(50);
    if (o == 5) return _okC;
    if (o >= 3) return const Color(0xFF7BC67E);
    if (o >= 1) return const Color(0xFFFFB74D);
    return const Color(0xFFEF9A9A);
  }

  @override
  Widget build(BuildContext context) => Rebuild((c) {
        final mode = widget.mode;
        late final List<DateTime> days;
        late final String label;
        if (mode == 0) {
          days = _range(addDays(anchor, -6), anchor);
          label = '${fmtShort(days.first)} تا ${fmtShort(anchor)} ${anchor.year}';
        } else if (mode == 1) {
          final last = DateTime(anchor.year, anchor.month + 1, 0);
          days = _range(anchor, last);
          label = '${urduMonths[anchor.month - 1]} ${anchor.year}';
        } else {
          days = _range(DateTime(anchor.year, 1, 1), DateTime(anchor.year, 12, 31));
          label = 'سال ${anchor.year}';
        }
        final today = dayOnly(DateTime.now());
        final past = days.where((d) => !d.isAfter(today)).toList();
        final s = _prayerStats(days);
        final ids = naflIdNames().map((e) => e[0]).toList();
        var nafl = 0, tarDays = 0, tarRak = 0, tjDays = 0, friYes = 0, friAll = 0;
        for (final d in past) {
          nafl += _naflRakat(d, ids);
          final t = _tar(d);
          if (t > 0) {
            tarDays++;
            tarRak += t;
          }
          if (_tjSt(d) == 1) tjDays++;
          if (d.weekday == DateTime.friday) {
            friAll++;
            final r = JRec.load(d);
            if (r.saved && r.st == 'yes') friYes++;
          }
        }
        final qadded = qazaLog().where((e) {
          final d = _parseDay('${e['d']}');
          return d != null && !d.isBefore(days.first) && !d.isAfter(days.last);
        }).length;

        final title = mode == 0 ? 'ہفتہ وار رپورٹ' : (mode == 1 ? 'ماہانہ رپورٹ' : 'سالانہ رپورٹ');
        final text = StringBuffer('$title - $label\n');
        text.writeln('ادا: ${s.offered} / ${s.slots} (${s.pc}٪)');
        text.writeln('با جماعت: ${s.jamaat} • اکیلے: ${s.alone} • قضا: ${s.qaza} • باقی: ${s.pending}');
        for (int i = 0; i < 5; i++) {
          text.writeln('${prayerInfos[i].name}: ${s.per[i]} / ${s.days}');
        }
        text.writeln('مکمل 5 نمازوں والے دن: ${s.perfect}');
        text.writeln('نوافل کی رکعات: $nafl • تراویح: $tarDays دن • تہجد: $tjDays دن • جمعہ: $friYes / $friAll');

        final breakdown = <Widget>[];
        if (mode == 0) {
          breakdown.add(sectionTitle('روزانہ تفصیل'));
          for (final d in days.reversed) {
            breakdown.add(box(
              c,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(children: [
                Expanded(child: Text(fmtDate(d), style: const TextStyle(fontSize: 13))),
                for (int i = 0; i < 5; i++)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: Icon(
                      prayerState(d, i) == 3 ? Icons.cancel : (prayerState(d, i) == 0 ? Icons.circle_outlined : Icons.check_circle),
                      size: 18,
                      color: prayerState(d, i) == 0 ? Colors.grey : statusColor(prayerState(d, i)),
                    ),
                  ),
              ]),
            ));
          }
        } else if (mode == 1) {
          breakdown.add(sectionTitle('دن بہ دن (رنگ = ادا شدہ نمازیں)'));
          breakdown.add(box(
            c,
            child: Column(children: [
              Directionality(
                textDirection: TextDirection.ltr,
                child: Wrap(spacing: 5, runSpacing: 5, children: [
                  for (final d in days)
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(color: _sq(d, _dayOffered(d)), borderRadius: BorderRadius.circular(8)),
                      child: Center(child: Text('${d.day}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: d.isAfter(today) ? Colors.grey : Colors.black87))),
                    ),
                ]),
              ),
              const SizedBox(height: 10),
              Wrap(spacing: 12, runSpacing: 4, children: [
                for (final e in [
                  [_okC, '5 نمازیں'],
                  [const Color(0xFF7BC67E), '3-4'],
                  [const Color(0xFFFFB74D), '1-2'],
                  [const Color(0xFFEF9A9A), 'کوئی نہیں'],
                ])
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Container(width: 12, height: 12, decoration: BoxDecoration(color: e[0] as Color, borderRadius: BorderRadius.circular(3))),
                    const SizedBox(width: 4),
                    Text(e[1] as String, style: const TextStyle(fontSize: 11)),
                  ]),
              ]),
            ]),
          ));
        } else {
          breakdown.add(sectionTitle('مہینہ وار'));
          final rows = <Widget>[];
          for (int m = 1; m <= 12; m++) {
            final md = days.where((d) => d.month == m);
            final ms = _prayerStats(md);
            rows.add(Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Row(children: [
                SizedBox(width: 62, child: Text(urduMonths[m - 1], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
                Expanded(child: _bar(ms.pct, green)),
                SizedBox(width: 44, child: Text(ms.slots == 0 ? '-' : '${ms.pc}٪', textAlign: TextAlign.end, style: const TextStyle(fontSize: 12))),
              ]),
            ));
          }
          breakdown.add(box(c, child: Column(children: rows)));
        }

        return _RPage(
          title: title,
          sub: label,
          icon: mode == 0 ? Icons.calendar_view_week : (mode == 1 ? Icons.calendar_month : Icons.event_note),
          color: mode == 0 ? const Color(0xFF0D47A1) : (mode == 1 ? const Color(0xFF5B21B6) : const Color(0xFFE65100)),
          copy: text.toString(),
          children: [
            DateNav(label: label, onPrev: () => _move(-1), onNext: () => _move(1)),
            _prayerStatsBox(c, s),
            sectionTitle('ہر نماز کا ریکارڈ'),
            _perPrayerBox(c, s),
            sectionTitle('دیگر عبادات'),
            box(
              c,
              child: Column(children: [
                _kv(c, Icons.verified, 'مکمل 5 نمازوں والے دن', '${s.perfect} / ${s.days}'),
                _kv(c, Icons.self_improvement, 'نوافل کی کل رکعات', '$nafl'),
                _kv(c, Icons.mosque, 'تراویح', '$tarDays دن • $tarRak رکعات'),
                _kv(c, Icons.nightlight_round, 'تہجد پڑھنے کے دن', '$tjDays'),
                _kv(c, Icons.account_balance, 'جمعہ کی نماز', '$friYes / $friAll'),
                _kv(c, Icons.alarm, 'نئی قضا نمازیں', '$qadded', col: _redC),
              ]),
            ),
            ...breakdown,
          ],
        );
      });
}

// ------------------------------------------------------------------ 6. TARAWEEH
class _TaraweehReport extends StatefulWidget {
  const _TaraweehReport();
  @override
  State<_TaraweehReport> createState() => _TaraweehState();
}

class _TaraweehState extends State<_TaraweehReport> {
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month, 1);

  void _move(int dir) {
    final nd = DateTime(month.year, month.month + dir, 1);
    if (nd.isAfter(dayOnly(DateTime.now()))) return;
    setState(() => month = nd);
  }

  @override
  Widget build(BuildContext context) => Rebuild((c) {
        final today = dayOnly(DateTime.now());
        final days = _range(month, DateTime(month.year, month.month + 1, 0)).where((d) => !d.isAfter(today)).toList();
        var cnt = 0, rak = 0, full = 0, maxPara = 0;
        final rows = <DateTime>[];
        for (final d in days) {
          final t = _tar(d);
          if (t > 0) {
            cnt++;
            rak += t;
            rows.add(d);
            if (t >= 20) full++;
          }
          final p = _para(d);
          if (p > maxPara) maxPara = p;
        }
        final all = _scanNafl(null);
        final hij = toHijri(month.add(const Duration(days: 14)));
        final label = '${urduMonths[month.month - 1]} ${month.year}';
        final text = StringBuffer('تراویح رپورٹ - $label\n');
        text.writeln('تراویح پڑھنے کے دن: $cnt • کل رکعات: $rak • مکمل 20 رکعات: $full دن • پارہ: $maxPara / 30');
        text.writeln('کل ریکارڈ (تمام وقت): ${all.tarDays} دن، ${all.tarRakat} رکعات');
        return _RPage(
          title: 'تراویح کی رپورٹ',
          sub: 'رمضان کی تراویح کا ریکارڈ • اسلامی ماہ: ${hijriMonths[clampI(hij[1] - 1, 0, 11)]} ${hij[0]}ھ',
          icon: Icons.mosque,
          color: const Color(0xFF00796B),
          copy: text.toString(),
          children: [
            DateNav(label: label, onPrev: () => _move(-1), onNext: () => _move(1)),
            box(
              c,
              child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _num('تراویح کے دن', '$cnt', green),
                  _num('کل رکعات', '$rak', const Color(0xFF00796B)),
                  _num('مکمل 20', '$full', gold),
                  _num('پارہ', '$maxPara', const Color(0xFF6D28D9)),
                ]),
                const SizedBox(height: 10),
                _bar(maxPara / 30, const Color(0xFF6D28D9)),
                const SizedBox(height: 4),
                Text(maxPara >= 30 ? 'ماشاءاللہ، قرآن مکمل ہوا' : 'قرآن: $maxPara / 30 پارے', style: TextStyle(fontSize: 12, color: subText(c))),
              ]),
            ),
            sectionTitle('تمام وقت کا خلاصہ'),
            box(c, child: Column(children: [
              _kv(c, Icons.event_available, 'کل دن (تراویح کا ریکارڈ)', '${all.tarDays}'),
              _kv(c, Icons.format_list_numbered, 'کل رکعات', '${all.tarRakat}'),
              _kv(c, Icons.menu_book, 'سب سے زیادہ پارہ', '${all.maxPara}'),
            ])),
            sectionTitle('دن بہ دن ریکارڈ'),
            if (rows.isEmpty) box(c, child: Center(child: Text('اس مہینے کا کوئی ریکارڈ نہیں', style: TextStyle(color: subText(c))))),
            for (final d in rows.reversed)
              box(
                c,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Column(children: [
                  Row(children: [
                    Expanded(child: Text(fmtDate(d), style: const TextStyle(fontSize: 13))),
                    Text('${_tar(d)} رکعات', style: const TextStyle(fontWeight: FontWeight.bold, color: green)),
                    if (_para(d) > 0) Text('  • پارہ ${_para(d)}', style: TextStyle(fontSize: 12, color: subText(c))),
                  ]),
                  const SizedBox(height: 5),
                  _bar(_tar(d) / 20, const Color(0xFF00796B), h: 7),
                ]),
              ),
          ],
        );
      });
}

// ------------------------------------------------------------------ 7. NAFL
class _NaflReport extends StatefulWidget {
  const _NaflReport();
  @override
  State<_NaflReport> createState() => _NaflRState();
}

class _NaflRState extends State<_NaflReport> {
  int range = 30; // days, 0 = all

  @override
  Widget build(BuildContext context) => Rebuild((c) {
        final today = dayOnly(DateTime.now());
        final start = range == 0 ? null : addDays(today, -(range - 1));
        final r = _scanNafl(start);
        final names = {for (final p in naflIdNames()) p[0]: p[1]};
        final ids = r.rak.keys.toList()..sort((a, b) => (r.rak[b] ?? 0).compareTo(r.rak[a] ?? 0));
        var total = 0;
        for (final v in r.rak.values) {
          total += v;
        }
        final mx = ids.isEmpty ? 1 : (r.rak[ids.first] ?? 1);
        final label = range == 0 ? 'تمام وقت' : (range == 7 ? 'پچھلے 7 دن' : (range == 30 ? 'پچھلے 30 دن' : 'پچھلا 1 سال'));
        final text = StringBuffer('نوافل رپورٹ - $label\nکل رکعات: $total • فعال دن: ${r.active.length}\n');
        for (final id in ids) {
          text.writeln('${names[id]}: ${r.times[id]} بار، ${r.rak[id]} رکعات');
        }
        return _RPage(
          title: 'نوافل کی رپورٹ',
          sub: 'تمام نفل نمازوں کا مکمل ریکارڈ • $label',
          icon: Icons.self_improvement,
          color: const Color(0xFF0D3B8C),
          copy: text.toString(),
          children: [
            Directionality(
              textDirection: TextDirection.ltr,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 7, label: Text('7 دن')),
                  ButtonSegment(value: 30, label: Text('30 دن')),
                  ButtonSegment(value: 365, label: Text('سال')),
                  ButtonSegment(value: 0, label: Text('کل')),
                ],
                selected: {range},
                onSelectionChanged: (s) => setState(() => range = s.first),
              ),
            ),
            const SizedBox(height: 10),
            box(
              c,
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                _num('کل رکعات', '$total', const Color(0xFF0D3B8C)),
                _num('فعال دن', '${r.active.length}', green),
                _num('اقسام', '${ids.length}', const Color(0xFF6D28D9)),
              ]),
            ),
            sectionTitle('نفل کی تفصیل'),
            if (ids.isEmpty) box(c, child: Center(child: Text('اس مدت کا کوئی نفل ریکارڈ نہیں', style: TextStyle(color: subText(c))))),
            for (final id in ids)
              box(
                c,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                child: Column(children: [
                  Row(children: [
                    Expanded(child: Text(names[id] ?? id, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold))),
                    Text('${r.times[id]} بار • ${r.rak[id]} رکعات', style: const TextStyle(fontSize: 12.5, color: green, fontWeight: FontWeight.bold)),
                  ]),
                  const SizedBox(height: 6),
                  _bar((r.rak[id] ?? 0) / mx, const Color(0xFF0D3B8C), h: 7),
                ]),
              ),
          ],
        );
      });
}

// ------------------------------------------------------------------ 8. JUMAH & EIDAIN
class _JumahEidReport extends StatefulWidget {
  const _JumahEidReport();
  @override
  State<_JumahEidReport> createState() => _JEState();
}

class _JEState extends State<_JumahEidReport> {
  int year = DateTime.now().year;

  String _yn(String v) => v == 'y' ? 'ہاں ✓' : (v == 'n' ? 'نہیں ✗' : 'ریکارڈ نہیں');
  Color? _ynC(String v) => v == 'y' ? _okC : (v == 'n' ? _redC : null);

  @override
  Widget build(BuildContext context) => Rebuild((c) {
        final today = dayOnly(DateTime.now());
        final fridays = _range(DateTime(year, 1, 1), DateTime(year, 12, 31)).where((d) => d.weekday == DateTime.friday && !d.isAfter(today)).toList();
        var yes = 0, no = 0, rak = 0;
        for (final f in fridays) {
          final r = JRec.load(f);
          if (!r.saved) continue;
          if (r.st == 'yes') {
            yes++;
            for (int i = 0; i < r.done.length && i < r.rk.length; i++) {
              if (r.done[i]) rak += r.rk[i];
            }
          } else {
            no++;
          }
        }
        final eidYears = <int>[];
        for (final k in sp.getKeys()) {
          if (k.startsWith('eid:')) {
            final y = int.tryParse(k.substring(4));
            if (y != null) eidYears.add(y);
          }
        }
        eidYears.sort((a, b) => b.compareTo(a));
        final text = StringBuffer('جمعہ و عیدین رپورٹ - $year\n');
        text.writeln('جمعہ: پڑھے $yes • نہیں پڑھے $no • ریکارڈ نہیں ${fridays.length - yes - no} (کل ${fridays.length})');
        for (final y in eidYears) {
          final m = loadEid(y);
          text.writeln('$y ھ: عید الفطر ${_yn(m['fp'] ?? '')}، عید الاضحیٰ ${_yn(m['ap'] ?? '')}، قربانی ${_yn(m['qd'] ?? '')}');
        }
        return _RPage(
          title: 'جمعہ و عیدین کی رپورٹ',
          sub: 'نماز جمعہ، عید الفطر، عید الاضحیٰ کا ریکارڈ',
          icon: Icons.account_balance,
          color: const Color(0xFF6A1B9A),
          copy: text.toString(),
          children: [
            DateNav(
              label: 'سال $year',
              onPrev: () => setState(() => year--),
              onNext: () {
                if (year < DateTime.now().year) setState(() => year++);
              },
            ),
            box(
              c,
              child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  _num('پڑھے', '$yes', _okC),
                  _num('نہیں پڑھے', '$no', _redC),
                  _num('ریکارڈ نہیں', '${fridays.length - yes - no}', Colors.grey),
                  _num('کل رکعات', '$rak', const Color(0xFF6A1B9A)),
                ]),
                const SizedBox(height: 10),
                _bar(fridays.isEmpty ? 0.0 : yes / fridays.length, _okC, h: 10),
                const SizedBox(height: 4),
                Text('$year میں اب تک ${fridays.length} جمعے', style: TextStyle(fontSize: 12, color: subText(c))),
              ]),
            ),
            sectionTitle('جمعہ کی تفصیل'),
            if (fridays.isEmpty) box(c, child: Center(child: Text('اس سال کا کوئی جمعہ نہیں', style: TextStyle(color: subText(c))))),
            for (final f in fridays.reversed)
              (() {
                final r = JRec.load(f);
                final s = !r.saved ? 0 : (r.st == 'yes' ? 1 : 3);
                return box(
                  c,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(fmtDate(f), style: const TextStyle(fontSize: 13)),
                        if (r.mosque.isNotEmpty) Text('مسجد: ${r.mosque}', style: TextStyle(fontSize: 11, color: subText(c))),
                      ]),
                    ),
                    _chipS(s, label: s == 0 ? 'ریکارڈ نہیں' : (s == 1 ? 'پڑھی' : 'نہیں پڑھی')),
                  ]),
                );
              })(),
            sectionTitle('عیدین اور قربانی'),
            if (eidYears.isEmpty) box(c, child: Center(child: Text('ابھی عیدین کا کوئی ریکارڈ نہیں', style: TextStyle(color: subText(c))))),
            for (final y in eidYears)
              (() {
                final m = loadEid(y);
                return box(
                  c,
                  child: Column(children: [
                    Align(alignment: Alignment.centerRight, child: Text('$y ھ', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: green))),
                    _kv(c, Icons.celebration, 'عید الفطر کی نماز', _yn(m['fp'] ?? ''), col: _ynC(m['fp'] ?? '')),
                    _kv(c, Icons.celebration, 'عید الاضحیٰ کی نماز', _yn(m['ap'] ?? ''), col: _ynC(m['ap'] ?? '')),
                    _kv(c, Icons.pets, 'قربانی', _yn(m['qd'] ?? ''), col: _ynC(m['qd'] ?? '')),
                  ]),
                );
              })(),
          ],
        );
      });
}

// ------------------------------------------------------------------ 9. QIBLA & PLACE
class _QiblaReport extends StatelessWidget {
  const _QiblaReport();

  String _dirName(double b) {
    const n = ['شمال', 'شمال مشرق', 'مشرق', 'جنوب مشرق', 'جنوب', 'جنوب مغرب', 'مغرب', 'شمال مغرب'];
    return n[((b + 22.5) ~/ 45) % 8];
  }

  @override
  Widget build(BuildContext context) => Rebuild((c) {
        final city = currentCity();
        final b = qiblaBearing(city.lat, city.lng);
        final dist = kaabaDistance(city.lat, city.lng);
        final now = DateTime.now();
        final off = now.timeZoneOffset;
        final sign = off.isNegative ? '-' : '+';
        final oh = off.abs().inHours;
        final om = off.abs().inMinutes % 60;
        final text = StringBuffer('قبلہ اور مقام کی رپورٹ\n');
        text.writeln('شہر: ${city.name} (${city.lat.toStringAsFixed(4)}, ${city.lng.toStringAsFixed(4)})');
        text.writeln('قبلہ: ${b.toStringAsFixed(1)}° (${_dirName(b)}) • فاصلہ: ${dist.round()} کلومیٹر');
        return _RPage(
          title: 'قبلہ اور مقام کی رپورٹ',
          sub: 'قبلہ کی سمت اور مقام کی تفصیل',
          icon: Icons.explore,
          color: const Color(0xFF556B14),
          copy: text.toString(),
          children: [
            box(
              c,
              child: Column(children: [
                SizedBox(
                  width: 150,
                  height: 150,
                  child: Stack(alignment: Alignment.center, children: [
                    Container(decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: green, width: 3), color: isDark(c) ? const Color(0xFF14201A) : Colors.white)),
                    const Align(alignment: Alignment.topCenter, child: Padding(padding: EdgeInsets.only(top: 6), child: Text('شمال', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: _redC)))),
                    Transform.rotate(angle: b * math.pi / 180, child: const Icon(Icons.navigation, size: 80, color: green)),
                  ]),
                ),
                const SizedBox(height: 6),
                Text('${b.toStringAsFixed(1)}°', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: green)),
                Text('${_dirName(b)} کی طرف (شمال سے گھڑی کی سمت)', style: TextStyle(fontSize: 12, color: subText(c))),
              ]),
            ),
            sectionTitle('مقام کی تفصیل'),
            box(
              c,
              child: Column(children: [
                _kv(c, Icons.location_city, 'شہر', city.name),
                _kv(c, Icons.my_location, 'عرض بلد (Latitude)', city.lat.toStringAsFixed(4)),
                _kv(c, Icons.my_location, 'طول بلد (Longitude)', city.lng.toStringAsFixed(4)),
                _kv(c, Icons.explore, 'قبلہ کا زاویہ', '${b.toStringAsFixed(1)}°'),
                _kv(c, Icons.navigation, 'قبلہ کی سمت', _dirName(b)),
                _kv(c, Icons.straighten, 'کعبہ شریف تک فاصلہ', '${dist.round()} کلومیٹر'),
                _kv(c, Icons.public, 'ٹائم زون', 'UTC$sign${oh.toString().padLeft(2, '0')}:${om.toString().padLeft(2, '0')}'),
                _kv(c, Icons.calendar_month, 'آج کی تاریخ', fmtDate(now)),
                _kv(c, Icons.nightlight_round, 'ہجری تاریخ', hijriText(now)),
              ]),
            ),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: () => go(c, const QiblaScreen()), icon: const Icon(Icons.explore), label: const Text('لائیو قبلہ کھولیں'))),
              const SizedBox(width: 10),
              Expanded(child: OutlinedButton.icon(onPressed: () => pickCity(c), icon: const Icon(Icons.location_city), label: const Text('شہر تبدیل کریں'))),
            ]),
            const SizedBox(height: 10),
          ],
        );
      });
}

// ------------------------------------------------------------------ 10. ANALYTICS
class _AnalyticsReport extends StatelessWidget {
  const _AnalyticsReport();

  @override
  Widget build(BuildContext context) => Rebuild((c) {
        final today = dayOnly(DateTime.now());
        DateTime? first;
        for (final k in sp.getKeys()) {
          if (!k.startsWith('pr|')) continue;
          final p = k.split('|');
          if (p.length != 3) continue;
          final d = _parseDay(p[1]);
          if (d == null) continue;
          if (first == null || d.isBefore(first)) first = d;
        }
        var start = first ?? today;
        if (today.difference(start).inDays > 3650) start = addDays(today, -3650);
        final days = _range(start, today);
        final s = _prayerStats(days);

        var best = 0, run = 0, cur = 0;
        for (final d in days) {
          if (_dayOffered(d) == 5) {
            run++;
            if (run > best) best = run;
          } else {
            run = 0;
          }
        }
        var i = days.length - 1;
        if (i >= 0 && _dayOffered(days[i]) < 5) i--;
        while (i >= 0 && _dayOffered(days[i]) == 5) {
          cur++;
          i--;
        }

        final wdOff = List<int>.filled(7, 0);
        final wdSlot = List<int>.filled(7, 0);
        for (final d in days) {
          wdOff[d.weekday - 1] += _dayOffered(d);
          wdSlot[d.weekday - 1] += 5;
        }
        final months = <List<dynamic>>[];
        for (int k = 5; k >= 0; k--) {
          final m = DateTime(today.year, today.month - k, 1);
          final ms = _prayerStats(_range(m, DateTime(m.year, m.month + 1, 0)));
          months.add([urduMonths[m.month - 1], ms.pct, ms.slots]);
        }

        var bestP = 0, worstP = 0;
        for (int p = 1; p < 5; p++) {
          if (s.per[p] > s.per[bestP]) bestP = p;
          if (s.per[p] < s.per[worstP]) worstP = p;
        }
        final nscan = _scanNafl(null);
        var naflTotal = 0;
        for (final v in nscan.rak.values) {
          naflTotal += v;
        }
        var tjDays = 0, friYes = 0;
        for (final k in sp.getKeys()) {
          if (k.startsWith('tj|') && k.endsWith('|st') && sp.getInt(k) == 1) tjDays++;
          if (k.startsWith('jm:') && JRec.load(_parseDay(k.substring(3)) ?? today).st == 'yes') friYes++;
        }
        final jamPct = s.offered == 0 ? 0 : (s.jamaat * 100 / s.offered).round();
        String tip;
        if (s.slots == 0) {
          tip = 'ابھی نمازوں کا ریکارڈ شروع کریں، پھر یہاں آپ کا مکمل تجزیہ نظر آئے گا۔';
        } else if (s.pc >= 90) {
          tip = 'ماشاءاللہ! آپ کی پابندی بہت اچھی ہے۔ اسے برقرار رکھیں اور جماعت کا اہتمام بڑھائیں۔';
        } else {
          tip = 'سب سے کمزور نماز ${prayerInfos[worstP].name} ہے، اس کے وقت پر یاددہانی لگا کر اس پر خصوصی توجہ دیں۔';
        }
        final text = StringBuffer('تجزیاتی رپورٹ\n');
        text.writeln('کل دن: ${s.days} • ادا: ${s.offered} / ${s.slots} (${s.pc}٪) • با جماعت: $jamPct٪');
        text.writeln('موجودہ مسلسل دن: $cur • بہترین سلسلہ: $best دن • مکمل 5 نمازوں والے دن: ${s.perfect}');
        text.writeln('بہترین نماز: ${prayerInfos[bestP].name} • کمزور نماز: ${prayerInfos[worstP].name}');
        text.writeln('نوافل کی رکعات: $naflTotal • تراویح: ${nscan.tarDays} دن • تہجد: $tjDays دن • جمعہ: $friYes');
        text.writeln('باقی قضا: ${qazaPendingTotal()} • ادا کی گئی قضا: ${qazaMadeTotal()}');

        return _RPage(
          title: 'تجزیاتی رپورٹ',
          sub: 'مجموعی اعداد و شمار اور گراف',
          icon: Icons.bar_chart,
          color: const Color(0xFF424242),
          copy: text.toString(),
          children: [
            _prayerStatsBox(c, s),
            box(
              c,
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                _num('موجودہ سلسلہ', '$cur دن', green),
                _num('بہترین سلسلہ', '$best دن', gold),
                _num('مکمل دن', '${s.perfect}', const Color(0xFF0D47A1)),
                _num('جماعت', '$jamPct٪', const Color(0xFF6A1B9A)),
              ]),
            ),
            box(
              c,
              color: green.withAlpha(isDark(c) ? 60 : 24),
              child: Row(children: [
                const Icon(Icons.lightbulb, color: gold),
                const SizedBox(width: 10),
                Expanded(child: Text(tip, style: const TextStyle(fontSize: 13.5, height: 1.6))),
              ]),
            ),
            sectionTitle('ہر نماز کی پابندی'),
            _perPrayerBox(c, s),
            box(c, child: Column(children: [
              _kv(c, Icons.emoji_events, 'سب سے زیادہ پڑھی جانے والی', prayerInfos[bestP].name, col: _okC),
              _kv(c, Icons.warning_amber, 'سب سے کم پڑھی جانے والی', prayerInfos[worstP].name, col: _redC),
            ])),
            sectionTitle('ہفتے کے دن کے حساب سے'),
            box(
              c,
              child: Column(children: [
                for (int d = 0; d < 7; d++)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(children: [
                      SizedBox(width: 62, child: Text(urduDays[d], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
                      Expanded(child: _bar(wdSlot[d] == 0 ? 0.0 : wdOff[d] / wdSlot[d], const Color(0xFF0D47A1))),
                      SizedBox(width: 44, child: Text(wdSlot[d] == 0 ? '-' : '${(wdOff[d] * 100 / wdSlot[d]).round()}٪', textAlign: TextAlign.end, style: const TextStyle(fontSize: 12))),
                    ]),
                  ),
              ]),
            ),
            sectionTitle('پچھلے 6 مہینے (گراف)'),
            box(
              c,
              child: SizedBox(
                height: 150,
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    for (final m in months)
                      Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                          Text((m[2] as int) == 0 ? '-' : '${((m[1] as double) * 100).round()}٪', style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 3),
                          Container(
                            height: math.max(4.0, 100.0 * (m[1] as double)),
                            margin: const EdgeInsets.symmetric(horizontal: 6),
                            decoration: BoxDecoration(color: green, borderRadius: BorderRadius.circular(6)),
                          ),
                          const SizedBox(height: 4),
                          FittedBox(fit: BoxFit.scaleDown, child: Text(m[0] as String, style: const TextStyle(fontSize: 10.5))),
                        ]),
                      ),
                  ]),
                ),
              ),
            ),
            sectionTitle('دیگر عبادات'),
            box(
              c,
              child: Column(children: [
                _kv(c, Icons.self_improvement, 'نوافل کی کل رکعات', '$naflTotal'),
                _kv(c, Icons.mosque, 'تراویح', '${nscan.tarDays} دن • ${nscan.tarRakat} رکعات'),
                _kv(c, Icons.nightlight_round, 'تہجد پڑھنے کے دن', '$tjDays'),
                _kv(c, Icons.account_balance, 'جمعہ کی نمازیں', '$friYes'),
                _kv(c, Icons.alarm, 'باقی قضا نمازیں', '${qazaPendingTotal()}', col: _redC),
                _kv(c, Icons.done_all, 'ادا کی گئی قضا', '${qazaMadeTotal()}'),
              ]),
            ),
          ],
        );
      });
}
