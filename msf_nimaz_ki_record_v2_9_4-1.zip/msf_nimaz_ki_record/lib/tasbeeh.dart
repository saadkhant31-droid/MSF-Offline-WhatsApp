import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'timetable.dart' show p12;
import 'nav_common.dart';
import 'duas.dart';
import 'settings.dart';

const zikrs = [
  ['سبحان اللہ', 'سُبْحَانَ اللّٰهِ'],
  ['الحمد للہ', 'اَلْحَمْدُ لِلّٰهِ'],
  ['اللہ اکبر', 'اَللّٰهُ اَكْبَرُ'],
  ['لا الہ الا اللہ', 'لَا اِلٰهَ اِلَّا اللّٰهُ'],
  ['درود شریف', 'اَللّٰهُمَّ صَلِّ عَلٰى مُحَمَّدٍ'],
  ['استغفار', 'اَسْتَغْفِرُ اللّٰهَ'],
];

const _dk = Color(0xFF0B3D2A);
const _g1 = Color(0xFF1E8A4C);
const _g2 = Color(0xFF0B5D3B);

String _iso(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class _Log {
  final String date, time;
  final int zikr, count;
  _Log(this.date, this.zikr, this.count, this.time);
}

List<_Log> _logs() {
  final out = <_Log>[];
  for (final s in sp.getStringList('tb_log') ?? <String>[]) {
    final p = s.split('|');
    if (p.length < 4) continue;
    out.add(_Log(p[0], clampI(int.tryParse(p[1]) ?? 0, 0, zikrs.length - 1), int.tryParse(p[2]) ?? 0, p[3]));
  }
  return out;
}

void _addLog(int zikr, int count) {
  if (count <= 0) return;
  final now = DateTime.now();
  final l = List<String>.from(sp.getStringList('tb_log') ?? <String>[]);
  l.insert(0, '${_iso(now)}|$zikr|$count|${p12(now)}');
  if (l.length > 200) l.removeRange(200, l.length);
  sp.setStringList('tb_log', l);
  bump();
}

class TasbeehScreen extends StatelessWidget {
  const TasbeehScreen({super.key});

  int get _zi => clampI(getI('tb_zikr'), 0, zikrs.length - 1);

  Future<void> _custom(BuildContext c) async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('اپنی تعداد درج کریں'),
        content: TextField(controller: ctrl, keyboardType: TextInputType.number, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ٹھیک ہے')),
        ],
      ),
    );
    if (ok == true) {
      final v = int.tryParse(ctrl.text.trim()) ?? 0;
      if (v > 0) _setTarget(v);
    }
  }

  void _setTarget(int n) {
    _addLog(_zi, getI('tb_count'));
    sp.setInt('tb_count', 0);
    setI('tb_target', n);
  }

  void _tap(BuildContext c) {
    final target = getI('tb_target', 33);
    var count = getI('tb_count') + 1;
    sp.setInt('tb_total', getI('tb_total') + 1);
    if (count >= target) {
      _addLog(_zi, target);
      count = 0;
      sp.setInt('tb_rounds', getI('tb_rounds') + 1);
      HapticFeedback.heavyImpact();
      toast(c, 'ماشاء اللہ! تسبیح مکمل ہوئی');
    } else {
      HapticFeedback.lightImpact();
    }
    setI('tb_count', count);
  }

  void _minus() {
    final count = getI('tb_count');
    if (count <= 0) return;
    final t = getI('tb_total');
    if (t > 0) sp.setInt('tb_total', t - 1);
    setI('tb_count', count - 1);
  }

  void _reset(BuildContext c) {
    _addLog(_zi, getI('tb_count'));
    setI('tb_count', 0);
    toast(c, 'گنتی ری سیٹ ہو گئی');
  }

  Future<void> _sheet(BuildContext c, String title, Widget Function(BuildContext) body) {
    return showModalBottomSheet<void>(
      context: c,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.8),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 8), child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: green))),
            Flexible(child: SingleChildScrollView(child: Rebuild(body))),
          ]),
        ),
      ),
    );
  }

  void _zikrList(BuildContext c) => _sheet(c, 'اذکار کی فہرست', (ctx) => Column(children: [
        for (int i = 0; i < zikrs.length; i++)
          ListTile(
            leading: Icon(_zi == i ? Icons.radio_button_checked : Icons.radio_button_off, color: green),
            title: Text(zikrs[i][0]),
            subtitle: Text(zikrs[i][1], style: const TextStyle(fontSize: 18, height: 1.8)),
            onTap: () {
              if (_zi != i) {
                _addLog(_zi, getI('tb_count'));
                sp.setInt('tb_count', 0);
                setI('tb_zikr', i);
              }
              Navigator.pop(ctx);
            },
          ),
      ]));

  void _virtue(BuildContext c) => _sheet(c, 'تسبیح کی فضیلت', (ctx) => const Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Text(
          'اَلَا بِذِكْرِ اللّٰهِ تَطْمَىِٕنُّ الْقُلُوْبُ\nخبردار! اللہ کی یاد ہی سے دلوں کو سکون ملتا ہے۔ (الرعد: 28)\n\n'
          'اے ایمان والو! اللہ کو کثرت سے یاد کرو۔ (الاحزاب: 41)\n\n'
          'ہر فرض نماز کے بعد 33 بار سبحان اللہ، 33 بار الحمد للہ اور 34 بار اللہ اکبر پڑھنا مسنون ہے۔ (صحیح مسلم)',
          style: TextStyle(fontSize: 15, height: 2),
        ),
      ));

  void _allRecords(BuildContext c) => _sheet(c, 'تمام ریکارڈ', (ctx) {
        final l = _logs();
        if (l.isEmpty) return const Padding(padding: EdgeInsets.all(20), child: Text('ابھی کوئی ریکارڈ نہیں'));
        return Column(children: [for (final r in l) _recRow(ctx, r)]);
      });

  void _byDate(BuildContext c) => _sheet(c, 'تاریخ کے مطابق ریکارڈ', (ctx) {
        final l = _logs();
        if (l.isEmpty) return const Padding(padding: EdgeInsets.all(20), child: Text('ابھی کوئی ریکارڈ نہیں'));
        final m = <String, int>{};
        for (final r in l) {
          m[r.date] = (m[r.date] ?? 0) + r.count;
        }
        final keys = m.keys.toList()..sort((a, b) => b.compareTo(a));
        return Column(children: [
          for (final k in keys)
            ListTile(
              leading: const Icon(Icons.calendar_month, color: green),
              title: Text(k),
              trailing: Text('${m[k]}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: green)),
            ),
        ]);
      });

  Widget _round(IconData ic, VoidCallback f) => InkWell(
        onTap: f,
        customBorder: const CircleBorder(),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(color: _dk, shape: BoxShape.circle, border: Border.all(color: gold, width: 2)),
          child: Icon(ic, color: Colors.white, size: 24),
        ),
      );

  Widget _bar(String t, IconData ic) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: const BoxDecoration(gradient: LinearGradient(colors: [_g2, green2]), borderRadius: BorderRadius.vertical(top: Radius.circular(12))),
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: Row(children: [
            Icon(ic, color: Colors.white, size: 18),
            const SizedBox(width: 6),
            Expanded(child: Text(t, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13))),
          ]),
        ),
      );

  BoxDecoration _card(BuildContext c) => BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: _g1.withAlpha(90)));

  Widget _top(BuildContext c) => Directionality(
        textDirection: TextDirection.ltr,
        child: SizedBox(
          height: 112,
          child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Expanded(
              flex: 2,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(gradient: const LinearGradient(colors: [_g1, _g2]), borderRadius: BorderRadius.circular(14), border: Border.all(color: gold, width: 1.4)),
                child: Row(children: [
                  const Icon(Icons.blur_circular, color: Colors.white, size: 54),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Directionality(
                      textDirection: TextDirection.rtl,
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
                        FittedBox(fit: BoxFit.scaleDown, child: Text('تسبیح کاؤنٹر', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold))),
                        FittedBox(fit: BoxFit.scaleDown, child: Text('اللہ کا ذکر کریں، دل کو سکون دیں', style: TextStyle(color: Colors.white, fontSize: 12))),
                      ]),
                    ),
                  ),
                ]),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              flex: 1,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: _card(c),
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
                    FittedBox(fit: BoxFit.scaleDown, child: Text('اَلَا بِذِكْرِ اللّٰهِ تَطْمَىِٕنُّ الْقُلُوْبُ', style: TextStyle(fontSize: 14, height: 1.7))),
                    SizedBox(height: 2),
                    FittedBox(fit: BoxFit.scaleDown, child: Text('اللہ کی یاد ہی سے دلوں کو سکون ملتا ہے', style: TextStyle(fontSize: 10.5))),
                    FittedBox(fit: BoxFit.scaleDown, child: Text('(الرعد: 28)', style: TextStyle(fontSize: 10.5))),
                  ]),
                ),
              ),
            ),
          ]),
        ),
      );

  Widget _panel(BuildContext c, int count, int target, String name) => Container(
        height: 270,
        decoration: BoxDecoration(
          gradient: const RadialGradient(colors: [Color(0xFF3C7A3A), Color(0xFF123A22)], radius: 0.9),
          borderRadius: BorderRadius.circular(14),
        ),
        child: LayoutBuilder(builder: (ctx, cons) {
          final size = (cons.maxWidth * 0.62).clamp(110.0, 200.0);
          return Stack(alignment: Alignment.center, children: [
            GestureDetector(
              onTap: () => _tap(c),
              child: SizedBox(
                width: size,
                height: size,
                child: Stack(alignment: Alignment.center, children: [
                  SizedBox(width: size, height: size, child: CircularProgressIndicator(value: target == 0 ? 0 : count / target, strokeWidth: 9, color: gold, backgroundColor: Colors.white24)),
                  Container(
                    width: size - 26,
                    height: size - 26,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: _dk, border: Border.all(color: gold, width: 3)),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text('$count', style: TextStyle(color: Colors.white, fontSize: size * 0.3, fontWeight: FontWeight.bold, height: 1.1)),
                      Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: FittedBox(fit: BoxFit.scaleDown, child: Text(name, style: const TextStyle(color: Colors.white, fontSize: 14)))),
                      Text('ہدف: $target', style: const TextStyle(color: Colors.white70, fontSize: 11)),
                    ]),
                  ),
                ]),
              ),
            ),
            Positioned(left: 4, child: _round(Icons.remove, _minus)),
            Positioned(right: 4, child: _round(Icons.add, () => _tap(c))),
            const Positioned(bottom: 6, child: Text('گننے کے لیے دائرے یا + پر ٹیپ کریں', style: TextStyle(color: Colors.white60, fontSize: 10))),
          ]);
        }),
      );

  Widget _side(BuildContext c, int count, String name) => Container(
        height: 270,
        decoration: _card(c),
        child: Column(children: [
          _bar('موجودہ گنتی', Icons.blur_circular),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Column(children: [
                    Text('$count', style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold, color: _g2, height: 1.1)),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(name, style: const TextStyle(fontSize: 13))),
                  ]),
                  Column(children: [
                    const Divider(height: 6),
                    Row(children: [
                      const Icon(Icons.track_changes, color: _g2, size: 22),
                      const SizedBox(width: 4),
                      const Expanded(child: Text('کل گنتی', style: TextStyle(fontSize: 11.5))),
                      Text('${getI('tb_total')}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ]),
                    Row(children: [
                      const Icon(Icons.loop, color: _g2, size: 22),
                      const SizedBox(width: 4),
                      const Expanded(child: Text('مکمل دور', style: TextStyle(fontSize: 11.5))),
                      Text('${getI('tb_rounds')}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ]),
                  ]),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () => _reset(c),
                      icon: const Icon(Icons.refresh, size: 18),
                      label: const FittedBox(fit: BoxFit.scaleDown, child: Text('ری سیٹ کریں')),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ]),
      );

  Widget _targets(BuildContext c, int target) {
    Widget tile(int n) {
      final sel = target == n;
      return Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: InkWell(
            onTap: () => _setTarget(n),
            borderRadius: BorderRadius.circular(10),
            child: Container(
              height: 62,
              decoration: BoxDecoration(color: sel ? _g2 : cardColor(c), borderRadius: BorderRadius.circular(10), border: Border.all(color: _g1.withAlpha(120))),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('$n', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: sel ? Colors.white : null)),
                Text('مرہ', style: TextStyle(fontSize: 11, color: sel ? Colors.white70 : null)),
                if (sel) const Icon(Icons.check, color: Colors.white, size: 12),
              ]),
            ),
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.only(top: 10),
      decoration: _card(c),
      child: Column(children: [
        _bar('تسبیح کے لیے تعداد منتخب کریں', Icons.checklist),
        Padding(
          padding: const EdgeInsets.all(6),
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Row(children: [
              for (final n in [11, 33, 66, 99, 100]) tile(n),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: InkWell(
                    onTap: () => _custom(c),
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      height: 62,
                      decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(10), border: Border.all(color: _g1.withAlpha(120))),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
                        Icon(Icons.edit, color: _g2, size: 20),
                        SizedBox(height: 2),
                        Padding(padding: EdgeInsets.symmetric(horizontal: 2), child: FittedBox(fit: BoxFit.scaleDown, child: Text('اپنی تعداد\nدرج کریں', textAlign: TextAlign.center, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)))),
                      ]),
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _recRow(BuildContext c, _Log r) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Row(children: [
            const Icon(Icons.calendar_month, color: _g2, size: 15),
            const SizedBox(width: 3),
            SizedBox(width: 66, child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(r.date, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)))),
            Expanded(child: Directionality(textDirection: TextDirection.rtl, child: Text(zikrs[r.zikr][0], textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5)))),
            Container(
              width: 34,
              padding: const EdgeInsets.symmetric(vertical: 2),
              decoration: BoxDecoration(color: _g1.withAlpha(40), borderRadius: BorderRadius.circular(6)),
              child: Text('${r.count}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(width: 4),
            const Icon(Icons.access_time, color: _g2, size: 15),
            const SizedBox(width: 2),
            SizedBox(width: 56, child: FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(r.time, style: const TextStyle(fontSize: 10.5)))),
          ]),
        ),
      );

  Widget _records(BuildContext c) {
    final l = _logs();
    return Container(
      decoration: _card(c),
      child: Column(children: [
        _bar('آخری تسبیح کا ریکارڈ', Icons.history),
        if (l.isEmpty)
          Padding(padding: const EdgeInsets.all(16), child: Text('ابھی کوئی ریکارڈ نہیں۔ تسبیح مکمل کریں تو یہاں نظر آئے گا۔', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: subText(c), height: 1.6)))
        else
          for (final r in l.take(5)) _recRow(c, r),
        Padding(
          padding: const EdgeInsets.all(6),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _allRecords(c),
              icon: const Icon(Icons.list_alt, size: 18),
              label: const Text('تمام ریکارڈ دیکھیں', style: TextStyle(fontSize: 12)),
              style: ElevatedButton.styleFrom(backgroundColor: _dk),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _duaCard(BuildContext c) => InkWell(
        onTap: () => go(c, const DuasScreen()),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: _card(c),
          child: Column(children: [
            _bar('دعا اور اذکار', Icons.volunteer_activism),
            const Padding(
              padding: EdgeInsets.all(8),
              child: Text('تسبیح کے ساتھ ساتھ یاد دعاؤں اور اذکار کو بھی اپنی زندگی کا حصہ بنائیں۔', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, height: 1.8)),
            ),
            const Icon(Icons.mosque, color: _g1, size: 44),
            Container(
              width: double.infinity,
              margin: const EdgeInsets.all(6),
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: _dk, borderRadius: BorderRadius.circular(10), border: Border.all(color: gold)),
              child: const Text('اللہ کا ذکر دل کو سکون دیتا ہے۔', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 10.5, height: 1.6)),
            ),
          ]),
        ),
      );

  Widget _useful(BuildContext c) {
    Widget b(String t, IconData ic, VoidCallback f) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: InkWell(
              onTap: f,
              borderRadius: BorderRadius.circular(10),
              child: Container(
                height: 66,
                padding: const EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(10), border: Border.all(color: _g1.withAlpha(110))),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(ic, color: _g2, size: 24),
                  const SizedBox(height: 4),
                  FittedBox(fit: BoxFit.scaleDown, child: Text(t, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))),
                ]),
              ),
            ),
          ),
        );
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 8),
      decoration: _card(c),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 6), child: Text('مفید بٹن', style: TextStyle(fontWeight: FontWeight.bold, color: _g2.withAlpha(230)))),
        Directionality(
          textDirection: TextDirection.ltr,
          child: Row(children: [
            b('تسبیح کی فضیلت', Icons.menu_book, () => _virtue(c)),
            b('اذکار کی فہرست', Icons.volunteer_activism, () => _zikrList(c)),
            b('تاریخ کے مطابق ریکارڈ', Icons.calendar_month, () => _byDate(c)),
            b('سیٹنگز', Icons.settings, () => go(c, const SettingsScreen())),
          ]),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Column(children: [
          appHeader(context, 'تسبیح کاؤنٹر', 'اللہ کے ذکر سے دل کو سکون ملتا ہے', null),
          Expanded(
            child: Rebuild((c) {
              final target = getI('tb_target', 33);
              final count = getI('tb_count');
              final name = zikrs[_zi][0];
              return ListView(padding: const EdgeInsets.fromLTRB(10, 10, 10, 12), children: [
                _top(c),
                const SizedBox(height: 10),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(flex: 2, child: _panel(c, count, target, name)),
                    const SizedBox(width: 8),
                    Expanded(flex: 1, child: _side(c, count, name)),
                  ]),
                ),
                _targets(c, target),
                const SizedBox(height: 10),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(flex: 2, child: _records(c)),
                    const SizedBox(width: 8),
                    Expanded(flex: 1, child: _duaCard(c)),
                  ]),
                ),
                _useful(c),
              ]);
            }),
          ),
        ]),
        bottomNavigationBar: msfNav7(context, icon3: Icons.blur_circular, label3: 'تسبیح'),
      );
}
