import 'kohat_data.dart';
import 'store.dart';

/// Names of the two Kohat timetables the user can choose between.
const ttNames = ['کوہاٹ نماز اوقات (متفقہ نقشہ)', 'سحر و افطار (کوہاٹ اور مضافات)'];
const ttShort = ['متفقہ نقشہ', 'سحر و افطار'];

const _cum = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];

/// 0 = متفقہ نقشہ, 1 = سحر و افطار نقشہ
int ttMap() => clampI(getI('ttmap', 0), 0, 1);

/// true = Hanafi (2 mithl) asr / isha, false = Shafi'i (1 mithl)
bool useHanafi() => getI('asr', 2) == 2;

class DayTimes {
  final DateTime sehri, fajr, sunrise, ishraq, chasht, zawal, zuhr, asr, maghrib, isha;
  const DayTimes({
    required this.sehri,
    required this.fajr,
    required this.sunrise,
    required this.ishraq,
    required this.chasht,
    required this.zawal,
    required this.zuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
  });
}

DayTimes dayTimes(DateTime date, {int? map, bool? hanafi}) {
  final m = map ?? ttMap();
  final i = _cum[date.month - 1] + date.day - 1;
  DateTime t(int mins) => DateTime(date.year, date.month, date.day, 0, mins);
  final han = hanafi ?? useHanafi();
  if (m == 0) {
    final r = kMap1.sublist(i * kMap1Cols, (i + 1) * kMap1Cols);
    // fajr, sunrise, noon, asr1, asr2, maghrib, isha
    return DayTimes(
      sehri: t(r[0] - 2),
      fajr: t(r[0]),
      sunrise: t(r[1]),
      ishraq: t(r[1] + 12),
      chasht: t(r[1] + 132),
      zawal: t(r[2]),
      zuhr: t(r[2] + 1),
      asr: t(han ? r[4] : r[3]),
      maghrib: t(r[5]),
      isha: t(r[6]),
    );
  }
  final r = kMap2.sublist(i * kMap2Cols, (i + 1) * kMap2Cols);
  // sehriEnd, fajr, sunrise, ishraq, chasht, noon, asr1, asr2, maghrib, ishaShafi, ishaHanafi
  final sehri = r[0] > r[1] ? r[1] : r[0];
  return DayTimes(
    sehri: t(sehri),
    fajr: t(r[1]),
    sunrise: t(r[2]),
    ishraq: t(r[3]),
    chasht: t(r[4]),
    zawal: t(r[5]),
    zuhr: t(r[5] + 1),
    asr: t(han ? r[7] : r[6]),
    maghrib: t(r[8]),
    isha: t(han ? r[10] : r[9]),
  );
}

String p12(DateTime t) {
  final h = t.hour % 12 == 0 ? 12 : t.hour % 12;
  return '${h.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')} ${t.hour >= 12 ? 'PM' : 'AM'}';
}
