import 'package:flutter/material.dart';
import 'store.dart';
import 'widgets.dart';
import 'home.dart';
import 'prayers.dart';
import 'settings.dart';
import 'eidain.dart' show EidainScreen;
import 'taraweeh.dart';
import 'tahajjud.dart';

/// Artwork header (image already contains the title + "واپس" button).
Widget artHeader(BuildContext c, String asset, double ratio) {
  final w = MediaQuery.of(c).size.width;
  return SizedBox(
    width: w,
    height: w * ratio,
    child: Stack(children: [
      Positioned.fill(child: Image.asset(asset, fit: BoxFit.fill)),
      Positioned(
        left: w * 0.02,
        top: w * 58 / 1024,
        width: w * 0.17,
        height: w * 70 / 1024,
        child: Material(
          color: Colors.transparent,
          child: InkWell(borderRadius: BorderRadius.circular(30), onTap: () => Navigator.maybePop(c)),
        ),
      ),
    ]),
  );
}

/// 7-item bottom bar used by the Qibla and Islamic Calendar screens.
/// [qibla] true: item 3 is "قبلہ" (active). false: item 3 is "عیدین" and "مزید" is active.
Widget msfBottomNav(BuildContext c, {required bool qibla, VoidCallback? onActiveTap}) {
  final items = <List<dynamic>>[
    [Icons.home, 'ہوم'],
    [Icons.mosque, 'نمازیں'],
    qibla ? [Icons.explore, 'قبلہ'] : [Icons.celebration, 'عیدین'],
    [Icons.nightlight_round, 'تراویح'],
    [Icons.bedtime, 'تہجد'],
    [Icons.settings, 'سیٹنگز'],
    [Icons.menu, 'مزید'],
  ];
  final active = qibla ? 2 : 6;

  void act(int i) {
    switch (i) {
      case 0:
        Navigator.of(c).popUntil((r) => r.isFirst);
        break;
      case 1:
        go(c, const PrayersScreen());
        break;
      case 2:
        if (qibla) {
          onActiveTap?.call();
        } else {
          go(c, const EidainScreen());
        }
        break;
      case 3:
        go(c, const TaraweehScreen());
        break;
      case 4:
        go(c, const TahajjudScreen());
        break;
      case 5:
        go(c, const SettingsScreen());
        break;
      case 6:
        if (qibla) {
          go(c, MorePage(features: allFeatures()));
        } else {
          Navigator.maybePop(c);
        }
        break;
    }
  }

  return Container(
    color: const Color(0xFF0B3D2A),
    padding: EdgeInsets.only(bottom: MediaQuery.of(c).padding.bottom, top: 4),
    child: Directionality(
      textDirection: TextDirection.ltr,
      child: Row(children: [
        for (int i = 0; i < items.length; i++)
          Expanded(
            child: InkWell(
              onTap: () => act(i),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 1.5, vertical: 2),
                padding: const EdgeInsets.symmetric(vertical: 5),
                decoration: i == active
                    ? BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF7CD65B), width: 1.4), color: const Color(0xFF14803F))
                    : null,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(items[i][0] as IconData, color: i == active ? gold : Colors.white, size: 22),
                  const SizedBox(height: 2),
                  FittedBox(fit: BoxFit.scaleDown, child: Text(items[i][1] as String, style: TextStyle(color: i == active ? gold : Colors.white, fontSize: 10.5, fontWeight: FontWeight.bold))),
                ]),
              ),
            ),
          ),
      ]),
    ),
  );
}

/// 7-item bottom bar (ہوم، نمازیں، <تیسرا آئٹم>، تراویح، تہجد، سیٹنگز، مزید).
/// [active] = 2 means the third item is the current screen.
Widget msfNav7(BuildContext c, {required IconData icon3, required String label3, int active = 2, VoidCallback? onActiveTap}) {
  final items = <List<dynamic>>[
    [Icons.home, 'ہوم'],
    [Icons.mosque, 'نمازیں'],
    [icon3, label3],
    [Icons.nightlight_round, 'تراویح'],
    [Icons.bedtime, 'تہجد'],
    [Icons.settings, 'سیٹنگز'],
    [Icons.menu, 'مزید'],
  ];
  void act(int i) {
    switch (i) {
      case 0:
        Navigator.of(c).popUntil((r) => r.isFirst);
        break;
      case 1:
        go(c, const PrayersScreen());
        break;
      case 2:
        onActiveTap?.call();
        break;
      case 3:
        go(c, const TaraweehScreen());
        break;
      case 4:
        go(c, const TahajjudScreen());
        break;
      case 5:
        go(c, const SettingsScreen());
        break;
      case 6:
        go(c, MorePage(features: allFeatures()));
        break;
    }
  }

  return Container(
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF0E5A3A), Color(0xFF06291B)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
      border: Border(top: BorderSide(color: gold.withAlpha(140), width: 1.5)),
    ),
    padding: EdgeInsets.only(bottom: MediaQuery.of(c).padding.bottom, top: 4),
    child: Directionality(
      textDirection: TextDirection.ltr,
      child: Row(children: [
        for (int i = 0; i < items.length; i++)
          Expanded(
            child: InkWell(
              onTap: () => act(i),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 1.5, vertical: 2),
                padding: const EdgeInsets.symmetric(vertical: 5),
                decoration: i == active
                    ? BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF7CD65B), width: 1.4), color: const Color(0xFF14803F))
                    : null,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(items[i][0] as IconData, color: i == active ? gold : Colors.white, size: 22),
                  const SizedBox(height: 2),
                  FittedBox(fit: BoxFit.scaleDown, child: Text(items[i][1] as String, style: TextStyle(color: i == active ? gold : Colors.white, fontSize: 10.5, fontWeight: FontWeight.bold))),
                ]),
              ),
            ),
          ),
      ]),
    ),
  );
}
