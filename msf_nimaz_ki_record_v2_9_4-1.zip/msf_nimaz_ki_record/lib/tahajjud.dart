import 'dart:io' show Platform;
import 'package:android_intent_plus/android_intent.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'store.dart';
import 'widgets.dart';
import 'home.dart';
import 'prayers.dart';
import 'reports.dart';
import 'settings.dart';

const _deep = Color(0xFF0B4D2E);
const _panel = Color(0xFF0E5B37);
const _ok = Color(0xFF1B7F45);
const _red = Color(0xFFD32F2F);
const _slate = Color(0xFF2F5A66);

const _verse = 'اور رات کے کچھ حصے میں تہجد پڑھیے، یہ آپ کے لیے ایک اضافی عبادت ہے۔';
const _verseRef = '(الاسراء: 79)';

class _St {
  final int id;
  final String label;
  final IconData icon;
  const _St(this.id, this.label, this.icon);
}

const _states = <_St>[
  _St(1, 'اٹھ گیا اور نماز پڑھ لی', Icons.self_improvement),
  _St(2, 'اٹھ گیا لیکن نماز نہیں پڑھی', Icons.mosque),
  _St(3, 'نیند کی وجہ سے نہیں اٹھ سکا', Icons.hotel),
  _St(4, 'غفلت یا سستی کی وجہ سے نہیں اٹھ سکا', Icons.warning_amber_rounded),
  _St(5, 'کام یا مصروفیت کی وجہ سے نہیں اٹھ سکا', Icons.work),
  _St(6, 'بیماری یا طبیعت خراب کی وجہ سے نہیں اٹھ سکا', Icons.sick),
  _St(7, 'الارم نہیں سنا', Icons.alarm_off),
  _St(8, 'رات کو دیر سے سویا اس لیے نہیں اٹھ سکا', Icons.nightlight_round),
  _St(9, 'کوئی دوسری وجہ', Icons.edit),
  _St(10, 'اپنی وجہ خود لکھیں', Icons.edit_note),
];

// ------------------------------------------------------------------ data helpers
String _k(DateTime d, String f) => 'tj|${dayKey(d)}|$f';
// Tahajjud rakats are stored under the same key as the Nafl screen (id '0').
String _rk(DateTime d) => 'nk|${dayKey(d)}|0';

int _st(DateTime d) => getI(_k(d, 'st'));
int _rak(DateTime d) => getI(_rk(d));
int _tm(DateTime d, String f) => getI(_k(d, f), -1);

void _clear(DateTime d, String f) => del(_k(d, f));

String _two(int n) => n.toString().padLeft(2, '0');
String _iso(DateTime d) => '${d.year}-${_two(d.month)}-${_two(d.day)}';

String _fmtMin(int m) {
  if (m < 0) return '--:--';
  final h = m ~/ 60;
  final mm = m % 60;
  final h12 = h % 12 == 0 ? 12 : h % 12;
  return '${_two(h12)}:${_two(mm)} ${h >= 12 ? 'PM' : 'AM'}';
}

String _reasonText(DateTime d) {
  final s = _st(d);
  if (s < 3) return '—';
  if (s == 10) {
    final w = getS(_k(d, 'why'));
    return w.isEmpty ? 'اپنی وجہ' : w;
  }
  return _states.firstWhere((e) => e.id == s).label;
}

Future<bool> _setAndroidAlarm(int min, bool daily) async {
  if (!Platform.isAndroid) return false;
  try {
    final args = <String, dynamic>{
      'android.intent.extra.alarm.HOUR': min ~/ 60,
      'android.intent.extra.alarm.MINUTES': min % 60,
      'android.intent.extra.alarm.MESSAGE': 'تہجد',
      'android.intent.extra.alarm.SKIP_UI': false,
    };
    if (daily) args['android.intent.extra.alarm.DAYS'] = <int>[1, 2, 3, 4, 5, 6, 7];
    await AndroidIntent(action: 'android.intent.action.SET_ALARM', arguments: args).launch();
    return true;
  } catch (_) {
    return false;
  }
}

// ------------------------------------------------------------------ screen
class TahajjudScreen extends StatefulWidget {
  const TahajjudScreen({super.key});
  @override
  State<TahajjudScreen> createState() => _TahajjudState();
}

class _TahajjudState extends State<TahajjudScreen> {
  DateTime date = dayOnly(DateTime.now());
  final ScrollController _sc = ScrollController();
  final TextEditingController _noteC = TextEditingController();
  final TextEditingController _mnoteC = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadCtrls();
  }

  @override
  void dispose() {
    _sc.dispose();
    _noteC.dispose();
    _mnoteC.dispose();
    super.dispose();
  }

  void _loadCtrls() {
    _noteC.text = getS(_k(date, 'note'));
    _mnoteC.text = getS(_k(date, 'mnote'));
  }

  void _setDate(DateTime d) {
    setState(() => date = dayOnly(d));
    _loadCtrls();
  }

  void _toTop() {
    if (_sc.hasClients) _sc.animateTo(0, duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
  }

  @override
  Widget build(BuildContext context) => AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent),
        child: Scaffold(
          backgroundColor: isDark(context) ? const Color(0xFF0F1913) : const Color(0xFFF0F6EF),
          body: Rebuild((c) => _body(c)),
          bottomNavigationBar: _nav(context),
        ),
      );

  Widget _body(BuildContext c) {
    final w = MediaQuery.of(c).size.width;
    return ListView(controller: _sc, padding: EdgeInsets.zero, children: [
      _header(c, w),
      Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
        child: Column(children: [
          _hero(c),
          const SizedBox(height: 8),
          _stateSection(c),
          const SizedBox(height: 8),
          _prayedSection(c),
          const SizedBox(height: 8),
          _missedSection(c),
          const SizedBox(height: 8),
          _bottomRow(c),
        ]),
      ),
    ]);
  }

  // ---------------------------------------------------------------- header
  Widget _header(BuildContext c, double w) => SizedBox(
        width: w,
        height: w * 212 / 1024,
        child: Stack(children: [
          Positioned.fill(child: Image.asset('assets/tahajjud/header.png', fit: BoxFit.fill)),
          // transparent hit area over the "واپس" button drawn in the artwork
          Positioned(
            left: w * 0.02,
            top: w * 60 / 1024,
            width: w * 0.16,
            height: w * 68 / 1024,
            child: Material(
              color: Colors.transparent,
              child: InkWell(borderRadius: BorderRadius.circular(30), onTap: () => Navigator.maybePop(c)),
            ),
          ),
        ]),
      );

  BoxDecoration _deco(BuildContext c, {Color? color, Color? border}) => BoxDecoration(
        color: color ?? cardColor(c),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: border ?? green.withAlpha(60)),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(16), blurRadius: 5, offset: const Offset(0, 2))],
      );

  // ---------------------------------------------------------------- hero
  Widget _hero(BuildContext c) => SizedBox(
        height: 150,
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            flex: 30,
            child: Material(
              color: Colors.transparent,
              child: Ink(
                decoration: _deco(c, color: Color.alphaBlend(green.withAlpha(24), cardColor(c))),
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => copyText(c, '$_verse $_verseRef'),
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Center(
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: SizedBox(
                          width: 110,
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            const Text(_verse, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, height: 1.7)),
                            const SizedBox(height: 4),
                            Text(_verseRef, style: TextStyle(fontSize: 11, color: subText(c))),
                          ]),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 70,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Stack(children: [
                Positioned.fill(child: Image.asset('assets/tahajjud/hero.png', fit: BoxFit.cover, alignment: Alignment.centerLeft)),
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [_deep.withAlpha(10), _deep.withAlpha(230), _deep],
                        stops: const [0.0, 0.5, 1.0],
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(children: [
                      Expanded(
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: AlignmentDirectional.centerStart,
                          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                            const Text('تہجد', style: TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold)),
                            const Text('اللہ کے قریب ہونے کا بہترین وقت', style: TextStyle(color: Colors.white, fontSize: 12.5)),
                          ]),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: _deep, border: Border.all(color: gold, width: 2.2)),
                        child: const Icon(Icons.nightlight_round, color: Colors.white, size: 32),
                      ),
                    ]),
                  ),
                ),
              ]),
            ),
          ),
        ]),
      );

  // ---------------------------------------------------------------- section frame
  Widget _section(BuildContext c, String title, IconData icon, List<Color> colors, Widget child) => Container(
        decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(70))),
        child: Column(children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(gradient: LinearGradient(colors: colors), borderRadius: const BorderRadius.vertical(top: Radius.circular(12))),
            child: Directionality(
              textDirection: TextDirection.ltr,
              child: Row(children: [
                Icon(icon, color: Colors.white, size: 26),
                const SizedBox(width: 10),
                Expanded(child: Text(title, textDirection: TextDirection.rtl, textAlign: TextAlign.left, style: const TextStyle(color: Colors.white, fontSize: 15.5, fontWeight: FontWeight.bold))),
              ]),
            ),
          ),
          Padding(padding: const EdgeInsets.all(8), child: child),
        ]),
      );

  // ---------------------------------------------------------------- 1. state tiles
  Future<void> _tapState(_St s) async {
    final cur = _st(date);
    if (s.id == 10) {
      final ctrl = TextEditingController(text: getS(_k(date, 'why')));
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('اپنی وجہ لکھیں'),
          content: TextField(controller: ctrl, autofocus: true, maxLines: 2, decoration: const InputDecoration(hintText: 'نہ اٹھنے کی وجہ')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('محفوظ کریں')),
          ],
        ),
      );
      final txt = ctrl.text.trim();
      ctrl.dispose();
      if (ok != true) return;
      if (txt.isEmpty) {
        if (mounted) toast(context, 'وجہ خالی ہے');
        return;
      }
      setS(_k(date, 'why'), txt);
      setI(_k(date, 'st'), 10);
      return;
    }
    if (cur == s.id) {
      _clear(date, 'st');
    } else {
      setI(_k(date, 'st'), s.id);
    }
  }

  Widget _stateTile(BuildContext c, _St s, double w) {
    final sel = _st(date) == s.id;
    return SizedBox(
      width: w,
      height: 112,
      child: Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(
            color: sel ? green.withAlpha(30) : cardColor(c),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: sel ? _ok : green.withAlpha(50), width: sel ? 2 : 1),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => _tapState(s),
            child: Stack(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(3, 8, 3, 6),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: sel ? _ok : Colors.transparent),
                    child: Icon(s.icon, color: sel ? Colors.white : _panel, size: 28),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: Center(
                      child: Text(s.label, textAlign: TextAlign.center, maxLines: 4, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9.5, height: 1.35, fontWeight: FontWeight.w600)),
                    ),
                  ),
                ]),
              ),
              if (sel) const Positioned(right: 3, top: 3, child: Icon(Icons.check_circle, color: _ok, size: 17)),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _stateSection(BuildContext c) => _section(
        c,
        'تہجد کے لیے اٹھنے کی کیفیت',
        Icons.self_improvement,
        const [Color(0xFF0E5B37), Color(0xFF2E8B57)],
        LayoutBuilder(builder: (c, cs) {
          const gap = 6.0;
          final double tw = (cs.maxWidth - gap * 4) / 5;
          return Directionality(
            textDirection: TextDirection.ltr,
            child: Column(children: [
              for (int r = 0; r < 2; r++)
                Padding(
                  padding: EdgeInsets.only(bottom: r == 0 ? gap : 0),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    for (int j = 0; j < 5; j++) _stateTile(c, _states[r * 5 + j], tw),
                  ]),
                ),
            ]),
          );
        }),
      );

  // ---------------------------------------------------------------- shared small widgets
  Widget _fieldCard(BuildContext c, IconData icon, String label, String value, VoidCallback onTap) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: _deco(c),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              child: Row(children: [
                Icon(icon, color: _panel, size: 30),
                const SizedBox(width: 8),
                Expanded(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: AlignmentDirectional.centerStart,
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(label, style: TextStyle(fontSize: 11, color: subText(c))),
                      Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );

  Widget _ynBtn(String text, bool sel, bool yes, VoidCallback onTap) {
    final col = yes ? _ok : _red;
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 7),
        decoration: BoxDecoration(
          color: sel ? col : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: sel ? col : Colors.grey.withAlpha(120)),
        ),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            if (sel) ...[Icon(yes ? Icons.check : Icons.close, color: Colors.white, size: 15), const SizedBox(width: 3)],
            Text(text, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, color: sel ? Colors.white : null)),
          ]),
        ),
      ),
    );
  }

  Widget _ynCard(BuildContext c, IconData icon, String label, int v, void Function(int) onChange) => Container(
        padding: const EdgeInsets.all(8),
        decoration: _deco(c),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            Icon(icon, color: _panel, size: 26),
            const SizedBox(width: 6),
            Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)))),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: _ynBtn('ہاں', v == 1, true, () => onChange(v == 1 ? 0 : 1))),
            const SizedBox(width: 6),
            Expanded(child: _ynBtn('نہیں', v == 2, false, () => onChange(v == 2 ? 0 : 2))),
          ]),
        ]),
      );

  void _setYN(String f, int v) {
    if (v == 0) {
      _clear(date, f);
    } else {
      setI(_k(date, f), v);
    }
  }

  Future<void> _pickDate() async {
    final now = dayOnly(DateTime.now());
    final r = await showDatePicker(
      context: context,
      initialDate: date,
      firstDate: DateTime(now.year - 5),
      lastDate: now,
      helpText: 'تاریخ منتخب کریں',
      cancelText: 'منسوخ',
      confirmText: 'ٹھیک ہے',
    );
    if (r != null && mounted) _setDate(r);
  }

  Future<void> _pickTime(String f, int def) async {
    final cur = _tm(date, f);
    final m = cur >= 0 ? cur : def;
    final r = await showTimePicker(context: context, initialTime: TimeOfDay(hour: m ~/ 60, minute: m % 60), cancelText: 'منسوخ', confirmText: 'ٹھیک ہے');
    if (r != null) setI(_k(date, f), r.hour * 60 + r.minute);
  }

  Widget _saveBtn(String text, VoidCallback onTap) => SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: onTap,
          icon: const Icon(Icons.save, size: 20),
          label: FittedBox(fit: BoxFit.scaleDown, child: Text(text, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.bold))),
          style: ElevatedButton.styleFrom(backgroundColor: _ok, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
        ),
      );

  Widget _noteField(TextEditingController ctrl, String hint) => TextField(
        controller: ctrl,
        maxLines: 2,
        style: const TextStyle(fontSize: 13),
        decoration: InputDecoration(
          hintText: hint,
          isDense: true,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );

  // ---------------------------------------------------------------- 2. prayed
  void _setRak(int v) {
    if (v <= 0) {
      del(_rk(date));
    } else {
      setI(_rk(date), v);
      if (_st(date) == 0) setI(_k(date, 'st'), 1);
    }
  }

  Future<void> _customRak() async {
    final ctrl = TextEditingController(text: _rak(date) > 0 ? '${_rak(date)}' : '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('رکعات کی تعداد'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(labelText: 'اپنی تعداد (1 تا 40)'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('منسوخ')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('محفوظ کریں')),
        ],
      ),
    );
    final v = int.tryParse(ctrl.text.trim()) ?? 0;
    ctrl.dispose();
    if (ok == true && v > 0) _setRak(clampI(v, 1, 40));
  }

  Widget _rakChip(String text, bool sel, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minWidth: 44),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: sel ? _ok : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: sel ? _ok : Colors.grey.withAlpha(130)),
          ),
          child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: sel ? Colors.white : null)),
        ),
      );

  Widget _fieldCardC(BuildContext c, IconData icon, String label, String value, VoidCallback onTap) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: _deco(c),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
              child: Row(children: [
                Icon(icon, color: _panel, size: 22),
                const SizedBox(width: 4),
                Expanded(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: AlignmentDirectional.centerStart,
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(label, style: TextStyle(fontSize: 10.5, color: subText(c))),
                      Text(value, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );

  Widget _rakChipC(String text, bool sel, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: sel ? _ok : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: sel ? _ok : Colors.grey.withAlpha(130)),
          ),
          child: FittedBox(fit: BoxFit.scaleDown, child: Text(text, style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: sel ? Colors.white : null))),
        ),
      );

  Widget _prayedSection(BuildContext c) {
    final r = _rak(date);
    const std = [2, 4, 6, 8, 10, 12];
    final customSel = r > 0 && !std.contains(r);
    Widget chip(int v) => Expanded(child: _rakChipC('$v', r == v, () => _setRak(r == v ? 0 : v)));

    final dateCol = Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      _fieldCardC(c, Icons.calendar_month, 'تاریخ', _iso(date), _pickDate),
      const SizedBox(height: 6),
      _fieldCardC(c, Icons.alarm, 'اٹھنے کا وقت', _fmtMin(_tm(date, 'wake')), () => _pickTime('wake', 225)),
      const SizedBox(height: 6),
      _fieldCardC(c, Icons.access_time, 'نماز کا وقت', _fmtMin(_tm(date, 'ptime')), () => _pickTime('ptime', 260)),
    ]);

    final midCol = Container(
      padding: const EdgeInsets.all(6),
      decoration: _deco(c),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Row(children: [
          Icon(Icons.format_list_numbered, color: _panel, size: 20),
          SizedBox(width: 4),
          Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text('کتنی رکعتیں پڑھیں؟', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)))),
        ]),
        const SizedBox(height: 6),
        Directionality(
          textDirection: TextDirection.ltr,
          child: Column(children: [
            Row(children: [
              chip(2), const SizedBox(width: 4), chip(4), const SizedBox(width: 4), chip(6), const SizedBox(width: 4), chip(8),
            ]),
            const SizedBox(height: 4),
            Row(children: [
              chip(10), const SizedBox(width: 4), chip(12), const SizedBox(width: 4),
              Expanded(flex: 2, child: _rakChipC(customSel ? '$r رکعت' : 'اپنی تعداد', customSel, _customRak)),
            ]),
          ]),
        ),
        const SizedBox(height: 8),
        _ynCard(c, Icons.menu_book, 'قرآن مجید کی تلاوت؟', getI(_k(date, 'quran')), (v) => _setYN('quran', v)),
      ]),
    );

    final rightCol = Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _ynCard(c, Icons.back_hand, 'دعا اور ذکر؟', getI(_k(date, 'dua')), (v) => _setYN('dua', v)),
      const SizedBox(height: 6),
      Container(
        padding: const EdgeInsets.all(6),
        decoration: _deco(c),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Row(children: [
            Icon(Icons.edit_note, color: _panel, size: 20),
            SizedBox(width: 4),
            Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text('اضافی نوٹس', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)))),
          ]),
          const SizedBox(height: 4),
          _noteField(_noteC, 'اللہ کا شکر، آج تہجد پڑھ لی۔'),
        ]),
      ),
      const SizedBox(height: 6),
      _saveBtn('محفوظ کریں', () {
        FocusScope.of(context).unfocus();
        final t = _noteC.text.trim();
        if (t.isEmpty) {
          del(_k(date, 'note'));
        } else {
          setS(_k(date, 'note'), t);
        }
        if (_st(date) != 1) setI(_k(date, 'st'), 1);
        toast(context, 'تہجد کا ریکارڈ محفوظ ہو گیا');
      }),
    ]);

    return _section(
      c,
      'اگر تہجد پڑھ لی تو نماز کا ریکارڈ',
      Icons.mosque,
      const [Color(0xFF0E5B37), Color(0xFF2E8B57)],
      IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(flex: 37, child: rightCol),
          const SizedBox(width: 6),
          Expanded(flex: 37, child: midCol),
          const SizedBox(width: 6),
          Expanded(flex: 26, child: dateCol),
        ]),
      ),
    );
  }

  // ---------------------------------------------------------------- 3. missed
  Future<void> _pickReason() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(ctx).size.height * 0.7,
          child: Column(children: [
            const Padding(padding: EdgeInsets.all(14), child: Text('نہ اٹھنے کی وجہ منتخب کریں', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
            Expanded(
              child: ListView(children: [
                for (final s in _states.where((e) => e.id >= 3))
                  ListTile(
                    leading: Icon(s.icon, color: _panel),
                    title: Text(s.label, style: const TextStyle(fontSize: 14)),
                    trailing: _st(date) == s.id ? const Icon(Icons.check_circle, color: _ok) : null,
                    onTap: () {
                      Navigator.pop(ctx);
                      _tapState(s);
                    },
                  ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _miniCard(BuildContext c, IconData icon, String label, Widget child, {VoidCallback? onTap}) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: _deco(c),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.all(7),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  Icon(icon, color: _slate, size: 20),
                  const SizedBox(width: 4),
                  Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(label, style: TextStyle(fontSize: 11, color: subText(c))))),
                ]),
                const SizedBox(height: 6),
                child,
              ]),
            ),
          ),
        ),
      );

  Widget _miniValue(String t) => Center(
        child: Text(t, textAlign: TextAlign.center, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, height: 1.4, fontWeight: FontWeight.bold)),
      );

  Widget _miniYN(BuildContext c, IconData icon, String label, String f, {void Function(int)? after}) {
    final v = getI(_k(date, f));
    return _miniCard(
      c,
      icon,
      label,
      Row(children: [
        Expanded(child: _ynBtn('ہاں', v == 1, true, () {
          _setYN(f, v == 1 ? 0 : 1);
          if (after != null) after(v == 1 ? 0 : 1);
        })),
        const SizedBox(width: 4),
        Expanded(child: _ynBtn('نہیں', v == 2, false, () {
          _setYN(f, v == 2 ? 0 : 2);
          if (after != null) after(v == 2 ? 0 : 2);
        })),
      ]),
    );
  }

  Widget _missedSection(BuildContext c) => _section(
        c,
        'اگر تہجد کے لیے نہیں اٹھ سکے',
        Icons.nightlight_round,
        const [Color(0xFF2F5A66), Color(0xFF4E8190)],
        Column(children: [
          IntrinsicHeight(
            child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Expanded(child: _miniCard(c, Icons.access_time, 'سونے کا وقت', _miniValue(_fmtMin(_tm(date, 'sleep'))), onTap: () => _pickTime('sleep', 23 * 60 + 30))),
              const SizedBox(width: 6),
              Expanded(child: _miniCard(c, Icons.hotel, 'نہ اٹھنے کی وجہ', _miniValue(_reasonText(date)), onTap: _pickReason)),
              const SizedBox(width: 6),
              Expanded(child: _miniCard(c, Icons.calendar_month, 'تاریخ', _miniValue(_iso(date)), onTap: _pickDate)),
            ]),
          ),
          const SizedBox(height: 6),
          IntrinsicHeight(
            child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Expanded(
                child: _miniCard(
                  c,
                  Icons.edit_note,
                  'اضافی نوٹس',
                  TextField(
                    controller: _mnoteC,
                    maxLines: 3,
                    minLines: 2,
                    style: const TextStyle(fontSize: 12),
                    decoration: InputDecoration(hintText: 'کل ضرور اٹھوں گا۔', hintStyle: const TextStyle(fontSize: 11), isDense: true, contentPadding: const EdgeInsets.all(6), border: OutlineInputBorder(borderRadius: BorderRadius.circular(8))),
                    onChanged: (t) {
                      if (t.trim().isEmpty) {
                        del(_k(date, 'mnote'));
                      } else {
                        setS(_k(date, 'mnote'), t.trim());
                      }
                    },
                    onSubmitted: (_) => toast(context, 'ریکارڈ محفوظ ہو گیا'),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: _miniYN(c, Icons.notifications_active, 'آئندہ یادہانی', 'remind', after: (v) {
                  if (v == 1) toast(context, 'نیچے "تہجد کی یادہانی" میں الارم کا وقت لگا لیں');
                }),
              ),
              const SizedBox(width: 6),
              Expanded(child: _miniYN(c, Icons.alarm, 'الارم لگایا تھا؟', 'alarm')),
            ]),
          ),
        ]),
      );

  // ---------------------------------------------------------------- monthly report
  Map<String, int> _stats(DateTime d) {
    final last = DateTime(d.year, d.month + 1, 0).day;
    final m = <String, int>{'woke': 0, 'prayed': 0, 'wokeNo': 0, 'sleep': 0, 'lazy': 0, 'busy': 0, 'other': 0, 'rak': 0};
    for (int i = 1; i <= last; i++) {
      final x = DateTime(d.year, d.month, i);
      final s = _st(x);
      if (s == 1 || s == 2) m['woke'] = m['woke']! + 1;
      if (s == 1) m['prayed'] = m['prayed']! + 1;
      if (s == 2) m['wokeNo'] = m['wokeNo']! + 1;
      if (s == 3) m['sleep'] = m['sleep']! + 1;
      if (s == 4) m['lazy'] = m['lazy']! + 1;
      if (s == 5) m['busy'] = m['busy']! + 1;
      if (s >= 6) m['other'] = m['other']! + 1;
      m['rak'] = m['rak']! + _rak(x);
    }
    return m;
  }

  Widget _miniSection(BuildContext c, String title, IconData icon, Widget child) => Container(
        decoration: BoxDecoration(color: cardColor(c), borderRadius: BorderRadius.circular(12), border: Border.all(color: green.withAlpha(70))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [Color(0xFF2F5A66), Color(0xFF4E8190)]),
              borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
            ),
            child: Row(children: [
              Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 5),
              Expanded(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.bold)))),
            ]),
          ),
          Padding(padding: const EdgeInsets.all(6), child: child),
        ]),
      );

  Widget _reportRow(BuildContext c, IconData icon, Color col, String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [
          Icon(icon, color: col, size: 14),
          const SizedBox(width: 4),
          Expanded(child: Text(label, maxLines: 2, style: const TextStyle(fontSize: 9.5, height: 1.25))),
          const SizedBox(width: 2),
          Text(value, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, color: col)),
        ]),
      );

  Widget _report(BuildContext c) {
    final s = _stats(date);
    return _miniSection(
      c,
      'تہجد ماہانہ رپورٹ',
      Icons.bar_chart,
      Column(mainAxisSize: MainAxisSize.min, children: [
        Text('${urduMonths[date.month - 1]} ${date.year}', style: TextStyle(fontSize: 10, color: subText(c))),
        _reportRow(c, Icons.star, _ok, 'تہجد کے لیے اٹھے', '${s['woke']} دن'),
        const Divider(height: 1),
        _reportRow(c, Icons.check_circle, _ok, 'تہجد ادا کی', '${s['prayed']} دن'),
        const Divider(height: 1),
        _reportRow(c, Icons.remove_circle, Colors.orange, 'اٹھے لیکن نماز نہیں پڑھی', '${s['wokeNo']} دن'),
        const Divider(height: 1),
        _reportRow(c, Icons.hotel, _red, 'نیند کی وجہ سے نہیں اٹھ سکے', '${s['sleep']} دن'),
        const Divider(height: 1),
        _reportRow(c, Icons.warning_amber_rounded, _red, 'غفلت یا سستی کی وجہ سے نہیں اٹھ سکے', '${s['lazy']} دن'),
        const Divider(height: 1),
        _reportRow(c, Icons.work, _red, 'کام یا مصروفیت کی وجہ سے نہیں اٹھ سکے', '${s['busy']} دن'),
        const Divider(height: 1),
        _reportRow(c, Icons.more_horiz, _red, 'دیگر وجوہات', '${s['other']} دن'),
        const Divider(height: 1),
        _reportRow(c, Icons.format_list_numbered, _panel, 'کل رکعتیں', '${s['rak']}'),
        const SizedBox(height: 2),
        TextButton(
          onPressed: () => go(c, const ReportScreen()),
          style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2), minimumSize: const Size(0, 28), tapTargetSize: MaterialTapTargetSize.shrinkWrap),
          child: const FittedBox(fit: BoxFit.scaleDown, child: Text('مکمل رپورٹس دیکھیں', style: TextStyle(color: green, fontSize: 11, fontWeight: FontWeight.bold))),
        ),
      ]),
    );
  }

  Widget _bottomRow(BuildContext c) => IntrinsicHeight(
        child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(flex: 28, child: _quote(c)),
          const SizedBox(width: 6),
          Expanded(flex: 32, child: _reminder(c)),
          const SizedBox(width: 6),
          Expanded(flex: 40, child: _report(c)),
        ]),
      );

  // ---------------------------------------------------------------- reminder
  Widget _switchRow(BuildContext c, IconData icon, String label, bool v, ValueChanged<bool> onChange) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Icon(icon, color: _slate, size: 18),
          const SizedBox(width: 4),
          Expanded(child: Text(label, maxLines: 2, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold, height: 1.25))),
          SizedBox(
            width: 38,
            height: 24,
            child: FittedBox(child: Switch(value: v, onChanged: onChange, activeTrackColor: _ok, materialTapTargetSize: MaterialTapTargetSize.shrinkWrap)),
          ),
        ]),
      );

  Widget _reminder(BuildContext c) {
    final on = getB('tj_al_on');
    final daily = getB('tj_daily', true);
    final min = getI('tj_al_min', 210);
    return _miniSection(
      c,
      'تہجد کی یادہانی',
      Icons.lightbulb,
      Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _switchRow(c, Icons.alarm, 'الارم لگائیں', on, (v) => setB('tj_al_on', v)),
        const Divider(height: 8),
        const Row(children: [
          Icon(Icons.access_time, color: _slate, size: 18),
          SizedBox(width: 4),
          Expanded(child: Text('اٹھنے کا وقت', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold))),
        ]),
        const SizedBox(height: 4),
        InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: () async {
            final r = await showTimePicker(context: context, initialTime: TimeOfDay(hour: min ~/ 60, minute: min % 60), cancelText: 'منسوخ', confirmText: 'ٹھیک ہے');
            if (r != null) setI('tj_al_min', r.hour * 60 + r.minute);
          },
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 7),
            alignment: Alignment.center,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.grey.withAlpha(130))),
            child: FittedBox(fit: BoxFit.scaleDown, child: Text(_fmtMin(min), style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold))),
          ),
        ),
        const Divider(height: 10),
        _switchRow(c, Icons.calendar_month, 'روزانہ یادہانی', daily, (v) => setB('tj_daily', v)),
        const SizedBox(height: 6),
        ElevatedButton(
          onPressed: () async {
            if (!on) {
              toast(context, 'سیٹنگز محفوظ ہو گئیں۔ الارم لگانے کے لیے "الارم لگائیں" آن کریں۔');
              return;
            }
            final ok = await _setAndroidAlarm(min, daily);
            if (!mounted) return;
            toast(context, ok ? 'الارم کی سیٹنگ گھڑی ایپ میں کھل گئی، وہاں تصدیق کریں' : 'سیٹنگز محفوظ ہو گئیں، لیکن اس فون پر گھڑی ایپ نہیں کھل سکی');
          },
          style: ElevatedButton.styleFrom(backgroundColor: _ok, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          child: const FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.settings, size: 16),
              SizedBox(width: 4),
              Text('سیٹنگز محفوظ کریں', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
      ]),
    );
  }

  // ---------------------------------------------------------------- quote
  Widget _quote(BuildContext c) => Material(
        color: Colors.transparent,
        child: Ink(
          decoration: _deco(c, color: Color.alphaBlend(gold.withAlpha(30), cardColor(c)), border: gold.withAlpha(120)),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => copyText(c, 'تہجد ایمان کی تازگی ہے اور دل کے سکون کی نماز ہے۔'),
            child: Column(children: [
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
                child: SizedBox(height: 90, width: double.infinity, child: Image.asset('assets/tahajjud/mosque.png', fit: BoxFit.cover)),
              ),
              const Expanded(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(6, 6, 6, 8),
                  child: Center(
                    child: Text('تہجد ایمان کی تازگی ہے اور دل کے سکون کی نماز ہے۔', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, height: 1.8, fontWeight: FontWeight.w600)),
                  ),
                ),
              ),
            ]),
          ),
        ),
      );

  // ---------------------------------------------------------------- bottom nav
  Widget _nav(BuildContext c) {
    const items = <List<dynamic>>[
      [Icons.home, 'ہوم'],
      [Icons.mosque, 'نمازیں'],
      [Icons.bedtime, 'تہجد'],
      [Icons.bar_chart, 'رپورٹس'],
      [Icons.settings, 'سیٹنگز'],
      [Icons.menu, 'مزید'],
    ];
    void act(int i) {
      switch (i) {
        case 0:
          Navigator.of(c).popUntil((r) => r.isFirst);
          break;
        case 1:
          go(c, const PrayersScreen());
          break;
        case 2:
          _toTop();
          break;
        case 3:
          go(c, const ReportScreen());
          break;
        case 4:
          go(c, const SettingsScreen());
          break;
        case 5:
          go(c, MorePage(features: allFeatures()));
          break;
      }
    }

    return Container(
      color: const Color(0xFF0B3D2A),
      padding: EdgeInsets.only(bottom: MediaQuery.of(c).padding.bottom, top: 4),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          for (int i = 0; i < items.length; i++)
            Expanded(
              child: InkWell(
                onTap: () => act(i),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  decoration: i == 2 ? BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFF7CD65B), width: 1.4), color: const Color(0xFF14803F)) : null,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(items[i][0] as IconData, color: i == 2 ? gold : Colors.white, size: 24),
                    const SizedBox(height: 2),
                    FittedBox(fit: BoxFit.scaleDown, child: Text(items[i][1] as String, style: TextStyle(color: i == 2 ? gold : Colors.white, fontSize: 11, fontWeight: FontWeight.bold))),
                  ]),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}
