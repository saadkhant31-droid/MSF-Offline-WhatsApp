package com.msf.msf_nimaz_ki_record

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

class MainActivity : FlutterActivity() {
    private val channel = "msf/wallpaper"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            try {
                handle(call, result)
            } catch (e: Throwable) {
                result.error("wp", e.message ?: "error", null)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun realSize(): IntArray {
        val dm = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    private fun handle(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "sync" -> {
                val ed = getSharedPreferences("msf_wp", MODE_PRIVATE).edit()
                (call.argument<String>("data"))?.let { ed.putString("data", it) }
                (call.argument<Int>("theme"))?.let { ed.putInt("theme", it) }
                (call.argument<Int>("dim"))?.let { ed.putInt("dim", it) }
                (call.argument<Boolean>("sec"))?.let { ed.putBoolean("sec", it) }
                ed.apply()
                result.success(true)
            }
            "deviceSize" -> {
                val s = realSize()
                result.success(listOf(s[0], s[1]))
            }
            "isActive" -> {
                val info = WallpaperManager.getInstance(this).wallpaperInfo
                result.success(info != null && info.packageName == packageName)
            }
            "openLive" -> {
                val comp = ComponentName(this, MsfWallpaperService::class.java)
                try {
                    val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, comp)
                    startActivity(i)
                } catch (e: Throwable) {
                    startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                }
                result.success(true)
            }
            "preview" -> {
                val w = call.argument<Int>("w") ?: 360
                val h = call.argument<Int>("h") ?: 780
                val theme = call.argument<Int>("theme") ?: 0
                val dim = call.argument<Int>("dim")
                Thread {
                    val bytes = try { renderPng(theme, dim, w, h) } catch (e: Throwable) { null }
                    runOnUiThread {
                        if (bytes != null) result.success(bytes) else result.error("wp", "render failed", null)
                    }
                }.start()
            }
            "setStatic" -> {
                val which = call.argument<Int>("which") ?: 3   // 1 home, 2 lock, 3 both
                val theme = call.argument<Int>("theme")
                val s = realSize()
                Thread {
                    var ok = false
                    try {
                        val bmp = renderBitmap(theme, null, s[0], s[1])
                        val wm = WallpaperManager.getInstance(this)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            val flag = when (which) {
                                1 -> WallpaperManager.FLAG_SYSTEM
                                2 -> WallpaperManager.FLAG_LOCK
                                else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                            }
                            wm.setBitmap(bmp, null, true, flag)
                        } else {
                            wm.setBitmap(bmp)
                        }
                        ok = true
                    } catch (e: Throwable) {
                        ok = false
                    }
                    runOnUiThread { result.success(ok) }
                }.start()
            }
            else -> result.notImplemented()
        }
    }

    private fun renderBitmap(theme: Int?, dim: Int?, w: Int, h: Int): Bitmap {
        val r = WpRenderer(this)
        r.reload()
        if (theme != null) r.themeIdx = theme.coerceIn(0, WpThemes.list.size - 1)
        if (dim != null) r.dimIdx = dim.coerceIn(0, WpDims.sizes.size - 1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        r.draw(Canvas(bmp), w, h, System.currentTimeMillis())
        return bmp
    }

    private fun renderPng(theme: Int, dim: Int?, w: Int, h: Int): ByteArray {
        val bmp = renderBitmap(theme, dim, w, h)
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 90, bos)
        bmp.recycle()
        return bos.toByteArray()
    }
}
