#!/usr/bin/env bash
# Run from the project root AFTER `flutter create`. Adds the live wallpaper service + channel.
set -e
SRC=native/android
KDIR=$(dirname "$(find android/app/src/main -name 'MainActivity.*' | head -n1)")
rm -f "$KDIR"/MainActivity.java "$KDIR"/MainActivity.kt
cp $SRC/MainActivity.kt $SRC/MsfWallpaperService.kt $SRC/MsfWallpaperRenderer.kt "$KDIR"/
mkdir -p android/app/src/main/res/xml android/app/src/main/res/values
cp $SRC/msf_wallpaper.xml android/app/src/main/res/xml/msf_wallpaper.xml
cp $SRC/msf_wp_strings.xml android/app/src/main/res/values/msf_wp_strings.xml
python3 - <<'PY'
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
perms = ('<uses-permission android:name="android.permission.SET_WALLPAPER"/>\n'
         '    <uses-feature android:name="android.software.live_wallpaper" android:required="false"/>\n    ')
svc = '''<service android:name="com.msf.msf_nimaz_ki_record.MsfWallpaperService"
            android:label="MSF Nimaz Live"
            android:permission="android.permission.BIND_WALLPAPER"
            android:exported="true">
            <intent-filter>
                <action android:name="android.service.wallpaper.WallpaperService"/>
            </intent-filter>
            <meta-data android:name="android.service.wallpaper" android:resource="@xml/msf_wallpaper"/>
        </service>
    </application>'''
if 'MsfWallpaperService' not in s:
    s = s.replace('<application', perms + '<application', 1)
    s = s.replace('</application>', svc, 1)
open(p, 'w', encoding='utf-8').write(s)
PY
echo "wallpaper patch applied to $KDIR"
