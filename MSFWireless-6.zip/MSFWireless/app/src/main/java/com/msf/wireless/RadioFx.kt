package com.msf.wireless

import kotlin.math.tanh
import kotlin.random.Random

/** Strong two-way radio sound: narrow band, hard clip, crunch, static. */
class RadioFx {
    private var hpIn = 0f
    private var hpOut = 0f
    private var lp1 = 0f
    private var lp2 = 0f

    fun process(buf: ShortArray) {
        val hpA = 0.76f      // ~400 Hz low cut
        val lpA = 0.60f      // ~2 kHz high cut
        for (i in buf.indices) {
            val x = buf[i] / 32768f
            val hp = hpA * (hpOut + x - hpIn)
            hpIn = x
            hpOut = hp
            lp1 += lpA * (hp - lp1)
            lp2 += lpA * (lp1 - lp2)
            var y = tanh(lp2 * 5.5f)                 // heavy drive
            y = Math.round(y * 28f) / 28f            // bit-crush crunch
            y += (Random.nextFloat() - 0.5f) * 0.045f // static hiss
            val v = (y * 0.85f * 32767f).toInt().coerceIn(-32768, 32767)
            buf[i] = v.toShort()
        }
    }

    companion object {
        /** "kshh" squelch burst at start/end of a transmission (~90 ms). */
        fun squelch(): ShortArray {
            val n = 720
            val out = ShortArray(n)
            var lp = 0f
            for (i in 0 until n) {
                val amp = 0.30f * (1f - i / n.toFloat())
                val noise = (Random.nextFloat() - 0.5f) * 2f
                lp += 0.55f * (noise - lp)
                out[i] = (lp * amp * 32767f).toInt().toShort()
            }
            return out
        }
    }
}
